<?php



/**

 * Created by PhpStorm.

 * User: root

 * Date: 12/2/16

 * Time: 10:03 PM

 */

class Groupsmodel extends CI_Model
{

    public function __construct()
    {

        parent::__construct();

    }



    function listgroup($limit = null)
    {

        $this->db->where('status', 0);

        $this->db->where('groupid!=', '1');

        (!$limit == null) ? $this->db->limit($limit['start'], $limit['end']) : "";

        return $this->db->get('group')->result_array();

    }

    function addGroup($data)
    {

        $this->db->insert('group', $data);

    }

    function getGroup($id)
    {

        $this->db->where('groupid', $id);

        $query = $this->db->get('group');

        if ($query->num_rows() > 0) {

            return $query->row();

        } else {

            return '';

        }

    }

    function editGroup($data, $id)
    {

        $this->db->where('groupid', $id);

        $this->db->update('group', $data);

    }

    function listmodule($parent_id = 0, $limit = null)
    {

        $this->db->select('*');

        $this->db->from('admin_menu');

        if ($this->session->userdata('PRJ_USER_GROUP') != 1) {

            $this->db->where('status', '1');

        }

        (!$limit == null) ? $this->db->limit($limit['start'], $limit['end']) : "";

        $res = $this->db->get();

        return $res;

    }

    function getgroupname($group_id)
    {

        $this->db->select('group_name');

        $this->db->where('groupid', $group_id);

        $query = $this->db->from('group');

        $result = $this->db->get();

        $group = $result->row();

        return $group->group_name;

    }

    function listuseraction($limit = null)
    {

        $this->db->select('*');

        $this->db->from('user_actions');

        (!$limit == null) ? $this->db->limit($limit['start'], $limit['end']) : "";

        $res = $this->db->get();

        return $res;

    }

    function checkgroup_permision($module_id, $user_action_id, $group_id)
    {

        $query = "SELECT 

                    fn_CheckGroupPermission(" . $module_id . "," . $user_action_id . "," . $group_id . ")

                  AS permission

                 ";

        $result = $this->db->query($query);

        $permission = $result->row();

        return $permission->permission;

    }

    // function updategroup_permision($permissions, $group_id, $login_id)
    // {
    //     $this->db->trans_start();

    //     $permission_set = '';

    //     if (count($permissions) > 0) {
    //         $permission_set = implode(",", $permissions);
    //     }
    //     // pp($permission_set);
    //     $parameters = array($permission_set, $group_id, $login_id);
    //     // pp($parameters);

    //     if (!$this->db->query('CALL sp_InsertGroupPermission(?,?,?)', $parameters)) {
    //         $error = $this->db->error();
    //         // pp($error); // Print SQL error for debugging
    //     }

    //     $this->db->trans_complete();

    //     if ($this->db->trans_status() === FALSE) {
    //         // Transaction failed
    //         // pp('Transaction Failed');
    //     } else {
    //         // Transaction succeeded
    //         // pp('Transaction Succeeded');
    //     }
    // }
    public function updategroup_permision($permissions, $group_id, $login_id)
    {
        // Start transaction
        $this->db->trans_start();

        // Prepare current date and time
        $current_date = date('Y-m-d H:i:s');

        // Check if $permissions is an array
        if (is_array($permissions)) {
            // pp($permissions);
            // Delete all existing permissions for the group_id
            $this->db->where('group_id', $group_id);
            $this->db->delete('permissions_per_group');

            foreach ($permissions as $permission) {
                // Split the permission string into module_id and user_action_id
                list($module_id, $user_action_id) = explode('_', $permission);

                // Ensure that the split was successful and valid
                if (is_numeric($module_id) && is_numeric($user_action_id)) {
                    // Parameters for the stored procedure
                    $parameters = array(
                        $module_id,
                        $user_action_id,
                        $group_id,
                        $login_id,  // added_by
                        $current_date,  // added_date
                        $login_id,  // modified_by
                        $current_date  // modified_date
                    );

                    // Execute the stored procedure
                    $this->db->query('CALL sp_InsertGroupPermission(?, ?, ?, ?, ?, ?, ?)', $parameters);
                } else {
                    // Handle error: invalid format
                    log_message('error', 'Invalid permission format: ' . $permission);
                }
            }
        } else {
            foreach ($permissions as $permission) {
                // Split the permission string into module_id and user_action_id
                list($module_id, $user_action_id) = explode('_', $permission);

                // Ensure that the split was successful and valid
                if (is_numeric($module_id) && is_numeric($user_action_id)) {
                    // Parameters for the stored procedure
                    $parameters = array(
                        $module_id,
                        $user_action_id,
                        $group_id,
                        $login_id,  // added_by
                        $current_date,  // added_date
                        $login_id,  // modified_by
                        $current_date  // modified_date
                    );

                    // Execute the stored procedure
                    $this->db->query('CALL sp_InsertGroupPermission(?, ?, ?, ?, ?, ?, ?)', $parameters);
                } else {
                    // Handle error: invalid format
                    log_message('error', 'Invalid permission format: ' . $permission);
                }
            }
            // Handle error: $permissions is not an array
            log_message('error', 'Permissions data is not an array: ' . print_r($permissions, true));
        }

        // Complete the transaction
        $this->db->trans_complete();

        // Check transaction status
        if ($this->db->trans_status() === FALSE) {
            // Transaction failed
            return FALSE;
        } else {
            // Transaction succeeded
            return TRUE;
        }
    }

    function getgroupid($user_id)
    {

        $this->db->select('user_group');

        $this->db->where('userid', $user_id);

        $query = $this->db->from('users');

        $result = $this->db->get();

        $group = $result->row();

        return $group->user_group;

    }

    function checkuser_perm($module_id, $user_action_id, $user_id)
    {

        $query = "SELECT 

                    fn_CheckUserPermission(" . $module_id . "," . $user_action_id . "," . $user_id . ")

                  AS permission

                 ";

        $result = $this->db->query($query);

        $permission = $result->row();

        return $permission->permission;

    }

    function updateuser_perm($permissions, $user_id, $login_id)
    {

        $this->db->trans_start();

        $permission_set = '';

        if (count($permissions) > 0) {

            $permission_set = implode(",", $permissions);

        }

        $parameters = array($permission_set, $user_id, $login_id);

        $qry_res = $this->db->query('CALL sp_InsertUserPermission(?,?,?)', $parameters);

        $this->db->trans_complete();

    }

}