<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once FCPATH.'/vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
class Report extends MX_Controller
{	
	public function __construct()
	{
		parent:: __construct();
        $this->load->model('ReportModel');
        $this->load->model('CommonModel');
        if(!$this->authlibrary->IsLoggedIn()){
            $this->session->set_userdata('return_url', current_url());
            redirect('Login');
        }
		$this->container='main';
	}
	public function Index()
	{
        $data['page']           = 'list_report';
        $data['main_topic']     = $this->CommonModel->getData('main_topic');
        $data['sub_topic']      = $this->CommonModel->getData('prakar');
        $data['category']       = $this->CommonModel->getData('category');
        $this->load->view('main', $data);
	}
    
    //serach report
    public function searchReport() {
        if($this->input->is_ajax_request()) {
            $main_topic                     = $this->input->post('main_topic');
            $subtype                        = $this->input->post('subtype');
            $category                       = $this->input->post('category');
            $from_date                      = $this->input->post('from_date');
            $to_date                        = $this->input->post('to_date');
            $data['main_topic']             = !empty($main_topic)?$main_topic:'-';
            $data['subtype']                = !empty($subtype)?$subtype:'-';
            $data['category']               = !empty($category)?$category:'-';
            $data['from_date']              = !empty($from_date)?$from_date:'-';
            $data['to_date']                = !empty($to_date)?$to_date:'-';
            $data['result']                 = $this->ReportModel->getSearchResult($main_topic,$subtype,$category,$from_date,$to_date);
            // pp($data['result']);
            $data_view                      = $this->load->view('search_list', $data, true);
            $response                       = array(
            'status'                        => 'success',
            'data'                          => $data_view
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
        }
    }

    //export
    public function ExportToExcel( $main_topic, $subtype, $category, $from_date, $to_date) {
        $data = $this->ReportModel->getSearchResult($main_topic,$subtype,$category,$from_date,$to_date);
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $rowCount = 2;
        $sheet->setCellValue('A1', 'दर्ता नं');
        $sheet->setCellValue('B1', 'दर्ता मिती');
        $sheet->setCellValue('C1', 'उद्योग, व्यवसायको पुरा नाम (नेपालीमा)');
        $sheet->setCellValue('D1', 'उद्योग, व्यवसायको पुरा नाम (ENGLISH)');
        $sheet->setCellValue('E1', 'उद्योग, व्यवसायको ठेगाना');
        $sheet->setCellValue('F1', 'स्थिर पूजीँ रु');
        $sheet->setCellValue('G1', 'चालु पूजीँ रु');
        $sheet->setCellValue('H1', 'कुल पूजीँ रु');
        $sheet->setCellValue('I1', 'उद्योग, व्यवसायको उद्देश्य');
        $sheet->setCellValue('J1', 'उद्योग, व्यवसायमा लगाउने पूजीँको श्रोत');
        $sheet->setCellValue('K1', 'उद्योग, व्यवसायको शीर्षक');
        $sheet->setCellValue('L1', 'उद्योग, व्यवसायको उप शीर्षक');
        $sheet->setCellValue('M1', 'उद्योग, व्यवसायले कारोवार गर्ने मुख्य चीज वस्तु विवरण');
        $sheet->setCellValue('N1', 'व्यवसायीको पुरा नाम');
        $sheet->setCellValue('O1', 'ना.प्र.प.नं.');
        $sheet->setCellValue('P1', 'जारी जिल्ला');
        $sheet->setCellValue('Q1', 'जारी मिति');
        $sheet->setCellValue('R1', 'स्थायी ठेगाना');
        $sheet->setCellValue('S1', 'बाजेको नाम');
        $sheet->setCellValue('T1', 'बावुको नाम');
        $sheet->setCellValue('U1', 'घर / जग्गा धनिको नाम');
        $sheet->setCellValue('V1', 'ठेगाना');
        $sheet->setCellValue('W1', 'मासिक भाडा रकम');
        foreach ($data as $element) {
            $sheet->setCellValue('A' . $rowCount, $element['darta_no']);
            $sheet->setCellValue('B' . $rowCount, $element['darta_miti']);
            $sheet->setCellValue('C' . $rowCount, $element['business_name_np']);
            $sheet->setCellValue('D' . $rowCount, $element['business_name_en']);
            $sheet->setCellValue('E' . $rowCount, $element['bgname'].'-'.$element['b_ward'].','.$element['dis_name'].','.$element['Title']);
            $sheet->setCellValue('F' . $rowCount, $element['fixed_capital']);
            $sheet->setCellValue('G' . $rowCount, $element['chalu_capital']);
            $sheet->setCellValue('H' . $rowCount, $element['b_captial']);
            $sheet->setCellValue('I' . $rowCount, $element['b_aim']);
            $sheet->setCellValue('J' . $rowCount, $element['topic_name']);
            $sheet->setCellValue('K' . $rowCount, $element['sub_topic']);
            $sheet->setCellValue('L' . $rowCount, $element['b_workdetails']);
            $sheet->setCellValue('M' . $rowCount, $element['b_owner_name']);
            $sheet->setCellValue('N' . $rowCount, $element['b_ctzn_no']);
            $sheet->setCellValue('O' . $rowCount, $element['b_ctzn_district']);
            $sheet->setCellValue('P' . $rowCount, $element['b_ctzn_date	']);
            $sheet->setCellValue('Q' . $rowCount, $element['pg_name'].'-'.$element['p_ward'].','.$element['pdis'].','.$element['p_pradesh']);
            $sheet->setCellValue('R' . $rowCount, $element['tgapa'].'-'.$element['t_ward'].','.$element['tdis'].','.$element['t_pradesh']);
            $sheet->setCellValue('S' . $rowCount, $element['grandfather_name']);
            $sheet->setCellValue('T' . $rowCount, $element['father_name']);
            $sheet->setCellValue('U' . $rowCount, $element['landlord']);
            $sheet->setCellValue('V' . $rowCount, $element['landlord_address']);
            $sheet->setCellValue('W' . $rowCount, $element['rent']);
            $rowCount++;
        }
        $writer = new Xlsx($spreadsheet);
        $filename = 'darta_wiwaran';
        $spreadsheet->getActiveSheet()->setTitle($filename); //set a title for Worksheet
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
        header('Cache-Control: max-age=0');
        $writer->save('php://output'); // download file
    }
}