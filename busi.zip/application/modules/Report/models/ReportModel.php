<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ReportModel extends CI_Model
{
	public function __construct()
	{
		parent:: __construct();
        $this->fy = current_fiscal_year();
	}
	
	//search report
	public function getSearchResult($main_topic = null,$subtype = null, $category = null,$from_date = null,$to_date = null) {
		$this->db->select('t1.*, t2.topic_name, t3.Title,t4.Title as p_pradesh,t5.Title as t_pradesh,t6.name as dis_name,t7.name as pdis,t8.name as tdis,t9.name as bgname,t10.name as pg_name, t11.name as tgapa, t12.sub_topic')->from('darta t1');
		$this->db->join('main_topic t2','t2.id = t1.b_type','left');
		//business address
		$this->db->join('provinces t3', 't3.id = t1.b_pradesh','left');
		$this->db->join('provinces t4', 't4.id = t1.p_pradesh','left');
		$this->db->join('provinces t5', 't5.id = t1.t_pradesh','left');

		$this->db->join('settings_district t6', 't6.id = t1.b_district','left');
		$this->db->join('settings_district t7', 't7.id = t1.p_district','left');
		$this->db->join('settings_district t8', 't8.id = t1.t_district','left');

		$this->db->join('settings_vdc_municipality t9',  't9.id 	 = t1.b_gapa','left');
		$this->db->join('settings_vdc_municipality t10', 't10.id = t1.p_gapa','left');
		$this->db->join('settings_vdc_municipality t11', 't11.id = t1.t_gapa','left');
		$this->db->join('prakar t12', 't12.id 	= t1.b_subtype','left');


		if(!empty($main_topic) && $main_topic !='-') {
			$this->db->where('t1.b_type',$main_topic);
		}
		if(!empty($subtype) && $subtype != '-') {
			$this->db->where('t1.b_subtype',$subtype);
		}
		if(!empty($category) && $category != '-') {
			$this->db->where('t1.category',$category);
		}
		if(!empty($from_date) && $from_date != '-') {
			$this->db->where('t1.darta_miti >=',$from_date);
		}
		if(!empty($to_date) && $to_date != '-') {
			$this->db->where('t1.darta_miti <=', $to_date);
		}
		$query = $this->db->get();
		return $query->result_array();
	}
	
}