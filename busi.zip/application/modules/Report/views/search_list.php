<?php
//pp($result);
//if(!empty($result)): ?>
<div class="table-responsive">
    <a href="<?php echo base_url()?>Report/ExportToExcel/<?php echo $main_topic?>/<?php echo $subtype?>/<?php echo $category?>/<?php echo $from_date?>/<?php echo $to_date?>" class="btn btn-info" title ="एक्सलमा एक्सपोर्ट गर्नुहोस्" alt ="एक्सलमा एक्सपोर्ट गर्नुहोस्"><i class="fa fa-cloud-download" aria-hidden="true"></i> Export</a>
    <table class="table">
        <thead>
            <tr>
                <th>क्र.स.</th>
                <th>दर्ता नं</th>
                <th>दर्ता मिती</th>
                <th>उद्योग, व्यवसायको पुरा नाम (नेपालीमा) </th>
                <th>उद्योग, व्यवसायको पुरा नाम (ENGLISH)</th>
                <th>उद्योग, व्यवसायको ठेगाना</th>
                <th>स्थिर पूजीँ रु </th>
                <th>चालु पूजीँ रु</th>
                <th>कुल पूजीँ रु</th>
                <th>उद्योग, व्यवसायको उद्देश्य</th>
                <th>उद्योग, व्यवसायको शीर्षक</th>
                <th>उद्योग, व्यवसायको उप शीर्षक</th>
                <th>व्यवसायको वर्ग</th>
                <th>उद्योग, व्यवसायमा लगाउने पूजीँको श्रोत </th>
                <th>उद्योग, व्यवसायले कारोवार गर्ने मुख्य चीज वस्तु विवरण </th>
                <th>व्यवसायीको पुरा नाम</th>
                <th>ना.प्र.प.नं.</th>
                <th>जारी जिल्ला</th>
                <th>जारी मिति</th>
                <th>स्थायी ठेगाना</th>
                <th>अस्थायी ठेगाना</th>
                <th>बाजेको नाम</th>
                <th>बावुको नाम</th>
                <th>घर / जग्गा धनिको नाम</th>
                <th>ठेगाना</th>
                <th>मासिक भाडा रकम</th>
            </tr>
        </thead>
        <tbody>
            <?php $i=1;if(!empty($result)) : foreach($result as $data) : ?>
                <tr>
                    <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['darta_no'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['darta_miti'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['business_name_np'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['business_name_en'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['bgname']).'-'.$this->mylibrary->convertedcit($data['b_ward'].','.$data['dis_name'].','.$data['Title'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['fixed_capital'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['chalu_capital'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['b_capital'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['b_aim'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['topic_name'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['sub_topic'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['category'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['b_capital_source'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['b_workdetails'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['b_owner_name'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['b_ctzn_no'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['b_ctzn_district'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['b_ctzn_date'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['pg_name']).'-'.$this->mylibrary->convertedcit($data['p_ward'].','.$data['pdis'].','.$data['p_pradesh'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['tgapa']).'-'.$this->mylibrary->convertedcit($data['t_ward'].','.$data['tdis'].','.$data['t_pradesh'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['grandfather_name'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['father_name'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['landlord'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['landlord_address'])?></td>
                    <td><?php echo $this->mylibrary->convertedcit($data['rent'])?></td>
                </tr>
            <?php endforeach;endif;?>
        </tbody>
    </table>
</div>
<?php else : ?>
    <div class="alert alert-danger">no records found in database !!!</div>
<?php endif;?>