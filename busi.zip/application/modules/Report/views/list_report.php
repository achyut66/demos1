<!--main content start-->
<section id="main-content">
    <section class="wrapper site-min-height">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo base_url()?>"><i class="fa fa-home"></i> ड्यासबोर्डमा जानुहोस</a></li>
            <li class="breadcrumb-item active">रिपोर्ट</li>
        </ol>
      </nav>
        <!-- page start-->
        <div class="row">
          <div class="col-sm-12">
            <section class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-2">
                            <select class="form-control" id="main_topic">
                                <option value="">शिर्षक छानुहोस</option>
                                <?php if(!empty($main_topic)): foreach($main_topic as $type): ?>
                                <option value="<?php echo $type['id']?>"><?php echo $type['topic_name']?></option>
                                <?php endforeach;endif;?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select class="form-control" id="subtype">
                                <option value="">सह शिर्षक छानुहोस</option>
                                <?php if(!empty($sub_topic)): foreach($sub_topic as $stype): ?>
                                <option value="<?php echo $stype['id']?>"><?php echo $stype['sub_topic']?></option>
                                <?php endforeach;endif;?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select class="form-control" id="category">
                                <option value="">वर्ग छानुहोस</option>
                                <?php if(!empty($category)): foreach($category as $ct): ?>
                                <option value="<?php echo $ct['category']?>"><?php echo $ct['category']?></option>
                                <?php endforeach;endif;?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <div class="input-group">
                                <input type="text" name="date" class="form-control date" value="" placeholder="देखि मिति " autocomplete="off" id="from_date">
                                <div class="input-group-prepend">
                                <button type="button" class="input-group-text btn btn-secondary" title=""><i class="fa fa-calendar" style="color:##6c757d;background: radial-gradient(#ffffff, transparent);"></i></button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="input-group">
                                <input type="text" name="date" class="form-control date" value="" placeholder="सम्म मिति " autocomplete="off" id="to_date">
                                <div class="input-group-prepend">
                                <button type="button" class="input-group-text btn btn-secondary" title=""><i class="fa fa-calendar" style="color:##6c757d;background: radial-gradient(#ffffff, transparent);"></i></button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <button type="button" class="btn btn-warning" title="खोजी गर्नुहोस्" id="filter_btn"><i class="fa fa-search"></i> खोज्नुहोस</button>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="card-body">
                    <div class="data-row">
                        <div class="alert alert-info"><h1>रिपोर्ट खोज्नुहोस</h1></div>
                    </div>
                </div>
            </section>
          </div>
        </div>
        <!-- page end-->
    </section>
</section>
<script type="text/javascript" src="<?php echo base_url()?>assets/nepali_datepicker/nepali.datepicker.v2.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $('.date').nepaliDatePicker();
    $('#main_topic').change(function() {
      obj = $(this);
      var type = obj.val();
      $.ajax({
        url:base_url+'CommonController/subtype',
        method:"POST",
        data:{type:type,'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'},
        success : function(resp){
          if(resp.status == 'success') {
            $('#subtype').html(resp.option);
          }
        }
      });
    });
    //search report
    $('#filter_btn').click(function() {
      obj = $(this);
      var main_topic    = $('#main_topic').val();
      var subtype       = $('#subtype').val();
      var category      = $('#category').val();
      var from_date     = $('#from_date').val();
      var to_date       = $('#to_date').val();
      $.ajax({
        url:base_url+'Report/searchReport',
        method:"POST",
        data:{main_topic:main_topic,subtype:subtype,category:category,from_date:from_date,to_date:to_date,'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'},
        success : function(resp){
          if(resp.status == 'success') {
            $('.data-row').html(resp.data);
          }
        }
      });
    })
  });
</script>
