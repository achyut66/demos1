<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>

  <style>
    .title {
      height: 45px;
      width: 485px;
      border: 1px solid #555;
      margin-left: 590px;
      border-radius: 25px;
      text-align: center;
      /* border-radius: 25px; */
      margin-top: 30px;
    }

    /*.stamp {*/
    /* border: 2px solid #555; */
    /* height: 62px;
    width: 202px;
     */
    /*  margin-left: 487px;*/
    /*  border-radius: 5px;*/
    /*  text-align:right;*/
    /*  margin-right:120px;*/
    /*  margin-top: 50px;*/
    /*}*/
    @page {
      size: landscape;
    }

    /* body { 
        writing-mode: tb-l;
    } */
  </style>
</head>

<body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle" style="margin-right:85px;">
          <h3 class=""><?php echo GNAME ?> </h3>
          <h4><?php echo SLOGAN ?></h4>
          <h6 style="margin-top:-10px;"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6 style="margin-top:-5px;"><?php echo STATENAME ?>,नेपाल</h6>

        </div>
        <div class="header-right">
          <div class="">

          </div>
        </div>
      </div>
      <div class="sub-header" style="margin-left:-400px;font-size:26px;margin-top:3px;">
        <div class="title">
          <p><b>मेलमिलाप कर्ताको प्रमाणपत्र</b></p>
        </div>
        <div class="text">
          <p style="font-size:18px;margin-top:-130px;margin-left:1105px;">दर्ता मिति:
            <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?>
          </p>
        </div>
      </div>
      <?php //pp($row['applicant_name']); ?>
      <div>
        <div style="margin-left:80px; margin-top:85px; margin-right:25px;">
          <p style="font-size:22px;">श्री <?php echo $row['name'] ?><br>
            <?php echo $row['gapa_napa'] ?>-
            <?php echo $this->mylibrary->convertedcit($row['ward_no']) ?>,<?php echo $this->mylibrary->convertedcit($row['district']) ?>
            । </p>
          <p style="font-size:22px;text-align:justify">यस गाउँपालिकाको न्यायिक समितिको मिति
            <b><?php echo $this->mylibrary->convertedcit($row['n_date']) ?></b> को बैठक नं
            <b><?php echo $this->mylibrary->convertedcit($row['meeting_no']) ?></b> को निर्णय नं
            <b><?php echo $this->mylibrary->convertedcit($row['desicion_no']) ?></b> अनुसार तपाईलाई मेलमिलाप सम्वन्धि
            कार्य गर्न मेलमिलाप सम्वन्धि कार्यविधि, <?php echo $row['bidi'] ?> बमोजिम यो प्रमाण पत्र प्रदान गरिएको छ ।
          </p>
        </div>

        <div style="margin-top:120px; text-align:right;margin-right:120px;">

          <p style="font-size:16px"><?php echo $checker['name'] ?></p>
          <p style="font-size:16px;margin-top:-15px;margin-left:-20px;"><?php echo $checker['designation'] ?></p>
        </div>

      </div>
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
  // $(document).ready(function(){
  //     $('#printme').on("click", function () {
  //         $('.hideme').hide();
  window.print();
  //     });
  // });
</script>

</html>