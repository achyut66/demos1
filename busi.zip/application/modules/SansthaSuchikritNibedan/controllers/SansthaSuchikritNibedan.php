<?php

/**
 * Created by PhpStorm.
 * User: root
 * Date: 12/2/16
 * Time: 9:57 PM
 */
class SansthaSuchikritNibedan extends MX_Controller
{
    public function __construct()
    {-
        parent::__construct();
        $this->load->model("CommonModel");
        //$this->load->model("SansthaSUchikritNibedan");
        $this->module_code = 'SANSTHASUCHIKRITNIBEDAN';
        if (!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login', 'location');
        }
    }
    public function Index()
    {
        //   if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $data['page']   = 'list_all';
            $data['sanstha'] = $this->CommonModel->getData('sanstha_suchikrit_nibedan');
            // pp($data);
            $this->load->view('main', $data);
    }
    public function getdata(){
        $result = $this->db->get('sanstha_suchikrit_nibedan')->result();
        $data   =  array();
        $i=1;
        foreach($result as $val)
        {
            $data[] = array(
                $i,
                $val-> nibedan_content,
            );
            $i++;
            
        }
        $output = array(
            "data" => $data);
            echo Json_encode($output);
    }
    public function add()
    {
        $data['page']           = 'add';
        $this->load->view('main', $data);
    }
    public function save()
    {
        if ($this->input->post('Submit')) {
            // $subject                       = $this->input->post('subject');
            $nibedan_content                    = $this->input->post('nibedan_content');
            $save_array                     = array(
                // 'subject'                      => $subject,
                'nibedan_content'               => $nibedan_content,
            );
            $result = $this->CommonModel->insertData('sanstha_suchikrit_nibedan', $save_array);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'सफलता पुर्बक सम्मिलित गरियो ');
                redirect('SansthaSuchikritNibedan/viewDetails/' . $result);
            }
        }
    }
    //view details
    public function viewDetails($id = NULL)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row']            = $this->CommonModel->getDataByID('sanstha_suchikrit_nibedan', $id);
            $data['page']           = 'view_details';
            $this->load->view('main', $data);
        }
    }
    public function edit($id)
    {
        $data['page']           = 'edit';
        $data['row']            = $this->CommonModel->getDataById('sanstha_suchikrit_nibedan', $id);
        $this->load->view('main', $data);
        //pp($data['row']);
    }
    public function update()
    {
        if ($this->input->post('Submit')) {
            $subject                       = $this->input->post('subject');
            $nibedan_content                    = $this->input->post('nibedan_content');
            $save_array                     = array(
                // 'subject'                      => $subject,
                'nibedan_content'               => $nibedan_content,
            );
            $result = $this->CommonModel->insertData('sanstha_suchikrit_nibedan', $save_array);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'सफलता पुर्बक सम्मिलित गरियो ');
                redirect('SansthaSuchikritNibedan/viewDetails/' . $result);
            }
        }
    }

    public function PrintNibedan($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row']            = $this->CommonModel->getDataById('sanstha_suchikrit_nibedan', $id);
            $data['page']           = 'PrintNibedan';
            //$data['staffs']         = $this->CommonModel->getData('staff');
            //$data['maker']          = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $this->load->view('PrintNibedan', $data);
        }
    }

}
?>