<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script> -->
  <title><?php echo GNAME ?></title>

  <style>
  .title {
    height: 45px;
    width: 485px;
    /* border: 1px solid #555; */
    margin-left: 139px;
    border-radius: 25px;
    text-align:center;
    /* border-radius: 25px; */
    margin-top: 60px;
  }
  .nagarpalika_title {
    height: 45px;
    width: 485px;
    /* border: 1px solid #555; */
    margin-left: 114px;
    text-align:center;
    /* border-radius: 25px; */
    margin-top: 60px;
  }
  element.style {
    margin-left: 4px;
    font-size: 26px;
    margin-top: 3px;
}

  .stamp {
    /* border: 2px solid #555; */
    /* height: 62px;
    width: 202px;
     */
    margin-left: 487px;
    border-radius: 5px;
    text-align:right;
    margin-right:120px;
    margin-top: 50px;
  }
  @page { 
        size: landscape;
  }
  div.a {
  text-indent: 80%;
}
td {
  height: 50px;
}
  </style>
</head>
<!-- yema darta ko data lai rakhnu content sahit -->
<body>
  <div class="main-wrapper">
    <div class="wrapper">
  <div class="page">
      <div class="header">
        
    
        <!-- <div class="header-middle">

          <h3 class=""><?php echo GNAME ?> </h3>
          <h4><?php echo SLOGAN ?></h4>
          <h6 style="margin-top:-10px;"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6 style="margin-top:-5px;"><?php echo STATENAME ?>,नेपाल</h6>
        </div>
        <div class="header-right"> -->
          <!-- <div class="photo">
            <span>Photo</span>
          </div> -->
        </div>
      </div>
      <!-- <div class="sub-header">
        <div class="title">
          <p style="margin-left:7px;font-size:26px;margin-top:3px;"> बिषय :<?php echo $this->mylibrary->convertedcit($row['subject']) ?>
</</b></p> -->
        </div>
        <div style="text-align:justify;margin-right:12px; margin-top: 20px;">
        <?php echo $this->mylibrary->convertedcit($row['nibedan_content']) ?>
</div>
      </div>
      <br>
        </div>
      </div>
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<!-- yaha samma darta ko content aaune bhayo  -->

<!-- suchikrit ho bahne content rakhnu -->
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
window.print();
</script>
</html>