<style>
.table-bordered td,
.table-bordered th {
  border: 1px solid #3a5d7f;
}
 </style>
 <section id="main-content">
   <section class="wrapper site-min-height">
     <nav aria-label="breadcrumb">
       <ol class="breadcrumb">
         <li class="breadcrumb-item"><a href="<?php echo base_url()?>"><i class="fa fa-home"></i> ड्यासबोर्डमा</a></li>
         <li class="breadcrumb-item active"><a href="<?php echo base_url()?>Register" class="bactive">उद्योग र व्यवसाय
             दर्ता अभिलेख </a></li>
         <li class="breadcrumb-item active"><a href="javascript:;" class="bactive">विवरण हेर्नुहोस</a></li>
       </ol>
     </nav>
     <div class="row">
       <aside class="profile-info col-lg-9">
         <section class="card">
           <header class="card-header text-light " style="background-color:#4d5886">निबेदन पत्र विवरण  <span> 
           </header>
           <div class="card-body">
             <div class="row">
               <div class="col-md-12">
                 <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
                                    if(!empty($success_message)) { ?>
                 <div class="alert alert-success">
                   <button class="close" data-close="alert"></button>
                   <span> <?php echo $success_message;?> </span>
                 </div>
                 <?php } ?>

                 <?php $err_message = $this->session->flashdata("MSG_ERR");
                                    if(!empty($err_message)) { ?>
                 <div class="alert alert-danger">
                   <button class="close" data-close="alert"></button>
                   <span> <?php echo $err_message;?> </span>
                 </div>
                 <?php } ?>
              <table class="table table-bordered">
                   <tr>
                     <td><strong><span>बिषय :</span>
                         <hr><?php echo $this->mylibrary->convertedcit($row['subject'])?>
                       </strong></td>
                    </tr>
                    <tr>
                     <td><strong><span>निबेदन को कन्टेन्ट: </span> <?php echo $row['nibedan_content']?>
                        </td>
                    </tr>
               </table>
        </section>
      </aside>
      <aside class="profile-nav col-lg-3">
         <section class="card">
           <ul class="nav nav-pills nav-stacked">
             <li class="active nav-item"><a class="nav-link"
                 href="<?php echo base_url()?>SansthaSuchikritNibedan/edit/<?php echo $row['id']?>"> <i class="fa fa-pencil"></i> विवरण
                 सम्पादन गर्नुहोस्</a></li>
                 <li class="nav-item"><a class="nav-link" href="<?php echo base_url() ?>SansthaSuchikritNibedan/PrintNibedan/<?php echo $row['id']?>" target="_blank"> <i class="fa fa-print"></i>निवेदन प्रिन्ट गर्नुहोस् </a></li>
           </ul>
         </section>
       </aside>
    </div>                                  
</div>