<style type="text/css">
  .card-header{
    background: #1b5693;
  }
</style>
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo base_url()?>"> ड्यासबोर्डमा</a></li>
          <li class="breadcrumb-item"><a href="<?php echo base_url()?>SansthaSuchikritNibedan/printNibedan">निबेदन पत्र हेर्नुहोस   </a></li>
          <li class="breadcrumb-item"><a href="javascript:;">नयाँ थप्नुहोस्</a></li>
      </ol>
    </nav>
    <a href="<?php echo base_url() ?>SansthaSuchikritNibedan" class="btn btn-sm btn-success">
              <i class="fa fa-plus"> सुचिमा जानुहोस </i>
            </a>
    <form class="form" method="post" action="<?php echo base_url()?>SansthaSuchikritNibedan/save" enctype ="multipart/form-data">
      <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
      <div class="row">
        <div class="col-sm-12">
           <?php $ERR_VALIDATION = $this->session->flashdata("ERR_VALIDATION");
              if(!empty($ERR_VALIDATION)) { ?>
              <div class="alert alert-danger">
                  <button class="close" data-close="alert"></button>
                  <span> <?php echo $ERR_VALIDATION;?> </span>
              </div>
            <?php } ?>
          <?php $success_message = $this->session->flashdata("MSG_EMP");
              if(!empty($success_message)) { ?>
              <div class="alert alert-success">
                  <button class="close" data-close="alert"></button>
                  <span> <?php echo $success_message;?> </span>
              </div>
            <?php } ?>

             <?php $ERR_UPLOAD = $this->session->flashdata("ERR_UPLOAD");
              if(!empty($ERR_UPLOAD)) { ?>
              <div class="alert alert-success">
                  <button class="close" data-close="alert"></button>
                  <span> <?php echo $ERR_UPLOAD;?> </span>
              </div>
            <?php } ?>
          <section class="card">
            <header class="card-header text-light "> निबेदन पत्र विवरण दाखिला गर्नुहोस</header>
            <div class="card-body">
                <div class="row">
                <!-- <div class="col-md-4">
                    <div class="form-group">
                      <label><b>बिषय  राख्नुहोस </b><span style="color: red">*</span></label>
                      <input type="text" class="form-control" placeholder=""  name="subject" value="" >
                    </div>
                  </div>
              </div> -->
              <div class="col-md-12">
                    <div class="form-group">
                      <label><b>निबेदन को कन्टेन्ट  राख्नुहोस  </b><span style="color: red">*</span></label>
                      <textarea  id="editor1"name=" nibedan_content"></textarea>
                      <!-- <textarea type="text" class="form-control darta_no" placeholder=""  name="subject" value="" rows="5" cols="60"> </textarea> -->
                    </div>
                  </div>
              </div>
              <div class="col-md-12 text-center">
          <hr>
          <button class="btn btn-primary btn-xs btn-save save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्" name="Submit" type="submit" value="Submit" id="btn_save_details"> सेभ गर्नुहोस्</button>
          <a href="<?php echo base_url()?>SansthaSuchikritNibedan" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
        </div>
      </div>
              </div>
              </section>
              </form>
              <script src="https://cdn.ckeditor.com/4.21.0/standard/ckeditor.js"></script>
              <script>
                        CKEDITOR.replace( 'editor1' );
                </script>