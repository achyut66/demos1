<?php

/**
 * Created by PhpStorm.
 */
class IjajatPatra extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->load->model("IjajatapartaModel");
        $this->module_code = 'IJAJATA-PATRA';
        if (!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login', 'location');
        }
    }

    /** 
     * This function load add buy or sell form
     * @param NULL
     * return load view with list
     */
    public function Index()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $data['page']   = 'list_all';
            $data['kirshisamuha'] = $this->CommonModel->getData('krishi_samuha_darta');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
     * This function load add buy or sell form
     * @param NULL
     * return view
     */
    public function add()
    {
        $data['page']           = 'add';
        $data['wards']          = $this->CommonModel->getData('settings_ward', 'DESC');
        $data['districts']      = $this->CommonModel->getData('settings_district', 'DESC');
        $data['pradesh']        = $this->CommonModel->getData('provinces', 'DESC');
        $data['prakar']         = $this->CommonModel->getData('main_topic');
        $data['category']       = $this->CommonModel->getData('category');
         $data['fiscal_year']    = $this->CommonModel->getData('fiscal_year');
        $data['gapana']         = $this->CommonModel->getData('settings_vdc_municipality', 'DESC');
        $darta                  = $this->IjajatapartaModel->GetMaxDartaID();
        $data['darta_no']       = $darta->darta_no + 1;
        $data['category']       = $this->CommonModel->getData('category');
        $this->load->view('main', $data);
    }
    /**
     * save form submitted into database
     * @param $_POST $save
     * @return void
     */
    public function save()
    {
        if ($this->input->post('Submit')) {
            $darta_no                       = $this->input->post('darta_no');
            $certificate_no                 = $this->input->post('certificate_no');
            $name                           = $this->input->post('org_name');
            $samuha_type                    = $this->input->post('samuha_type');
            $p_pardesh                      = $this->input->post('p_pardesh');
            $p_district                     = $this->input->post('p_district');
            $p_gapa                         = $this->input->post('p_gapa');
            $p_ward                         = $this->input->post('p_ward');
            $tol                            = $this->input->post('tol');
            $contact_no                     = $this->input->post('contact_no');
            $email                          = $this->input->post('email');
            $firm_type                      = $this->input->post('firm_type');
            $contact_person                 = $this->input->post('contact_person');
            $contact_address                = $this->input->post('contact_address');
            $c_number                       = $this->input->post('c_number');
            $c_email                        = $this->input->post('c_email');
            $org_darta_no                   = $this->input->post('org_darta_no');
            $org_darta_miti                 = $this->input->post('org_darta_miti');
            $a_capital                      = $this->input->post('a_capital');
            $c_capital                      = $this->input->post('c_capital');
            $warga                          = $this->input->post('warga');
            $samuha                         = $this->input->post('samuha');
            $s_amount                       = $this->input->post('s_amount');
            $s_bank                         = $this->input->post('s_bank');
            $m_amount                       = $this->input->post('m_amount');
            $m_bank                         = $this->input->post('m_bank');
            $c_amount                       = $this->input->post('c_amount');
            $c_bank                         = $this->input->post('c_bank');
            $b_amount                       = $this->input->post('b_amount');
            $b_bank                         = $this->input->post('b_bank');

            //आफ्नो स्वामित्वमा रहेको निर्माण सम्बन्धी सवारी साधन मेशिनरी औजारको विवरणः
            $device_name                    = $this->input->post('device_name');
            $device_no                      = $this->input->post('device_no');
            $device_capacity                = $this->input->post('device_capacity');
            $device_amount                  = $this->input->post('device_amount');
            $device_date                    = $this->input->post('device_date');
            $other_detail                   = $this->input->post('other_detail');

            //यस अघि सम्पन्न गरेको कामको विवरणः
            $pre_work                       = $this->input->post('pre_work');
            $per_work_year                  = $this->input->post('per_work_year');
            $work_amount                    = $this->input->post('work_amount');
            $work_office                    = $this->input->post('work_office');
            $work_status                    = $this->input->post('work_status');

            $save_array                     = array(
                'name'                      => $name,
                'darta_no'                  => $darta_no,
                'darta_miti'                => convertDate(date('Y-m-d')),
                'p_pradesh'                 => $p_pardesh,
                'p_district'                => $p_district,
                'p_gapa'                    => $p_gapa,
                'p_ward'                    => $p_ward,
                'tol'                       => $tol,
                'contact_no'                => $contact_no,
                'email'                     => $email,
                'firm_type'                 => $firm_type,
                'contact_person'            => $contact_person,
                'contact_address'           => $contact_address,
                'c_number'                  => $c_number,
                'c_email'                   => $c_email,
                'org_darta_no'              => $org_darta_no,
                'org_darta_miti'            => $org_darta_miti,
                'a_capital'                 => $a_capital,
                'c_capital'                 => $c_capital,
                'warga'                     => $warga,
                'samuha'                    => $samuha,
                's_amount'                  => $s_amount,
                's_bank'                    => $s_bank,
                'm_amount'                  => $m_amount,
                'm_bank'                    => $m_bank,
                'c_amount'                  => $c_amount,
                'c_bank'                    => $c_bank,
                'b_amount'                  => $b_amount,
                'b_bank'                    => $b_bank,
                'fiscal_year'               => current_fiscal_year(),
                'status'                    => 1,
                'created_at'                => convertDate(date('Y-m-d')),
                'created_by'                => $this->session->userdata('PRJ_USER_BID'),
            );
            $result = $this->CommonModel->insertData('ijajat_patra', $save_array);
            if ($result) {
                $device = array();
                $pre_works = array();
                if (!empty($device_name)) {
                    foreach ($device_name as $key   => $index) {
                        $device[] = array(
                            'device_name'           => $device_name[$key],
                            'device_no'             => $device_no[$key],
                            'device_capacity'       => $device_capacity[$key],
                            'device_amount'         => $device_amount[$key],
                            'device_date'           => $device_date[$key],
                            'other_detail'          => $other_detail[$key],
                            'darta_no'              => $darta_no,
                            'trans_id'              => $result,
                        );
                    }
                    $this->CommonModel->batchInsert($device, 'device_details');
                }
                if (!empty($pre_work)) {
                    foreach ($pre_work as $key   => $index) {
                        $pre_works[] = array(
                            'pre_work'              => $pre_work[$key],
                            'per_work_year'         => $per_work_year[$key],
                            'work_amount'           => $work_amount[$key],
                            'work_office'           => $work_office[$key],
                            'work_status'           => $work_status[$key],
                            'darta_no'              => $darta_no,
                            'trans_id'              => $result,
                        );
                    }
                    $this->CommonModel->batchInsert($pre_works, 'previouis_work_details');
                }

                // if ($child) {
                $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                redirect('IjajatPatra/viewDetails/' . $result);
                // } else {
                //     $this->CommonModel->deleteData('krishi_samuha_darta', $result);
                //     $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                //     redirect('IjajatPatra/Add');
                // }
            }
        }
    }
    //view details
    public function viewDetails($id)
    {
        if (empty($id)) {
            show_404();
        } else {
            $data['row']                    = $this->CommonModel->getDataByID('ijajat_patra', $id);
            $data['device_details']         = $this->CommonModel->getWhereAll('device_details', array('trans_id' => $id));
            $data['workdetails']            = $this->CommonModel->getWhereAll('previouis_work_details', array('trans_id' => $id));
            $data['page']                   = 'view_details';
            $this->load->view('main', $data);
        }
    }
    public function edit($id)
    {
        $data['page']                   = 'edit';
        $data['wards']                  = $this->CommonModel->getData('settings_ward', 'DESC');
        $data['districts']              = $this->CommonModel->getData('settings_district', 'DESC');
        $data['pradesh']                = $this->CommonModel->getData('provinces', 'DESC');
        $data['prakar']                 = $this->CommonModel->getData('main_topic');
        $data['category']               = $this->CommonModel->getData('category');
        $data['subtopic']               = $this->CommonModel->getData('prakar');
        $data['gapana']                 = $this->CommonModel->getData('settings_vdc_municipality', 'DESC');
        $data['row']                    = $this->CommonModel->getDataByID('ijajat_patra', $id);
        $data['device_details']         = $this->CommonModel->getWhereAll('device_details', array('trans_id' => $id));
        $data['workdetails']            = $this->CommonModel->getWhereAll('previouis_work_details', array('trans_id' => $id));
        $data['category']               = $this->CommonModel->getData('category');
        $this->load->view('main', $data);
    }
    //update details
    public function update()
    {
        if ($this->input->post('Submit')) {
            $id                             = $this->input->post('id');
            $darta_no                       = $this->input->post('darta_no');
            $name                           = $this->input->post('org_name');
            $p_pardesh                      = $this->input->post('p_pardesh');
            $p_district                     = $this->input->post('p_district');
            $p_gapa                         = $this->input->post('p_gapa');
            $p_ward                         = $this->input->post('p_ward');
            $tol                            = $this->input->post('tol');
            $contact_no                     = $this->input->post('contact_no');
            $email                          = $this->input->post('email');
            $firm_type                      = $this->input->post('firm_type');
            $contact_person                 = $this->input->post('contact_person');
            $contact_address                = $this->input->post('contact_address');
            $c_number                       = $this->input->post('c_number');
            $c_email                        = $this->input->post('c_email');
            $org_darta_no                   = $this->input->post('org_darta_no');
            $org_darta_miti                 = $this->input->post('org_darta_miti');
            $a_capital                      = $this->input->post('a_capital');
            $c_capital                      = $this->input->post('c_capital');
            $warga                          = $this->input->post('warga');
            $samuha                         = $this->input->post('samuha');
            $s_amount                       = $this->input->post('s_amount');
            $s_bank                         = $this->input->post('s_bank');
            $m_amount                       = $this->input->post('m_amount');
            $m_bank                         = $this->input->post('m_bank');
            $c_amount                       = $this->input->post('c_amount');
            $c_bank                         = $this->input->post('c_bank');
            $b_amount                       = $this->input->post('b_amount');
            $b_bank                         = $this->input->post('b_bank');

            //आफ्नो स्वामित्वमा रहेको निर्माण सम्बन्धी सवारी साधन मेशिनरी औजारको विवरणः
            $device_id                      = $this->input->post('device_id');
            $device_name                    = $this->input->post('device_name');
            $device_no                      = $this->input->post('device_no');
            $device_capacity                = $this->input->post('device_capacity');
            $device_amount                  = $this->input->post('device_amount');
            $device_date                    = $this->input->post('device_date');
            $other_detail                   = $this->input->post('other_detail');

            //new fields

            $device_name_new                    = $this->input->post('device_name_new');
            $device_no_new                      = $this->input->post('device_no_new');
            $device_capacity_new                = $this->input->post('device_capacity_new');
            $device_amount_new                  = $this->input->post('device_amount_new');
            $device_date_new                    = $this->input->post('device_date_new');
            $other_detail_new                   = $this->input->post('other_detail_new');

            //यस अघि सम्पन्न गरेको कामको विवरणः
            $work_id                        = $this->input->post('work_id');
            $pre_work                       = $this->input->post('pre_work');
            $per_work_year                  = $this->input->post('per_work_year');
            $work_amount                    = $this->input->post('work_amount');
            $work_office                    = $this->input->post('work_office');
            $work_status                    = $this->input->post('work_status');
            //new fields
            $pre_work_new                       = $this->input->post('pre_work_new');
            $per_work_year_new                  = $this->input->post('per_work_year_new');
            $work_amount_new                    = $this->input->post('work_amount_new');
            $work_office_new                    = $this->input->post('work_office_new');
            $work_status_new                    = $this->input->post('work_status_new');
            $save_array                     = array(
                'name'                      => $name,
                'p_district'                => $p_district,
                'p_gapa'                    => $p_gapa,
                'p_ward'                    => $p_ward,
                'tol'                       => $tol,
                'contact_no'                => $contact_no,
                'email'                     => $email,
                'firm_type'                 => $firm_type,
                'contact_person'            => $contact_person,
                'contact_address'           => $contact_address,
                'c_number'                  => $c_number,
                'c_email'                   => $c_email,
                'org_darta_no'              => $org_darta_no,
                'org_darta_miti'            => $org_darta_miti,
                'a_capital'                 => $a_capital,
                'c_capital'                 => $c_capital,
                'warga'                     => $warga,
                'samuha'                    => $samuha,
                's_amount'                  => $s_amount,
                's_bank'                    => $s_bank,
                'm_amount'                  => $m_amount,
                'm_bank'                    => $m_bank,
                'c_amount'                  => $c_amount,
                'c_bank'                    => $c_bank,
                'b_amount'                  => $b_amount,
                'b_bank'                    => $b_bank,
                'modified_by'               => convertDate(date('Y-m-d')),
                'modified_at'               => $this->session->userdata('PRJ_USER_BID'),
            );
            $result = $this->CommonModel->updateData('ijajat_patra', $id, $save_array);
            if ($result) {
                $device = array();
                $pre_works = array();
                if (!empty($device_name)) {
                    foreach ($device_name as $key   => $index) {
                        $device[] = array(
                            'id'                    => $device_id[$key],
                            'device_name'           => $device_name[$key],
                            'device_no'             => $device_no[$key],
                            'device_capacity'       => $device_capacity[$key],
                            'device_amount'         => $device_amount[$key],
                            'device_date'           => $device_date[$key],
                            'other_detail'          => $other_detail[$key],
                        );
                    }
                    $this->CommonModel->batchUpdate('device_details', $device_id, $device);
                }
                if (!empty($pre_work)) {
                    foreach ($pre_work as $key   => $indexs) {
                        $pre_works[] = array(
                            'id'                    => $work_id[$key],
                            'pre_work'              => $pre_work[$key],
                            'per_work_year'         => $per_work_year[$key],
                            'work_amount'           => $work_amount[$key],
                            'work_office'           => $work_office[$key],
                            'work_status'           => $work_status[$key],
                        );
                    }
                    $this->CommonModel->batchUpdate('previouis_work_details', $work_id, $pre_works);
                }
                $device_new = array();
                $pre_works_new = array();
                if (!empty($device_name_new)) {
                    foreach ($device_name_new as $key   => $index) {
                        $device_new[] = array(
                            'device_name'           => $device_name_new[$key],
                            'device_no'             => $device_no_new[$key],
                            'device_capacity'       => $device_capacity_new[$key],
                            'device_amount'         => $device_amount_new[$key],
                            'device_date'           => $device_date_new[$key],
                            'other_detail'          => $other_detail_new[$key],
                            'darta_no'              => $darta_no,
                            'trans_id'              => $id,
                        );
                    }
                    $this->CommonModel->batchInsert($device_new, 'device_details');
                }
                if (!empty($pre_work_new)) {
                    foreach ($pre_work_new as $key   => $index) {
                        $pre_works_new[] = array(
                            'pre_work'              => $pre_work_new[$key],
                            'per_work_year'         => $per_work_year_new[$key],
                            'work_amount'           => $work_amount_new[$key],
                            'work_office'           => $work_office_new[$key],
                            'work_status'           => $work_status_new[$key],
                            'darta_no'              => $darta_no,
                            'trans_id'              => $id,
                        );
                    }
                    $this->CommonModel->batchInsert($pre_works_new, 'previouis_work_details');
                }
                // if ($child) {
                $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                redirect('IjajatPatra');
                // } else {
                //     $this->CommonModel->deleteData('krishi_samuha_darta', $result);
                //     $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                //     redirect('IjajatPatra/Add');
                // }
            }
        }
    }
    //print certificate
    public function printcertificate($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row']            = $this->CommonModel->getDataById('ijajat_patra', $id);
            $data['members']        = $this->CommonModel->getWhereAll('krishi_samuha_members', array('samuha_id' => $id));
            $data['staffs']         = $this->CommonModel->getData('staff');
            $this->load->view('print_details', $data);
        }
    }
    //print printPramanparta
    public function certificate($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row']            = $this->CommonModel->getDataById('ijajat_patra', $id);
            $data['maker']          = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $this->load->view('certificate', $data);
        }
    }
    //datatable list
    public function GetAllList()
    {
        if ($this->input->is_ajax_request()) {
            $columns = array(0     => 'id');
            $limit                  = $this->input->post('length');
            $start                  = $this->input->post('start');

            //main_topic, business_name, darta_no, darta_miti
            $type                   = $this->input->post('type');
            $samuha_name            = $this->input->post('samuhan_name');
            $darta_no               = $this->input->post('darta_no');
            $darta_miti             = $this->input->post('darta_miti');
            $sn                     = $start + 1;
            $order                  = $columns[$this->input->post('order')[0]['column']];
            $dir                    = $this->input->post('order')[0]['dir'];
            $totalData              = $this->IjajatapartaModel->CountAll($samuha_name, $type, $darta_no, $darta_miti);
            $totalFiltered          = $totalData;
            $posts                  = $this->IjajatapartaModel->GetAll($limit, $start, $order, $dir, $samuha_name, $type, $darta_no, $darta_miti);
            // pp($posts);
            $data                   = array();
            if (!empty($posts)) {
                $i = 1;
                foreach ($posts as $post) {
                    $nestedData['sn']               = $this->mylibrary->convertedcit($sn++);
                    $nestedData['id']               = $post->id;
                    $nestedData['darta_date']       = $this->mylibrary->convertedcit($post->darta_miti);
                    $nestedData['name']             = $this->mylibrary->convertedcit($post->name);
                    $nestedData['type']             = $this->mylibrary->convertedcit($post->firm_type);
                    $nestedData['address']          = $post->tol . '-' . $this->mylibrary->convertedcit($post->p_ward) . ',  ' . $post->p_gapa;
                    $nestedData['darta_no']         = '<span class="badge badge-pill badge-secondary">' . $this->mylibrary->convertedcit($post->darta_no) . '</span>';
                    $nestedData['warga']            = $post->warga;
                    //$nestedData['male']             = $this->mylibrary->convertedcit($post->total_male_member);
                    //$nestedData['female']           = $this->mylibrary->convertedcit($post->total_female_member);
                    //$nestedData['gathan_miti']      = $this->mylibrary->convertedcit($post->gathan_miti);
                    $data[] = $nestedData;
                }
            }
            $json_data = array(
                "draw"            => intval($this->input->post('draw')),
                "recordsTotal"    => intval($totalData),
                "recordsFiltered" => intval($totalFiltered),
                "data"            => $data
            );
            echo json_encode($json_data);
        } else {
            exit('HTTPS!!');
        }
    }
    public function updatePhoto()
    {
        $data['id'] = $this->input->post('id');
        $this->load->view('upload_photo', $data);
    }
    //update photo
    public function updateImage()
    {
        $id                         = $this->input->post('id');
        $userfile                   = $_FILES['userfile']['name'];
        $file                       =  preg_replace('/\s+/', '_', $userfile);
        if (!empty($userfile)) {
            $config = array(
                'upload_path'       => './assets/business_owner/',
                'allowed_types'     => "jpg|png|PNG|jpeg|JPEG",
                'max_size'          => 1024,
                'overwrite'         => TRUE,
                'file_name'         => preg_replace('/\s+/', '_', $file),
            );
            $this->load->library('upload');
            $this->upload->initialize($config);
            if (!$this->upload->do_upload('userfile')) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => 'Cannot upload image'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $this->upload->do_upload();
            }
            $update_array = array('image' => $file);
            $result = $this->CommonModel->updateData('darta', $id, $update_array);
            if ($result) {
                $response = array(
                    'status'        => 'success',
                    'message'       => 'redirect',
                    'redirect_url'  => base_url() . 'Register/viewDetails/' . $id,
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        }
    }
    //renew darta
    public function renew($id)
    {
        $data['page'] = 'renew_darta';
        $data['row'] = $this->CommonModel->getDataById('ijajat_patra', $id);
        $this->load->view('main', $data);
    }
    //save nabikarn details
    public function nabikaran()
    {
        if ($this->input->post('Submit')) {
            $darta_id                   = $this->input->post('darta_id');
            $darta_no                   = $this->input->post('darta_no');
            $b_type                     = $this->input->post('b_type');
            $b_subtype                  = $this->input->post('b_subtype');
            $date                       = $this->input->post('date');
            $fiscal_year_from           = $this->input->post('fiscal_year_from');
            $fiscal_year_to             = $this->input->post('fiscal_year_to');
            $rasid_no                   = $this->input->post('rasid_no');
            $dastur                     = $this->input->post('dastur');
            $remarks                    = $this->input->post('remarks');
            $rasid_no                   = $this->input->post('rasid_no');
            $save_array                 = array(
                'darta_id'              => $darta_id,
                'date'                  => $date,
                'darta_no'              => $darta_no,
                'b_type'                => '',
                'b_subtype'             => '',
                'fiscal_year_from'      => $fiscal_year_from,
                'fiscal_year_to'        => $fiscal_year_to,
                'rasid_no'              => $rasid_no,
                'dastur'                => $dastur,
                'remarks'               => $remarks,
                'fiscal_year'           => current_fiscal_year(),
                'created_at'            => convertDate(date('Y-m-d h:i:sa')),
                'created_by'            => $this->session->userdata('PRJ_USER_BID'),
                'added_ward'            => $this->session->userdata('PRJ_USER_WARD'),
                'renew_type'            => $this->uri->segment(1),
            );
            $result = $this->CommonModel->insertData('renew', $save_array);
            if ($result) {
                $renew_status = array('renew_status' => 1);
                $this->CommonModel->updateData('ijajat_patra', $darta_id, $renew_status);
                $this->session->set_flashdata('MSG_SUCCESS', 'तपाई नवकिरण गर्न सफल हुनुभयो');
                redirect('IjajatPatra');
            }
        }
    }
    //list nabikaran details
    public function listNabikarnDetails($darta_id)
    {
        $data['page']       = 'renew_darta_list';
        $data['renews']     = $this->CommonModel->getWhereAll('renew', array('darta_id' => $darta_id));
        $data['darta']      = $this->CommonModel->getWhere('darta', array('id' => $darta_id));
        $this->load->view('main', $data);
    }
    //edit renew
    public function editRenew($renewid)
    {
        $data['page'] = 'renew_darta_edit';
        $data['row'] = $this->CommonModel->getDataById('renew', $renewid);
        $this->load->view('main', $data);
    }
    //update reneew details
    public function updateRenew()
    {
        if ($this->input->post('Submit')) {
            $id                         = $this->input->post('id');
            $darta_id                   = $this->input->post('darta_id');
            $fiscal_year_from           = $this->input->post('fiscal_year_from');
            $fiscal_year_to             = $this->input->post('fiscal_year_to');
            $rasid_no                   = $this->input->post('rasid_no');
            $dastur                     = $this->input->post('dastur');
            $remarks                    = $this->input->post('remarks');
            $rasid_no                   = $this->input->post('rasid_no');
            $save_array                 = array(
                'fiscal_year_from'      => $fiscal_year_from,
                'fiscal_year_to'        => $fiscal_year_to,
                'rasid_no'              => $rasid_no,
                'dastur'                => $dastur,
                'remarks'               => $remarks,
                'modified_at'            => convertDate(date('Y-m-d h:i:sa')),
                'modified_by'            => $this->session->userdata('PRJ_USER_BID'),
            );
            $result = $this->CommonModel->updateData('renew', $id, $save_array);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'success');
                redirect('Register/listNabikarnDetails/' . $darta_id);
            }
        }
    }
    //delete renew
    public function deleteRenewDetails($id)
    {
        $row = $this->CommonModel->getDataById('renew', $id);
        if (!empty($row)) {
            $result = $this->CommonModel->deleteData('renew', $id);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'success');
                redirect('Register/listNabikarnDetails/' . $row['darta_id']);
            }
        }
    }
    //print renew certificate
    public function renewCertificate($darta_id)
    {
        $data['renewDetails'] = $this->CommonModel->getWhere('renew', array('darta_id' => $darta_id));
        if (empty($data['renewDetails'])) {
            $this->session->set_flashdata('MSG_ERR', 'नवीकरण गरिएको छैन. कृपया नवीकरण गर्नुहोस');
            redirect('Register/viewDetails/' . $darta_id);
        } else {
            $data['renewdetails'] = $this->CommonModel->getWhereAll('renew', array('darta_id' => $darta_id));
            $this->load->view('renew_certificate', $data);
        }
    }
    //update maker
    public function updateMaker()
    {
        $id                 = $this->input->post('id');
        $maker              = $this->input->post('maker');
        $data               = array('maker' => $maker);
        $result             = $this->CommonModel->updateData('ijajat_patra', $id, $data);
        if ($result) {
            $response       = array(
                'status'    => 'success',
                'data'      => "सफलतापूर्वक सम्मिलित गरियो",
                'message'   => 'success'
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
        }
    }
    //update checker
    public function updateChecker()
    {
        $id                 = $this->input->post('id');
        $checker            = $this->input->post('checker');
        $data               = array('checker' => $checker);
        $result             = $this->CommonModel->updateData('krishi_samuha_darta', $id, $data);
        if ($result) {
            $response       = array(
                'status'    => 'success',
                'data'      => "सफलतापूर्वक सम्मिलित गरियो",
                'message'   => 'success'
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
        }
    }
    //remove members
    public function removeDevice($id, $faram_id)
    {
        if (empty($id)) {
            show_404();
        } else {
            $result = $this->CommonModel->deleteData('device_details', $id);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'Member removed successfully');
                redirect('IjajatPatra/edit/' . $faram_id);
            }
        }
    }

    public function removeWork($id, $faram_id)
    {
        if (empty($id)) {
            show_404();
        } else {
            $result = $this->CommonModel->deleteData('previouis_work_details', $id);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'Member removed successfully');
                redirect('IjajatPatra/edit/' . $faram_id);
            }
        }
    }
    /*-----------------------------------------------------------------------
        RENEW DETAILS
     ------------------------------------------------------------------------*/
    public function RenewDetails($id)
    {
        $data['page'] = 'renew_darta';
        $data['row'] = $this->CommonModel->getDataById('ijajat_patra', $id);
        $this->load->view('main', $data);
    }
}//end of class