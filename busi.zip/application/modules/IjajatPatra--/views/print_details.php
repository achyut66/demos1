<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/landscape.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>

  <style>
  .title {
    height: 45px;
    width: 425px;
    border: 1px solid #555;
    margin-left: 320px;
    /* border-radius: 25px; */
    /* border-radius: 25px; */
    margin-top: 50px;
  }

  .stamp {
    /* border: 2px solid #555; */
    height: 62px;
    /* width: 202px; */
    margin-top: 50px;
    margin-left: 487px;
    border-radius: 5px;
  }
  </style>
</head>

<body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle">

          <h3 class=""><?php echo GNAME ?> </h3>
          <h4><?php echo SLOGAN ?></h4>
          <h6 style="margin-top:-10px;"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6 style="margin-top:-5px;"><?php echo STATENAME ?>,नेपाल</h6>
        </div>
        <div class="header-right">
          <div class="">
            <a href="<?php echo base_url() ?>IjajatPatra/certificate/<?php echo $row['id'] ?>" target="_blank"
              class="btn btn-info btn-sm" style="margin-top:10px;"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस </a>
            <a href="<?php echo base_url()?>IjajatPatra" class="btn btn-success btn-sm" style="margin-top:10px;">दर्ता
              सुचीमा जानुहोस </a>
          </div>
        </div>
      </div>

      <div>

        <div style="margin-left:50px;">
          <p style="font-size:18px;margin-top:50px;">इजाजत-पत्र नं.
            <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?></p>
        </div>


        <div style="margin-left:485px; text-align:right;margin-top:-50px;">
          <p style="font-size:18px;margin-top:0px;">मिति:
            <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></p>
        </div>

        <div class="sub-header">
          <div class="title" style="float:center">
            <p style="margin-left:37px;font-size:26px;margin-top:3px;"><b>इजाजतपत्र -पत्र</b></p>
          </div>
        </div>

        <div style="margin-left:50px; margin-top:105px; margin-right:50px;">
          <p style="text-indent: 2em;font-size:22px;text-align:justify">
            <?php echo GNAME ?>को <?php echo $row['warga'] ?> निर्माण व्यवसायी ईजाजत पत्र सम्बन्धी
            कार्यविधि २०७५ को दफा २ को उपदफा (४) बमोजिम निर्माण व्यवसाय गर्न <?php echo $row['tol'] ?>
            <?php echo $this->mylibrary->convertedcit($row['p_ward']) ?> स्थित कार्यालय भएको
            <b><?php echo $row['name'] ?></b> लाई ईजाजत
            पत्र प्रदान गरिएको छ ।
          </p>
        </div>

        <div style="margin-top:70px;border: solid 2px #000; width:118px;margin-left:60px;border-radius:100px;">
          <p style="font-size:18px; margin-left:30px;margin-top:20px"><?php echo $row['warga'] ?></p>
        </div>

        <div style="border-top: dotted 2px #000; width:307px;margin-left:690px; margin-top: -61px;">
          <!-- <p>ईजाजत पत्र दिनेको</p> -->
          <select class="form-control" name="maker" id="maker">
            <option value="">--छान्नुहोस्--</option>
            <?php if (!empty($staffs)) : foreach ($staffs as $staff) : ?>
            <option value="<?php echo $staff['id'] ?>" <?php if($staff['id'] == $row['maker']){ echo 'selected';}?>>
              <?php echo $staff['name'] ?></option>
            <?php endforeach;
                    endif; ?>
          </select>
        </div>
      </div>
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
$(document).ready(function() {
  var base_url = "<?php echo base_url() ?>";
  $('#maker').change(function() {
    obj = $(this);
    var maker = obj.val();
    var id = "<?php echo $this->uri->segment(3) ?>";
    $.ajax({
      url: base_url + 'IjajatPatra/updateMaker',
      method: "POST",
      data: {
        maker: maker,
        id: id,
        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
      },
      success: function(resp) {
        if (resp.status == 'success') {
          location.reload();
        }
      }
    });
  });
  $('#checker').change(function() {
    obj = $(this);
    var checker = obj.val();
    var id = "<?php echo $this->uri->segment(3) ?>";
    $.ajax({
      url: base_url + 'IjajatPatra/updateChecker',
      method: "POST",
      data: {
        checker: checker,
        id: id,
        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
      },
      success: function(resp) {
        if (resp.status == 'success') {
          location.reload();
        }
      }
    });
  });
});
</script>

</html>