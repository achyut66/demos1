<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>

  <style>
  .title {
    height: 45px;
    width: 285px;
    border: 1px solid #555;
    margin-left: 590px;
    border-radius: 25px;
    text-align:center;
    /* border-radius: 25px; */
    margin-top: 30px;
  }

  .stamp {
    /* border: 2px solid #555; */
    /* height: 62px;
    width: 202px;
     */
    margin-left: 487px;
    border-radius: 5px;
    text-align:right;
    margin-right:120px;
    margin-top: 50px;
  }


   @page { 
        size: landscape;
    }
  </style>
</head>

<body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle">

          <h3 class=""><?php echo GNAME ?> </h3>
          <h4><?php echo SLOGAN ?></h4>
          <h6 style="margin-top:-10px;"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6 style="margin-top:-5px;"><?php echo STATENAME ?>,नेपाल</h6>
        </div>
        <div class="header-right">
          <div class="">

          </div>
        </div>
      </div>

      <div>

        <div style="margin-left:50px;">
          <p style="font-size:18px;margin-top:50px;">इजाजत-पत्र नं.
            <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?></p>
        </div>


        <div style="margin-right:150px;text-align:right; margin-top:-50px;">
          <p style="font-size:18px;margin-top:0px;">मिति:
            <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></p>
        </div>

        <div class="sub-header">
          <div class="title">
            <p style=" text-align:center;font-size:26px;margin-top:3px;"><b>इजाजतपत्र -पत्र</b></p>
          </div>
        </div>

        <div style="margin-left:50px; margin-top:100px; margin-right:30px;">
          <p style="text-indent: 2em;font-size:22px;text-align:justify">
            <?php echo GNAME ?>को <?php echo $row['warga'] ?> निर्माण व्यवसायी ईजाजत पत्र सम्बन्धी
            कार्यविधि २०७५ को दफा २ को उपदफा (४) बमोजिम निर्माण व्यवसाय गर्न <?php echo $row['tol'] ?>
            <?php echo $this->mylibrary->convertedcit($row['p_ward']) ?> स्थित कार्यालय भएको
            <b><?php echo $row['name'] ?></b> लाई ईजाजत
            पत्र प्रदान गरिएको छ ।
          </p>
        </div>

        <div style="margin-top:120px;border: solid 2px #000; width:118px;margin-left:60px;border-radius:100px;">
          <p style="font-size:18px; margin-left:30px;margin-top:20px"><?php echo $row['warga'] ?></p>
        </div>

        <div style="margin-right:150px; text-align:right; margin-top: -40px;">
          <p style="font-size:18px;text-decoration:underline;margin-left:-67px;"><b>ईजाजत पत्र दिनेको:</b></p>
          <p style="font-size:18px;margin-right:67px;margin-top:-16px;">दस्तखत: </p>
          <p style="font-size:18px;margin-right:0px;margin-top:-10px">नाम: <?php echo $maker['name'] ?></p>
          <p style="font-size:18px;margin-right:10px;margin-top:-10px;">पद: <?php echo $maker['designation'] ?></p>
          <p style="font-size:18px;margin-right:-10px;margin-top:-10px;">मिति:
            <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></p>
        </div>
      </div>
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
window.print();
</script>

</html>