<!--main content start-->
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"><i class="fa fa-home"></i> ड्यासबोर्डमा जानुहोस</a></li>
        <li class="breadcrumb-item active">कृषि समूह दर्ता सुची </li>
      </ol>
    </nav>
    <!-- page start-->
    <div class="row">
      <div class="col-sm-12">
        <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
        if (!empty($success_message)) { ?>
          <div class="alert alert-success">
            <button class="close" data-close="alert"></button>
            <span> <?php echo $success_message; ?> </span>
          </div>
        <?php } ?>

        <section class="card">
          <header class="card-header">
            <span style="text-align:center">कृषि समूह दर्ता सुची </span>
            <span class="tools">
              <?php if ($this->authlibrary->HasModulePermission('AG-DEPARTMENT-ADD', "ADD")) { ?>
                <a href="<?php echo base_url() ?>AgricultureDepartment/Add" class=" btn btn-secondary pull-right" title=""><i class="fa fa-plus-circle"></i> समूह दर्ता फारम </a>
              <?php } ?>
            </span>
          </header>

          <div class="card-body">
            <div class="row">
              <div class="col-md-3">
                <input type="text" class="form-control" id="samuha_name" placeholder="समुहको नाम ">
              </div>
              <div class="col-md-3">
                <input type="text" class="form-control" id="type" placeholder="समुहको किसिम ">
              </div>
              <div class="col-md-2">
                <input type="text" class="form-control" id="darta_no" placeholder="दर्ता नं.">
              </div>
              <div class="col-md-2">
                <div class="input-group">
                  <input type="text" name="date" class="form-control " value="" placeholder="दर्ता मिति " autocomplete="off" id="darta_miti">
                  <div class="input-group-prepend">
                    <button type="button" class="input-group-text btn btn-secondary" title=""><i class="fa fa-calendar" style="color:##6c757d;background: radial-gradient(#ffffff, transparent);"></i></button>
                  </div>
                </div>
              </div>
              <div class="col-md-2">
                <button type="button" class="btn btn-warning" title="खोजी गर्नुहोस्" id="filter"><i class="fa fa-search"></i> खोज्नुहोस</button>
              </div>
            </div>
            <hr>
            <div class="adv-table">
              <table class="display table table-bordered table-striped" id="dartalist">
                <thead style="background: #1b5693; color:#fff">
                  <tr>
                    <th>#</th>
                    <th>दर्ता नं.</th>
                    <th>दर्ता मिति</th>
                    <th>समुहको नाम</th>
                    <th>समुहको किसिम</th>
                    <th>ठेगाना</th>
                    <th>पुरुष सदस्य संख्या</th>
                    <th>महिला सदस्य संख्या</th>
                    <th>गठन मिति</th>
                    <?php if ($this->authlibrary->HasModulePermission('AG-DEPARTMENT-LIST', 'EDIT')) { ?>
                      <th class="hidden-phone"></th>
                    <?php } ?>
                  </tr>
                </thead>
                <tbody></tbody>
              </table>
            </div>
          </div>
        </section>
      </div>
    </div>
    <!-- page end-->
  </section>
</section>
<script src="<?php echo base_url('assets/datatable/datatables.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/nepali_datepicker/nepali.datepicker.v2.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#darta_miti').nepaliDatePicker();
    fetch_all_data();

    function fetch_all_data(samuha_name, type, darta_no, darta_miti) {
      var oTable = $('#dartalist').DataTable({
        "order": [
          [0, "desc"]
        ],
        "searching": false,
        'lengthChange': false,
        "processing": true,
        "serverSide": true,
        'language': {
          'loadingRecords': '&nbsp;',
          'processing': '<div class="spinner"></div>'
        },
        "ajax": {
          "url": "<?php echo base_url('AgricultureDepartment/GetAllList') ?>",
          "dataType": "json",
          "type": "POST",
          "data": {
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>',
            samuha_name: samuha_name,
            type: type,
            darta_no: darta_no,
            darta_miti: darta_miti
          }
        },
        "columns": [{
            "data": "sn"
          },
          {
            "data": "darta_no"
          },
          {
            "data": "darta_date"
          },
          {
            "data": "name"
          },
          {
            "data": "type"
          },
          {
            "data": "address"
          },
          {
            "data": "male"
          },
          {
            "data": "female"
          },
          {
            "data": "gathan_miti"
          },
          <?php if ($this->authlibrary->HasModulePermission('AG-DEPARTMENT-LIST', 'EDIT')) { ?> {
              "data": "",
              render: function(data, type, row) {
                var res = '<a href="<?php echo base_url() ?>AgricultureDepartment/viewDetails/' + row.id + '"' + ' class="btn btn-secondary btn-sm" alt="पुरा विवरण हेर्नुहोस " title="पुरा विवरण हेर्नुहोस "><i class="fa fa-eye"></i></a> <a href="<?php echo base_url() ?>AgricultureDepartment/edit/' + row.id + '"' + '  class="btn btn-primary btn-sm" alt="विवरण सम्पादन गर्नुहोस" title="विवरण सम्पंदा गर्नुहोस"><i class="fa fa-pencil"></i></a> <a href="<?php echo base_url() ?>AgricultureDepartment/RenewDetails/' + row.id + '"' + '  class="btn btn-warning btn-sm" alt="नबिकरण गर्नुहोस " title="नबिकरण गर्नुहोस"><i class="fa fa- fa-unlock-alt"></i></a> <a href="<?php echo base_url() ?>AgricultureDepartment/printcertificate/' + row.id + '"' + '  class="btn btn-info btn-sm" alt="प्रमाण पत्र प्रिन्ट गर्नुहोस " title="प्रमाण पत्र प्रिन्ट गर्नुहोस "><i class="fa fa-print"></i></a>';

                return res;
              },
            },
          <?php } ?>
        ],
      });
    }
    $('#filter').click(function() {
      var type = $('#type').val();
      var samuha_name = $('#samuha_name').val();
      var darta_no = $('#darta_no').val();
      var darta_miti = $('#darta_miti').val();
      $('#dartalist').DataTable().destroy();
      fetch_all_data(samuha_name, type, darta_no, darta_miti);
    });
  });
</script>