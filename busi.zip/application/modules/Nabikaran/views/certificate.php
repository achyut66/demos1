<html>
    <head>
        <style type='text/css'>
            body, html {
                margin: 0;
                padding: 0;
            }
            
            body {
                color: black;
                display: table;
                font-family: Kalimati, Georgia, serif;
                font-size: 24px;
                text-align: center;
                -webkit-print-color-adjust: exact !important;
            }
            .container {
                /* border: 20px solid tan; */
                width: 983px;
                height: 18.5cm;
                display: table-cell;
                background-image: url('../../assets/img/nepali_kagaz1.jpg') !important;
                background-repeat: no-repeat, repeat;
                background-size: cover;
                /* vertical-align: middle; */

                /* border: 10px solid transparent;
                padding: 15px;
                border-image: url('../../assets/img/bg_color.png') 30 stretch; */
                
                /* background-image: url('../../assets/img/bg_color.png') !important; */
            }
            .page{
                width: 983px;
                height: 18.5cm;
                display: table-cell;
                /* background-image: url('../../assets/img/bg_color.png') !important; */
                background-repeat: no-repeat, repeat;
                background-size: cover;
                background-image: url('../../assets/img/nepali_kagaz1.jpg') !important;
                background-repeat: no-repeat, repeat;
                background-size: cover;
            }
            .logo {
                color: tan;
            }

            .marquee {
                color: #000;
                font-size: 38px;
                margin: 20px;
                margin-top: -135px;
            }
            .assignment {
                margin: 20px;
            }
            .person {
                border-bottom: 2px solid black;
                font-size: 32px;
                font-style: italic;
                margin: 20px auto;
                width: 400px;
            }
            .reason {
                margin: 20px;
            }
            .sarkar-logo {
                width:100px;
                height:100px;
                margin:50px;
            }
            .palika-logo {
                width:100px;
                margin-left:782px;
                margin-top:-140px;
                /* float:right; */
            }
            .stamp{
                /* float: right;  */
                /* margin-top:50px; */
                /* border: 1px solid #555;  */
                /* margin-left: 427px;  */
                /* height: 88px; 
                margin-top:-40px; 
                width: 145px; */
                /* margin-right: 2px; */
                /* height:88px;
                width: 206px;
                margin-top: 166px;
                margin-left: 616px; */

                height: 62px;
                width: 202px;
                margin-top: 150px;
                margin-left: 637px;
                border-radius: 25px;

                border-radius: 25px;
            }
            .title {
                height: 62px;
                width: 419px;
                border: 1px solid #555;
                margin-left: 230px;
                border-radius: 25px;
                border-radius: 25px;
                margin-top: 5px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="">
            
                <div class="sarkar-logo">
                    <img src="<?php echo base_url()?>assets/img/nepal-govt.png" style="height: 100px; width: 100px;">
                </div>
                <div class="marquee">
                   <p style="margin-top:-28px"><?php echo GNAME?></p>
                   <p style="margin-top:-39px; font-size:32px;"><?php echo 'कृषि विकाश शाखा ';?></p>
                   <p style="margin-top:-25px; font-size:16px;"><?php echo ADDRESS.','.DISTRICT?></p>
                   <p style="margin-top:-15px; font-size:16px;"><?php echo STATENAME?>,नेपाल</p>
                </div>
                <?php if(!empty(PALIKALOGO)):?>
                <div class="palika-logo">
                    <img src="<?php echo base_url()?>assets/img/<?php echo PALIKALOGO?>" style="height: 100px; width: 100px;float:right;margin-right:60px;margin-top:-35px;">
                </div>
                <?php endif;?>
                <div class="stamp">
                <p style="margin-left:20px; margin-top:5px; font-size:18px">दर्ता नं. <?php echo $this->mylibrary->convertedcit($row['darta_no'])?><p>
                <p style="margin-left:60px;margin-top:-20px; font-size:18px">मिति: <?php echo $this->mylibrary->convertedcit($row['darta_date'])?></p>
                </div>
                <div class="title"><p style="margin-left:37px;font-size:26px;margin-top:10px;"><b>किर्षक समूह दर्ता प्रमाण-पत्र </b></p></div>
                <div><p style="text-indent: 2em;margin-left:60px;margin-right:60px; font-size:22px;text-align:justify">समूह पदितिलाई सुव्यवस्थित गर्दै कृषि प्रसार कार्यलाई टेवा पराउने उदेश्यले यस <?php echo DISTRICT?> जिल्ला <?php echo GNAME?> वडा नं-<?php echo $this->mylibrary->convertedcit($row['p_ward'])?>, मा मिति <?php echo $this->mylibrary->convertedcit($row['gathan_miti'])?> गते गठित श्री <b><?php echo $row['samuha_name']?></b>लाई <?php echo $row['bidi']?> यस कार्यलायको अभिलेखमा दर्ता गरि यो  प्रमाण पत्र प्रदान गरिएको छ |</p></div>
                <div style="margin-top:80px;border-top: dotted 2px #000; width:118px;margin-left:60px;">
                    <p style="font-size:18px"><?php echo $maker['name']?> </p>
                    <p style="font-size:18px;margin-top:-15px;"><?php echo $maker['designation']?></p>
                </div>
                <div style="border-top: dotted 2px #000; width:107px;margin-left:680px;margin-top:-99px">
                    <p style="font-size:14px"><?php echo $checker['name']?> </p>
                    <p style="font-size:14px;margin-top:-15px;"><?php echo $checker['designation']?></p>
                </div>
            </div>
        </div>
        <script src="<?php echo base_url()?>assets/js/jquery.js"></script>
        <script type="text/javascript">
            // $(document).ready(function(){
            //     $('#printme').on("click", function () {
            //         $('.hideme').hide();
                    window.print();
            //     });
            // });
        </script>
    </body>
</html>