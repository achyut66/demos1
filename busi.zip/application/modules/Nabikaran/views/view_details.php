 <!--main content start-->
 <style>
     .table-bordered td, .table-bordered th{
        border: 1px solid #3a5d7f;
     }
 </style>
<section id="main-content">
    <section class="wrapper site-min-height">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url()?>"><i class="fa fa-home"></i> ड्यासबोर्डमा</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo base_url()?>AgricultureDepartment" class="bactive"> कृषि, पशु विकास शाखा</a></li>
                <li class="breadcrumb-item active"><a href="javascript:;" class="bactive">विवरण हेर्नुहोस</a></li>
            </ol>
        </nav>
              <!-- page start-->
        <div class="row">
            <aside class="profile-info col-lg-9">
                <section class="card">
                    <header class="card-header text-light " style="background-color:#4d5886">समुहको नाम: <?php echo $row['samuha_name']?> <span class="btn btn-success btn-circle"> दर्ता नं. <?php echo $this->mylibrary->convertedcit($row['darta_no'])?></span>
                    </header>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
                                    if(!empty($success_message)) { ?>
                                    <div class="alert alert-success">
                                        <button class="close" data-close="alert"></button>
                                        <span> <?php echo $success_message;?> </span>
                                    </div>
                                <?php } ?>

                                <?php $err_message = $this->session->flashdata("MSG_ERR");
                                    if(!empty($err_message)) { ?>
                                    <div class="alert alert-danger">
                                        <button class="close" data-close="alert"></button>
                                        <span> <?php echo $err_message;?> </span>
                                    </div>
                                <?php } ?>
                                <?php $err_message = $this->session->flashdata("MSG_WAR");
                                    if(!empty($err_message)) { ?>
                                    <div class="alert alert-warning">
                                        <button class="close" data-close="alert"></button>
                                        <span> <?php echo $err_message;?> </span>
                                    </div>
                                <?php } ?>
                                

                                <table class="table table-bordered">
                                    <tr>
                                        <td><strong><span>दर्ता मिति: </span><?php echo $this->mylibrary->convertedcit($row['darta_date'])?></strong></td>
                                        <td><strong><span>समुहको किसिम:</span> <?php echo $row['samuha_type']?></td>
                                        <td colspan=2><strong><span> ठेगाना: </span><?php echo $row['tol']?>-<?php echo $this->mylibrary->convertedcit($row['p_ward'])?>,<?php echo $row['p_district'];?>,<?php echo $row['p_pardesh'];?></strong></td>
                                    </tr>
                                    <tr>
                                        <td><strong><span>पुरुष सदस्य संख्या:</span> <?php echo $this->mylibrary->convertedcit($row['total_male_member'])?></strong></td>
                                        <td><strong><span>महिला सदस्य संख्या:</span> <?php echo $this->mylibrary->convertedcit($row['total_female_member'])?></strong></td>
                                        <td><strong><span>जम्मा सदस्य संख्या :</span> <?php echo $this->mylibrary->convertedcit($row['total_member'])?></strong></td>
                                        <td><strong><span>गठन मिति : </span><?php echo $this->mylibrary->convertedcit($row['gathan_miti'])?></strong></td>
                                    </tr>
                                    <tr>
                                        <td><strong><span>नियमित बैठक बस्ने दिन: </span> <?php echo $this->mylibrary->convertedcit($row['baithak_day'])?></strong></td>
                                        <td><strong><span>समुहको हितकोषमा संकलन हुने रकम: </span> <?php echo $this->mylibrary->convertedcit($row['rakam'])?></strong></td>
                                        <td colspan = 2><strong><span>समुहको हितकोषमा हालसम्म संकलित रकम: </span> <?php echo $this->mylibrary->convertedcit($row['total_rakam'])?></strong></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="card">
                    <header class="card-header text-light " style="background-color:#4d5886">व्यवसायीको विवरण</header>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                            <table class="table" id="add_new_fields">
                                <thead>
                                    <tr>
                                    <th>पुरा नाम थर</th>
                                    <th>पद</th>
                                    <th>शैक्षिक योग्यता</th>
                                    <th>उमेर</th>
                                    <th>जग्गा / पशु, चौपाया विवरण</th>
                                    <th>सम्पर्क नं.</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($members)) : foreach($members as $member) : ?>
                                    <tr>
                                    
                                    <td><?php echo $this->mylibrary->convertedcit($member['full_name'])?></td>
                                    <td><?php echo $this->mylibrary->convertedcit($member['deg'])?></td>
                                    <td><?php echo $this->mylibrary->convertedcit($member['qualification'])?></td>
                                    <td><?php echo $this->mylibrary->convertedcit($member['age'])?></td>
                                    <td><?php echo $this->mylibrary->convertedcit($member['jagga'])?></td>
                                    <td><?php echo $this->mylibrary->convertedcit($member['contact_no'])?></td>
                                    </tr>
                                    <?php endforeach;endif;?>
                                </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>
               
            </aside>
            <aside class="profile-nav col-lg-3">
                <section class="card">
                    <div class="user-heading round">
                        <!-- <a href="#" data-toggle="modal" data-target="#editModel" data-url="<?php //echo base_url()?>Register/updatePhoto" data-id = "<?php //echo $row['id']?>">
                            <img src="<?php //echo base_url()?>assets/business_owner/<?php //echo !empty($row['image'])?$row['image']:'emt.jpg'?>" alt="">
                        </a>  -->
                        <h1><?php echo !empty($row['samuha_name'])?$row['samuha_name']:''?></h1>
                        <p>(<?php echo $row['samuha_type']?>)</p>
                        <p><?php echo $row['tol'].'-'.$this->mylibrary->convertedcit($row['p_ward']).' ,'.$this->mylibrary->convertedcit($row['p_gapa'])?>,<?php echo $row['p_district'];?><br><?php echo $row['p_pardesh'];?></p>
                    </div>

                    <ul class="nav nav-pills nav-stacked">
                        <li class="active nav-item"><a class="nav-link" href="<?php echo base_url()?>AgricultureDepartment/edit/<?php echo $row['id']?>"> <i class="fa fa-pencil"></i> विवरण सम्पादन गर्नुहोस्</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo base_url()?>AgricultureDepartment/printcertificate/<?php echo $row['id']?>" target="_blank"> <i class="fa fa-print"></i>प्रमाणपत्र प्रिन्ट गर्नुहोस् </a></li>
                        <!-- <li class="nav-item"><a class="nav-link" href="<?php echo base_url()?>AgricultureDepartment/listNabikarnDetails/<?php echo $row['id']?>"> <i class="fa fa-file"></i>नवीकरणको विवरण </a></li> -->
                        
                    </ul>

                </section>
            </aside>
        </div>   
    </section>
</section><!--main content end-->
