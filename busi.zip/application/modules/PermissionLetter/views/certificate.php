<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>

  <style>
  .title {
    height: 45px;
    width: 485px;
    border: 1px solid #555;
    margin-left: 160px;
     border-radius: 25px; 
    /* border-radius: 25px; */
    margin-top: 55px;
  }

  /*.stamp {*/
    /* border: 2px solid #555; */
    /* height: 62px;
    width: 202px;
     */
  /*  margin-left: 487px;*/
  /*  border-radius: 5px;*/
  /*  text-align:right;*/
  /*  margin-right:120px;*/
  /*  margin-top: 50px;*/
  /*}*/


   @page { 
        size: landscape;
    }
    /* body { 
        writing-mode: tb-l;
    } */
  </style>
</head>

<body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle">
          <h3 class=""><?php echo GNAME ?> </h3>
          <h4><?php echo SLOGAN ?></h4>
          <h6 style="margin-top:-10px;"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6 style="margin-top:-5px;"><?php echo STATENAME ?>,नेपाल</h6>

        </div>
        <div class="header-right">
          <div class="">
            
          </div>
        </div>
      </div>

      <!--<div class="stamp">-->
        <p style="font-size:18px;margin-top:16px;margin-left:45px;">दर्ता नं.:
          <?php echo $this->mylibrary->convertedcit($row['darta_no'].'/'.$row['fiscal_year']) ?></p>
        <p style="font-size:18px;margin-top:-49px;margin-left:695px;">मिति:
          <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></p>
      <!--</div>-->


      <div class="sub-header">
        <div class="title">
          <p style="margin-left:57px;font-size:26px;margin-top:3px;"><b>भारि उपकरण संचालन अनुमति पत्र</b></p>
        </div>

      </div>
      <div>


        <div style="margin-left:50px; margin-top:35px; margin-right:50px;">
          <p style="font-size:22px;text-align:justify"><?php echo $row['gapa_napa']?> क्षेत्र भित्र विभिन्न निर्माण कार्यमा भारि उपकरण प्रयोग गर्न अनुमति पाउँ भनि <?php echo $row['gapa_napa']?> वडा नं. <?php echo $this->mylibrary->convertedcit($row['ward_no'])?> बस्ने श्री <?php echo $row['name']?>ले यस कार्यलयमा निवेदन दिनु भएको हुँदा <?php echo $row['gapa_napa']?>को <?php echo $row['bidi']?> गाउँसभावाट पारित आ. व. <?php echo $this->mylibrary->convertedcit($row['fiscal_year'])?> को परिधि भित्र रही <?php echo $this->mylibrary->convertedcit($row['sawari_no'])?> नं. को भारि उपकरण प्रयोग गर्न यो अनुमिति पत्र प्रदान गरिएको छ ।</p>
        </div>

        <div style="margin-top:80px;text-align:right;margin-right:120px">
          <p style="font-size:16px"><?php echo $checker['name'] ?></p>
          <p style="font-size:16px;margin-top:-15px;margin-left:0px;"><?php echo $checker['designation'] ?></p>
        </div>
       
      </div>
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
// $(document).ready(function(){
//     $('#printme').on("click", function () {
//         $('.hideme').hide();
window.print();
//     });
// });
</script>

</html>