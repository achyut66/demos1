<style type="text/css">
  .card-header{
    background: #1b5693;
  }
</style>
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url()?>"> ड्यासबोर्डमा</a></li>
        <li class="breadcrumb-item"><a href="<?php echo base_url()?>RasaynikMaal">रासायनिक मल बिक्रेता सुची </a></li>
        <li class="breadcrumb-item"><a href="javascript:;">नयाँ थप्नुहोस्</a></li>
      </ol>
    </nav>

    <form class="form" method="post" action="<?php echo base_url()?>RasaynikMaal/update" enctype ="multipart/form-data">
      <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
      <input type="hidden" name="id" value="<?php echo $row['id']?>">
      <div class="row">
        <div class="col-sm-12">
           <?php $ERR_VALIDATION = $this->session->flashdata("ERR_VALIDATION");
              if(!empty($ERR_VALIDATION)) { ?>
              <div class="alert alert-danger">
                  <button class="close" data-close="alert"></button>
                  <span> <?php echo $ERR_VALIDATION;?> </span>
              </div>
            <?php } ?>
          <?php $success_message = $this->session->flashdata("MSG_EMP");
              if(!empty($success_message)) { ?>
              <div class="alert alert-success">
                  <button class="close" data-close="alert"></button>
                  <span> <?php echo $success_message;?> </span>
              </div>
            <?php } ?>

             <?php $ERR_UPLOAD = $this->session->flashdata("ERR_UPLOAD");
              if(!empty($ERR_UPLOAD)) { ?>
              <div class="alert alert-success">
                  <button class="close" data-close="alert"></button>
                  <span> <?php echo $ERR_UPLOAD;?> </span>
              </div>
            <?php } ?>
          <section class="card">
            <header class="card-header text-light ">विवरण दाखिला गर्नुहोस</header>
            <div class="card-body">
              <div class="row">
                  <div class="col-md-3">
                    <div class="form-group">
                      <label><b>दर्ता नं</b><span style="color: red">*</span></label>
                      <input type="text" class="form-control darta_no" placeholder=""  name="darta_no" value="<?php echo $row['darta_no']?>" readonly >
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="form-group">
                    <label><b>कार्यविधि</b><span style="color: red">*</span></label>
                      <select class="form-control searchable" name="karyawidi" required>
                        <option value="">छान्नुहोस् </option>
                        <?php if(!empty($karyabids)): foreach($karyabids as $kb) : ?>
                          <option value = "<?php echo $kb['detail']?>" <?php if($kb['detail'] == $row['bidi']){ echo 'selected';}?>><?php echo $kb['detail']?></option>
                        <?php endforeach;endif;?>
                      </select>
                      
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="form-group">
                      <label>समुहको नाम<span style="color: red">* [ <input type="checkbox" name="is_personal" value="1" id="is_personal" <?php if($row['is_personal'] == '1'){echo "checked";} ?>> यदी व्यक्तिगत भएमा ]</span></label>
                      

                      <div class="exitings_name">
                        <?php if($row['is_personal'] != 1 ) : ?>
                        <select class="form-control searchable" name="samuha_name">
                        <?php if(!empty($samuha)) : foreach($samuha as $key => $group) : ?>
                        <option value="<?php echo $group['samuha_name']?>" <?php if($group['samuha_name'] == $row['name']){ echo 'selected';}?>><?php echo $group['samuha_name']?></option>
                        <?php endforeach;endif;?>
                        </select>
                        <?php else : ?>
                        <input type="text" class="form-control samuha_name" placeholder=""  name="samuha_name" value="<?php echo $row['name']?>">
                        <?php endif;?>
                      </div>


                      
                      <div class="samuha">
                        <select class="form-control searchable" name="samuha_name">
                        <?php if(!empty($samuha)) : foreach($samuha as $key => $group) : ?>
                        <option value="<?php echo $group['samuha_name']?>" <?php if($group['samuha_name'] == $row['name']){ echo 'selected';}?>><?php echo $group['samuha_name']?></option>
                        <?php endforeach;endif;?>
                        </select>
                      </div>
                      <div class="personal">
                        <input type="text" class="form-control samuha_name" placeholder=""  name="name" value="" id="exiting_name">
                      </div>
                      
                    </div>
                  </div>

                  <div class="col-md-3">
                    <div class="form-group">
                      <label class="">प्रदेश </label>
                        <select class="form-control searchable dd_select npl_state" name="p_pardesh" required id="state-2">
                        <option value="">छान्नुहोस्</option>
                        <?php if(!empty($pradesh)) : 
                            foreach ($pradesh as $key => $p) : ?>
                              <option value="<?php echo $p['Title']?>" <?php if($p['Title'] == $row['pradesh']) {echo 'selected';}?>><?php echo $p['Title']?></option>
                        <?php endforeach;endif;?>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="form-group">
                      <label class="">जिल्ला</label>
                      <select class="form-control  searchable dd_select npl_district" id="district-2" required name="p_district" >
                        <option value=""></option>
                        <?php if(!empty($districts)) : 
                            foreach($districts as $d) :?>
                              <option value="<?php echo $d['name']?>" <?php if($d['name'] == $row['district']) {echo 'selected';}?>><?php echo $d['name']?></option>
                        <?php endforeach;endif;?>
                      </select>
                    </div>
                  </div>

                  <div class="col-md-3">
                    <div class="form-group">
                      <label class="">ग.पा / न. पा</label>
                      <select class="form-control npl_gapana searchable dd_select select_option" name="p_gapa" id="gapa-2" required>
                        <?php if(!empty($gapana)) :
                          foreach ($gapana as $key => $gp) : ?>
                            <option value="<?php echo $gp['name']?>"
                              <?php if($gp['name'] == $row['gapa_napa']){
                                echo 'selected';
                              } ?>
                              ><?php echo $gp['name']?></option>
                        <?php endforeach;endif;?>
                      </select>
                    </div>
                  </div>

                  <div class="col-md-3">
                    <div class="form-group">
                      <label class="">वडा </label>
                      <select class="select_option searchable form-control npl_state" name = "p_ward" >
                        <option value = "">छानुहोस</option>
                        <?php if(!empty($wards)) : 
                          foreach ($wards as $key => $w) : ?>
                          <option value="<?php echo $w['name']?>"  <?php if($w['name'] == $row['ward_no']){ echo 'selected';} ?>><?php echo $this->mylibrary->convertedcit($w['name'])?></option>
                        <?php endforeach;endif;?>
                      </select>
                    </div>
                  </div>
                  
                  <div class="col-md-3">
                    <div class="form-group">
                     <label>टोल <span style="color: red">*</span></label>
                     <input type="text" class="form-control tol" placeholder=""  name="tol" value="<?php echo $row['tol']?>">
                    </div>
                  </div>
              </div>
          </section>
        </div>
       
        <div class="col-md-12 text-center">
          <hr>
          <button class="btn btn-primary btn-xs btn-save save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्" name="Submit" type="submit" value="Submit" id="btn_save_details"> सेभ गर्नुहोस्</button>
          <a href="<?php echo base_url()?>RasaynikMaal" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
        </div>
      </div>
  </form>
  </section>
</section>
<script type="text/javascript" src="<?php echo base_url()?>assets/assets/select2/js/select2.min.js"></script>
<script>
  $(document).ready(function(){
     $('.personal').hide();
     $('.samuha').hide();
    $('#male_member, #female_member').keyup(function() {
      obj = $(this);
      var male_member = $('#male_member').val()||0;
      var female_member = $('#female_member').val()||0;
      var total = parseInt(male_member) + parseInt(female_member);
      $('#total_member').val(total); 
    });

    $('.npl_state').change( function (){
      var id_selected     = $(this).attr("id");
      var res             = id_selected.split("-");
      var id              = res[res.length - 1];
      var state           = $(this).val();
      $.ajax({
        url:base_url+'CommonController/getDistrictByStateName',
        method:"POST",
        data:{state:state,'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'},
        success : function(resp){
          if(resp.status == 'success') {
            $('#district-'+id).html(resp.option);
          }
        }
      });
    });

    $('.npl_district').change( function (){
      var id_selected     = $(this).attr("id");
      var res             = id_selected.split("-");
      var id              = res[res.length - 1];
      var district           = $(this).val();
      $.ajax({
        url:base_url+'CommonController/getGapaByStateName',
        method:"POST",
        data:{district:district,'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'},
        success : function(resp){
          if(resp.status == 'success') {
            $('#gapa-'+id).html(resp.option);
          }
        }
      });
    });

    //add new row
    $('.btnAddNew').click(function(e) {
      e.preventDefault();
        var trOneNew = $('.nagadi_rasid_frm').length+1;
        var new_row = 
        '<tr>'+
          '<td><input type="text" name="full_name[]" value="" class="form-control" required></td>'+
          '<td><input type="text" name="deg[]" value="" class="form-control" required></td>'+
          '<td><input type="text" class="form-control" placeholder="" name="qualification[]" required="required" value=""></td>'+
          '<td><input type="text" class="form-control" placeholder="" name="age[]" required="required" value=""></td>'+
          '<td><input type="text" class="form-control" placeholder="" name="jagga[]" required="required" value=""></td>'+
          '<td><input type="text" class="form-control number_field" placeholder="" name="contact_no[] " required="required" value=""></td>'+
          '<td><button type="button" class="btn btn-danger btn-block remove-row" data-toggle="tooltip" title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>'+
        '<tr>'
        $("#add_new_fields").append(new_row);
    });
    $("body").on("click",".remove-row", function(e){
          e.preventDefault();
          
          if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
           var amt = $(this).closest("tr").find('.topic_rate').val();
           var t_amt = $('#t_total').val();
           var new_amt = t_amt-amt;
           $("#t_total").val(new_amt);
           $(this).parent().parent().remove();
          }
        });

    $(document).on('change', '#is_personal' ,function() {
      $('.exitings_name').hide();
      if ($('#is_personal').is(':checked')) {
         $('.personal').show();
         $('.samuha').hide();
      } else {
        var value = "<?php echo $row['name']?>";
        $('#exiting_name').val(value);
        $('.personal').hide();
        $('.samuha').show();
      }
    });
  });
</script>