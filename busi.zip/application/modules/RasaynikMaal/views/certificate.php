<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>

  <style>
 .title {
    height: 45px;
    width: 485px;
    border: 1px solid #555;
    margin-left: 590px;
    border-radius: 25px;
    text-align:center;
    /* border-radius: 25px; */
    margin-top: 30px;
  }

  /*.stamp {*/
    /* border: 2px solid #555; */
    /* height: 62px;
    width: 202px;
     */
  /*  margin-left: 487px;*/
  /*  border-radius: 5px;*/
  /*  text-align:right;*/
  /*  margin-right:120px;*/
  /*  margin-top: 50px;*/
  }
@page { 
        size: landscape;
    }
  </style>
</head>

<body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle" style="margin-left:-90px;">
          <h3 class=""><?php echo GNAME ?> </h3>
          <h4><?php echo 'कृषि विकाश शाखा ' ?></h4>
          <h6 style="margin-top:-5px;"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6 style="margin-top:-5px;"><?php echo STATENAME ?>,नेपाल</h6>

        </div>
        <div class="header-right">
          <div class="">

          </div>
        </div>
      </div>

      <div class="stamp text-left" style="margin-left:52px; margin-top:-118px; color:red;">
        <p class="text-left" style="margin-right:90px;margin-top:128px;">दर्ता नं.
          <?php echo $this->mylibrary->convertedcit($row['darta_no'])?>/<?php echo $this->mylibrary->convertedcit($row['fiscal_year']) ?></p>
        <p class="text-left" style="margin-left:425px;margin-top:-32px;">दर्ता मिति:
          <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></p>
      </div>


      <div class="sub-header" style="margin-left:-506px;font-size:26px;margin-top:45px;">
        <div class="title">
         <p><b>रासायनिक मल बिक्रेता प्रमाण-पत्र</b></p>
        </div>
      </div>
      <div>


        <div style="margin-left:60px; margin-top:65px; margin-right:50px;">
           <p style="font-size:22px;text-align:justify">यस गाउँपालिकामा रासायनिक मल वितरण कार्यलाई टेवा 
           पुर्याउने उदेश्यले यस <?php echo $row['district']?> जिल्ला
            <?php echo $row['gapa_napa']?>
            वडा नं-<?php echo $this->mylibrary->convertedcit($row['ward_no'])?>, स्थित
             श्री
            <b><?php echo $row['name']?></b> लाई <?php echo $row['bidi']?> बमोजिम यस कार्यलायको अभिलेखमा दर्ता गरि यो
            प्रमाण पत्र प्रदान गरिएको छ |
          </p>
        </div>

        <div style="margin-top:180px;margin-left:35px;">
          <p style="font-size:16px">( <?php echo $maker['name'] ?> )</p>
          <p style="font-size:16px;margin-top:-15px;margin-left:0px;"><?php echo $maker['designation'] ?></p>
        </div>
        <div style=" text-align:right; margin-right:120px;margin-top:-68px">
          <p style="font-size:16px">( <?php echo $checker['name'] ?> )</p>
          <p style="font-size:16px;margin-top:-15px;margin-left:0px;"><?php echo $checker['designation'] ?></p>
        </div>
      </div>
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
// $(document).ready(function(){
//     $('#printme').on("click", function () {
//         $('.hideme').hide();
window.print();
//     });
// });
</script>

</html>