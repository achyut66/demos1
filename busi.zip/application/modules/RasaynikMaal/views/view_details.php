 <!--main content start-->
 <style>
     .table-bordered td,
     .table-bordered th {
         border: 1px solid #3a5d7f;
     }
 </style>
 <section id="main-content">
     <section class="wrapper site-min-height">
         <nav aria-label="breadcrumb">
             <ol class="breadcrumb">
                 <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"><i class="fa fa-home"></i> ड्यासबोर्डमा</a></li>
                 <li class="breadcrumb-item active"><a href="<?php echo base_url() ?>RasaynikMaal" class="bactive"> रासायनिक मल बिक्रेता सुची</a></li>
                 <li class="breadcrumb-item active"><a href="javascript:;" class="bactive">विवरण हेर्नुहोस</a></li>
             </ol>
         </nav>
         <!-- page start-->
         <div class="row">
             <aside class="profile-info col-lg-9">
                 <section class="card">
                     <header class="card-header text-light " style="background-color:#4d5886">समुहको नाम: <?php echo $row['name'] ?> <span class="btn btn-success btn-circle"> दर्ता नं. <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?></span>
                     </header>
                     <div class="card-body">
                         <div class="row">
                             <div class="col-md-12">
                                 <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
                                    if (!empty($success_message)) { ?>
                                     <div class="alert alert-success">
                                         <button class="close" data-close="alert"></button>
                                         <span> <?php echo $success_message; ?> </span>
                                     </div>
                                 <?php } ?>

                                 <?php $err_message = $this->session->flashdata("MSG_ERR");
                                    if (!empty($err_message)) { ?>
                                     <div class="alert alert-danger">
                                         <button class="close" data-close="alert"></button>
                                         <span> <?php echo $err_message; ?> </span>
                                     </div>
                                 <?php } ?>
                                 <?php $err_message = $this->session->flashdata("MSG_WAR");
                                    if (!empty($err_message)) { ?>
                                     <div class="alert alert-warning">
                                         <button class="close" data-close="alert"></button>
                                         <span> <?php echo $err_message; ?> </span>
                                     </div>
                                 <?php } ?>


                                 <table class="table table-bordered">
                                     <tr>
                                         <td><strong><span>दर्ता मिति: </span><?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></strong></td>
                                         <td colspan=2><strong><span> ठेगाना: </span><?php echo $row['tol'] ?>-<?php echo $this->mylibrary->convertedcit($row['ward_no']) ?>,<?php echo $row['district']; ?>,<?php echo $row['pradesh']; ?></strong></td>
                                     </tr>
                                    
                                 </table>
                             </div>
                         </div>
                     </div>
                 </section>
             </aside>
             <aside class="profile-nav col-lg-3">
                 <section class="card">
                     <div class="user-heading round">
                        
                         <h1><?php echo !empty($row['name']) ? $row['name'] : '' ?></h1>
                         <p><?php echo $row['tol'] . '-' . $this->mylibrary->convertedcit($row['ward_no']) . ' ,' . $this->mylibrary->convertedcit($row['gapa_napa']) ?>,<?php echo $row['district']; ?><br><?php echo $row['pradesh']; ?></p>
                     </div>

                     <ul class="nav nav-pills nav-stacked">
                         <li class="active nav-item"><a class="nav-link" href="<?php echo base_url() ?>RasaynikMaal/edit/<?php echo $row['id'] ?>"> <i class="fa fa-pencil"></i> विवरण सम्पादन गर्नुहोस्</a></li>
                         <li class="nav-item"><a class="nav-link" href="<?php echo base_url() ?>RasaynikMaal/printcertificate/<?php echo $row['id'] ?>" target="_blank"> <i class="fa fa-print"></i>प्रमाणपत्र प्रिन्ट गर्नुहोस् </a></li>
                     </ul>

                 </section>
             </aside>
         </div>
     </section>
 </section>
 <!--main content end-->