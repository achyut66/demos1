<?php

/**
 * Created by PhpStorm.
 * User: root
 * Date: 12/2/16
 * Time: 9:57 PM
 */
class RasaynikMaal extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->load->model("RmModel");
        $this->module_code = 'RASAINIK-MAAL';
        if (!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login', 'location');
        }
    }

    /** 
     * This function load add buy or sell form
     * @param NULL
     * return load view with list
     */
    public function Index()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $data['page']   = 'list_all';
            $data['fiscal_year'] = $this->CommonModel->getData('fiscal_year', 'DESC');
            $data['kirshisamuha'] = $this->CommonModel->getData('krishi_samuha_darta');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
     * This function load
     * @param NULL
     * return view
     */
    public function add()
    {
        $data['page']           = 'add';
        $data['wards']          = $this->CommonModel->getData('settings_ward', 'DESC');
        $data['districts']      = $this->CommonModel->getData('settings_district', 'DESC');
        $data['pradesh']        = $this->CommonModel->getData('provinces', 'DESC');
        $data['gapana']         = $this->CommonModel->getData('settings_vdc_municipality', 'DESC');
        $data['samuha']         = $this->CommonModel->getData('krishi_samuha_darta', 'DESC');
        $darta                  = $this->RmModel->GetMaxDartaID();
        $data['darta_no']       = $darta->darta_no + 1;
        $data['karyabids']      = $this->CommonModel->getData('karya_bidi');
        $this->load->view('main', $data);
    }
    //save 
    public function save()
    {
        if ($this->input->post('Submit')) {
            $darta_no                       = $this->input->post('darta_no');
            $fiscal_year                    = $this->input->post('fiscal_year');
            $darta_miti                     = $this->input->post('darta_miti');
            $samuha_name                    = $this->input->post('samuha_name');
            $p_pardesh                      = $this->input->post('p_pardesh');
            $p_district                     = $this->input->post('p_district');
            $p_gapa                         = $this->input->post('p_gapa');
            $p_ward                         = $this->input->post('p_ward');
            $tol                            = $this->input->post('tol');
            $is_personal                    = $this->input->post('is_personal');
            $name                           = $this->input->post('name');
            $karyawidi                      = $this->input->post('karyawidi');
            $save_array                     = array(
                'bidi'                      => $karyawidi,
                'name'                      => empty($is_personal)? $samuha_name:$name,
                'pradesh'                   => $p_pardesh,
                'district'                  => $p_district,
                'gapa_napa'                 => $p_gapa,
                'ward_no'                   => $p_ward,
                'tol'                       => $tol,
                'darta_no'                  => $darta_no,
                'fiscal_year'               => current_fiscal_year(),
                'darta_miti'                => convertDate(date('Y-m-d')),
                'status'                    => 1,
                'is_personal'               => $is_personal,
                'created_at'                => convertDate(date('Y-m-d')),
                'created_by'                => $this->session->userdata('PRJ_USER_BID'),
            );
            $result = $this->CommonModel->insertData('rasayenik_maal', $save_array);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                redirect('RasaynikMaal/viewDetails/' . $result);
            } else {
                $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                redirect('RasaynikMaal/Add');
            }
        }
    }

    //view details
    public function viewDetails($id)
    {
        if (empty($id)) {
            show_404();
        } else {
            $data['row']            = $this->CommonModel->getDataByID('rasayenik_maal', $id);
            //$data['members']        = $this->CommonModel->getWhereAll('rasayenik_maal', array('samuha_id' => $id));
            //$data['renew_details']  = $this->CommonModel->getWhereAll('renew', array('renew_type' => $this->uri->segment(1), 'darta_id' => $id));
            $data['page']           = 'view_details';
            $this->load->view('main', $data);
        }
    }


    public function edit($id)
    {
        $data['page']           = 'edit';
        $data['wards']          = $this->CommonModel->getData('settings_ward', 'DESC');
        $data['districts']      = $this->CommonModel->getData('settings_district', 'DESC');
        $data['pradesh']        = $this->CommonModel->getData('provinces', 'DESC');
        $data['prakar']         = $this->CommonModel->getData('main_topic');
        $data['category']       = $this->CommonModel->getData('category');
        $data['subtopic']       = $this->CommonModel->getData('prakar');
        $data['gapana']         = $this->CommonModel->getData('settings_vdc_municipality', 'DESC');
        $data['samuha']         = $this->CommonModel->getData('krishi_samuha_darta', 'DESC');
        $data['row']            = $this->CommonModel->getDataById('rasayenik_maal', $id);
        //pp($data['row']);
        $data['karyabids']      = $this->CommonModel->getData('karya_bidi');
        $this->load->view('main', $data);
    }

    //update details
    public function update()
    {
        if ($this->input->post('Submit')) {
            $id                             = $this->input->post('id');
            $darta_no                       = $this->input->post('darta_no');
            $fiscal_year                    = $this->input->post('fiscal_year');
            $darta_miti                     = $this->input->post('darta_miti');
            $samuha_name                    = $this->input->post('samuha_name');
            $name                           = $this->input->post('name');
            $p_pardesh                      = $this->input->post('p_pardesh');
            $p_district                     = $this->input->post('p_district');
            $p_gapa                         = $this->input->post('p_gapa');
            $p_ward                         = $this->input->post('p_ward');
            $tol                            = $this->input->post('tol');
            $is_personal                    = $this->input->post('is_personal');
            $karyawidi                      = $this->input->post('karyawidi');
            $save_array                     = array(
                'bidi'                      => $karyawidi,
                'name'                      => empty($is_personal)? $samuha_name:$name,
                'pradesh'                   => $p_pardesh,
                'district'                  => $p_district,
                'gapa_napa'                 => $p_gapa,
                'ward_no'                   => $p_ward,
                'tol'                       => $tol,
                'darta_no'                  => $darta_no,
                'darta_miti'                => convertDate(date('Y-m-d')),
                'is_personal'               => $is_personal,
                'modified_by'                => convertDate(date('Y-m-d')),
                'modified_at'                => $this->session->userdata('PRJ_USER_BID'),
            );
            $result = $this->CommonModel->updateData('rasayenik_maal', $id, $save_array);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                redirect('RasaynikMaal/viewDetails/'.$id);
            } else {
                $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                redirect('RasaynikMaal/');
            }
        }
    }

    //print certificate
    public function printcertificate($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row']            = $this->CommonModel->getDataById('rasayenik_maal', $id);
            $data['staffs']         = $this->CommonModel->getData('staff');
            $data['fiscal_year']    = $this->CommonModel->getData('fiscal_year');
            $this->load->view('print_details', $data);
        }
    }

    //print printPramanparta
    public function certificate($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row']            = $this->CommonModel->getDataById('rasayenik_maal', $id);
            $data['maker']          = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $data['checker']        = $this->CommonModel->getWhere('staff', array('id' => $data['row']['checker']));
            $data['fiscal_year']    = $this->CommonModel->getData('fiscal_year');
            $this->load->view('certificate', $data);
        }
    }
    //datatable list
    public function GetAllList()
    {
        if ($this->input->is_ajax_request()) {
            $columns = array(0      => 'id');
            $limit                  = $this->input->post('length');
            $start                  = $this->input->post('start');
            $fiscal_year            = $this->input->post('fiscal_year');
            $samuha_name            = $this->input->post('samuhan_name');
            $darta_no               = $this->input->post('darta_no');
            $darta_miti             = $this->input->post('darta_miti');
            $sn                     = $start + 1;
            $order                  = $columns[$this->input->post('order')[0]['column']];
            $dir                    = $this->input->post('order')[0]['dir'];
            $totalData              = $this->RmModel->CountAll($fiscal_year, $samuha_name, $darta_no, $darta_miti);
            $totalFiltered          = $totalData;
            $posts                  = $this->RmModel->GetAll($limit, $start, $order, $dir, $fiscal_year, $samuha_name, $darta_no, $darta_miti);
            $data                   = array();
            if (!empty($posts)) {
                $i = 1;
                foreach ($posts as $post) {
                    $nestedData['sn']               = $this->mylibrary->convertedcit($sn++);
                    $nestedData['id']               = $post->id;
                    $nestedData['name']             = $this->mylibrary->convertedcit($post->name);
                    $nestedData['address']          = $post->tol . '-' . $this->mylibrary->convertedcit($post->ward_no) . ',  ' . $post->gapa_napa;
                    $nestedData['darta_no']         = '<span class="badge badge-pill badge-secondary">' . $this->mylibrary->convertedcit($post->darta_no) . '</span>';
                    $nestedData['darta_date']       = $this->mylibrary->convertedcit($post->darta_miti);
                    
                    $data[] = $nestedData;
                }
            }
            $json_data = array(
                "draw"            => intval($this->input->post('draw')),
                "recordsTotal"    => intval($totalData),
                "recordsFiltered" => intval($totalFiltered),
                "data"            => $data
            );
            echo json_encode($json_data);
        } else {
            exit('HTTPS!!');
        }
    }

    public function updatePhoto()
    {
        $data['id'] = $this->input->post('id');
        $this->load->view('upload_photo', $data);
    }

    //update photo
    public function updateImage()
    {
        $id                         = $this->input->post('id');
        $userfile                   = $_FILES['userfile']['name'];
        $file                       =  preg_replace('/\s+/', '_', $userfile);
        if (!empty($userfile)) {
            $config = array(
                'upload_path'       => './assets/business_owner/',
                'allowed_types'     => "jpg|png|PNG|jpeg|JPEG",
                'max_size'          => 1024,
                'overwrite'         => TRUE,
                'file_name'         => preg_replace('/\s+/', '_', $file),
            );
            $this->load->library('upload');
            $this->upload->initialize($config);
            if (!$this->upload->do_upload('userfile')) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => 'Cannot upload image'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $this->upload->do_upload();
            }
            $update_array = array('image' => $file);
            $result = $this->CommonModel->updateData('darta', $id, $update_array);
            if ($result) {
                $response = array(
                    'status'        => 'success',
                    'message'       => 'redirect',
                    'redirect_url'  => base_url() . 'Register/viewDetails/' . $id,
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        }
    }



    //update maker
    public function updateMaker()
    {
        $id                 = $this->input->post('id');
        $maker              = $this->input->post('maker');
        $data               = array('maker' => $maker);
        $result             = $this->CommonModel->updateData('rasayenik_maal', $id, $data);
        if ($result) {
            $response       = array(
                'status'    => 'success',
                'data'      => "सफलतापूर्वक सम्मिलित गरियो",
                'message'   => 'success'
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
        }
    }

    //update checker
    public function updateChecker()
    {
        $id                 = $this->input->post('id');
        $checker            = $this->input->post('checker');
        $data               = array('checker' => $checker);
        $result             = $this->CommonModel->updateData('rasayenik_maal', $id, $data);
        if ($result) {
            $response       = array(
                'status'    => 'success',
                'data'      => "सफलतापूर्वक सम्मिलित गरियो",
                'message'   => 'success'
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
        }
    }

    //remove members
    public function removeMember($id, $faram_id)
    {
        if (empty($id)) {
            show_404();
        } else {
            $result = $this->CommonModel->deleteData('krishi_samuha_members', $id);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'Member removed successfully');
                redirect('AgricultureDepartment/edit/' . $faram_id);
            }
        }
    }

    /*-----------------------------------------------------------------------
        RENEW DETAILS
     ------------------------------------------------------------------------*/
    public function RenewDetails($id)
    {
        $data['page'] = 'renew_darta';
        $data['row'] = $this->CommonModel->getDataById('krishi_samuha_darta', $id);
        $renew_details = $this->CommonModel->getWhere('renew', array('fiscal_year_from' => current_fiscal_year(), 'darta_id' => $id));
        if (!empty($renew_details)) {
            $this->session->set_flashdata('MSG_SUCCESS', 'समूह नवीकरण भइसकेको छ');
            redirect('AgricultureDepartment');
        }
        $this->load->view('main', $data);
    }

    //save nabikarn details
    public function nabikaran()
    {
        if ($this->input->post('Submit')) {
            $samuha_id                  = $this->input->post('samuha_id');
            $darta_id                   = $this->input->post('darta_id');
            $darta_no                   = $this->input->post('darta_no');
            $b_type                     = $this->input->post('b_type');
            $b_subtype                  = $this->input->post('b_subtype');
            $date                       = $this->input->post('date');
            $fiscal_year_from           = $this->input->post('fiscal_year_from');
            $fiscal_year_to             = $this->input->post('fiscal_year_to');
            $rasid_no                   = $this->input->post('rasid_no');
            $dastur                     = $this->input->post('dastur');
            $remarks                    = $this->input->post('remarks');
            $rasid_no                   = $this->input->post('rasid_no');
            $save_array                 = array(
                'darta_id'              => $darta_id,
                'date'                  => $date,
                'darta_no'              => $darta_no,
                'b_type'                => '',
                'b_subtype'             => '',
                'fiscal_year_from'      => $fiscal_year_from,
                'fiscal_year_to'        => $fiscal_year_to,
                'rasid_no'              => $rasid_no,
                'dastur'                => $dastur,
                'remarks'               => $remarks,
                'fiscal_year'           => current_fiscal_year(),
                'created_at'            => convertDate(date('Y-m-d h:i:sa')),
                'created_by'            => $this->session->userdata('PRJ_USER_BID'),
                'added_ward'            => $this->session->userdata('PRJ_USER_WARD'),
                'renew_type'            => $this->uri->segment(1),
            );
            $result = $this->CommonModel->insertData('renew', $save_array);
            if ($result) {
                $renew_status = array('renew_status' => 1);
                $this->CommonModel->updateData('krishi_samuha_darta', $samuha_id, $renew_status);
                $this->session->set_flashdata('MSG_SUCCESS', 'तपाई नवकिरण गर्न सफल हुनुभयो');
                redirect('AgricultureDepartment');
            }
            // pp($save_array);
            // $darta_details = $this->CommonModel->getWhere('darta', array('id' => $darta_id));
            // if ($darta_details['fiscal_year'] == current_fiscal_year()) {
            //     $this->session->set_flashdata('MSG_WAR', 'नवीकरण गर्न मिल्दैन');
            //     redirect('Register/viewDetails/' . $darta_id);
            // }
            // $checkIfExits = $this->CommonModel->getWhere('renew', array('darta_id', 'fiscal_year' => current_fiscal_year()));
            // if (!empty($checkIfExits)) {
            //     $this->session->set_flashdata('MSG_ERR', 'नवीकरण गरिसकेको छ');
            //     redirect('Register/viewDetails/' . $darta_id);
            // }
            // $result = $this->CommonModel->insertData('renew', $save_array);
            // if ($result) {
            //     $this->session->set_flashdata('MSG_SUCCESS', 'तपाई नवकिरण गर्न सफल हुनुभयो');
            //     redirect('Register/viewDetails/' . $darta_id);
            // }
        }
    }

    //list nabikaran details
    public function listNabikarnDetails($darta_id)
    {
        $data['page']       = 'renew_darta_list';
        $data['renews']     = $this->CommonModel->getWhereAll('renew', array('darta_id' => $darta_id));
        $data['darta']      = $this->CommonModel->getWhere('darta', array('id' => $darta_id));
        $this->load->view('main', $data);
    }

    //edit renew
    public function editRenew($renewid)
    {
        $data['page'] = 'renew_darta_edit';
        $data['row'] = $this->CommonModel->getDataById('renew', $renewid);
        $this->load->view('main', $data);
    }

    //update reneew details
    public function updateRenew()
    {
        if ($this->input->post('Submit')) {
            $id                         = $this->input->post('id');
            $darta_id                   = $this->input->post('darta_id');
            $fiscal_year_from           = $this->input->post('fiscal_year_from');
            $fiscal_year_to             = $this->input->post('fiscal_year_to');
            $rasid_no                   = $this->input->post('rasid_no');
            $dastur                     = $this->input->post('dastur');
            $remarks                    = $this->input->post('remarks');
            $rasid_no                   = $this->input->post('rasid_no');
            $save_array                 = array(
                'fiscal_year_from'      => $fiscal_year_from,
                'fiscal_year_to'        => $fiscal_year_to,
                'rasid_no'              => $rasid_no,
                'dastur'                => $dastur,
                'remarks'               => $remarks,
                'modified_at'            => convertDate(date('Y-m-d h:i:sa')),
                'modified_by'            => $this->session->userdata('PRJ_USER_BID'),
            );
            $result = $this->CommonModel->updateData('renew', $id, $save_array);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'success');
                redirect('Register/listNabikarnDetails/' . $darta_id);
            }
        }
    }

    //delete renew
    public function deleteRenewDetails($id)
    {
        $row = $this->CommonModel->getDataById('renew', $id);
        if (!empty($row)) {
            $result = $this->CommonModel->deleteData('renew', $id);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'success');
                redirect('Register/listNabikarnDetails/' . $row['darta_id']);
            }
        }
    }

    //print renew certificate
    public function renewCertificate($darta_id)
    {
        $data['renewDetails'] = $this->CommonModel->getWhere('renew', array('darta_id' => $darta_id));
        if (empty($data['renewDetails'])) {
            $this->session->set_flashdata('MSG_ERR', 'नवीकरण गरिएको छैन. कृपया नवीकरण गर्नुहोस');
            redirect('Register/viewDetails/' . $darta_id);
        } else {
            $data['renewdetails'] = $this->CommonModel->getWhereAll('renew', array('darta_id' => $darta_id));
            $this->load->view('renew_certificate', $data);
        }
    }
}//end of class