<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/landscape_print.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>

  <style>
  .title{
  height: 45px;
    width: 425px;
    border: 1px solid #555;
    margin-left: 690px;
   
    margin-top: 50px;
}

  .stamp {
    /* border: 2px solid #555; */
    /* height: 62px;
    width: 202px;*/
    margin-top: 30px; 
    margin-left: 790px;
    border-radius: 5px;
  }
  /*@page { */
  /*      size: landscape;*/
  /*}*/
</style>
</head>

<body>
 <div class="main-wrapper">
    <div class="">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle" style="margin-right:160px;">
          <h3 class="palika-name"><?php echo GNAME ?> </h3>
          <h4 class = "slogan"><?php echo SLOGAN ?></h4>
          <h6 class ="address"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6 class ="address"><?php echo STATENAME ?>,नेपाल</h6>

        </div>
        <div class="header-right">
          <div class="">
          
          </div>
        </div>
      </div>

      <div class="stamp">
        <p style="font-size:18px;margin-top:-12px;margin-left:-739px;">आबद्धता न.:
          <?php echo $this->mylibrary->convertedcit($row['darta_no'].'-'.$row['fiscal_year']) ?></p>
      </div>


      <div class="sub-header" style="margin-left:-492px;font-size:26px;margin-top:3px;">
        <div class="title text-center">
          <p><b>आवद्धताको प्रमाण-पत्र</b></p>
        </div>

      </div>
      <div>

      <?php $date = explode('-', $row['n_date']);?>
        <div style="margin-left:50px; margin-top:70px; margin-right:50px;">
          <p style="font-size:22px;text-align:justify">
            <?php echo $row['district']?> जिल्ला <?php echo $row['gapa_napa']?> वडा नं. <?php echo $this->mylibrary->convertedcit($row['ward_no'])?> स्थित श्री <b><?php echo $this->mylibrary->convertedcit($row['name'])?></b> लाई  <?php echo $this->mylibrary->convertedcit($date[0]) ?> <?php echo getNepaliMonthName($date[1])?> <?php echo $this->mylibrary->convertedcit($date[2])?> गते यस कार्यालयमा अभिलेख राखी यो आबद्धताको प्रमाण पत्र प्रदान गरिएको छ । </p>
         
        </div>
        <hr style="border:2px solid black;">
          <div class="header-middle" style="margin-right:-32px;">
            <h3 class=""><?php echo GNAMEEN ?> </h3>
            <h4 class = ""><?php echo SLOGANEN ?></h4>
            <h6 class =""><?php echo ADDRESSEN . ',' . DISTRICTEN ?></h6>
            <h6 class =""><?php echo STATENAMEEN ?>,Nepal</h6>
          </div>
        <p style="font-size:18px;margin-top:-12px;margin-left:48px;">Affiliation No: <?php echo $row['darta_no'].'/'.$row['fiscal_year']?></p>
      <div class="sub-header">
        <div class="">
          <p style="text-align:center; margin-left:37px;font-size:26px;margin-top:3px; text-decoration:underline;"><b>CERTIFICATE OF AFFILIATION</b></p>
        </div>
      </div>
        <div style="margin-left:50px; margin-top:80px; margin-right:50px;">
          <p style="font-size:22px;text-align:justify">
         This certificate of Affiliation has been issused to <?php echo $row['name_en']?> on <?php echo convertNepDate($row['n_date'])?>.</p>
        </div>

        <div style="margin-top:60px;margin-left:578px;">
          <p style="font-size:16px"><?php echo $checker['name'] ?></p>
          <p style="font-size:16px;margin-top:-15px;margin-left:-4px;"><?php echo $checker['designation'] ?></p>
        </div>
       
      </div>
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
// $(document).ready(function(){
//     $('#printme').on("click", function () {
//         $('.hideme').hide();
window.print();
//     });
// });
</script>

</html>