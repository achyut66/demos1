<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/landscape.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>

  <style>
  
   @page { 
        size: landscape;
    }
    /* body { 
        writing-mode: tb-l;
    } */
  </style>
</head>

<body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle">
          <h3 class="palika-name"><?php echo GNAME ?> </h3>
          <h4 class = "slogan"><?php echo SLOGAN ?></h4>
          <h6 class ="address"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6 class ="address"><?php echo STATENAME ?>,नेपाल</h6>

        </div>
        <div class="header-right">
          <div class="">
            <a href="<?php echo base_url()?>Affiliation/certificate/<?php echo $row['id']?>" target="_blank"
              class="btn btn-info btn-sm" style="margin-top:10px;"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस </a>
            <a href="<?php echo base_url()?>Affiliation" class="btn btn-success btn-sm"
              style="margin-top:10px;">दर्ता
              सुचीमा जानुहोस </a>
          </div>
        </div>
      </div>

      <div class="stamp">
        <p style="font-size:18px;margin-top:-12px;margin-left:20px;">आबद्धता न.:
          <?php echo $this->mylibrary->convertedcit($row['darta_no'].'-'.$row['fiscal_year']) ?></p>
      </div>


      <div class="sub-header">
        <div class="title">
          <p style="margin-left:37px;font-size:26px;margin-top:3px;"><b>आवद्धताको प्रमाण-पत्र</b></p>
        </div>

      </div>
      <div>

      <?php $date = explode('-', $row['n_date']);?>
        <div style="margin-left:50px; margin-top:80px; margin-right:50px;">
          <p style="font-size:22px;text-align:justify">
            <?php echo $row['district']?> जिल्ला <?php echo $row['gapa_napa']?> वडा नं. <?php echo $this->mylibrary->convertedcit($row['ward_no'])?> स्थित श्री <b><?php echo $this->mylibrary->convertedcit($row['name'])?></b> लाई  <?php echo $this->mylibrary->convertedcit($date[0]) ?> <?php echo getNepaliMonthName($date[1])?> <?php echo $this->mylibrary->convertedcit($date[2])?> गते यस कार्यालयमा अभिलेख राखी यो आबद्धताको प्रमाण पत्र प्रदान गरिएको छ । </p>
         
        </div>
          <div class="header-middle">
            <h3 class=""><?php echo GNAMEEN ?> </h3>
            <h4 class = ""><?php echo SLOGANEN ?></h4>
            <h6 class =""><?php echo ADDRESSEN . ',' . DISTRICTEN ?></h6>
            <h6 class =""><?php echo STATENAMEEN ?>,Nepal</h6>
          </div>
        <p style="font-size:18px;margin-top:-12px;margin-left:800px;">Affiliation No: <?php echo $row['darta_no']?></p>
      <div class="sub-header">
        <div class="">
          <p style="text-align:center; margin-left:37px;font-size:26px;margin-top:3px; text-decoration:underline;"><b>CERTIFICATE OF AFFILIATION</b></p>
        </div>
      </div>
        <div style="margin-left:50px; margin-top:80px; margin-right:50px;">
          <p style="font-size:22px;text-align:justify">
         This certificate of Affiliation has been issused to <?php echo $row['name_en']?> on <?php echo convertNepDate($row['n_date'])?></p>
        </div>
        <div style="border-top: dotted 2px #000; width:100px;margin-left:690px;margin-top:45px">
          <p style="font-size:18px"><select class="" id="checker">
              <option value=""> प्रमाणित गर्नेको नाम छान्नुहोस्</option>
              <?php if(!empty($staffs)) : foreach($staffs as $staf):?>
              <option value="<?php echo $staf['id']?>" <?php if($row['checker'] == $staf['id']){echo 'selected';}?>><?php echo $staf['name']?>(<?php echo $staf['designation']?>)</option>
              <?php endforeach;endif;?>
            </select></p>
        </div>
      </div>
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
$(document).ready(function() {
  var base_url = "<?php echo base_url() ?>";
  $('#maker').change(function() {
    obj = $(this);
    var maker = obj.val();
    var id = "<?php echo $this->uri->segment(3) ?>";
    $.ajax({
      url: base_url + 'RasaynikMaal/updateMaker',
      method: "POST",
      data: {
        maker: maker,
        id: id,
        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
      },
      success: function(resp) {
        if (resp.status == 'success') {
          location.reload();
        }
      }
    });
  });
  $('#checker').change(function() {
    obj = $(this);
    var checker = obj.val();
    var id = "<?php echo $this->uri->segment(3) ?>";
    $.ajax({
      url: base_url + 'Affiliation/updateChecker',
      method: "POST",
      data: {
        checker: checker,
        id: id,
        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
      },
      success: function(resp) {
        if (resp.status == 'success') {
          location.reload();
        }
      }
    });
  });
});
</script>

</html>