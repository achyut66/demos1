<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="">
		<title><?php echo GNAME?></title>
        <!-- <link href="<?php //echo base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php //echo base_url()?>assets/css/bootstrap-reset.css" rel="stylesheet">
		<link href="<?php //echo base_url()?>assets/assets/font-awesome/css/font-awesome.css" rel="stylesheet" /> -->
		<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/a4size.css">
	</head>
	<body class="document">
		<div class="page">
            <table class="table">
                <thead>
                    <tr>
                        <th>नवीकरण मिति </th>
                        <th>नवीकरण अवधि</th>
                        <th>रसिद नं.</th>
                        <th>दस्तुर</th>
                        <th>दस्तख</th>
                        <th>कैफियत</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($renewdetails)) : foreach($renewdetails as $renew) : ?>
                    <tr>
                        <td><?php echo $this->mylibrary->convertedcit($renew['date'])?></td>
                        <td><?php echo $this->mylibrary->convertedcit($renew['fiscal_year_from']).'-'.$this->mylibrary->convertedcit($renew['fiscal_year_to'])?></td>
                        <td><?php echo $this->mylibrary->convertedcit($renew['rasid_no'])?></td>
                        <td><?php echo $this->mylibrary->convertedcit($renew['dastur'])?></td>
                        <td><?php echo $this->mylibrary->convertedcit($renew[])?></td>
                        <td><?php echo $this->mylibrary->convertedcit($renew['remarks'])?></td>
                    </tr>
                    <?php endforeach;endif;?>
                    
                </tbody>
            </table>
        </div>
		<script src="<?php echo base_url()?>assets/js/jquery.js"></script>
        <script type="text/javascript">
            //window.print();
        </script>
	</body>
</html>