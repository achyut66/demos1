<!--main content start-->
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url()?>">ड्यासबोर्डमा जानुहोस </a></li>
        <li class="breadcrumb-item" ><a href="javascrip:;">स्थानीय सरकार सञ्‍चालन ऐन, २०७४ को दफा ११ उपदफा २ (ञ) ६ तथा बेनीघाट रोराङ गाउँपालिका आर्थिक ऐन सुची</a></li>
      </ol>
    </nav>
    <!-- page start-->
    <div class="row">
      <div class="col-sm-12">
        <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
            if(!empty($success_message)) { ?>
            <div class="alert alert-success">
                <button class="close" data-close="alert"></button>
                <span> <?php echo $success_message;?> </span>
            </div>
          <?php } ?>
        <section class="card">
          <header class="card-header">
          स्थानीय सरकार सञ्‍चालन ऐन
          <span class="tools">
            <?php if($this->authlibrary->HasModulePermission('YAIN', "ADD")) { ?>
            <button type="button" data-toggle="modal" href="#addModel" class="btn btn-secondary pull-right" data-url="<?php echo base_url()?>SarkarYain/add"><i class="fa fa-plus-circle"></i> नया वर्ग थप्नुहोस्</button>
            <?php } ?>
          </span>
          </header>
          <div class="card-body">
            <div class="adv-table">
            <table  class="table table-lightbordered table-striped" id="dataTable1">
                      <thead>
                        <tr>
                          <th class="">#</th>
                          <th>ऐन</th>
                          <th>आर्थिक वर्ष</th>
                          <?php if($this->authlibrary->HasModulePermission('YAIN', "EDIT") || $this->authlibrary->HasModulePermission('YAIN', "DELETE") ) { ?>
                            <th>कार्य</th>
                          <?php } ?>
                        </tr>
                      </thead>
                      <tbody>
                        <?php if(!empty($rules)) :
                          $i = 1;
                          foreach($rules as $key => $value) : ?>
                          <tr>
                            <td class=""><?php echo $this->mylibrary->convertedcit($i++)?></td>
                            <td><?php echo $this->mylibrary->convertedcit($value['rules'])?></td>
                            <td><?php echo $this->mylibrary->convertedcit($value['fiscal_year'])?></td>
                            <?php if($this->authlibrary->HasModulePermission('YAIN', "EDIT") || $this->authlibrary->HasModulePermission('Yain', "DELETE") ) { ?>
                              <td class="row-actions">
                                <?php if($this->authlibrary->HasModulePermission('YAIN', "EDIT")) { ?>
                                <button type="button" data-toggle="modal" href="#editModel" class="btn btn-info"  data-url="<?php echo base_url()?>SarkarYain/edit" data-id = "<?php echo $value['id']?>"><i class="fa fa-pencil"></i></button>
                                <?php } ?>
                                <?php if($this->authlibrary->HasModulePermission('YAIN', "DELETE") ) { ?>
                                  <a class="btn btn-danger" title=" विवरण हटानुहोस" href="<?php echo base_url()?>SarkarYain/Delete/<?php echo $value['id']?>" onclick="javascript:return confirm('Are you sure you want to delete this comment?')"><i class="fa fa-trash-o"></i></a>
                                <?php } ?>
                              </td>
                            <?php } ?>
                          </tr>
                        <?php endforeach;endif; ?>
                      </tbody>
                    </table>
            </div>
          </div>
        </section>
      </div>
    </div>
    <!-- page end-->
  </section>
</section>