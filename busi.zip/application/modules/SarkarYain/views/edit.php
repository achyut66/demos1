<form action="<?php echo base_url() ?>SarkarYain/Update" method="post" class="form save_post">
<button aria-label="Close" class="close" data-dismiss="modal" type="button"><span class="fa fa-times"></span></button>
<div class="onboarding-content with-gradient">
  <h4 class="onboarding-title">
    स्थानिय सरकार संचालन ऐन सम्पादन गर्नुहोस
  </h4>
  <div class="onboarding-text">
    <span class="text-danger">[ कृपया * चिन्न लगाएको ठाउँ खाली नछोड्नुहोला ] </span>
  </div>
  <hr>
    <div class="onboarding-text">
      <select class="form-control" name="fiscal_year" required><option value = ""> आर्थिक वर्ष छान्नुहोस्</option>
        <?php if(!empty($fiscal_year)) : foreach($fiscal_year as $fy) : ?>
        <option value = "<?php echo $fy['year']?>" <?php if($fy['year'] == $row['fiscal_year']){ echo 'selected';}?>><?php echo $fy['year']?></option>
        <?php endforeach; endif;?>
      </select>
    </div>
    <hr>

    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
    <div class="row">
      <div class="col-sm-12">
        <div class="form-group">
          <label for="">ऐन<span class="text-danger"> * </span></label>
          <input class="form-control" type="text" name="yain" required="true" value="<?php echo $row['rules'] ?>">
          <input class="form-control" type="hidden" name="id" required="true" value="<?php echo $row['id'] ?>">
        </div>
      </div>
      <div class="col-sm-12">
        <button class="btn btn-primary btn-xs btn-block save_btn" data-toggle="tooltip" title="सेभ गर्नुहोस्" name="Submit" type="submit" value="Submit">सेभ गर्नुहोस्</button>
      </div>
    </div>
  
</div>
</form>