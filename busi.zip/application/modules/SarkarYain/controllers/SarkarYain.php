<?php
class SarkarYain extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->module_code = 'YAIN';
        if(!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login','location');
        }
    }

    /**
        * This function list all the land minimun rate
        * @param NULL
        * @return void
     */
    public function Index()
    {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $data['page']       = 'list_all';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'      => '',
                'सरकार संचालन ऐन'   => 'SarkarYain',
            ));
            $data['breadcrumb'] = $this->breadcrumb->output();
            $data['rules']   = $this->CommonModel->getData('sarkar_yain','DESC');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
        * On ajax call load view
        * @param  NULL
        * @return void
     */
    public function add() {
        $data['pageTitle'] = "";
        $data['fiscal_year']   = $this->CommonModel->getData('fiscal_year','DESC');
        $this->load->view('add', $data);
    }

    /**
        * Call on ajax request
        * save fiscal year
        * @return NULL
     */
    public function save() {
        if($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('yain[]', 'yain', 'required');
            if($this->form_validation->run() == false) {
                $response           = array(
                    'status'                => 'v_errors',
                    'validation_errors'     => 'कृपया * चिन्न लागेको ठाउँ खाली भएको हुनाले सभ हुन असफल भयो',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $yain               = $this->input->post('yain');
            $fiscal_year        = $this->input->post('fiscal_year');
            $post       = array();
            if(!empty($yain)) {
                foreach ($yain as $key => $indexv) {
                    $post[]    = array(
                        'fiscal_year'   => $fiscal_year,
                        'rules'          => $yain[$key],                         
                    );
                }
               $result = $this->CommonModel->batchInsert($post, 'sarkar_yain');
                if($result) {
                    $response = array(
                        'status'        => 'success',
                        'data'          => "सफलतापूर्वक सम्मिलित गरियो",
                        'message'       => 'redirect',
                        'redirect_url'  => base_url().'SarkarYain',
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                } else {
                    $response = array(
                        'status'      => 'error',
                        'data'         => "Fail",
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                }
            } 
        } else {
            exit('no direct script allowed');
        }
    }

     /**
        * On ajax call load view
        * @param  $id $_POST['id']
        * @return void
     */
    public function edit() {
        $id             = $this->input->post('id');
        $data['fiscal_year']   = $this->CommonModel->getData('fiscal_year','DESC');
        $data['row']    = $this->CommonModel->getDataByID('sarkar_yain',$id);
        $this->load->view('edit',$data);
    }

    /**
        * This function on ajaxcall update land area type data
        * @param  $_POST
        * @return json response
     */
    public function Update() {
        if($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $this->form_validation->set_rules('yain', 'yain', 'required');
            if($this->form_validation->run() == false) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => '<div class="alert alert-danger">'.validation_errors().'</div>',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $post_data = array(
                'rules'             => $this->input->post('yain'),
                'fiscal_year'    => $this->input->post('fiscal_year'),
            );
            $result = $this->CommonModel->UpdateData('sarkar_yain',$id,$post_data);
            if($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } 
        } else {
                exit('no direct script allowed');
        }
    }

    /**
        * This function delete data from database.
        * check proper id is in format of not.
        * @param $id int pk
        * @return boolean.
     */
    public function Delete($id) {
            $result = $this->CommonModel->deleteData('sarkar_yain',$id);
            if($result) {
                redirect('SarkarYain');
            }
    }

}