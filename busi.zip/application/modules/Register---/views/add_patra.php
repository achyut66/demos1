<div class="card"><h3 class="card-header"> कृपाय विवरण दाखिला गर्नुहोस</h3>
<div class="card-body">
    <form action="<?php echo base_url()?>Register/LetterSetting" method="post" class="form">
  <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
  <input type="hidden" name="darta_no" value="<?php echo $id; ?>">
  <div class="form-group">
    <div class="col-md-12">
      <div class="form-group">
        <label><b>उद्योग रजिष्ट्रेशनको किसिम</b></label>
        <input type ="text" name="business_type" class="form-control"> 
      </div>
      <div class="form-group">
        <table class="table table-bordered" id="add_new_fields">
          <thead><tr><th>बोधार्थ</th><th>-</th></tr></thead>
          <tbody><tr><td><input type ="text" name="bdetails[]" class="form-control"></td><td><button class="btn btn-secondary btn-block btnAddNew"><i class="fa fa-plus"></i></button></td></tr></tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="modal-footer">
    <button class="btn btn-primary save_btn" data-toggle="tooltip" title="सम्पादन गर्नुहोस्" name="Submit" type="submit" value="Submit">सेभ गर्नुहोस्</button>
    <button type="button" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्" data-dismiss="modal">रद्द गर्नुहोस्</button>
  </div>
</form>
</div>
</div>

<script type="text/javascript" src="<?php echo base_url()?>assets/js/customjs.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      
      //add new row
      $('.btnAddNew').click(function(e) {
        e.preventDefault();
        var trOneNew = $('.nagadi_rasid_frm').length+1;
        var new_row = 
        '<tr>'+
          '<td>'+
          '<input type ="text" name="bdetails[]" class="form-control">'+'</td>'+
          '<td><button type="button" class="btn btn-danger btn-block remove-row" data-toggle="tooltip" title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>'+
          '<tr>'
          $("#add_new_fields").append(new_row);
        });
        $("body").on("click",".remove-row", function(e){
          e.preventDefault();
          
          if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
           var amt = $(this).closest("tr").find('.topic_rate').val();
           var t_amt = $('#t_total').val();
           var new_amt = t_amt-amt;
           $("#t_total").val(new_amt);
           $(this).parent().parent().remove();
          }
        });

    });
  </script>