<!DOCTYPE html>
<html>
  <head>
    <title>राईनास  नगरपालिका </title>
    <style>
      body {
        background: rgb(204, 204, 204);
      }
      .page {
        background: white;
        display: block;
        margin: 0 auto;
        /*margin-bottom: 0.5cm;*/
        background-image: url("../../../assets/img/page0001.jpg");
        background-repeat: no-repeat;
        background-size:cover;
      }
      .page {
        width: 21cm;
        height: 29.7cm;
      }
      @media print {
        * {
        -webkit-print-color-adjust: exact;
    }
        body,
        page {
          margin:0;
          box-shadow: 0;
        }
      }
    </style>
    
  </head>
  <body>
    <div class="page">
      <img src="<?php echo base_url()?>/assets/img/nepal-govt.png" style="margin-top: 100px; height: 150px; width: 150px; margin-left: 80px;">
      <strong><p style="margin-top:-170px;  font-size: 28px; text-align: center; color: rgb(239, 16, 16);"><?php echo GNAME ?></p></strong>
      <br>
      <p style="margin-top:-45px;  font-size: 20px; text-align: center; color: rgb(239, 16, 16);"><?php echo SLOGAN ?></p>
      <br>
      <p style="margin-top:-40px;  font-size: 20px; text-align: center; color: rgb(239, 16, 16);"><?php echo ADDRESS . ',' . DISTRICT ?></p>
      <br>
      <p style="margin-top:-40px;  font-size:18px; text-align: center; color: rgb(239, 16, 16);"><?php echo STATENAME ?>, नेपाल  </p>
      <a href="#" data-toggle="modal" data-target="#editModel"
               data-url="<?php echo base_url()?>Register/updatePhoto" data-id="<?php echo $row['id']?>"> -->
<!-- /image that Occur in certificate preview -->
              <img style="margin-top: -82px; height: 130px; width: 130px; margin-left: 553px;"
                 src="<?php echo base_url()?>assets/business_owner/<?php echo !empty($row['image'])?$row['image']:'emt.jpg'?>"
                 alt="">

      <!-- <img src="<?php echo base_url()?>/assets/img/p.png" style="margin-top: -220px; height: 130px; width: 130px; margin-left: 580px;">
      <br> -->
      <!-- <div class="text-center" style="margin-top:40px;">
        <img src="<?php echo base_url()?>assets/img/pramad.png" style="margin-top: -20px;  height: 80px; width: 300px; margin-left:240px;">
      </div>  -->
      <div class="darta" style="margin-left: 80px; font-size:18px; margin-top:10px;" >व्यवसाय दर्ता नं. <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?>/<?php echo $this->mylibrary->convertedcit($row['fiscal_year']) ?></div>
      <div class="darta" style="margin-left: 550px;margin-top: -22px; font-size:18px; " >दर्ता मितिः <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?> </div>
      <div class="bbody" style="margin-left: 80px; font-size:18px;" >
      <p style="text-align:justify; margin-right: 80px;">तपसिलमा उल्लेखित व्यवसाय स्थानीय सरकार संचालन ऐन  २०७४ को दफा २ (ञ) ६ ,प्रादेशिक  व्यापार तथा व्यवसाय  सम्बन्धि ऐन २०७६ दफा ३ तथा राईनास  नगरपालिका आर्थिक ऐन २०७९ दफा ५ बमोजिम यो  व्यवसाय दर्ता प्रमाणपत्र दिइएको छ ।</p>
      </div><br>
      <div class="bbbody" style="margin-left: 80px; font-size:15px; margin-top:-21px">
      <b>१. व्यक्ति/फर्म/कम्पनीको नामः- <?php echo $this->mylibrary->convertedcit($row['business_name_np']) ?></b><br><br>
        <b>२. ठेगानाः <?php echo $bgapa['name']?>-<?php echo $this->mylibrary->convertedcit($row['b_ward'])?>,<?php echo $bdistrict['name']?>, <?php echo $bstate['Title']?></b><br><br
        >
        <b>३. कारोवारको किसिमः <?php echo $row['b_workdetails']?>  </b><br><br>
        <b>४. मालिक/साझेदार/संचालक मुख्य व्यक्तिको नामः- <?php echo $this->mylibrary->convertedcit($row['b_owner_name']) ?> </b><br><br>
        <b>५.नागरिकता नं : <?php echo $this->mylibrary->convertedcit($row['b_ctzn_no']) ?> </b><br><br>
        <b>६.नागरिकता जारि गरेको मिति: : <?php echo $this->mylibrary->convertedcit($row['b_ctzn_date']) ?> </b><br><br>
        <b>७. ठेगानाः <?php echo $pgapa['name']?>-<?php echo $this->mylibrary->convertedcit($row['p_ward'])?>,<?php echo $pdistrict['name']?>, <?php echo $pstate['Title']?></b></b><br><br>
        <b>८. कारोवारको मुख्य स्थानः- <?php echo $bgapa['name']?> </b><br><br>
        <b>९. कूल पूँजिः- <?php echo $this->mylibrary->convertedcit($row['b_captial']) ?>/-</b><br><br>
        <b>१०. व्यवसाय रहेको बाटोको नाम  :-  <?php echo $this->mylibrary->convertedcit($row['road_name']) ?> </b><br><br>
      <b> ११ . व्यवसायको वर्ग :- <?php echo $this->mylibrary->convertedcit($row['category']) ?> </b><br>
      </div><br>
      <div class="darta" style="margin-left: 80px; font-size:18px;" >&nbsp&nbsp&nbsp...................................<br>
      (प्रमाण–पत्र पाउनेको सही) </div>
      <div class="darta" style="margin-left: 490px;margin-top: -35px; font-size:18px; " > &nbsp&nbsp&nbsp&nbsp&nbsp<?php echo !empty($row['checker'])?$checker['name']:''?><br>(प्रमाण–पत्र जारी गर्नेको सही)  </div>
      <!-- <div class="text-left" style="margin-left:80px;">
        <b><u>द्रष्टब्य </u></b><br>
        <?php if(!empty($commits)) : foreach($commits as $commit) : ?>
        <p><?php echo $commit['commits']?>।</p>
        <?php endforeach; endif;?>

      </div> -->
    </div> 
 <script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
    <script type="text/javascript">
       window.print();
    </script>
  </body>   
</html>
