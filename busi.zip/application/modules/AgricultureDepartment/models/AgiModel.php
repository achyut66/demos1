<?php

/**
 * Created by PhpStorm.
 * User: root
 */
class AgiModel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    //get distinct data
    public function getDistinctParkar()
    {
        $this->db->distinct();
        $this->db->select('main_topic');
        $this->db->from('prakar');
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function getSubTopic()
    {
        $this->db->select('sub_topic');
        $this->db->from('prakar');
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function GetMaxDartaID()
    {
        $maxid = 0;
        $row = $this->db->query("SELECT MAX(`darta_no`) AS `darta_no` FROM `krishi_samuha_darta`")->row();
        return $row;
    }

    public function GetAll($limit, $start, $col, $dir, $fiscal_year = NULL, $samuha_name = NULL, $samuha_type = NULL, $darta_no = NULL, $darta_miti = NULL)
    {
        $this->db->select('*')->from('krishi_samuha_darta');

        if(!empty($fiscal)) {
            $this->db->where('fiscal_year', $fiscal_year);
        }
        if (!empty($samuha_name)) {
            $this->db->like('samuha_name', $samuha_name);
        }
        if (!empty($samuha_type)) {
            $this->db->like('samuha_type', $samuha_type);
        }

        if (!empty($darta_no)) {
            $this->db->where('darta_no', $darta_no);
        }
        if (!empty($darta_miti)) {
            $this->db->where('darta_date', $darta_miti);
        }

        if ($this->session->userdata('PRJ_USER_BID') != 1) {
            $this->db->where('created_by', $this->session->userdata('PRJ_USER_BID'));
        }
        $this->db->limit($limit, $start);
        $this->db->order_by($col, $dir);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return null;
        }
    }

    /**
     * This function on ajax call get list of land owner profile
     * This function is used for datatables for server side uses
     * @param INT $limit, INT $start, INT $col, INT $fiscal, INT $fiscal_year
     * @return json
     */
    public function CountAll($fiscal_year = NULL, $samuha_name = NULL, $samuha_type = NULL, $darta_no = NULL, $darta_miti = NULL)
    {
        $this->db->select('*')->from('krishi_samuha_darta');
        if(!empty($fiscal_year)) {
            $this->db->where('fiscal_year', $fiscal_year);
        }
        if (!empty($samuha_name)) {
            $this->db->like('samuha_name', $samuha_name);
        }
        if (!empty($samuha_type)) {
            $this->db->like('samuha_type', $samuha_type);
        }

        if (!empty($darta_no)) {
            $this->db->where('darta_no', $darta_no);
        }
        if (!empty($darta_miti)) {
            $this->db->where('darta_date', $darta_miti);
        }
        if ($this->session->userdata('PRJ_USER_BID') != 1) {
            $this->db->where('created_by', $this->session->userdata('PRJ_USER_BID'));
        }
        $query = $this->db->get();
        return $query->num_rows();
    }

    //check for darta details 
    // public function checkDartaDetails($darta_id) {
    //     $this->db->select('*')
    // }
}