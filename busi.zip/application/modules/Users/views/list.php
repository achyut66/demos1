<!--main content start-->
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> ड्यासबोर्डमा जानुहोस</a></li>
        <li class="breadcrumb-item"><a href="javascript:;">प्रयोगकर्ताहरूको सूची</a></li>
      </ol>
    </nav>
    <!-- page start-->
    <div class="row">
      <div class="col-sm-12">
        <?php
        $success_message = $this->session->flashdata("MSG_SUCCESS");
        $delete_message = $this->session->flashdata("MSG_DELETE");
        if (!empty($success_message)) { ?>
          <div class="alert alert-success">
            <button class="close" data-close="alert"></button>
            <span> <?php echo $success_message; ?> </span>
          </div>
        <?php } ?>
        <?php if (!empty($delete_message)) { ?>
          <div class="alert alert-danger">
            <button class="close" data-close="alert"></button>
            <span> <?php echo $delete_message; ?> </span>
          </div>
        <?php } ?>
        <section class="card" style="margin-bottom: -25px;">
          <header class="card-header">प्रयोगकर्ताहरूको सूची
            <span class="tools">
              <a class="btn btn-secondary pull-right" href="<?php echo base_url() ?>Users/Add" style="color:#FFF"><i
                  class="fa fa-plus-circle"></i> नयाँ प्रयोगकर्ता थप्नुहोस् </a>
            </span>
          </header>
          <div class="card-body">
            <div class="adv-table">
              <table class="display table table-bordered table-striped" id="dynamic-table">
                <thead style="background: #1b5693; color:#fff">
                  <tr>
                    <th text-aligh="right">#</th>
                    <th>भूमिका</th>
                    <th>नाम</th>
                    <th>संकेत नं.</th>
                    <th>पद</th>
                    <th>शाखा</th>
                    <th>कार्यलयमा हाजिर मिति</th>
                    <th>Ward No</th>
                    <th>user name</th>
                    <th class="hidden-phone">.....</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $i = 1;
                  if ($users->num_rows() > 0):
                    foreach ($users->result_array() as $value): ?>
                      <tr class="gradeX">
                        <td><?php echo $this->mylibrary->convertedcit($i++) ?></td>
                        <td>
                          <?php $role = $this->CommonModel->getWhere('group', array('groupid' => $value['user_group']));
                          echo $this->mylibrary->convertedcit($role['group_name']) ?>
                        </td>
                        <td><?php echo $this->mylibrary->convertedcit($value['name']) ?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['employee_id']) ?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['designation']) ?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['branch_name']) ?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['office_join_date']) ?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['ward']) ?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['user_name']) ?></td>
                        <td class="center hidden-phone">
                          <a class="btn btn-info btn-sm"
                            href="<?php echo base_url() ?>Users/EditUser/<?php echo $value['userid'] ?>"
                            data-toggle="tooltip" title="विवरण सम्पादन गर्नुहोस्"><i class="fa fa-pencil"></i></a>
                          <!-- <a href = "<?php echo base_url() ?>Users/EditUserPerm/<?php echo $value['userid'] ?>" class="btn btn-success btn-sm" data-toggle="tooltip" title="अनुमति सम्पादन गर्नुहोस्" ><i class="fa fa-exclamation-triangle"></i></a> -->
                          <a href="<?php echo base_url() ?>Users/deleteUser/<?php echo $value['userid'] ?>"
                            class="btn btn-danger btn-sm deactive_users" data-toggle="tooltip"
                            title="प्रयोगकर्ताहरू निस्क्रिय गर्नुहोस्"><i class="fa fa-trash-o"></i></a>
                        </td>
                      </tr>
                    <?php endforeach; endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </div>
    </div>
  </section>
</section>
<script type="text/javascript">
  $(document).on('show.bs.modal', '#editModel', function (e) {
    var id = $(e.relatedTarget).data('id'); //Fetch id from modal trigger button
    $.ajax({
      type: 'POST',
      url: '<?php echo base_url() ?>Setting/addRoadType', //Here you will fetch records 
      data: { updateID: id }, //Pass $id
      success: function (data) {
        $("#editModel").find('.modal-view').html(data);
      }
    });
  });
</script>