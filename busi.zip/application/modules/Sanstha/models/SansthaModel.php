<?php
class SansthaModel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
    public function getDistinctParkar()
    {
        $this->db->distinct();
        $this->db->select('sanstha');
        $this->db->from('prakar');
        $query = $this->db->get()->result_array();
        return $query;
    }
    public function getSubTopic()
    {
        $this->db->select('sub_topic');
        $this->db->from('prakar');
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function GetMaxDartaID()
    {
        $maxid = 0;
        $row = $this->db->query("SELECT MAX(`darta_no`) AS `darta_no` FROM `sanstha`")->row();
        return $row;
    }
    public function GetAll($limit,$start,$col,$dir, $sanstha = NULL,$sanstha_name = NULL,$darta_no =NULL,$darta_miti=NULL)
    { 
        $this->db->select('*')->from('sanstha');
        if(!empty($sanstha)){
            $this->db->where('sanstha_type', $sanstha);
        }
        if(!empty($sanstha_name)) {
            $this->db->like('sanstha_name', $sanstha_name);
        }
        if(!empty($darta_no)) {
            $this->db->where('darta_no', $darta_no);
        }
        if(!empty($darta_miti)) {
            $this->db->where('darta_miti', $darta_miti);
        }
        
        if($this->session->userdata('PRJ_USER_BID') != 1) {
            $this->db->where('added_ward',$this->session->userdata('PRJ_USER_WARD'));
        }
        $this->db->limit($limit, $start);
        $this->db->order_by('darta_no','desc');
        $query = $this->db->get();
        if($query->num_rows()>0) {
            return $query->result(); 
        } else {
            return null;
        }
    }
    public function CountAll($sanstha = NULL,$sanstha_name = NULL,$darta_no =NULL,$darta_miti=NULL)
    {
        $this->db->select('*')->from('sanstha');
        if(!empty($sanstha)){
            $this->db->where('sanstha_type', $sanstha);
        }
        if(!empty($sanstha_name)) {
            $this->db->like('$sanstha_name', $sanstha_name);
        }
        if(!empty($darta_no)) {
            $this->db->where('darta_no', $darta_no);
        }
        if(!empty($darta_miti)) {
            $this->db->where('darta_miti', $darta_miti);
        }
        if($this->session->userdata('PRJ_USER_BID') != 1) {
            $this->db->where('added_ward',$this->session->userdata('PRJ_USER_WARD'));
        }
        $query = $this->db->get();
        return $query->num_rows();
    }

}
?>