<?php

/**
 * Created by PhpStorm.
 * User: root
 * Date: 12/2/16
 * Time: 9:57 PM
 */
// $this->load->helper('download');
class Sanstha extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->load->model("SansthaModel");
        $this->load->library('upload');
        $this->module_code = 'SANSTHA';
        if (!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login', 'location');
        }
    }

    /** 
     * This function load add buy or sell form
     * @param NULL
     * return load view with list
     */
    // download the files
    public function downloadImage($id)
    {
        $file_name_one = $this->CommonModel->getDataByID('documents', $id);
        $file_name = $file_name_one['doc_name'];
        // file path
        $file_path = base_url() . 'assets/darta_images/' . $file_name;

        // Load the download helper to use the force_download() function
        $this->load->helper('download');

        // Use the force_download() function to send the file to the user for download
        force_download($file_name, file_get_contents($file_path));
    }





    // ends here
    public function Index()
    {
        //   if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
        $data['page'] = 'list_all';
        $data['sanstha'] = $this->CommonModel->getData('sanstha');
        // pp($data['sanstha']);
        $this->load->view('main', $data);
        //   } else {
        //  $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
        //    redirect('Dashboard');
        //   }
        // pp($data['sanstha']);
    }

    /**
     * This function load add buy or sell form
     * @param NULL
     * return view
     */
    // display the uploaded files into views

    public function addPatra()
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataById('sanstha', $id);
            $data['darta_suchikrit'] = $this->CommonModel->getData('darta_suchikrit');
            $data['fiscal_year'] = $this->CommonModel->getData('fiscal_year');
            $data['sarkari_yin'] = $this->CommonModel->getDataById('sarkar_yain', 2);
            // pp($data['row']);
            // die;
            $data['staffs'] = $this->CommonModel->getData('staff');
            // $data['maker']          = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            // pp($data['row']);
            $this->load->view('sanstha_tippani_letter', $data);
        }

    }
    public function addPatraPrint($id)
    {
        // pp($id);
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataById('sanstha', $id);
            $data['darta_suchikrit'] = $this->CommonModel->getData('darta_suchikrit');
            $data['fiscal_year'] = $this->CommonModel->getData('fiscal_year');
            $data['sarkari_yin'] = $this->CommonModel->getDataById('sarkar_yain', 2);
            // pp($data['row']);
            // die;
            $data['maker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            // pp($data['row']);
            $this->load->view('sanstha_tippani_letter_print', $data);
        }

    }
    public function ShowFiles()
    {
        // if ($this->authlibrary->HasModulePermission($this->module_code, "FILES")) {
        $data['page'] = 'display_files';
        $data['documents'] = $this->CommonModel->get_image_file('Sanstha');
        $this->load->view('main', $data);
        // } else {
        // $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
        // redirect('Dashboard');
        // }
    }

    public function add()
    {
        $data['page'] = 'add';
        $data['wards'] = $this->CommonModel->getData('settings_ward', 'DESC');
        $data['districts'] = $this->CommonModel->getData('settings_district', 'DESC');
        $data['pradesh'] = $this->CommonModel->getData('provinces', 'DESC');
        $data['prakar'] = $this->CommonModel->getData('main_topic');
        $data['fiscal_year'] = $this->CommonModel->getData('fiscal_year');
        $data['darta_suchikrit'] = $this->CommonModel->getData('darta_suchikrit');
        $data['gapana'] = $this->CommonModel->getWhereAll('settings_vdc_municipality', array('district' => DISTRICT));
        $darta = $this->SansthaModel->GetMaxDartaID();
        $data['darta_no'] = $darta->darta_no + 1;
        //$data['certificate_no']       = $certificate_no->certificate_no + 1;
        $data['karyabids'] = $this->CommonModel->getData('karya_bidi');
        $this->load->view('main', $data);
    }
    //save sanstha darta
    public function save()
    {
        $karyawidi = $this->input->post('karyawidi');
        $fiscal_year = $this->input->post('fiscal_year');
        $darta_miti = $this->input->post('darta_miti');
        $darta_no = $this->input->post('certificate_no');
        $darta_suchikrit = $this->input->post('darta_suchikrit');
        $b_darta_office = $this->input->post('b_darta_office');
        $b_odarta_miti = $this->input->post('b_odarta_miti');
        $b_odarta_no = $this->input->post('b_odarta_no');
        $b_pan_no = $this->input->post('b_pan_no');
        $sanstha_name = $this->input->post('sanstha_name');
        $sanstha_type = $this->input->post('sanstha_type');
        $adhaxya_name = $this->input->post('adhaxya_name');
        $nirnaya_date = $this->input->post('nirnaya_date');
        $nibedan_miti = $this->input->post('nibedan_miti');
        $p_pardesh = $this->input->post('p_pardesh');
        $p_district = $this->input->post('p_district');
        $p_gapa = $this->input->post('p_gapa');
        $p_ward = $this->input->post('p_ward');
        $tol = $this->input->post('tol');
        $male_member = $this->input->post('male_member');
        $female_member = $this->input->post('female_member');
        $total_member = $this->input->post('total_member');
        $gathan_miti = $this->input->post('gathan_miti');
        $baithak_day = $this->input->post('baithak_day');
        $phone_no = $this->input->post('phone_no');
        $email = $this->input->post('email');
        $full_name = $this->input->post('full_name');
        $deg = $this->input->post('deg');
        $qualification = $this->input->post('qualification');
        $age = $this->input->post('age');
        $contact_no = $this->input->post('contact_no');
        $rakam = $this->input->post('rakam');
        $total_rakam = $this->input->post('total_rakam');
        $doc_type = $this->input->post('image_t_name');
        $doc_file = $this->input->post('userfile');
        $fields_array = $_FILES['userfile']['name'];

        $save_array = array(
            'karyawidi' => $karyawidi,
            'fiscal_year' => $fiscal_year,
            'darta_miti' => $darta_miti,
            //'certificate_no'            => $certificate_no,
            'darta_no' => $darta_no,
            'nibedan_miti' => $nibedan_miti,
            'sanstha_name' => $sanstha_name,
            'sanstha_type' => $sanstha_type,
            'adhaxya_name' => $adhaxya_name,
            'nirnaya_date' => $nirnaya_date,
            'p_pardesh' => $p_pardesh,
            'p_district' => $p_district,
            'p_gapa' => $p_gapa,
            'p_ward' => $p_ward,
            'tol' => $tol,
            'male_member' => $male_member,
            'female_member' => $female_member,
            'total_member' => $total_member,
            'gathan_miti' => $gathan_miti,
            'darta_suchikrit' => $darta_suchikrit,
            'baithak_day' => $baithak_day,
            'rakam' => $rakam,
            'total_rakam' => $total_rakam,
            'b_darta_office' => $b_darta_office,
            'b_odarta_miti' => $b_odarta_miti,
            'b_odarta_no' => $b_odarta_no,
            'b_pan_no' => $b_pan_no,
            'phone_no' => $phone_no,
            'email' => $email,
            'status' => 1,
            'added_on' => date('Y-m-d'),
            'darta_date' => convertDate(date('Y-m-d')),
            'added_by' => $this->session->userdata('PRJ_USER_BID'),
        );
        // pp($save_array);
        $result = $this->CommonModel->insertData('sanstha', $save_array);
        if ($result) {
            if (!empty($fields_array)) {
                $path = 'darta_images';
                $uploads = upload_multiple($path, 'userfile', $doc_type, $result, $this->uri->segment(1), 1);
                // pp($uploads);
                $this->CommonModel->batchInsert($uploads, 'documents');
            }
            $members = array();
            foreach ($full_name as $key => $index)
            // pp($index);
            {
                $members[] = array(
                    'sanstha_id' => $result,
                    'full_name' => $full_name[$key],
                    'deg' => $deg[$key],
                    'qualification' => $qualification[$key],
                    'age' => $age[$key],
                    'contact_no' => $contact_no[$key],
                    'darta_no' => $darta_no,
                    'status' => 1,
                );
            }

            $child = $this->CommonModel->batchInsert($members, 'sanstha_members');
            if ($child) {
                $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                redirect('Sanstha/viewDetails/' . $result);
            } else {
                $this->CommonModel->deleteData('sanstha', $result);
                $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                redirect('Sanstha');
            }
            // }
            //         if(!empty( $fields_array )) {
            //         $path = 'darta_images';
            //         $uploads = upload_multiple($path, 'userfile', $doc_type, $result, $this->uri->segment(1), 1);
            //         $this->CommonModel->batchInsert($uploads, 'documents');
            //         }
            // }
            //     $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
            //     redirect('Sanstha/viewDetails/' . $result);
        }
    }
    public function viewDetails($id)
    {
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataByID('sanstha', $id);
            $data['members'] = $this->CommonModel->getWhereAll('sanstha_members', array('sanstha_id' => $id));
            //$data['renew_details']  = $this->CommonModel->getWhereAll('renew', array('renew_type' => $this->uri->segment(1), 'sanstha_id' => $id));


            $data['page'] = 'view_details';
            $this->load->view('main', $data);
        }
    }
    public function edit($id)
    {
        $data['page'] = 'edit';
        $data['wards'] = $this->CommonModel->getData('settings_ward', 'DESC');
        $data['districts'] = $this->CommonModel->getData('settings_district', 'DESC');
        $data['pradesh'] = $this->CommonModel->getData('provinces', 'DESC');
        $data['gapana'] = $this->CommonModel->getData('settings_vdc_municipality', 'DESC');

        $data['darta_suchikrit'] = $this->CommonModel->getData('darta_suchikrit');
        $data['row'] = $this->CommonModel->getDataById('sanstha', $id);

        $data['members'] = $this->CommonModel->getWhereAll('sanstha_members', array('sanstha_id' => $id));
        $data['karyabids'] = $this->CommonModel->getData('karya_bidi');
        $data['fiscal_year'] = $this->CommonModel->getData('fiscal_year');
        // pp($data['row']);
        $this->load->view('main', $data);
    }
    public function update()
    {
        if ($this->input->post('Submit')) {
            $id = $this->input->post('id');
            $karyawidi = $this->input->post('karyawidi');
            $fiscal_year = $this->input->post('fiscal_year');
            $darta_miti = $this->input->post('darta_miti');
            $darta_no = $this->input->post('darta_no');
            $darta_suchikrit = $this->input->post('darta_suchikrit');
            $b_darta_office = $this->input->post('b_darta_office');
            $b_odarta_miti = $this->input->post('b_odarta_miti');
            $b_odarta_no = $this->input->post('b_odarta_no');
            $b_pan_no = $this->input->post('b_pan_no');
            $sanstha_name = $this->input->post('sanstha_name');
            $sanstha_type = $this->input->post('sanstha_type');
            $adhaxya_name = $this->input->post('adhaxya_name');
            $nirnaya_date = $this->input->post('nirnaya_date');
            $nibedan_miti = $this->input->post('nibedan_miti');
            $p_pardesh = $this->input->post('p_pardesh');
            $p_district = $this->input->post('p_district');
            $p_gapa = $this->input->post('p_gapa');
            $p_ward = $this->input->post('p_ward');
            $tol = $this->input->post('tol');
            $male_member = $this->input->post('male_member');
            $female_member = $this->input->post('female_member');
            $total_member = $this->input->post('total_member');
            $gathan_miti = $this->input->post('gathan_miti');
            $baithak_day = $this->input->post('baithak_day');
            $phone_no = $this->input->post('phone_no');
            $email = $this->input->post('email');
            $full_name = $this->input->post('full_name');
            $deg = $this->input->post('deg');
            $qualification = $this->input->post('qualification');
            $age = $this->input->post('age');
            $contact_no = $this->input->post('contact_no');
            $rakam = $this->input->post('rakam');
            $total_rakam = $this->input->post('total_rakam');

            //member details
            $fullname = $this->input->post('full_name');
            $deg = $this->input->post('deg');
            $qualification = $this->input->post('qualification');
            $contact_no = $this->input->post('contact_no');
            $memberid = $this->input->post('member_id');

            //if input new member are added

            // $fullname_new                       = $this->input->post('full_name_new');
            // $deg_new                            = $this->input->post('deg_new');
            // $qualification_new                  = $this->input->post('qualification_new');
            // $contact_no_new                     = $this->input->post('contact_no_new');

            $save_array = array(
                'karyawidi' => $karyawidi,
                'fiscal_year' => $fiscal_year,
                'darta_miti' => $darta_miti,
                //'certificate_no'            => $certificate_no,
                'darta_no' => $darta_no,
                'nibedan_miti' => $nibedan_miti,
                'sanstha_name' => $sanstha_name,
                'sanstha_type' => $sanstha_type,
                'adhaxya_name' => $adhaxya_name,
                'nirnaya_date' => $nirnaya_date,
                'p_pardesh' => $p_pardesh,
                'p_district' => $p_district,
                'p_gapa' => $p_gapa,
                'p_ward' => $p_ward,
                'tol' => $tol,
                'male_member' => $male_member,
                'female_member' => $female_member,
                'total_member' => $total_member,
                'gathan_miti' => $gathan_miti,
                'darta_suchikrit' => $darta_suchikrit,
                'baithak_day' => $baithak_day,
                'rakam' => $rakam,
                'total_rakam' => $total_rakam,
                'b_darta_office' => $b_darta_office,
                'b_odarta_miti' => $b_odarta_miti,
                'b_odarta_no' => $b_odarta_no,
                'b_pan_no' => $b_pan_no,
                'phone_no' => $phone_no,
                'email' => $email,
                'status' => 1,
                'added_on' => date('Y-m-d'),
                'darta_date' => convertDate(date('Y-m-d')),
                'added_by' => $this->session->userdata('PRJ_USER_BID'),

            );
            // pp($save_array);
            $result = $this->CommonModel->updateData('sanstha', $id, $save_array);
            if ($result) {
                // Update existing members
                if (!empty($fullname)) {
                    $members = array();
                    foreach ($fullname as $key => $index) {
                        $members[] = array(
                            'id' => $memberid[$key],
                            'sanstha_id' => $id,
                            'darta_no' => $darta_no,
                            'full_name' => $fullname[$key],
                            'deg' => $deg[$key],
                            'qualification' => $qualification[$key],
                            'contact_no' => $contact_no[$key],
                        );
                    }
                    // pp($members);
                    $updateResult = $this->CommonModel->batchUpdate('sanstha_members', $memberid, $members);
                    if ($result) {
                        $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                        redirect('Sanstha/');
                    } else {
                        //$this->CommonModel->deleteData('krishi_samuha_darta', $result);
                        $this->session->set_flashdata('MSG_SUCCESS', 'Successfully updated');
                        redirect('Sanstha/');
                    }
                }
            }
        }
    }
    // delete sanstha data
    //delete renew
    public function deleteSansthaDetails($id)
    {
        $row = $this->CommonModel->getDataById('sanstha', $id);
        if ($row['status'] == 1) {
            echo "active xa";
        } else {
            echo "radda bhayeko";
        }
        // pp($row);
        if (!empty($row)) {
            $result = $this->CommonModel->deleteData('sanstha', $id);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'success');
                redirect('Sanstha/index/' . $row['id']);
            }
        }
    }
    // ends here
    public function GetAllList()
    {
        if ($this->input->is_ajax_request()) {
            $columns = array(0 => 'id');
            $limit = $this->input->post('length');
            $start = $this->input->post('start');

            //main_topic, business_name, darta_no, darta_miti
            $sanstha = $this->input->post('sanstha');
            $sanstha_name = $this->input->post('sanstha_name');
            $darta_no = $this->input->post('darta_no');
            $darta_miti = $this->input->post('darta_miti');
            $sn = $start + 1;
            $order = '';
            $dir = $this->input->post('order')[0]['dir'];
            $totalData = $this->SansthaModel->CountAll($sanstha, $sanstha_name, $darta_no, $darta_miti);
            $totalFiltered = $totalData;
            $posts = $this->SansthaModel->GetAll($limit, $start, $order, $dir, $sanstha, $sanstha_name, $darta_no, $darta_miti);
            $data = array();
            if (!empty($posts)) {
                $i = 1;
                foreach ($posts as $post) {
                    $nestedData['sn'] = $this->mylibrary->convertedcit($sn++);
                    $nestedData['id'] = $post->id;
                    $nestedData['date'] = $this->mylibrary->convertedcit($post->darta_miti);
                    $nestedData['name'] = $this->mylibrary->convertedcit($post->sanstha_name);
                    $nestedData['darta_no'] = '<span class="badge badge-pill badge-danger">' . $this->mylibrary->convertedcit($post->darta_no) . "</span>";
                    $nestedData['dno'] = $post->darta_no;
                    $nestedData['is_trash'] = $post->is_trash;
                    $nestedData['adhaxya_name'] = $this->mylibrary->convertedcit($post->adhaxya_name);
                    $data[] = $nestedData;

                    $data[] = $nestedData;
                }
            }

            $json_data = array(
                "draw" => intval($this->input->post('draw')),
                "recordsTotal" => intval($totalData),
                "recordsFiltered" => intval($totalFiltered),
                "data" => $data
            );
            echo json_encode($json_data);
        } else {
            exit('HTTPS!!');
        }
    }
    public function certificate($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataById('sanstha', $id);
            $data['darta_suchikrit'] = $this->CommonModel->getData('darta_suchikrit');
            $data['fiscal_year'] = $this->CommonModel->getData('fiscal_year');
            $data['sarkari_yin'] = $this->CommonModel->getDataById('sarkar_yain', 2);
            // pp($data['sarkari_yin']);
            $data['staffs'] = $this->CommonModel->getData('staff');
            // $data['maker']          = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            // pp($data['row']);
            $this->load->view('certificate_benighat', $data);
        }
    }
    public function certificateSecondPage($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataById('sanstha', $id);
            $data['darta_suchikrit'] = $this->CommonModel->getData('darta_suchikrit');
            $data['fiscal_year'] = $this->CommonModel->getData('fiscal_year');
            $data['sarkari_yin'] = $this->CommonModel->getDataById('sarkar_yain', 2);
            // pp($data['sarkari_yin']);
            $data['staffs'] = $this->CommonModel->getData('staff');
            // $data['maker']          = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            // pp($data['row']);
            $this->load->view('certificate_benighat_second_page', $data);
        }
    }
    public function PrintCertificate($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataById('sanstha', $id);
            $data['fiscal_year'] = $this->CommonModel->getData('fiscal_year');
            $data['darta_suchikrit'] = $this->CommonModel->getData('darta_suchikrit');
            $data['sarkari_yin'] = $this->CommonModel->getDataById('sarkar_yain', 2);
            $data['maker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $data['checker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['checker']));
            $this->load->view('certificate_benighat_print', $data);
        }
    }
    public function PrintCertificateBack($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataById('sanstha', $id);
            //$data['staffs']         = $this->CommonModel->getData('staff');
            //$data['maker']          = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $this->load->view('PrintCertificateBack', $data);
        }
    }
    public function PrintCertificateSuchikrit($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataById('sanstha', $id);
            $data['staffs'] = $this->CommonModel->getData('staff');
            $data['maker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $this->load->view('PrintCertificateSuchikrit', $data);
        }
    }
    public function SansthaTippani($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataById('sanstha', $id);
            //$data['staffs']         = $this->CommonModel->getData('staff');
            //$data['maker']          = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $this->load->view('SansthaTippani', $data);
        }
    }
    public function SansthaNibedanDemo()
    {
        //$data['row']            = $this->CommonModel->getDataById('sanstha', $id);
        //$data['staffs']         = $this->CommonModel->getData('staff');
        //$data['maker']          = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
        $this->load->view('Sanstha/SansthaNibedanDemo');
    }
    public function PrintSansthaNibedanDemo()
    {
        //$data['row']            = $this->CommonModel->getDataById('sanstha', $id);
        //$data['staffs']         = $this->CommonModel->getData('staff');
        //$data['maker']          = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
        $this->load->view('Sanstha/PrintSansthaNibedanDemo');
    }
    public function updateMaker()
    {
        $id = $this->input->post('id');
        $maker = $this->input->post('maker');
        $data = array('maker' => $maker);
        $result = $this->CommonModel->updateData('sanstha', $id, $data);
        if ($result) {
            $response = array(
                'status' => 'success',
                'data' => "सफलतापूर्वक सम्मिलित गरियो",
                'message' => 'success'
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
        }
    }

    //update checker
    public function updateChecker()
    {
        $id = $this->input->post('id');
        $checker = $this->input->post('checker');
        $data = array('checker' => $checker);
        $result = $this->CommonModel->updateData('sanstha', $id, $data);
        if ($result) {
            $response = array(
                'status' => 'success',
                'data' => "सफलतापूर्वक सम्मिलित गरियो",
                'message' => 'success'
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
        }
    }

    //     public function listNabikarnDetails()
    //     {

    //         $data['page']       = 'renew_sanstha_list';
    //         $data['sanstha']      = $this->CommonModel->getWhere('sanstha', array('id' => $sanstha_id));
    //         $this->load->view('main', $data);
    //   }
    public function renew()
    {
        $data['page'] = 'renew_sanstha';
        $data['row'] = $this->CommonModel->getDataById('sanstha', $id);
        $data['row'] = $this->CommonModel->getDataById('sanstha', $id);
        $this->load->view('main', $data);
    }
    // public function nabikaran()
    // {
    //     if ($this->input->post('Submit')) {
    //         $sanstha_id                  = $this->input->post('$sanstha_id');
    //         $darta_no                   = $this->input->post('darta_no');
    //         $date                       = $this->input->post('date');
    //         $fiscal_year_from           = $this->input->post('fiscal_year_from');
    //         $fiscal_year_to             = $this->input->post('fiscal_year_to');
    //         $rasid_no                   = $this->input->post('rasid_no');
    //         $dastur                     = $this->input->post('dastur');
    //         $remarks                    = $this->input->post('remarks');
    //         $save_array                 = array(
    //             // 'sanstha_id'              => $sanstha_id,
    //             'date'                  => $date,
    //             'darta_no'              => $darta_no,
    //             'fiscal_year_from'      => $fiscal_year_from,
    //             'fiscal_year_to'        => $fiscal_year_to,
    //             'rasid_no'              => $rasid_no,
    //             'dastur'                => $dastur,
    //             'remarks'               => $remarks,
    //             'fiscal_year'           => current_fiscal_year(),
    //             'created_at'            => convertDate(date('Y-m-d h:i:sa')),
    //             //'created_by'            => $this->session->userdata('PRJ_USER_BID'),
    //             'added_ward'            => $this->session->userdata('PRJ_USER_WARD'),
    //         );
    //         $sanstha_details = $this->CommonModel->getWhere('sanstha', array('id' => $sanstha_id));
    //         if ($sanstha_details['fiscal_year'] == current_fiscal_year()) {
    //             $this->session->set_flashdata('MSG_WAR', 'नवीकरण गर्न मिल्दैन');
    //             //redirect('Sanstha/viewDetails/' . $sanstha_id);
    //         }
    //         $checkIfExits = $this->CommonModel->getWhere('renew_sanstha', array('sanstha_id', 'fiscal_year' => current_fiscal_year()));
    //         if (!empty($checkIfExits)) {
    //             $this->session->set_flashdata('MSG_ERR', 'नवीकरण गरिसकेको छ');
    //             //redirect('Sanstha/viewDetails/' . $sanstha_id);
    //         }
    //         $result = $this->CommonModel->insertData('renew_sanstha', $save_array);
    //         if ($result) {
    //             $this->session->set_flashdata('MSG_SUCCESS', 'तपाई नवकिरण गर्न सफल हुनुभयो');
    //             //redirect('Sanstha/viewDetails/' . $sanstha_id);
    //         }
    //     }
    // }





}
?>