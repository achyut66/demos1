<!doctype html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title>संस्था टिप्पणी </title>
</head>
<body>
<div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle" style="margin-top:-86px;">
          <h3 class=""><?php echo GNAME ?> </h3>
          <h4><?php echo SLOGAN ?></h4>
          <h6 style="margin-top:-10px;"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6 style="margin-top:-5px;"><?php echo STATENAME ?>,नेपाल</h6>
        </div>
<div>
<div class="sub-header">
        <div class="title">
          <p style="margin-left:250px;font-size:22px;margin-top:38px;"><b><u> बिषय : संस्था दर्ता सम्बन्धमा । </u> </b></p>
        </div>
      </div>
          <p style="font-size:18px;margin-top:50px; margin-left:40px;">श्रीमान,
            </p>
        </div>
        <div style="text-align:justify;margin-right:12px; margin-top: 20px;">
        प्रस्तुत बिसयमा <?php echo $row['sanstha_name'] ?> <?php echo $this->mylibrary->convertedcit($row['p_gapa'])?>- वडा नं <?php echo $this->mylibrary->convertedcit($row['p_ward'])?>
         द्वारा  मिति  
         <?php echo $this->mylibrary->convertedcit($row['gathan_miti']) ?> गते  तदर्थ समिति गठन  गरी,  
         मिति 
         <?php echo $this->mylibrary->convertedcit($row['nibedan_miti']) ?>
         गते यस नगरपालिका मा  उक्त  दर्ता गर्न निबेदन पेश गरेको देखिन्छ।  निबेदन साथ् वडा नं ४ कार्यालयको  
        सिफारिस पत्र  निर्णयको  प्रतिलिपि  तथा अन्य  कागजातका साथै    राइनास नगरपालिका  संस्था दर्ता तथा नबिकरण सम्बन्धि ऐन , 
        २०७६  दफा ४ तथा  दफा ५ को उपदफा (३) बमोजिम  समिति गठन तथा ३  प्रतिबिधान  प्रमाणित   भई   पेश  हुन आएकोले 
         सोहि ऐनको  दफा ५ को उपदफा बमोजिम  <?php echo $row['sanstha_name'] ?> नामक  संस्था दर्ता गर्न  मनासिब देखिने हुदा निर्णयार्थ  पेश गरेको छु ।
</div>
</body>
</html>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
window.print();
</script>