<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>
  <style>
  .title {
    height: 45px;
    width: 485px;
    /* border: 1px solid #555; */
    margin-left: 173px;
    border-radius: 25px;
    text-align:center;
    /* border-radius: 25px; */
    margin-top: 60px;
  }
  .nagarpalika_title {
    height: 45px;
    width: 485px;
    /* border: 1px solid #555; */
    margin-left: 114px;
    text-align:center;
    /* border-radius: 25px; */
    margin-top: 60px;
  }
  element.style {
    margin-left: 4px;
    font-size: 26px;
    margin-top: 3px;
}
  .stamp {
    /* border: 2px solid #555; */
    /* height: 62px;
    width: 202px;
     */
    margin-left: 487px;
    /* border-radius: 5px; */
    text-align:right;
    margin-right:120px;
    margin-top: 50px;
  }
  @page { 
        size: horizontal;
  }
  </style>
</head>
<body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header">
        <div class="header-middle">
          श्रीमान् प्रमुख प्रशासकीय अधिकृतज्यू
          <h5 class=""><?php echo GNAME ?> </h5>
          <h5><?php echo SLOGAN ?></h5>
        </div>
      </div>
      <div class="sub-header">
        <div class="title">
          <p style="margin-left:173px;font-size:20px;margin-top:3px;margin-left:1px;">बिषय : संस्था दर्ता</p>
        </div>
      </div>
        <div style="text-align:justify;margin-right:12px; margin-top: 20px;">
        मिति ..................................... मा आन्तरिक मामिला तथा कानून मन्त्रालय प्रदेश नं. ५ जिल्ला प्रशासन कार्यालय …………………..................मा दर्ता भई ………………………..................................
        सम्बन्धी काम गर्ने उद्देश्यले स्थापना गरिएको ………………….............................संस्थाले राइनास नगरपालिकाको
         नगर क्षेत्रमा समेत आफ्नो कार्यक्षेत्र बनाई काम गर्न चाहेकाले   दर्ता तथा नियमन सम्बन्धी नियमावली, २०७८ बमोजिम संस्था सूचिकृतका लागि देहायको विवरण खोली निवेदन गरेका छौं । 
         संस्थाको विधानको एक प्रति यसैसाथ संलग्न गरिएको छ ।
      <div>
          <p style="font-size:18px;margin-top:18px; margin-left:-6px;">विवरणः
        </div>
        <div>
          <p style="font-size:18px;margin-top:-19px; margin-left:-6px;"> संस्थाको नाम :
        </div>
        <div style="margin-left:-6px;margin-top:-5px;"> संस्था दर्ता न. र मिति :
      </div>
      <br>
      <div style="margin-left:-6px;margin-top:-5px;">समाजकल्याण परिषदमा आवद्धता न. :
      </div>
      <br>
      <div style="margin-left:-6px;margin-top:-5px;">४. संस्थाको उद्देश्यहरु :
</div>
<br>
<div style="margin-left:-6px;margin-top:-5px;">
(क)
</div>
<div style="margin-left:-6px;margin-top:-5px;">
(ख)
</div>
<div style="margin-left:-6px;margin-top:-5px;">
(ग)
</div>
<div style="margin-left:-6px;margin-top:-5px;">
५. संस्थाको कार्यक्षेत्र :
</div>
<br>
<div style="margin-left:-6px;margin-top:-5px;">
६. संस्थाको कार्यप्रकृति विवरण :
</div>
<br>
<div style="margin-left:-6px;margin-top:-5px;">
७. कार्य समितिका सदस्यहरुको :
</div>
<div style="text-align:justify;margin-right:12px; margin-top: 20px;">
नाम 
</div>
१ 
<br>
२ 
<br>
३ 
<br>
४
<br>      
<div style="margin-left:20px;margin-top:-99px;text-indent: 30%;">  
ठेगाना
</div>
<br>
<div style="margin-left:20px;margin-top:-31px;text-indent:75%;">
पेसा<p style="font-size:18px"></p>
</div>
</div>
<div  style="margin-top:79px;">
७. आर्थिक श्रोत तथा  बजेट   विवरण :
</div>
<div  style="margin-top:45px;">
८. संस्थाको कार्यालयको ठेगाना :
</div>
<div  style="margin-top:40px;">
९. सम्पर्क व्यक्ति र फोन नं :
</div>
</div>
</div>
  </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
window.print();
</script>
</html>