<!doctype html>
<html lang="en">


<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>

  <style>
    .title {
      height: 45px;
      width: 485px;
      border: 1px solid #555;
      margin-left: 139px;
      border-radius: 25px;
      text-align: center;
      /* border-radius: 25px; */
      margin-top: 60px;
    }

    .nagarpalika_title {
      height: 45px;
      width: 485px;
      /* border: 1px solid #555; */
      margin-left: 114px;
      text-align: center;
      /* border-radius: 25px; */
      margin-top: 60px;
    }

    element.style {
      margin-left: 4px;
      font-size: 26px;
      margin-top: 3px;
    }

    .stamp {
      /* border: 2px solid #555; */
      /* height: 62px;
    width: 202px;
     */
      margin-left: 487px;
      border-radius: 5px;
      text-align: right;
      margin-right: 120px;
      margin-top: 50px;
    }

    @page {
      size: landscape;
    }

    div.a {
      text-indent: 80%;
    }

    td {
      height: 50px;
    }

    .body {
      margin-left: 290px;
    }
  </style>
</head>

<a class="nav-link"
  href="<?php echo base_url() ?>Sanstha/PrintCertificate/<?php echo $row['id'] ?>/<?php echo $row['darta_suchikrit'] ?>"
  target="_blank">
  <div class="text-right" style="margin-left:523px;margin-top:-15px;"><button class="btn btn-primary"> (पहिलो
      पृष्ट) प्रिन्ट
      गर्नुहोस्</button>
</a></div>
<a class="nav-link" style="margin-left:706px;margin-top:-54px;"
  href="<?php echo base_url() ?>Sanstha/certificateSecondPage/<?php echo $row['id'] ?>/<?php echo $row['darta_suchikrit'] ?>"
  target="_blank">
  <div class="text-right"><button class="btn btn-warning"> (दोश्रो पृष्ट) प्रिन्ट
      गर्नुहोस्</button></div>
</a>

<body class="body">
  <div class="main-wrapper" style="margin-left:25px;">
    <div class="wrapper">
      <div class="page" style="margin-left:-25px; margin-top:50px;">
        <div class="header">
          <div class="header-left">
            <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
          </div>
          <div class="header-middle text-center" style="margin-left: -61px;margin-top:10px;">
            <h3 class=""><?php echo GNAME ?> </h3>
            <h4><?php echo SLOGAN ?></h4>
            <h6><?php echo ADDRESS . ',' . DISTRICT ?></h6>
            <h6><?php echo STATENAME ?>,नेपाल</h6>

            <img src="<?php echo base_url() ?>assets/img/plb.png"
              style="margin-top: -154px;margin-left: 560px;height: 94px;width: 94px;">
          </div>
          <div class="header-right">
            <!-- <div class="photo">
                <span>Photo</span>
              </div> -->
          </div>
        </div>
        <div class="sub-header">
          <div class="title">
            <p style="margin-left:7px;font-size:26px;margin-top:3px;"><b>संस्था दर्ता प्रमाण पत्र</b></p>
          </div>
        </div>
        <br>
        <div>
          <p style="font-size:18px;margin-top:25px;">दर्ता नं.
            <?php echo $this->mylibrary->convertedcit($row['darta_no'] . '/' . $row['fiscal_year']) ?>
          </p>
        </div>
        <div class="text-right" style="margin-top:-29px;margin-left:495px;">
          दर्ता मिति: <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?>
        </div>
        <div style="margin-left:-1px;margin-top:-5px;">
          <strong>
            श्री अध्यक्ष ज्यू, <br>
            श्री <?php echo $this->mylibrary->convertedcit($row['sanstha_name']) ?>,
        </div>
        <div style="margin-left:0px;margin-top:5px;">
          <?php echo 'गल्छी - ' . $this->mylibrary->convertedcit($row['p_ward']) . ',' . DISTRICT ?>
          |
        </div></strong>
        <div style="text-align:justify;margin-right:12px; margin-top: 20px;">
          <!-- मिति 
            <strong><?php echo $this->mylibrary->convertedcit($row['nirnaya_date']) ?></strong>
            को   निर्णय  अनुसार श्री  
            <strong><?php echo $this->mylibrary->convertedcit($row['sanstha_name']) ?></strong>
            नामक 
            संस्था , संस्था दर्ता  तथा  नियमन सम्बन्धि 
     ऐन  २०७८ को दफा ४ (३) बमोजिम  आज   मिति -->
          <?php
          // $date_from_nep_eng = $this->mylibrary->convertedcit(nep_to_eng($row['darta_miti']));
          $date = new DateTime($row['darta_miti']);

          $year = $date->format('Y');
          $month = $date->format('m');
          $day = $date->format('d');
          $dayOfWeek = $date->format('l');
          // pp($dayOfWeek);
          // $bsDate = '2081-02-09';
          // list($bsYear, $bsMonth, $bsDay) = explode('-', $bsDate);
          
          // // Convert Bikram Sambat date to jDateTime object
          // $bsDateTime = new jDateTime();
          // $bsDateTime->setDate($bsYear, $bsMonth, $bsDay);
          
          // // Get the name of the day of the week
          // $dayOfWeek = $bsDateTime->getDayOfWeekName();
          // pp($dayOfWeek); // Output the day of the week
          
          if ($month == 1) {
            $name = "बैशाख";
          } elseif ($month == 2) {
            $name = "जेष्ठ";
          } elseif ($month == 3) {
            $name = "आषाढ";
          } elseif ($month == 4) {
            $name = "श्रावन";
          } elseif ($month == 5) {
            $name = "भाद्र";
          } elseif ($month == 6) {
            $name = "आश्विन";
          } elseif ($month == 7) {
            $name = "कार्तिक";
          } elseif ($month == 8) {
            $name = "मङ्सिर";
          } elseif ($month == 9) {
            $name = "पौष";
          } elseif ($month == 10) {
            $name = "मार्ग";
          } elseif ($month == 11) {
            $name = "फाल्गुन";
          } else {
            $name = "चैत्र";
          }

          if ($dayOfWeek == "Sunday") {
            $roj = 1;
          } elseif ($dayOfWeek == "Monday") {
            $roj = 2;
          } elseif ($dayOfWeek == "Tuesday") {
            $roj = 3;
          } elseif ($dayOfWeek == "Wednesday") {
            $roj = 4;
          } elseif ($dayOfWeek == "Thursday") {
            $roj = 5;
          } elseif ($dayOfWeek == "Friday") {
            $roj = 6;
          } else {
            $roj = 7;
          }
          //  pp($dayOfWeek);
          ?>
          यस
          <b><?= $this->mylibrary->convertedcit(GNAME) ?></b>, वडा नं
          <b><?= $this->mylibrary->convertedcit($row['p_ward']) ?> ,<?= $this->mylibrary->convertedcit(DISTRICT) ?></b>
          मा रहेको
          श्री
          <b><?php echo $this->mylibrary->convertedcit($row['sanstha_name']) ?></b>
          नामक संस्थालाई
          <b><?= $this->mylibrary->convertedcit(GNAME) ?></b>
          <b><?= $this->mylibrary->convertedcit($sarkari_yin['rules']) ?></b> बमोजिम
          <b><?= $this->mylibrary->convertedcit($year) ?></b> साल
          <b><?= $this->mylibrary->convertedcit($name) ?></b> महिना
          <b><?= $this->mylibrary->convertedcit($day) ?></b> गते
          <!-- रोज <b><?= $this->mylibrary->convertedcit($roj) ?></b>  -->
          मा दर्ता गरि यो प्रमाण –पत्र प्रदान गरिएको छ l
          <strong>
          </strong>
        </div>
        <br>
        <div style="margin-top:80px;border-top: dotted 2px #000; width:118px;margin-left:30px;">
          <p style="font-size:18px">
          <div class="" id="maker" style="margin-left:-28px;width:170px;">
            <option value="">(प्रमाण-पत्र पाउनेको सहि)</option>
          </div>
          </p>
        </div>
        <div style="border-top: dotted 2px #000; width:100px;margin-left:514px;margin-top:-45px">
          <p style="font-size:18px">
            <select class="" id="checker" style="margin-left:-29px;width:170px;">
              <option value=""> प्रमाणित गर्नेको नाम छान्नुहोस्</option>
              <?php if (!empty($staffs)):
                foreach ($staffs as $staf): ?>
                  <option value="<?php echo $staf['id'] ?>" <?php if ($row['checker'] == $staf['id']) {
                       echo 'selected';
                     } ?>>
                    <?php echo $staf['name'] ?>(<?php echo $staf['designation'] ?>)
                  </option>
                <?php endforeach; endif; ?>
            </select>
          </p>
        </div>
      </div>
    </div>
  </div> <!-- endof warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
  // window.print();
</script>
<script type="text/javascript">
  $(document).ready(function () {
    var base_url = "<?php echo base_url() ?>";
    $('#maker').change(function () {
      obj = $(this);
      var maker = obj.val();
      var id = "<?php echo $this->uri->segment(3) ?>";
      $.ajax({
        url: base_url + 'Sanstha/updateMaker',
        method: "POST",
        data: {
          maker: maker,
          id: id,
          '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        },
        success: function (resp) {
          if (resp.status == 'success') {
            location.reload();
          }
        }
      });
    });
    $('#checker').change(function () {
      obj = $(this);
      var checker = obj.val();
      var id = "<?php echo $this->uri->segment(3) ?>";
      $.ajax({
        url: base_url + 'Sanstha/updateChecker',
        method: "POST",
        data: {
          checker: checker,
          id: id,
          '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        },
        success: function (resp) {
          if (resp.status == 'success') {
            location.reload();
          }
        }
      });
    });
  });
</script>

</html>