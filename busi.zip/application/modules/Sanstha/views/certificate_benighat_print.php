<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/landscape_print.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title>
    <?php echo GNAME ?>
  </title>

  <style>
    .title {
      height: 45px;
      width: 485px;
      border: 1px solid #555;
      margin-left: 312px;
      border-radius: 25px;
      text-align: center;
      /* border-radius: 25px; */
      margin-top: 30px;
    }

    .stamp {
      /* border: 2px solid #555; */
      /* height: 62px;
    width: 202px;
     */
      margin-left: 487px;
      border-radius: 5px;
      text-align: right;
      margin-right: 120px;
      margin-top: 50px;
    }

    @media print {
      @page {
        size: landscape;
      }
    }
  </style>
</head>

<body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle text-center" style="margin-left: -61px;margin-top:10px;">
          <h3 class=""><?php echo GNAME ?> </h3>
          <h4><?php echo SLOGAN ?></h4>
          <h6><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6><?php echo STATENAME ?>,नेपाल</h6>

          <img src="<?php echo base_url() ?>assets/img/plb.png"
            style="margin-top: -154px;margin-left: 800px;height: 94px;width: 94px;">
        </div>
        <div class="header-right">
          <div class="">

          </div>
        </div>
      </div>
      <div class="sub-header" style="margin-left: -57px;margin-bottom:90px;">
        <div class="title">
          <p style="margin-left:11px;font-size:26px;margin-top:3px;"><b>संस्था दर्ता प्रमाण-पत्र</b></p>
        </div>

      </div>
      <div>

        <div class="text-left" style="margin-top: -45px;">
          <div class="" style="font-size:20px;">दर्ता नं.
            <?php echo $this->mylibrary->convertedcit($row['darta_no'] . '-' . $row['fiscal_year']) ?>
          </div>
          <div class="" style="font-size:20px;">श्री अध्यक्ष ज्यू, <br>
            श्री <?php echo $this->mylibrary->convertedcit($row['sanstha_name']) ?>,
            <br>
            <?php echo 'गल्छी - ' . $this->mylibrary->convertedcit($row['p_ward']) . ',' . DISTRICT ?>
            |
          </div>
        </div>

        <div class="text-right" style="margin-left: 706px;margin-top:-95px;font-size:20px;">
          <div class="">दर्ता मिति:
            <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?>
          </div>
        </div>
        <?php
        $date = new DateTime($row['darta_miti']);
        $year = $date->format('Y');
        $month = $date->format('m');
        $day = $date->format('d');
        $dayOfWeek = $date->format('l');
        if ($month == 1) {
          $name = "बैशाख";
        } elseif ($month == 2) {
          $name = "जेष्ठ";
        } elseif ($month == 3) {
          $name = "आषाढ";
        } elseif ($month == 4) {
          $name = "श्रावन";
        } elseif ($month == 5) {
          $name = "भाद्र";
        } elseif ($month == 6) {
          $name = "आश्विन";
        } elseif ($month == 7) {
          $name = "कार्तिक";
        } elseif ($month == 8) {
          $name = "मङ्सिर";
        } elseif ($month == 9) {
          $name = "पौष";
        } elseif ($month == 10) {
          $name = "मार्ग";
        } elseif ($month == 11) {
          $name = "फाल्गुन";
        } else {
          $name = "चैत्र";
        }

        if ($dayOfWeek == "Sunday") {
          $roj = 1;
        } elseif ($dayOfWeek == "Monday") {
          $roj = 2;
        } elseif ($dayOfWeek == "Tuesday") {
          $roj = 3;
        } elseif ($dayOfWeek == "Wednesday") {
          $roj = 4;
        } elseif ($dayOfWeek == "Thursday") {
          $roj = 5;
        } elseif ($dayOfWeek == "Friday") {
          $roj = 6;
        } else {
          $roj = 7;
        }
        //  pp($dayOfWeek);
        ?>
        <div style="margin-left:20px; margin-top:105px; margin-right:50px;">
          <p style="font-size:20px;margin-top:-20px;text-indent: 2em;text-align:justify">
            यस
            <b><?= $this->mylibrary->convertedcit(GNAME) ?></b>, वडा नं
            <b><?= $this->mylibrary->convertedcit($row['p_ward']) ?>
              ,<?= $this->mylibrary->convertedcit(DISTRICT) ?></b>
            मा रहेको
            श्री
            <b><?php echo $this->mylibrary->convertedcit($row['sanstha_name']) ?></b>
            नामक संस्थालाई
            <b><?= $this->mylibrary->convertedcit(GNAME) ?></b>
            <b><?= $this->mylibrary->convertedcit($sarkari_yin['rules']) ?></b> बमोजिम
            <b><?= $this->mylibrary->convertedcit($year) ?></b> साल
            <b><?= $this->mylibrary->convertedcit($name) ?></b> महिना
            <b><?= $this->mylibrary->convertedcit($day) ?></b> गते
            <!-- रोज <b><?= $this->mylibrary->convertedcit($roj) ?></b> -->
            मा दर्ता गरि यो प्रमाण –पत्र प्रदान गरिएको छ l
          </p>
        </div>
        <div style="font-size:20px;margin-top: 225px;">
          (प्रमाण-पत्र पाउनेको सहि)
          <!-- <p><?php echo $maker['name'] ?></p> -->
          <!-- <p><?php echo $maker['designation'] ?></p> -->
        </div>
        <div style="font-size:20px;margin-top: -52px;margin-left: 879px;">
          <p><?php echo $checker['name'] ?></p>
          <p><?php echo $checker['designation'] ?></p>
        </div>
      </div>
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
  window.print();
</script>

</html>