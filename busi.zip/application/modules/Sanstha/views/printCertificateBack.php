<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>

  <style>
  .title {
    height: 45px;
    width: 485px;
    border: 1px solid #555;
    margin-left: 114px;
    border-radius: 25px;
    text-align:center;
    /* border-radius: 25px; */
    margin-top: 60px;
  }
  .nagarpalika_title {
    height: 45px;
    width: 485px;
    /* border: 1px solid #555; */
    margin-left: 114px;
    text-align:center;
    /* border-radius: 25px; */
    margin-top: 60px;
  }
  element.style {
    margin-left: 4px;
    font-size: 26px;
    margin-top: 3px;
}

  .stamp {
    /* border: 2px solid #555; */
    /* height: 62px;
    width: 202px;
     */
    margin-left: 487px;
    border-radius: 5px;
    text-align:right;
    margin-right:120px;
    margin-top: 50px;
  }
  @page { 
        size: landscape;
  }
  div.a {
  text-indent: 80%;
}
td {
  height: 50px;
}
  </style>
</head>

<body>
  <div class="main-wrapper">
    <div class="wrapper">
  <div class="page">
<div class="nagarpalika_title">
          <p style="margin-left:-217px;font-size:26px;margin-top:-109px;"><b>राईनस  नगरपालिका </b></p>
        </div>
        <div class="nagarpalika_title">
          <p style="margin-left:-192px;font-size:16px;margin-top:-66px;"><b><u>नविकरण</u> </b></p>
        </div>
        <div>
          <table style="margin-left:-32px;">
            <thead>
              <tr>
                <th> सि.नं</th>
                <th> मिति: </th>
                <th> बहाल रहने मिति अबधि </th>
                <th>दस्तखत </th>
                <th> कैफियत </th>
             </tr>
           </thead>
            <tbody>
              <tr>
                <td> </td>
                <td> </td>
                <td> </td>
                <td> </td>
                <td>  </td>
</tr>
          </tbody>
           </table>
</div>

        </div>
      </div>
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
window.print();
</script>
</html>