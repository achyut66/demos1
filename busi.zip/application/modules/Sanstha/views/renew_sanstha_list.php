main content start
<section id="main-content">
    <section class="wrapper site-min-height">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo base_url()?>"><i class="fa fa-home"></i> ड्यासबोर्डमा जानुहोस</a></li>
            <li class="breadcrumb-item active"><a href="<?php echo base_url()?>Sanstha" class="bactive">उद्योग र व्यवसाय दर्ता अभिलेखमा जानुहोस </a></li>
                <li class="breadcrumb-item active"><a href="javascript:;" class="bactive">नवीकरण विवरण</a></li>
      </ol>
      </nav>
        <!-- page start-->
        <div class="row">
          <div class="col-sm-12">
            <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
                if(!empty($success_message)) { ?>
                <div class="alert alert-success">
                    <button class="close" data-close="alert"></button>
                    <span> <?php echo $success_message;?> </span>
                </div>
              <?php } ?>
        
            <section class="card">
              <header class="card-header">
              <span><strong>संस्थाको नाम 
:- <?php echo $sanstha['sanstha_name']?> <button class="btn btn-outline-success mb-2">दर्ता नं. <?php echo $this->mylibrary->convertedcit($sanstha['darta_no'])?></button> <strong></span>
                <?php if(!empty($renews)) : ?>
                  <span class="tools">
                    <a href = "<?php echo base_url()?>Sanstha/renew/<?php echo $sanstha['id']?>" class=" btn btn-secondary pull-right" title=""><i class="fa fa-info-circle"></i> नवीकरण गर्नुहोस </a>
                </span>
                <?php endif;?>
              </header>
              
              <div class="card-body">
                <div class="adv-table">
                  <table  class="table table-bordered" id="">
                    <thead style="background: #1b5693; color:#fff">
                        <tr>
                          <th>#</th>
                          <th>नवीकरण मिति</th>
                          <th>नवीकरण अवधि</th>
                          <th>रसिद नं</th>
                          <th>बुझाएको दस्तुर</th>
                          <th>कैफियत</th>
                          <!-- <?php if($this->authlibrary->HasModulePermission('REGISTER', 'VIEW')){ ?>
                          <th class="hidden-phone"></th>
                          <?php } ?> -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i=1;if(!empty($renews)): foreach($renews as $r) : ?>
                        <tr>
                            <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                            <td><?php echo $this->mylibrary->convertedcit($r['date'])?></td>
                            <td><?php echo $this->mylibrary->convertedcit($r['fiscal_year_from']).'-'.$this->mylibrary->convertedcit($r['fiscal_year_to'])?></td>
                            <td><?php echo $this->mylibrary->convertedcit($r['rasid_no'])?></td>
                            <td><?php echo $this->mylibrary->convertedcit($r['dastur'])?></td>
                            <td><?php echo $this->mylibrary->convertedcit($r['remarks'])?></td>
                            <td>
                                <?php if($this->authlibrary->HasModulePermission('COMMITMENT', "EDIT")) { ?>
                                <a href ="<?php echo base_url()?>Register/editRenew/<?php echo $r['id']?>" class="btn btn-info"><i class="fa fa-pencil"></i></a>
                                <?php } ?>

                                <?php if($this->authlibrary->HasModulePermission('COMMITMENT', "DELETE")) { ?>
                                <a href = "<?php echo base_url()?>Register/deleteRenewDetails/<?php echo $r['id']?>" class=" btn btn-danger delete_data"><i class="fa fa-trash-o"></i></button>
                                <?php } ?>
                            </td>
                        </tr>
                        <?php endforeach;?>
                        <?php else : ?>
                        <tr>
                            <td colspan = 8><div class="alert alert-danger">नवीकरण गरिएको छैन!!<hr><a href = "<?php echo base_url()?>Register/renew/<?php echo $sanstha['id']?>" class=" btn btn-secondary" title=""><i class="fa fa-plus-circle"></i> नवीकरण गर्नुहोस  </a></div></td>
                        </tr>
                        <?php endif;?>
                    </tbody>
                  </table>
              </div>
            </section>
          </div>
        </div>
        <!-- page end-->
    </section>
</section>
<script src="<?php echo base_url('assets/datatable/datatables.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/nepali_datepicker/nepali.datepicker.v2.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $('#darta_miti').nepaliDatePicker();
    fetch_all_data();
    function fetch_all_data(main_topic, business_name, darta_no, darta_miti){
      var oTable = $('#dartalist').DataTable({
        "order": [[ 0, "desc" ]],
        "searching": false,
        'lengthChange':false,
        "processing": true,
        "serverSide": true,
        'language': {
            'loadingRecords': '&nbsp;',
            'processing': '<div class="spinner"></div>'
        },
        "ajax":{
          "url": "<?php echo base_url('Register/GetAllList') ?>",
          "dataType": "json",
          "type": "POST",
          "data":{  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>', main_topic:main_topic, business_name:business_name,darta_no:darta_no,darta_miti:darta_miti}
          },
        "columns": [
              { "data": "sn" },
              { "data": "darta_no" },
              { "data": "date" },
              { "data": "name" },
              { "data": "owner_name" },
              <?php if($this->authlibrary->HasModulePermission('REGISTER', 'VIEW')){ ?>
              {
                "data": "", render: function ( data, type, row ) {
                  var res = '<a href="<?php echo base_url()?>Register/viewDetails/'+row.id+'"'+' class="btn btn-info btn-sm"><i class="fa fa-info-circle"></i> पुरा विवरण हेर्नुहोस</a>';
                  return res;
                },
              },
              <?php } ?>
           ],
      });
    }
    $('#filter').click(function(){
      var main_topic        = $('#main_topic').val();
      var business_name     = $('#business_name').val();
      var darta_no          = $('#darta_no').val();
      var darta_miti        = $('#darta_miti').val();
      $('#dartalist').DataTable().destroy();
      fetch_all_data(main_topic, business_name,darta_no, darta_miti);
    });
  });
</script>
