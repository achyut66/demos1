<!--main content start-->
<html>

<head> </head>
<title> </title>
<link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">

<body>
  <section id="main-content">
    <section class="wrapper site-min-height">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"><i class="fa fa-home"></i> ड्यासबोर्डमा
              जानुहोस</a></li>
          <li class="breadcrumb-item active">संस्था दर्ता सुची</li>
        </ol>
      </nav>
      <!-- page start-->
      <div class="row">
        <div class="col-sm-12">
          <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
          if (!empty($success_message)) { ?>
            <div class="alert alert-success">
              <button class="close" data-close="alert"></button>
              <span> <?php echo $success_message; ?> </span>
            </div>
          <?php } ?>

          <section class="card">
            <header class="card-header">
              <span style="text-align:center">संस्था दर्ता अभिलेख</span>
              <span class="tools">
                <!-- <?php if ($this->authlibrary->HasModulePermission('REGISTER', "ADD")) { ?> -->
                  <a href="<?php echo base_url() ?>Sanstha/add" class=" btn btn-secondary pull-right" title=""><i
                      class="fa fa-plus-circle"></i> नयाँ संस्था दर्ता थप्नुहोस् </a>
                  <!-- <?php } ?> -->
              </span>
            </header>
            <div class="card-body">
              <div class="adv-table">
                <table class="display table table-bordered table-striped" id="myTable">
                  <thead style="background: #1b5693; color:#fff">
                    <tr>
                      <th> सि. नं</th>
                      <th>संस्था को नाम </th>
                      <th>संस्थाको किसिम </th>
                      <!-- <th>संस्था / सुचिकृत</th> -->
                      <th>दर्ता नं</th>
                      <th>दर्ता मिति</th>
                      <th>संस्थाको अध्यक्ष्यको नाम </th>
                      <th>.</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if (!empty($sanstha)) { ?>
                      <?php $i = 1;
                      foreach ($sanstha as $d):
                        if ($d['darta_suchikrit'] == 1) {
                          $if = '<button class="btn btn-warning">दर्ता</button>';
                        } else {
                          $if = '<button class="btn btn-warning">सूचीकरण</button>';
                        }
                        ?>
                        <tr>
                          <td><?= $this->mylibrary->convertedcit($i); ?></td>
                          <td><?php echo $this->mylibrary->convertedcit($d['sanstha_name']) ?></td>
                          <td><?php echo $this->mylibrary->convertedcit($d['sanstha_type']) ?></td>
                          <!-- <td><?= $if ?></td> -->
                          <td><?php echo $this->mylibrary->convertedcit($d['darta_no']) ?></td>
                          <td><?php echo $this->mylibrary->convertedcit($d['darta_miti']) ?></td>
                          <td><?php echo $this->mylibrary->convertedcit($d['adhaxya_name']) ?></td>
                          <td><a href="<?php echo base_url() ?>Sanstha/viewDetails/<?php echo $d['id'] ?>"
                              class="btn btn-secondary btn-sm" alt="पुरा विवरण हेर्नुहोस " title="पुरा विवरण हेर्नुहोस "><i
                                class="fa fa-eye"></i></a>
                            <a href="<?php echo base_url() ?>Sanstha/addPatra/<?php echo $d['id'] ?>"
                              class="btn btn-primary btn-sm" alt="संस्था दर्ता टिप्पणी ">संस्था दर्ता टिप्पणी</a>
                            <a href="<?php echo base_url() ?>Sanstha/edit/<?php echo $d['id'] ?>"
                              class="btn btn-primary btn-sm" alt="विवरण सम्पादन गर्नुहोस" title="विवरण सम्पंदा गर्नुहोस">
                              <i class="fa fa-pencil"></i></a>
                            <a href="<?php echo base_url() ?>Sanstha/edit/<?php echo $d['id'] ?>"
                              class="btn btn-warning btn-sm" alt="नबिकरण गर्नुहोस " title="नबिकरण गर्नुहोस">
                              <i class="fa fa- fa-unlock-alt"></i></a>
                            <button type="button" title="प्रमाण पत्र " data-toggle="modal"
                              href="<?php echo base_url() ?>Sanstha/certificate/<?php echo $d['id'] ?>"" class=" btn
                              btn-info btn-sm" style="margin-left:5px"><i class="fa fa-asterisk"></i></button>
                            <button type="button" title="सिफारिस पत्र" data-toggle="modal" href="#previewModel"
                              class="btn btn btn-default  btn-sm" data-url="" style="margin-left:5px"><i
                                class="fa fa-file"></i></button>
                            <a href="<?php echo base_url() ?>Sanstha/deleteSansthaDetails/<?php echo $d['id'] ?>"
                              class="btn btn-danger btn-sm delete_row" style="margin-left:5px" title="रद्ध गर्नुहोस"
                              id="delete_row">
                              <i class="fa fa-times-circle"></i></a>
                            <!-- <a href="<?php echo base_url() ?>Sanstha/ShowFiles/<?php echo $d['id'] ?>"
                              class="btn btn-warning btn-sm" alt="See Files" title="Show Files">
                              <i class="fa fa-fa-download"></i></a> -->
                          </td>
                        </tr>
                        <?php $i++; endforeach; ?>
                    <?php } else {
                    } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        </div>
      </div>
      <!-- page end-->
    </section>
  </section>
</body>
<html>
<script type="text/javascript"
  src="<?php echo base_url() ?>assets/nepali_datepicker/nepali.datepicker.v2.2.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
  integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
  integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
  integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"> </script>
<script>
  $(document).ready(function () {
    $('#myTable').DataTable();
  });
</script>
<script>
  $('#filter').click(function () {
    var sanstha_name = $('#sanstha_name').val();
    var sanstha_type = $('#sanstha_type').val();
    var darta_no = $('#darta_no').val();
    var darta_miti = $('#darta_miti').val();
    var adhaxya_name = $('#adhaxya_name').val();
    $('#myTable').DataTable().destroy();

    fetch_all_data(sanstha_name, sanstha_type, darta_no, darta_miti, adhaxya_name);
  });

  $(document).on('click', '.delete_row', function (e) {
    return confirm("Are you sure?");
  });

</script>