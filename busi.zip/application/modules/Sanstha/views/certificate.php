<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>

  <style>
  .title {
    height: 45px;
    width: 485px;
    border: 1px solid #555;
    margin-left: 139px;
    border-radius: 25px;
    text-align:center;
    /* border-radius: 25px; */
    margin-top: 60px;
  }
  .nagarpalika_title {
    height: 45px;
    width: 485px;
    /* border: 1px solid #555; */
    margin-left: 114px;
    text-align:center;
    /* border-radius: 25px; */
    margin-top: 60px;
  }
  element.style {
    margin-left: 4px;
    font-size: 26px;
    margin-top: 3px;
}

  .stamp {
    /* border: 2px solid #555; */
    /* height: 62px;
    width: 202px;
     */
    margin-left: 487px;
    border-radius: 5px;
    text-align:right;
    margin-right:120px;
    margin-top: 50px;
  }
  @page { 
        size: landscape;
  }
  div.a {
  text-indent: 80%;
}
td {
  height: 50px;
}
  </style>
</head>
<a class="nav-link" href="<?php echo base_url() ?>Sanstha/PrintCertificate/<?php echo $row['id'] ?>/<?php echo $row['darta_suchikrit']?>" target="_blank"> 
<div class="text-right" style="margin-left:641px;"><button class="btn btn-primary">प्रमाणपत्र प्रिन्ट गर्नुहोस्</button></a></div>
<!-- yema darta ko data lai rakhnu content sahit -->
<?php if($row['darta_suchikrit']==1){?>
<body>
    <div class="main-wrapper" style="margin-left:25px;">
    <div class="wrapper">
        <div class="page" style="margin-left:-89px; margin-top:-73px;">
          <div class="header">
            <div class="header-left">
              <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
            </div>
            <div class="header-middle">
    
              <h3 class=""><?php echo GNAME ?> </h3>
              <h4><?php echo SLOGAN ?></h4>
              <h6 style="margin-top:-10px;"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
              <h6 style="margin-top:-5px;"><?php echo STATENAME ?>,नेपाल</h6>
            </div>
            <div class="header-right">
              <!-- <div class="photo">
                <span>Photo</span>
              </div> -->
            </div>
          </div>
          <div class="sub-header">
            <div class="title">
              <p style="margin-left:7px;font-size:26px;margin-top:3px;"><b>संस्था  दर्ता प्रमाण पत्र</b></p>
            </div>
          </div>
          <br>
          <div class="a" style="margin-top:-156px;margin-left:62px;">
          मिति: <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?>
            </div>
          <div style="margin-top:132px;">
              <p style="font-size:18px;margin-top:50px;">संस्था दर्ता प्रमाण-पत्र  नं.
                <?php echo $this->mylibrary->convertedcit($row['darta_no'].'-'. $row['fiscal_year']) ?></p>
            </div>
            <div style="margin-left:-1px;margin-top:-5px;">
    <strong><?php echo $this->mylibrary->convertedcit($row['sanstha_name'])?>,
    </div>
    <div style="margin-left:0px;margin-top:5px;">
    <?php echo $row['tol'].' '.$this->mylibrary->convertedcit($row['p_ward']). ',' . DISTRICT ?> |
    </div></strong>
            <div style="text-align:justify;margin-right:12px; margin-top: 20px;">
            मिति 
            <strong><?php echo $this->mylibrary->convertedcit($row['nirnaya_date']) ?></strong>
            को   निर्णय  अनुसार श्री  
            <strong><?php echo $this->mylibrary->convertedcit($row['sanstha_name']) ?></strong>
            नामक 
            संस्था , संस्था दर्ता  तथा  नियमन सम्बन्धि 
     ऐन  २०७८ को दफा ४ (३) बमोजिम  आज   मिति
     <strong><?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></strong>
     गते  
     दर्ता  गरि यो प्रमाण -पत्र   दिइएको छ ।
    </div>
            <br>
            <div style="margin-top:80px;border-top: dotted 2px #000; width:118px;margin-left:30px;">
              <p style="font-size:18px">
                  <select class="" id="maker" style="margin-left:-28px;width:170px;">
                  <option value=""> तयार गर्नेको नाम छान्नुहोस्</option>
                  <?php if(!empty($staffs)) : foreach($staffs as $staff):?>
                  <option value="<?php echo $staff['id']?>" <?php if($row['maker'] == $staff['id']){echo 'selected';}?>><?php echo $staff['name']?>(<?php echo $staff['designation']?>)</option>
                  <?php endforeach;endif;?>
                </select></p>
            </div>
            <div style="border-top: dotted 2px #000; width:100px;margin-left:514px;margin-top:-45px">
              <p style="font-size:18px">
                  <select class="" id="checker" style="margin-left:-29px;width:170px;">
                  <option value=""> प्रमाणित गर्नेको नाम छान्नुहोस्</option>
                  <?php if(!empty($staffs)) : foreach($staffs as $staf):?>
                  <option value="<?php echo $staf['id']?>" <?php if($row['checker'] == $staf['id']){echo 'selected';}?>><?php echo $staf['name']?>(<?php echo $staf['designation']?>)</option>
                  <?php endforeach;endif;?>
                </select></p>
            </div>
            </div>
        </div>
    </div> <!-- endof warpper-->
</body>
<!-- yaha samma darta ko content aaune bhayo  -->

<!-- suchikrit ho bahne content rakhnu -->
<?php }else{ ?>
  <body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header" style="margin-top:165px;">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle" style="margin-left:105px;">
          <h3 class=""><?php echo GNAME ?> </h3>
          <h4><?php echo SLOGAN ?></h4>
          <h6 style="margin-top:-10px;"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6 style="margin-top:-5px;"><?php echo STATENAME ?>,नेपाल</h6>
        </div>
        <div class="text-right" style="margin-top:25px; margin-left:65px;">मिति:  
        <?php echo $this->mylibrary->convertedcit(convertDate(date("y-m-d"))) ?></div>
        <div class="header-right">
        </div>
      </div>
      <div class="sub-header">
        <div class="title" style="margin-top:70px;">
          <p style="margin-left:7px;font-size:26px;margin-top:3px;"><b> संस्था सूचीकरण सम्बन्धि प्रमाणपत्र </b></p>
        </div>
      </div>
        <div style="text-align:justify;margin-right:12px; margin-top: 140px;">
        <!-- मिति  
        <strong><?php echo $this->mylibrary->convertedcit($row['b_odarta_miti']) ?></strong> गते 
        दर्ता नं <strong><?php echo $this->mylibrary->convertedcit($row['darta_no'])?></strong>
        मा  
        <strong><?php echo $this->mylibrary->convertedcit($row['b_darta_office']) ?></strong> मा  दर्ता भएको श्री 
        <u><strong><?php echo $this->mylibrary->convertedcit($row['sanstha_name'])?></strong></u> लाई  राइनास नगरपालिका क्षेत्र मा काम गर्ने ,सहकार्य गर्ने प्रयोजनका  लागि  संस्था दर्ता तथा  
        नियमन सम्बन्धि नियमावली, २०७८ बमोजिम  
        मिति <strong><?php echo $this->mylibrary->convertedcit(convertDate(date("y-m-d"))) ?></strong> 
        <?php if(!empty($row['b_odarta_no'])){?>
        ( अन्य निकाय दर्ता नं 
        <strong><?php echo $this->mylibrary->convertedcit($row['b_odarta_no'])?></strong> )
        <?php }else{}?>
        गते  
        
        सुचिकृत गरि यो प्रमाण पत्र प्रदान गरिएको छ । -->
        मिति 
        <strong><?php echo $this->mylibrary->convertedcit($row['b_odarta_miti']) ?></strong> दर्ता नम्बर 
        <strong><?php echo $this->mylibrary->convertedcit($row['b_odarta_no'])?>/<?php echo $this->mylibrary->convertedcit($row['fiscal_year'])?></strong> मा 
        <strong><?php echo $this->mylibrary->convertedcit($row['b_darta_office']) ?></strong>
        दर्ता भएको 
        <u><strong><?php echo $this->mylibrary->convertedcit($row['sanstha_name'])?></strong></u> राइनास नगरपालिका क्षेत्रमा काम गर्ने,सहकार्य गर्ने प्रयोजनका लागि संस्था दर्ता तथा नियमन सम्बन्धि नियमावली , २०७८ बमोजिम 
        <strong><?php echo $this->mylibrary->convertedcit(convertDate(date("y-m-d"))) ?></strong> गते सुचिकृत गरि यो प्रमाण-पत्र प्रदान गरिएको छ l 
</div>
<br>
<div style="margin-top:80px;width:118px;margin-left:30px;">
<div class="text-left"><u><b>स्थानीय अधिकारी</b></u></div>
<br>
              <p style="font-size:18px">
                  <select class="" id="maker" style="margin-left:-28px;width:170px;">
                  <option value=""> तयार गर्नेको नाम छान्नुहोस्</option>
                  <?php if(!empty($staffs)) : foreach($staffs as $staff):?>
                  <option value="<?php echo $staff['id']?>" <?php if($row['maker'] == $staff['id']){echo 'selected';}?>><?php echo $staff['name']?>(<?php echo $staff['designation']?>)</option>
                  <?php endforeach;endif;?>
                </select></p>
            </div>
            <!-- <div style="border-top: dotted 2px #000; width:100px;margin-left:514px;margin-top:-45px">
              <p style="font-size:18px">
                  <select class="" id="checker" style="margin-left:-29px;width:170px;">
                  <option value=""> प्रमाणित गर्नेको नाम छान्नुहोस्</option>
                  <?php if(!empty($staffs)) : foreach($staffs as $staf):?>
                  <option value="<?php echo $staf['id']?>" <?php if($row['checker'] == $staf['id']){echo 'selected';}?>><?php echo $staf['name']?>(<?php echo $staf['designation']?>)</option>
                  <?php endforeach;endif;?>
                </select></p>
            </div> -->
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</div>
</div>
</body>
<?php }?>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
// window.print();
</script>
<script type="text/javascript">
$(document).ready(function() {
  var base_url = "<?php echo base_url() ?>";
  $('#maker').change(function() {
    obj = $(this);
    var maker = obj.val();
    var id = "<?php echo $this->uri->segment(3) ?>";
    $.ajax({
      url: base_url + 'Sanstha/updateMaker',
      method: "POST",
      data: {
        maker: maker,
        id: id,
        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
      },
      success: function(resp) {
        if (resp.status == 'success') {
          location.reload();
        }
      }
    });
  });
  $('#checker').change(function() {
    obj = $(this);
    var checker = obj.val();
    var id = "<?php echo $this->uri->segment(3) ?>";
    $.ajax({
      url: base_url + 'Sanstha/updateChecker',
      method: "POST",
      data: {
        checker: checker,
        id: id,
        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
      },
      success: function(resp) {
        if (resp.status == 'success') {
          location.reload();
        }
      }
    });
  });
});
</script>

</html>