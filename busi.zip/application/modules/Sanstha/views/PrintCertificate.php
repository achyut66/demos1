<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>

  <style>
  .title {
    height: 45px;
    width: 485px;
    border: 1px solid #555;
    margin-left: 139px;
    border-radius: 25px;
    text-align:center;
    /* border-radius: 25px; */
    margin-top: 100px;
  }
  .title1 {
    height: 45px;
    width: 485px;
    border: 1px solid #555;
    margin-left: 220px;
    border-radius: 25px;
    text-align:center;
     border-radius: 25px; 
    margin-top: 180px;
  }
  .nagarpalika_title {
    height: 45px;
    width: 485px;
    /* border: 1px solid #555; */
    margin-left: 114px;
    text-align:center;
    /* border-radius: 25px; */
    margin-top: 60px;
  }
  element.style {
    margin-left: 4px;
    font-size: 26px;
    margin-top: 3px;
}

  .stamp {
     border: 2px solid #555; 
     height: 62px;
    width: 202px;
     
    margin-left: 487px;
    border-radius: 5px;
    text-align:right;
    margin-right:120px;
    margin-top: 50px;
  }
  .header-middle{
      font-size:36px;
      margin-left:-119px;
      margin-top:60px;
      font-weight:bold;
  }
  .first{
      font-size:32px;
  }
  .second{
      font-size:32px;
  }
  .third{
      font-size:24px;
  }
  .fourth{
      font-size:24px;
  }
  @page { 
        size: portrait;
  }
  div.a {
  text-indent: 77%;
}
td {
  height: 50px;
}
  </style>
</head>
<!-- yema darta ko data lai rakhnu content sahit -->
<?php if($row['darta_suchikrit']==1){?>
<body>
  <div class="main-wrapper">
    <div class="wrapper">
  <div class="page">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle">
          <h3 class="first"><?php echo GNAME ?> </h3>
          <h4 class="second"><?php echo SLOGAN ?></h4>
          <h6 class="third" style="margin-top:-10px;"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6 class="fourth" style="margin-top:-5px;"><?php echo STATENAME ?>,नेपाल |</h6>
        </div>
        
        <div class="header-right">
        </div>
      </div>
      <div class="sub-header">
      <div>
          <p style="font-size:18px;margin-top:19px;margin-left:-6px;">संस्था दर्ता प्रमाण-पत्र  नं.
            <?php echo $this->mylibrary->convertedcit($row['darta_no'].'-'. $row['fiscal_year']) ?></p>
        </div>
<div class="a" style="margin-top:-35px;margin-left:65px;">
      मिति: <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?>
</div>
        <div class="title" style="margin-left:140px;margin-top:103px;">
          <p style="margin-left:-5px;font-size:26px;margin-top:4px;"><b>संस्था  दर्ता प्रमाणपत्र</b></p>
        </div>
      </div>
      <br>
<div class="text" style="font-size:20px; margin-top:35px;">
        श्री 
        <strong><?php echo $this->mylibrary->convertedcit($row['sanstha_name']) ?>
        <br>
        <?php echo $row['tol'].' '.$this->mylibrary->convertedcit($row['p_ward']). ',' . DISTRICT ?> |
        </strong>
</div>
        <div style="margin-right:12px; margin-top: 80px; font-size:22px;">
        मिति
        <strong><?php echo $this->mylibrary->convertedcit($row['nirnaya_date']) ?></strong>    को   निर्णय  अनुसार श्री 
        <strong><?php echo $this->mylibrary->convertedcit($row['sanstha_name']) ?></strong> नामक 
        संस्था , संस्था दर्ता  तथा  नियमन सम्बन्धि 
 ऐन  २०७८ को दफा ४ (३) बमोजिम  आज   मिति
 <strong><?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></strong>
 गते  
 दर्ता  गरि यो प्रमाण -पत्र   दिइएको छ ।
</div>
<br>
        <div style="font-size:16px; margin-top:95px; ">
          <p><?php echo $maker['name'] ?></p>
          <p><?php echo $maker['designation'] ?></p>
        </div>
        <div style="font-sixe:16px; margin-top:-75px; margin-left:650px;">
          <p><?php echo $checker['name'] ?></p>
          <p><?php echo $checker['designation'] ?></p>
        </div>
        </div>
      </div>
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<!-- yaha samma darta ko content aaune bhayo  -->

<!-- suchikrit ho bahne content rakhnu -->
<?php }else{ ?>
  <body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header" style="margin-top:-27px;">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle" style="margin-left:84px;font-wight:bold;">
          <h3 style="font-size:24px;"><?php echo GNAME ?> </h3>
          <h4 style="font-size:24px;"><?php echo SLOGAN ?></h4>
          <h6 style="margin-top:-10px;font-size:20px;"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6 style="margin-top:-5px;font-size:20px;"><?php echo STATENAME ?>,नेपाल</h6>
        </div>
        <div class="text-right" style="margin-top:194px; margin-left:33px;">मिति:  
        <?php echo $this->mylibrary->convertedcit(convertDate(date("y-m-d"))) ?></div>
        <div class="header-right">
          <!-- <div class="photo">
            <span>Photo</span>
          </div> -->
        </div>
      </div>
      <div class="sub-header" style="margin-left:-124px; margin-top:-67px;">
        <div class="title1" style="margin-top:128px;">
          <p style="margin-left:7px;font-size:26px;"><b> संस्था सूचीकरण सम्बन्धि प्रमाणपत्र </b></p>
        </div>
        <?php //pp($row);?>
      </div>
        <div style="text-align:justify;margin-right:12px; margin-top: 110px;">
        <!-- मिति  
        <strong><?php echo $this->mylibrary->convertedcit($row['b_odarta_miti']) ?></strong> गते 
        दर्ता नं 
        ( अन्य निकाय दर्ता नं 
        <strong><?php echo $this->mylibrary->convertedcit($row['b_odarta_no'])?></strong> )
        मा  
        <strong><?php echo $this->mylibrary->convertedcit($row['b_darta_office']) ?></strong> मा  दर्ता भएको श्री 
        <u><strong><?php echo $this->mylibrary->convertedcit($row['sanstha_name'])?></strong></u> लाई  राइनास नगरपालिका क्षेत्र मा काम गर्ने ,सहकार्य गर्ने प्रयोजनका  लागि  संस्था दर्ता तथा  
        नियमन सम्बन्धि नियमावली, २०७८ बमोजिम  
        मिति <strong><?php echo $this->mylibrary->convertedcit(convertDate(date("y-m-d"))) ?></strong> 
        गते  
        सुचिकृत गरि यो प्रमाण पत्र प्रदान गरिएको छ । -->
        मिति 
        <strong><?php echo $this->mylibrary->convertedcit($row['b_odarta_miti']) ?></strong> दर्ता नम्बर 
        <strong><?php echo $this->mylibrary->convertedcit($row['b_odarta_no'])?>/<?php echo $this->mylibrary->convertedcit($row['fiscal_year'])?></strong> मा 
        <strong><?php echo $this->mylibrary->convertedcit($row['b_darta_office']) ?></strong>
        दर्ता भएको 
        <u><strong><?php echo $this->mylibrary->convertedcit($row['sanstha_name'])?></strong></u> राइनास नगरपालिका क्षेत्रमा काम गर्ने,सहकार्य गर्ने प्रयोजनका लागि संस्था दर्ता तथा नियमन सम्बन्धि नियमावली , २०७८ बमोजिम 
        <strong><?php echo $this->mylibrary->convertedcit(convertDate(date("y-m-d"))) ?></strong> गते सुचिकृत गरि यो प्रमाण-पत्र प्रदान गरिएको छ l 
</div>
        <div style="font-size:16px; margin-top:435px;">
        <div class="text-left"><u><b>स्थानीय अधिकारी                       </b></u></div>
        <br>
        <div class="text-left">दस्तखत :</div><br>
          <div class="text-left">नाम : <p style="margin-left:41px;margin-top:-24px;"><?php echo $maker['name'] ?></p></div>
          <div class="text-left">दर्जा : <p style="margin-left:43px;margin-top:-24px;"><?php echo $maker['designation'] ?></p></div>
        </div>
        <!-- <div style="font-size:16px; margin-top:-102px; margin-left:480px;">
           <div class="text-center" style="margin-left:-47px;">___________________________________</div>
          <p>( <?php echo $checker['name'] ?> )</p>
          <p><?php echo $checker['designation'] ?></p>
        </div> -->
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</div>
</div>
</body>
<?php }?>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
window.print();
</script>
</html>