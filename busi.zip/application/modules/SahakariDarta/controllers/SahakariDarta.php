<?php

/**
 * Created by PhpStorm.
 * User: root
 * Date: 12/2/16
 * Time: 9:57 PM
 */
class SahakariDarta extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->load->model("SahakariDartaModel");
        $this->module_code = 'SAHAKARI-DARTA';
        if (!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login', 'location');
        }
    }

    /**
     * This function load add buy or sell form
     * @param NULL
     * return load view with list
     */
    public function Index()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $data['page']   = 'list_all';
            $data['rows'] = $this->CommonModel->getData('sahakari_darta');
            $data['fiscal_year'] = $this->CommonModel->getData('fiscal_year', 'DESC');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
     * This function load add buy or sell form
     * @param NULL
     * return view
     */
    public function add()
    {
        $data['page']           = 'add';
        $data['wards']          = $this->CommonModel->getData('settings_ward', 'DESC');
        $data['districts']      = $this->CommonModel->getData('settings_district', 'DESC');
        $data['pradesh']        = $this->CommonModel->getData('provinces', 'DESC');
        $data['prakar']         = $this->CommonModel->getData('main_topic');
        $data['category']       = $this->CommonModel->getData('category');
        $data['gapana']         = $this->CommonModel->getData('settings_vdc_municipality', 'DESC');
        $darta                  = $this->SahakariDartaModel->GetMaxDartaID();
        $data['darta_no']       = $darta->darta_no + 1;
        $data['karyabids']      = $this->CommonModel->getData('karya_bidi');
        $this->load->view('main', $data);
    }
    //save 
    public function save()
    {
        if ($this->input->post('Submit')) {
            $darta_no                       = $this->input->post('darta_no');
            $fiscal_year                    = current_fiscal_year();
            $darta_miti                     = $this->input->post('darta_miti');
            $name                           = $this->input->post('name');
            $p_pardesh                      = $this->input->post('p_pardesh');
            $p_district                     = $this->input->post('p_district');
            $p_gapa                         = $this->input->post('p_gapa');
            $p_ward                         = $this->input->post('p_ward');
            $tol                            = $this->input->post('tol');
            $total_male_member              = $this->input->post('total_male_member');
            $total_female_member            = $this->input->post('total_female_member');
            $total_member                   = $this->input->post('total_member');
            $working_area                   = $this->input->post('working_area');
            $responsibility                 = $this->input->post('responsibility');
            $total_share_amount             = $this->input->post('total_share_amount');
            $entry_share_amount             = $this->input->post('entry_share_amount');
            $aims                           = $this->input->post('aim');
            $aim                            = implode('<>', $aims);
            $main_works                     = $this->input->post('main_work');
            $sakari_datra_ain               = $this->input->post('sakari_datra_ain');
            $main_work                      = implode('<>', $main_works);
            $save_array                     = array(
                'darta_no'                  => $darta_no,
                'name'                      => $name,
                'p_pradesh'                 => $p_pardesh,
                'p_district'                => $p_district,
                'p_gapa'                    => $p_gapa,
                'p_ward'                    => $p_ward,
                'tol'                       => $tol,
                't_male'                    => $total_male_member,
                't_female'                  => $total_female_member,
                'total_member'              => $total_member,
                'working_area'              => $working_area,
                'responsibility'            => $responsibility,
                'total_share_amount'        => $total_share_amount,
                'entry_share_amount'        => $entry_share_amount,
                'aim'                       => $aim,
                'main_work'                 => $main_work,
                'fiscal_year'               => current_fiscal_year(),
                'darta_miti'                => $darta_miti,
                'status'                    => 1,
                'created_at'                => convertDate(date('Y-m-d')),
                'created_by'                => $this->session->userdata('PRJ_USER_BID'),
                'sakari_datra_ain'          => $sakari_datra_ain,
            );
            $result = $this->CommonModel->insertData('sahakari_darta', $save_array);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                redirect('SahakariDarta');
            }
        }
    }

    //view details
    public function viewDetails($id = NULL)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row']            = $this->CommonModel->getDataByID('sahakari_darta', $id);
            //$data['members']        = $this->CommonModel->getWhereAll('krishi_samuha_members',array('samuha_id', $id));
            $data['page']           = 'view_details';
            $this->load->view('main', $data);
        }
    }

    public function edit($id)
    {
        $data['page']           = 'edit';
        $data['wards']          = $this->CommonModel->getData('settings_ward', 'DESC');
        $data['districts']      = $this->CommonModel->getData('settings_district', 'DESC');
        $data['pradesh']        = $this->CommonModel->getData('provinces', 'DESC');
        $data['prakar']         = $this->CommonModel->getData('main_topic');
        $data['category']       = $this->CommonModel->getData('category');
        $data['subtopic']       = $this->CommonModel->getData('prakar');
        $data['gapana']         = $this->CommonModel->getData('settings_vdc_municipality', 'DESC');
        $data['row']            = $this->CommonModel->getDataById('sahakari_darta', $id);
        //pp($data['row']);
        $data['members']        = $this->CommonModel->getWhereAll('krishi_samuha_members', array('samuha_id', $id));
        $data['karyabids']      = $this->CommonModel->getData('karya_bidi');
        $this->load->view('main', $data);
    }

    //update details
    public function update()
    {
        if ($this->input->post('Submit')) {
            $id                             = $this->input->post('id');
            $darta_no                       = $this->input->post('darta_no');
            $name                           = $this->input->post('name');
            $p_pardesh                      = $this->input->post('p_pardesh');
            $p_district                     = $this->input->post('p_district');
            $p_gapa                         = $this->input->post('p_gapa');
            $p_ward                         = $this->input->post('p_ward');
            $tol                            = $this->input->post('tol');
            $total_male_member              = $this->input->post('total_male_member');
            $total_female_member            = $this->input->post('total_female_member');
            $total_member                   = $this->input->post('total_member');
            $working_area                   = $this->input->post('working_area');
            $responsibility                 = $this->input->post('responsibility');
            $total_share_amount             = $this->input->post('total_share_amount');
            $entry_share_amount             = $this->input->post('entry_share_amount');
            $sakari_datra_ain               = $this->input->post('sakari_datra_ain');
            $aims                           = $this->input->post('aim');
            $aim                            = implode('<>', $aims);
            $main_works                     = $this->input->post('main_work');
            $main_work                      = implode('<>', $main_works);
            $save_array                     = array(
                'darta_no'                  => $darta_no,
                'name'                      => $name,
                'p_pradesh'                 => $p_pardesh,
                'p_district'                => $p_district,
                'p_gapa'                    => $p_gapa,
                'p_ward'                    => $p_ward,
                'tol'                       => $tol,
                't_male'                    => $total_male_member,
                't_female'                  => $total_female_member,
                'total_member'              => $total_member,
                'working_area'              => $working_area,
                'responsibility'            => $responsibility,
                'total_share_amount'        => $total_share_amount,
                'entry_share_amount'        => $entry_share_amount,
                'aim'                       => $aim,
                'main_work'                 => $main_work,
                'modified_by'               => convertDate(date('Y-m-d')),
                'modified_at'               => $this->session->userdata('PRJ_USER_BID'),
                'sakari_datra_ain'          => $sakari_datra_ain,
            );
            $result = $this->CommonModel->updateData('sahakari_darta', $id, $save_array);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                redirect('SahakariDarta/viewDetails/' . $id);
            }
        }
    }

    //print certificate
    public function printcertificate($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row']            = $this->CommonModel->getDataById('sahakari_darta', $id);
            $data['staffs']         = $this->CommonModel->getData('staff');
            $data['maker']          = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $this->load->view('print_details', $data);
        }
    }

    //print printPramanparta
    public function certificate($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row']            = $this->CommonModel->getDataById('sahakari_darta', $id);
            $data['staffs']         = $this->CommonModel->getData('staff');
            $data['maker']          = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $this->load->view('certificate', $data);
        }
    }
    //datatable list
    public function GetAllList()
    {
        if ($this->input->is_ajax_request()) {
            $columns = array(0     => 'id');
            $limit                  = $this->input->post('length');
            $start                  = $this->input->post('start');
            $type                   = $this->input->post('type');
            $fiscal_year            = $this->input->post('fiscal_year');
            $samuha_name            = $this->input->post('samuhan_name');
            $darta_no               = $this->input->post('darta_no');
            $darta_miti             = $this->input->post('darta_miti');
            $sn                     = $start + 1;
            $order                  = $columns[$this->input->post('order')[0]['column']];
            $dir                    = $this->input->post('order')[0]['dir'];
            $totalData              = $this->SahakariDartaModel->CountAll($fiscal_year, $samuha_name, $type, $darta_no, $darta_miti);
            $totalFiltered          = $totalData;
            $posts                  = $this->SahakariDartaModel->GetAll($limit, $start, $order, $dir, $fiscal_year, $samuha_name, $type, $darta_no, $darta_miti);

            $data                   = array();
            if (!empty($posts)) {
                $i = 1;
                foreach ($posts as $post) {
                    if ($post->renew_status == 1) {
                        $has_nabikaran = 'भएको';
                    } else {
                        $has_nabikaran = '-';
                    }
                    $nestedData['sn']               = $this->mylibrary->convertedcit($sn++);
                    $nestedData['id']               = $post->id;
                    $nestedData['darta_miti']             = $this->mylibrary->convertedcit($post->darta_miti);
                    $nestedData['name']             = $this->mylibrary->convertedcit($post->name);
                    $nestedData['address']          = $post->tol . '-' . $this->mylibrary->convertedcit($post->p_ward) . ',  ' . $post->p_gapa;
                    $nestedData['darta_no']         = '<span class="badge badge-pill badge-secondary">' . $this->mylibrary->convertedcit($post->darta_no) . '</span>';
                    //$nestedData['darta_date']       = $this->mylibrary->convertedcit($post->darta_date);
                    $nestedData['male']             = $this->mylibrary->convertedcit($post->t_male);
                    $nestedData['female']           = $this->mylibrary->convertedcit($post->t_female);
                    $nestedData['nabikaran_status'] = $has_nabikaran;
                    $data[] = $nestedData;
                }
            }
            $json_data = array(
                "draw"            => intval($this->input->post('draw')),
                "recordsTotal"    => intval($totalData),
                "recordsFiltered" => intval($totalFiltered),
                "data"            => $data
            );
            echo json_encode($json_data);
        } else {
            exit('HTTPS!!');
        }
    }

    public function updatePhoto()
    {
        $data['id'] = $this->input->post('id');
        $this->load->view('upload_photo', $data);
    }

    //update photo
    public function updateImage()
    {
        $id                         = $this->input->post('id');
        $userfile                   = $_FILES['userfile']['name'];
        $file                       =  preg_replace('/\s+/', '_', $userfile);
        if (!empty($userfile)) {
            $config = array(
                'upload_path'       => './assets/business_owner/',
                'allowed_types'     => "jpg|png|PNG|jpeg|JPEG",
                'max_size'          => 1024,
                'overwrite'         => TRUE,
                'file_name'         => preg_replace('/\s+/', '_', $file),
            );
            $this->load->library('upload');
            $this->upload->initialize($config);
            if (!$this->upload->do_upload('userfile')) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => 'Cannot upload image'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $this->upload->do_upload();
            }
            $update_array = array('image' => $file);
            $result = $this->CommonModel->updateData('darta', $id, $update_array);
            if ($result) {
                $response = array(
                    'status'        => 'success',
                    'message'       => 'redirect',
                    'redirect_url'  => base_url() . 'Register/viewDetails/' . $id,
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        }
    }
    /* ------------------------------------------------------
    renew details
    ----------------------------------------------------*/
    //renew darta
    public function RenewDetails($id)
    {
        $data['page'] = 'renew_darta';
        $data['row'] = $this->CommonModel->getDataById('sahakari_darta', $id);
        $renew_details = $this->CommonModel->getWhere('renew', array('fiscal_year_from' => current_fiscal_year(), 'darta_id' => $id));
        if (!empty($renew_details)) {
            $this->session->set_flashdata('MSG_SUCCESS', 'समूह नवीकरण भइसकेको छ');
            redirect('SahakariDarta');
        }
        $this->load->view('main', $data);
    }

    //save nabikarn details
    public function nabikaran()
    {
        if ($this->input->post('Submit')) {
            $samuha_id                  = $this->input->post('darta_id');
            $darta_no                   = $this->input->post('darta_no');
            $b_type                     = $this->input->post('b_type');
            $b_subtype                  = $this->input->post('b_subtype');
            $date                       = $this->input->post('date');
            $fiscal_year_from           = $this->input->post('fiscal_year_from');
            $fiscal_year_to             = $this->input->post('fiscal_year_to');
            $rasid_no                   = $this->input->post('rasid_no');
            $dastur                     = $this->input->post('dastur');
            $remarks                    = $this->input->post('remarks');
            $rasid_no                   = $this->input->post('rasid_no');
            $save_array                 = array(
                'darta_id'              => $samuha_id,
                'date'                  => $date,
                'darta_no'              => $darta_no,
                'b_type'                => '',
                'b_subtype'             => '',
                'fiscal_year_from'      => $fiscal_year_from,
                'fiscal_year_to'        => $fiscal_year_to,
                'rasid_no'              => $rasid_no,
                'dastur'                => $dastur,
                'remarks'               => $remarks,
                'fiscal_year'           => current_fiscal_year(),
                'created_at'            => convertDate(date('Y-m-d h:i:sa')),
                'created_by'            => $this->session->userdata('PRJ_USER_BID'),
                'added_ward'            => $this->session->userdata('PRJ_USER_WARD'),
                'renew_type'            => $this->uri->segment(1),
            );
            $result = $this->CommonModel->insertData('renew', $save_array);
            if ($result) {
                $renew_status = array('renew_status' => 1);
                $this->CommonModel->updateData('sahakari_darta', $samuha_id, $renew_status);
                $this->session->set_flashdata('MSG_SUCCESS', 'तपाई नवकिरण गर्न सफल हुनुभयो');
                redirect('SahakariDarta');
            }
            // pp($save_array);
            // $darta_details = $this->CommonModel->getWhere('darta', array('id' => $darta_id));
            // if ($darta_details['fiscal_year'] == current_fiscal_year()) {
            //     $this->session->set_flashdata('MSG_WAR', 'नवीकरण गर्न मिल्दैन');
            //     redirect('Register/viewDetails/' . $darta_id);
            // }
            // $checkIfExits = $this->CommonModel->getWhere('renew', array('darta_id', 'fiscal_year' => current_fiscal_year()));
            // if (!empty($checkIfExits)) {
            //     $this->session->set_flashdata('MSG_ERR', 'नवीकरण गरिसकेको छ');
            //     redirect('Register/viewDetails/' . $darta_id);
            // }
            // $result = $this->CommonModel->insertData('renew', $save_array);
            // if ($result) {
            //     $this->session->set_flashdata('MSG_SUCCESS', 'तपाई नवकिरण गर्न सफल हुनुभयो');
            //     redirect('Register/viewDetails/' . $darta_id);
            // }
        }
    }

    //list nabikaran details
    public function listNabikarnDetails($darta_id)
    {
        $data['page']       = 'renew_darta_list';
        $data['renews']     = $this->CommonModel->getWhereAll('renew', array('darta_id' => $darta_id));
        $data['darta']      = $this->CommonModel->getWhere('darta', array('id' => $darta_id));
        $this->load->view('main', $data);
    }

    //edit renew
    public function editRenew($renewid)
    {
        $data['page'] = 'renew_darta_edit';
        $data['row'] = $this->CommonModel->getDataById('renew', $renewid);
        $this->load->view('main', $data);
    }

    //update reneew details
    public function updateRenew()
    {
        if ($this->input->post('Submit')) {
            $id                         = $this->input->post('id');
            $darta_id                   = $this->input->post('darta_id');
            $fiscal_year_from           = $this->input->post('fiscal_year_from');
            $fiscal_year_to             = $this->input->post('fiscal_year_to');
            $rasid_no                   = $this->input->post('rasid_no');
            $dastur                     = $this->input->post('dastur');
            $remarks                    = $this->input->post('remarks');
            $rasid_no                   = $this->input->post('rasid_no');
            $save_array                 = array(
                'fiscal_year_from'      => $fiscal_year_from,
                'fiscal_year_to'        => $fiscal_year_to,
                'rasid_no'              => $rasid_no,
                'dastur'                => $dastur,
                'remarks'               => $remarks,
                'modified_at'            => convertDate(date('Y-m-d h:i:sa')),
                'modified_by'            => $this->session->userdata('PRJ_USER_BID'),
            );
            $result = $this->CommonModel->updateData('renew', $id, $save_array);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'success');
                redirect('Register/listNabikarnDetails/' . $darta_id);
            }
        }
    }

    //delete renew
    public function deleteRenewDetails($id)
    {
        $row = $this->CommonModel->getDataById('renew', $id);
        if (!empty($row)) {
            $result = $this->CommonModel->deleteData('renew', $id);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'success');
                redirect('Register/listNabikarnDetails/' . $row['darta_id']);
            }
        }
    }

    //print renew certificate
    public function renewCertificate($darta_id)
    {
        $data['renewDetails'] = $this->CommonModel->getWhere('renew', array('darta_id' => $darta_id));
        if (empty($data['renewDetails'])) {
            $this->session->set_flashdata('MSG_ERR', 'नवीकरण गरिएको छैन. कृपया नवीकरण गर्नुहोस');
            redirect('Register/viewDetails/' . $darta_id);
        } else {
            $data['renewdetails'] = $this->CommonModel->getWhereAll('renew', array('darta_id' => $darta_id));
            $this->load->view('renew_certificate', $data);
        }
    }

    //update maker
    public function updateMaker()
    {
        $id                 = $this->input->post('id');
        $maker              = $this->input->post('maker');
        $data               = array('maker' => $maker);
        $result             = $this->CommonModel->updateData('sahakari_darta', $id, $data);
        if ($result) {
            $response       = array(
                'status'    => 'success',
                'data'      => "सफलतापूर्वक सम्मिलित गरियो",
                'message'   => 'success'
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
        }
    }

    //update checker
    public function updateChecker()
    {
        $id                 = $this->input->post('id');
        $checker            = $this->input->post('checker');
        $data               = array('checker' => $checker);
        $result             = $this->CommonModel->updateData('darta', $id, $data);
        if ($result) {
            $response       = array(
                'status'    => 'success',
                'data'      => "सफलतापूर्वक सम्मिलित गरियो",
                'message'   => 'success'
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
        }
    }

    //remove members
    public function removeMember($id, $faram_id)
    {
        if (empty($id)) {
            show_404();
        } else {
            $result = $this->CommonModel->deleteData('krishi_samuha_members', $id);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'Member removed successfully');
                redirect('AgricultureDepartment/edit/' . $faram_id);
            }
        }
    }
}//end of class