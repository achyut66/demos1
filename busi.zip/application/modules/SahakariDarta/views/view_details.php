 <!--main content start-->
 <style>
     .table-bordered td, .table-bordered th{
        border: 1px solid #3a5d7f;
     }
 </style>
<section id="main-content">
    <section class="wrapper site-min-height">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url()?>"><i class="fa fa-home"></i> ड्यासबोर्डमा</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo base_url()?>SahakariDarta" class="bactive">सहकारी दर्ता सुचीमा जानुहोस</a></li>
                <li class="breadcrumb-item active"><a href="javascript:;" class="bactive">विवरण हेर्नुहोस</a></li>
            </ol>
        </nav>
              <!-- page start-->
        <div class="row">
            <aside class="profile-info col-lg-9">
                <section class="card">
                    <header class="card-header text-light " style="background-color:#4d5886">संस्थाको  नाम: <?php echo $row['name']?> <span class="btn btn-success btn-circle"> दर्ता नं. <?php echo $this->mylibrary->convertedcit($row['darta_no'])?></span>
                    </header>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
                                    if(!empty($success_message)) { ?>
                                    <div class="alert alert-success">
                                        <button class="close" data-close="alert"></button>
                                        <span> <?php echo $success_message;?> </span>
                                    </div>
                                <?php } ?>

                                <?php $err_message = $this->session->flashdata("MSG_ERR");
                                    if(!empty($err_message)) { ?>
                                    <div class="alert alert-danger">
                                        <button class="close" data-close="alert"></button>
                                        <span> <?php echo $err_message;?> </span>
                                    </div>
                                <?php } ?>
                                <?php $err_message = $this->session->flashdata("MSG_WAR");
                                    if(!empty($err_message)) { ?>
                                    <div class="alert alert-warning">
                                        <button class="close" data-close="alert"></button>
                                        <span> <?php echo $err_message;?> </span>
                                    </div>
                                <?php } ?>
                                

                                <table class="table table-bordered">
                                    <tr>
                                        <td><strong><span>दर्ता मिति: </span><?php echo $this->mylibrary->convertedcit($row['darta_miti'])?></strong></td>
                                        <td><strong><span>पुरुष सदस्य संख्या:</span> <?php echo $this->mylibrary->convertedcit($row['t_male'])?></strong></td>
                                        <td><strong><span>महिला सदस्य संख्या:</span> <?php echo $this->mylibrary->convertedcit($row['t_female'])?></strong></td>
                                        <td><strong><span>जम्मा सदस्य संख्या :</span> <?php echo $this->mylibrary->convertedcit($row['total_member'])?></strong></td>
                                        <td><strong><span>कार्य क्षेत्र: </span><?php echo $this->mylibrary->convertedcit($row['working_area'])?></strong></td>
                                    </tr>
                                    <tr>
                                        <td><strong><span>दायित्व </span> <?php echo $this->mylibrary->convertedcit($row['responsibility'])?></strong></td>
                                        <td><strong><span>प्राप्त शेयर पूजीँको रकम: </span> <?php echo $this->mylibrary->convertedcit($row['total_share_amount'])?></strong></td>
                                        <td><strong><span>प्राप्त प्रवेश शुल्कको रकम: </span> <?php echo $this->mylibrary->convertedcit($row['entry_share_amount'])?></strong></td>
                                        <td colspan = 2><strong><span>सहकारी ऐन: <?php echo $row['sakari_datra_ain']?></span></strong></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="card">
                    <header class="card-header text-light " style="background-color:#4d5886">उद्देश्यहरु</header>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                            <table class="table table-hover personal-task">
                                <tbody>
                                    <?php $amis = explode('<>',$row['aim']);
                                    if(!empty($amis)) :$i=1; foreach($amis as $key => $ami) : ?>
                                    <tr>
                                        <td style="width:50px;"><?php echo $this->mylibrary->convertedcit($i++)?></td>
                                        <td style="text-align:left"><?php echo $this->mylibrary->convertedcit($ami)?></td>
                                    </tr>
                                    <?php endforeach;endif;?>
                                </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="card">
                    <header class="card-header text-light " style="background-color:#4d5886">मुख्य कार्य</header>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                            <table class="table table-hover personal-task">
                                <tbody>
                                    <?php $mainworks = explode('<>',$row['main_work']);
                                    if(!empty($mainworks)) :$i=1; foreach($mainworks as $key => $mainwork) : ?>
                                    <tr>
                                        <td style="width:50px;"><?php echo $this->mylibrary->convertedcit($i++)?></td>
                                        <td style="text-align:left"><?php echo $this->mylibrary->convertedcit($mainwork)?></td>
                                    </tr>
                                    <?php endforeach;endif;?>
                                </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>
               
            </aside>
            <aside class="profile-nav col-lg-3">
                <section class="card">
                    <div class="user-heading round">
                        <!-- <a href="#" data-toggle="modal" data-target="#editModel" data-url="<?php //echo base_url()?>Register/updatePhoto" data-id = "<?php //echo $row['id']?>">
                            <img src="<?php //echo base_url()?>assets/business_owner/<?php //echo !empty($row['image'])?$row['image']:'emt.jpg'?>" alt="">
                        </a>  -->
                        <h1><?php echo !empty($row['name'])?$row['name']:''?></h1>
                        <p><?php echo $row['tol'].'-'.$this->mylibrary->convertedcit($row['p_ward']).' ,'.$this->mylibrary->convertedcit($row['p_gapa'])?>,<?php echo $row['p_district'];?><br><?php echo $row['p_pradesh'];?></p>
                    </div>

                    <ul class="nav nav-pills nav-stacked">
                        <li class="active nav-item"><a class="nav-link" href="<?php echo base_url()?>SahakariDarta/edit/<?php echo $row['id']?>"> <i class="fa fa-pencil"></i> विवरण सम्पादन गर्नुहोस्</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo base_url()?>SahakariDarta/printcertificate/<?php echo $row['id']?>" target="_blank"> <i class="fa fa-print"></i>प्रमाणपत्र प्रिन्ट गर्नुहोस् </a></li>
                        <!-- <li class="nav-item"><a class="nav-link" href="<?php echo base_url()?>SahakariDarta/listNabikarnDetails/<?php echo $row['id']?>"> <i class="fa fa-file"></i>नवीकरणको विवरण </a></li> -->
                        
                    </ul>

                </section>
            </aside>
        </div>   
    </section>
</section><!--main content end-->
