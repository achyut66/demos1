<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>

  <style>
  .title {
    height: 45px;
    width: 485px;
    border: 1px solid #555;
    margin-left: 590px;
    border-radius: 25px;
    text-align:center;
    /* border-radius: 25px; */
    margin-top: 60px;
  }

  .stamp {
    /* border: 2px solid #555; */
    /* height: 62px;
    width: 202px;
     */
    margin-left: 487px;
    border-radius: 5px;
    text-align:right;
    margin-right:120px;
    margin-top: 50px;
  }
  @page { 
        size: landscape;
  }
  </style>
</head>

<body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle">

          <h3 class=""><?php echo GNAME ?> </h3>
          <h4><?php echo SLOGAN ?></h4>
          <h6 style="margin-top:-10px;"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6 style="margin-top:-5px;"><?php echo STATENAME ?>,नेपाल</h6>
        </div>
        <div class="header-right">
          <!-- <div class="photo">
            <span>Photo</span>
          </div> -->
        </div>
      </div>
      <div class="sub-header" style="margin-left:-337px;font-size:26px;margin-top:3px;">
        <div class="title">
          <p><b>सहकारी दर्ता प्रमाण पत्र</b></p>
        </div>

      </div>
      <div>

        <div style="margin-left:50px; margin-top:120px;">
          <p style="font-size:18px;margin-top:50px;">दर्ता नं.
            <?php echo $this->mylibrary->convertedcit($row['darta_no'].'-'. $row['fiscal_year']) ?></p>
        </div>

        <div style="margin-left:50px;margin-top:-10px;">
          <p style="font-size:18px;margin-top:10px;">श्री. <?php echo $this->mylibrary->convertedcit($row['name']) ?>
          </p>
        </div>
        <div style="margin-left:50px; margin-top:-10px;">
          <p style="font-size:18px;margin-top:0px;">
            <?php echo $this->mylibrary->convertedcit($row['p_gapa']) . '-' . $this->mylibrary->convertedcit($row['p_ward']) . ' ,' . $row['tol'] . ' ,' . $row['p_district'] ?>
            ।</p>
        </div>
        <div style="text-align:right;margin-right:50px; margin-top:-110px;">
          <p>दर्ता मिति:
            <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></p>
        </div>

        <div style="margin-left:50px; margin-top:105px; margin-right:50px;">
          <p style="font-size:18px;margin-top:0px;text-align:justify"><?php echo GNAME ?>
            <?php echo $row['sakari_datra_ain'] ?> बमोजिम श्री <?php echo $row['name'] ?>
            <?php echo $row['tol'] . '-' . $this->mylibrary->convertedcit($row['p_ward']) ?> स्वीकृत विनियम सहित यो
            प्रमाण
            पत्र प्रदान गरिएको छ ।
        </div>
        <div style="text-align:right;margin-right:60px; margin-top: 70px;">
          <p style="font-size:18px"><?php echo $maker['name'] ?></p>
          <p style="font-size:18px;margin-top:-15px;margin-left:-30px;"><?php echo $maker['designation'] ?></p>
        </div>
      </div>
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
window.print();
</script>

</html>