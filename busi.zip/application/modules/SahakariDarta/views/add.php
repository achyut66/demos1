<style type="text/css">
  .card-header{
    background: #1b5693;
  }
</style>
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo base_url()?>"> ड्यासबोर्डमा</a></li>
          <li class="breadcrumb-item"><a href="<?php echo base_url()?>Register">कृषि समूह दर्ता सुची </a></li>
          <li class="breadcrumb-item"><a href="javascript:;">नयाँ थप्नुहोस्</a></li>
      </ol>
    </nav>

    <form class="form" method="post" action="<?php echo base_url()?>SahakariDarta/save" enctype ="multipart/form-data">
      <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
      <div class="row">
        <div class="col-sm-12">
           <?php $ERR_VALIDATION = $this->session->flashdata("ERR_VALIDATION");
              if(!empty($ERR_VALIDATION)) { ?>
              <div class="alert alert-danger">
                  <button class="close" data-close="alert"></button>
                  <span> <?php echo $ERR_VALIDATION;?> </span>
              </div>
            <?php } ?>
          <?php $success_message = $this->session->flashdata("MSG_EMP");
              if(!empty($success_message)) { ?>
              <div class="alert alert-success">
                  <button class="close" data-close="alert"></button>
                  <span> <?php echo $success_message;?> </span>
              </div>
            <?php } ?>

             <?php $ERR_UPLOAD = $this->session->flashdata("ERR_UPLOAD");
              if(!empty($ERR_UPLOAD)) { ?>
              <div class="alert alert-success">
                  <button class="close" data-close="alert"></button>
                  <span> <?php echo $ERR_UPLOAD;?> </span>
              </div>
            <?php } ?>
          <section class="card">
            <header class="card-header text-light ">विवरण दाखिला गर्नुहोस [<span style="color:red">* चिन्न लगाएको ठाउँ खाली नछोडनुहोला</span>]</header>
            <div class="card-body">
              <div class="row">
                  <div class="col-md-2">
                    <div class="form-group">
                      <label><b>दर्ता नं</b><span style="color: red">*</span></label>
                      <input type="text" class="form-control darta_no" placeholder=""  name="darta_no" value="<?php echo $darta_no?>" readonly >
                    </div>
                  </div>

                  <div class="col-md-2">
                    <div class="form-group">
                      <label><b>मिति</b><span style="color: red">*</span></label>
                      <input type="text" class="form-control darta_no" placeholder=""  name="darta_miti" value="<?php echo convertDate(date('Y-m-d'))?>" readonly >
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>संस्थाको नाम<span style="color: red">*</span></label>
                      <input type="text" class="form-control" placeholder=""  name="name" value="">
                    </div>
                  </div>

                  <div class="col-md-4">
                    <div class="form-group">
                      <label class="">प्रदेश </label>
                        <select class="form-control dd_select npl_state" name="p_pardesh" required id="state-2">
                        <option value="">छान्नुहोस्</option>
                        <?php if(!empty($pradesh)) : 
                            foreach ($pradesh as $key => $p) : ?>
                              <option value="<?php echo $p['Title']?>" <?php if($p['Title'] == STATE) {echo 'selected';}?>><?php echo $p['Title']?></option>
                        <?php endforeach;endif;?>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="form-group">
                      <label class="">जिल्ला</label>
                      <select class="form-control dd_select npl_district" id="district-2" required name="p_district" >
                        <option value=""></option>
                        <?php if(!empty($districts)) : 
                            foreach($districts as $d) :?>
                              <option value="<?php echo $d['name']?>" <?php if($d['name'] == DISTRICT) {echo 'selected';}?>><?php echo $d['name']?></option>
                        <?php endforeach;endif;?>
                      </select>
                    </div>
                  </div>

                  <div class="col-md-3">
                    <div class="form-group">
                      <label class="">ग.पा / न. पा</label>
                      <select class="form-control npl_gapana dd_select select_option" name="p_gapa" id="gapa-2" required>
                        <?php if(!empty($gapana)) :
                          foreach ($gapana as $key => $gp) : ?>
                            <option value="<?php echo $gp['name']?>"
                              <?php if($gp['name'] == GNAME){
                                echo 'selected';
                              } ?>
                              ><?php echo $gp['name']?></option>
                        <?php endforeach;endif;?>
                      </select>
                    </div>
                  </div>

                  <div class="col-md-3">
                    <div class="form-group">
                      <label class="">वडा </label>
                      <select class="select_option form-control npl_state" name = "p_ward" >
                        <option value = "">छानुहोस</option>
                        <?php if(!empty($wards)) : 
                          foreach ($wards as $key => $w) : ?>
                          <option value="<?php echo $w['name']?>"><?php echo $this->mylibrary->convertedcit($w['name'])?></option>
                        <?php endforeach;endif;?>
                      </select>
                    </div>
                  </div>
                  
                  <div class="col-md-3">
                    <div class="form-group">
                     <label>टोल <span style="color: red">*</span></label>
                     <input type="text" class="form-control tol" placeholder=""  name="tol" value="">
                    </div>
                  </div>
                  
                  <div class="col-md-3">
                    <div class="form-group">
                     <label>पुरुष सदस्य संख्या <span style="color: red">*</span></label>
                     <input type="text" class="form-control number_field" placeholder="" id="male_member"  name="total_male_member" value="">
                    </div>
                  </div>

                  <div class="col-md-3">
                    <div class="form-group">
                     <label>महिला सदस्य संख्या <span style="color: red">*</span></label>
                     <input type="text" class="form-control number_field" placeholder="" id="female_member" name="total_female_member" value="">
                    </div>
                  </div>
                  
                  <div class="col-md-3">
                    <div class="form-group">
                     <label>जम्मा सदस्य संख्या <span style="color: red">*</span></label>
                     <input type="text" class="form-control number_field" placeholder=""  name="total_member" id="total_member" value="">
                    </div>
                  </div>

                  <!-- कार्य क्षेत्र:-  -->
                  <div class="col-md-3">
                    <div class="form-group">
                     <label>कार्य क्षेत्र <span style="color: red">*</span></label>
                     <input type="text" class="form-control" placeholder=""  name="working_area" id="working_area" value="">
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="form-group">
                     <label>दायित्व <span style="color: red">*</span></label>
                     <input type="text" class="form-control" placeholder=""  name="responsibility" id="responsibility" value="">
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="form-group">
                     <label>प्राप्त शेयर पूजीँको रकम<span style="color: red">*</span></label>
                     <input type="text" class="form-control" placeholder=""  name="total_share_amount" id="total_share_amount" value="">
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="form-group">
                     <label>प्राप्त प्रवेश शुल्कको रकम<span style="color: red">*</span></label>
                     <input type="text" class="form-control" placeholder=""  name="entry_share_amount" id="entry_share_amount" value="">
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="form-group">
                     <label>सहकारी ऐन<span style="color: red">*</span></label>
                     <input type="text" class="form-control" placeholder=""  name="sakari_datra_ain" id="sakari_datra_ain" value="">
                    </div>
                  </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                    <hr>
                    <h4>संस्थाको उद्देश्यहरु</h4>
                    <table class="table" id="add_new_fields">
                      <thead>
                        <tr>
                          <th>उद्देश्य</th>
                          <th style="width:50px;">#</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><textarea class="form-control" name="aim[]"></textarea></td>
                          <td>-</td>
                        </tr>
                      </tbody>
                    </table>
                    <button type="button" class="btn btn-secondary btn-block btnAddNew"><i class="fa fa-plus-circle"></i> नयाँ संस्थाको उद्देश्य थप्नुहोस </button>
                </div>

                <div class="col-md-12">
                    <hr>
                    <h4>मुख्य कार्य</h4>
                    <table class="table" id="add_new_work_fields">
                      <thead>
                        <tr>
                          <th>कार्य</th>
                          <th style="width:50px;">#</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><textarea class="form-control" name="main_work[]"></textarea></td>
                          <td>-</td>
                        </tr>
                      </tbody>
                    </table>
                    <button type="button" class="btn btn-secondary btn-block btnaddwork"><i class="fa fa-plus-circle"></i> नयाँ मुख्य कार्य थप्नुहोस </button>
                </div>

            </div>
          </section>
        </div>
       
        <div class="col-md-12 text-center">
          <hr>
          <button class="btn btn-primary btn-xs btn-save save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्" name="Submit" type="submit" value="Submit" id="btn_save_details"> सेभ गर्नुहोस्</button>
          <a href="<?php echo base_url()?>SahakariDarta" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
        </div>
      </div>
  </form>
  </section>
</section>
<script type="text/javascript" src="<?php echo base_url()?>assets/assets/select2/js/select2.min.js"></script>
<script>
  $(document).ready(function(){
    $('#male_member, #female_member').keyup(function() {
      obj = $(this);
      var male_member = $('#male_member').val()||0;
      var female_member = $('#female_member').val()||0;
      var total = parseInt(male_member) + parseInt(female_member);
      $('#total_member').val(total); 
    });

    $('.npl_state').change( function (){
      var id_selected     = $(this).attr("id");
      var res             = id_selected.split("-");
      var id              = res[res.length - 1];
      var state           = $(this).val();
      $.ajax({
        url:base_url+'CommonController/getDistrictByStateName',
        method:"POST",
        data:{state:state,'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'},
        success : function(resp){
          if(resp.status == 'success') {
            $('#district-'+id).html(resp.option);
          }
        }
      });
    });

    $('.npl_district').change( function (){
      var id_selected     = $(this).attr("id");
      var res             = id_selected.split("-");
      var id              = res[res.length - 1];
      var district           = $(this).val();
      $.ajax({
        url:base_url+'CommonController/getGapaByStateName',
        method:"POST",
        data:{district:district,'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'},
        success : function(resp){
          if(resp.status == 'success') {
            $('#gapa-'+id).html(resp.option);
          }
        }
      });
    });

    //add new row
    $('.btnAddNew').click(function(e) {
      e.preventDefault();
        var new_row = 
        '<tr>'+
          '<td><textarea class="form-control" name="aim[]"></textarea></td>'+
          '<td><button type="button" class="btn btn-danger remove-row" data-toggle="tooltip" title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>'+
        '<tr>'
        $("#add_new_fields").append(new_row);
    });
    $("body").on("click",".remove-row", function(e){
      e.preventDefault();
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });

    //add new work details
    $('.btnaddwork').click(function(e) {
      e.preventDefault();
        var new_row = 
        '<tr>'+
          '<td><textarea class="form-control" name="main_work[]"></textarea></td>'+
          '<td><button type="button" class="btn btn-danger remove-row-work" data-toggle="tooltip" title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>'+
        '<tr>'
        $("#add_new_work_fields").append(new_row);
    });
    $("body").on("click",".remove-row-work", function(e){
      e.preventDefault();
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });
  });
</script>