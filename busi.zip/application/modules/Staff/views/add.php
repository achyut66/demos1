<!--main content start-->
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url()?>">ड्यासबोर्डमा जानुहोस </a></li>
        <li class="breadcrumb-item" ><a href="<?php echo base_url()?>Staff/">कर्मचारीको सुचीमा जानुहोस</a></li>
        <li class="breadcrumb-item" ><a href="javascrip:;">नयाँ थप्नुहोस</a></li>
      </ol>
    </nav>
    <!-- page start-->
    <div class="row">
      <div class="col-sm-12">
        <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
            if(!empty($success_message)) { ?>
            <div class="alert alert-success">
                <button class="close" data-close="alert"></button>
                <span> <?php echo $success_message;?> </span>
            </div>
          <?php } ?>
        <section class="card">
          <header class="card-header">कर्मचारी थप्नुहोस</header>
          <div class="card-body">
            <?php echo form_open('Staff/Save', array('name'=>'save', 'id'=>'save', 'method'=>'post', 'class'=>'form-horizontal save_post'));?>
            
            <div class="form-group row">
                <label class="col-form-label col-sm-2" for="">नाम<span
                    class="text-danger">&nbsp;*</span></label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="name" required="true">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-form-label col-sm-2" for="">पद<span
                    class="text-danger">&nbsp;*</span></label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="designation" required="true">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-form-label col-sm-2" for="">मोबाइल नं<span
                    class="text-danger">&nbsp;*</span></label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="mobile" required="true">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-form-label col-sm-2" for="">इ-मेल<span
                    class="text-danger">&nbsp;*</span></label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="email" required="true">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-form-label col-sm-2" for="">अवस्था<span
                    class="text-danger">&nbsp;*</span></label>
                <div class="col-sm-8">
                    <div class="form-check">
                        <label class="form-check-label"><input class="form-check-input" name="status" type="radio" value="1" checked="true">Active</label>
                        <label class="form-check-label" style="margin-left: 50px;"><input class="form-check-input" name="status" type="radio" value="2">Inactive</label>
                    </div>
                </div>
            </div>
                        
            <div class="form-group row">
                <label class="col-form-label col-sm-2" for="">कैफियत</label>
                <div class="col-sm-8">
                    <textarea class="form-control" name="remarks"></textarea>
                </div>
            </div>

            <div class="form-buttons-w">
                <button type="submit" class='btn btn-submit btn-primary btn-block save_btn' name="submit">सम्पादन गर्नुहोस्</button>
            </div>
            <?php echo form_close()?>
          </div>
        </section>
      </div>
    </div>
    <!-- page end-->
  </section>
</section>