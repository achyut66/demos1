<script type="text/javascript">
  $(document).ready(function(){
    /*-------------------------------------------------------------------------------------------------*/
    //add new samiti fields.
    $('.btnAddMoreSamiti').click(function(e) {
       
        var MaxInputs       = 2;
        var InputsWrapper   = $("#InputsWrapper");
        var x = InputsWrapper.length; //initlal text box count
        if(x <= MaxInputs) {
          e.preventDefault();
          var trOneNew = $('.frm_tbl_samiti').length+1;
          var new_row =  '<tr class="nagadi_rasid_frm">'+
                            '<td><input type="text" class="form-control" name="name[]" required="true"></td>'+
                            '<td>'+
                              '<select name="designation[]" class="form-control select2"><option value=""></option><?php if(!empty($position)) : foreach($position as $p) : ?><option value="<?php echo $p["name"]?>"><?php echo $p["name"]?></option><?php endforeach;endif;?></select>'+
                            '</td>'+
                            '<td><input type="number" class="form-control" name="mobile_no[]" required="true"></td>'+
                            '<td><input type="email" class="form-control" name="email[]" required="true"></td>'+
                            '<td><button type="button" class="btn btn-outline-danger remove-samiti-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="पदाधिकारीको विवरण हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button>'+
                            '</td>'+
                          '<tr>';
          $("#frm_tbl_samiti").append(new_row);
          x++;
        } else {
          alert('cannot add more');
          return;
        }

        $(".select2").select2({             
          placeholder: "छानुहोस"               
        });
    });
    //remove samati members.
    $("body").on("click",".remove-samiti-row", function(e){
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });

    //add new samiti fields on edit.
    $('.btnAddMoreSamitiEdit').click(function(e) {
        var MaxInputs       = 2;
        var InputsWrapper   = $("#InputsWrapper");
        var x = InputsWrapper.length; //initlal text box count
        if(x <= MaxInputs) {
          e.preventDefault();
          var trOneNew = $('.frm_tbl_samiti').length+1;
          var new_row =  '<tr class="nagadi_rasid_frm">'+
                            '<td><input type="text" class="form-control" name="name_new[]" required="true"></td>'+
                            '<td><select name="designation_new[]" class="form-control select2" required="true"><option value=""></option><?php if(!empty($position)) :foreach($position as $p) : ?><option value="<?php echo $p["name"]?>"><?php echo $p['name']?></option><?php endforeach;endif;?></select></td>'+
                            '<td><input type="number" class="form-control" name="mobile_no_new[]" required="true"></td>'+
                            '<td><input type="email" class="form-control" name="email_new[]" required="true"></td>'+
                            '<td><button type="button" class="btn btn-outline-danger remove-samiti-row-edit" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="पदाधिकारीको विवरण हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button>'+
                            '</td>'+
                          '<tr>';
          $("#frm_tbl_samiti").append(new_row);
          x++;
        } else {
          alert('cannot add more');
          return;
        }
      });
    //remove samati members on edit.
    $("body").on("click",".remove-samiti-row-edit", function(e){
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });
  });
</script>