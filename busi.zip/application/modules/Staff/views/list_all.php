<!--main content start-->
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url()?>">ड्यासबोर्डमा जानुहोस </a></li>
        <li class="breadcrumb-item" ><a href="javascrip:;">कर्मचारीको सुची</a></li>
      </ol>
    </nav>
    <!-- page start-->
    <div class="row">
      <div class="col-sm-12">
        <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
            if(!empty($success_message)) { ?>
            <div class="alert alert-success">
                <button class="close" data-close="alert"></button>
                <span> <?php echo $success_message;?> </span>
            </div>
          <?php } ?>
        <section class="card">
          <header class="card-header">
          कर्मचारी थप्नुहोस
          <span class="tools">
            <?php if($this->authlibrary->HasModulePermission('BTYPE', "ADD")) { ?>
              <a class="btn btn-secondary pull-right" href="<?php echo base_url()?>Staff/Add" ><i class="fa fa-plus-circle" ></i><span> कर्मचारी थप्नुहोस</span></a>
            <?php } ?>
          </span>
          </header>
          <div class="card-body">
            <div class="adv-table">
            <table  class="table table-lightbordered table-striped" id="dataTable1">
                      <thead>
                        <tr>
                          <th class="text-right">#</th> 
                          <th>नाम</th>
                          <th>पद</th>
                          <th>मोबाइल नं</th>
                          <th>इ-मेल</th>
                          <th>अवस्था</th>
                          <?php if($this->authlibrary->HasModulePermission('STAFF', "EDIT") || $this->authlibrary->HasModulePermission('STAFF', "DELETE") ) { ?>
                            <th>कार्य</th>
                          <?php } ?>
                        </tr>
                      </thead>
                      <tbody>
                        <?php if(!empty($staffs)) :
                          $i = 1;
                          foreach($staffs as $key => $value) : ?>
                          <tr>
                            <td class="text-right"><?php echo $this->mylibrary->convertedcit($i++)?></td>
                            <td><?php echo $this->mylibrary->convertedcit($value['name'])?></td>
                            <td><?php echo $this->mylibrary->convertedcit($value['designation'])?></td>
                            <td><?php echo $this->mylibrary->convertedcit($value['mobile'])?></td>
                            <td><?php echo $this->mylibrary->convertedcit($value['email'])?></td>
                            <td>
                              <?php if($value['status'] == 1) { ?>
                                <a href="#" class=" btn btn-success btn-sm"><i class="fa fa-check-circle"></i> Active</a>
                              <?php } else { ?>
                               <a href="#" class=" btn btn-danger btn-sm"><i class="fa fa-times-circle"></i> Inactive</a>
                             <?php  } ?>
                             </td>
                            <?php if($this->authlibrary->HasModulePermission('STAFF', "EDIT") || $this->authlibrary->HasModulePermission('STAFF', "DELETE") ) { ?>
                              <td class="row-actions">
                                <?php if($this->authlibrary->HasModulePermission('STAFF', "EDIT")) { ?>
                                 <a href="<?php echo base_url()?>Staff/Edit/<?php echo $value['id']?>" class="btn btn-info" data-placement="bottom" data-toggle="tooltip" title="" type="button" data-original-title="सम्पादन गर्नुहोस्"><i class="fa fa-pencil"></i> </a>
                                <?php } ?>
                                <?php if($this->authlibrary->HasModulePermission('STAFF', "DELETE") ) { ?>
                                  <a class="btn btn-danger" title=" विवरण हटानुहोस" href="<?php echo base_url()?>Staff/Delete/<?php echo $value['id']?>" onclick="javascript:return confirm('Are you sure you want to delete this comment?')"><i class="fa fa-trash-o"></i></a>
                                <?php } ?>
                              </td>
                            <?php } ?>
                          </tr>
                        <?php endforeach;endif; ?>
                      </tbody>
                    </table>
            </div>
          </div>
        </section>
      </div>
    </div>
    <!-- page end-->
  </section>
</section>