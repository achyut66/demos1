<?php 

class SamitiModel extends CI_Model {

    public function getSamatiList() {
        $this->db->select('t1.*,count(t2.samiti_id) as tm')->from('samati_name t1');
        $this->db->join('meeting_members t2', 't2.samiti_id = t1.id','left');
        $this->db->group_by('t2.samiti_id');
        $query = $this->db->get();
        return $query->result_array();
    }

    //insert members
    public function batchInsert($post_data) {
        $this->db->trans_start();
        $this->db->insert_batch('meeting_members',$post_data);
        $this->db->trans_complete();        
        return ($this->db->trans_status() === FALSE)? FALSE:TRUE;
    }

    public function updateMembers($id, $post_array) {
        $this->db->trans_start();
        $this->db->update_batch('meeting_members',$post_array,'id');
        $this->db->trans_complete();
        // was there any update or error?
        if ($this->db->affected_rows() > 0) {
            return TRUE;
        } else {
            // any trans error?
            if ($this->db->trans_status() === FALSE) {
                return false;
            }
            return true;
        }
    }
}