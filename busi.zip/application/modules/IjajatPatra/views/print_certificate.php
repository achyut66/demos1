<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>

  <style>
    .title {
      height: 45px;
      width: 485px;
      border: 1px solid #555;
      margin-left: 139px;
      border-radius: 25px;
      text-align: center;
      /* border-radius: 25px; */
      margin-top: 100px;
    }

    .title1 {
      height: 45px;
      width: 485px;
      border: 1px solid #555;
      margin-left: 220px;
      border-radius: 25px;
      text-align: center;
      /* border-radius: 25px; */
      margin-top: 180px;
    }

    .nagarpalika_title {
      height: 45px;
      width: 485px;
      /* border: 1px solid #555; */
      margin-left: 114px;
      text-align: center;
      /* border-radius: 25px; */
      margin-top: 60px;
    }

    element.style {
      margin-left: 4px;
      font-size: 26px;
      margin-top: 3px;
    }

    .stamp {
      /* border: 2px solid #555; */
      /* height: 62px;
    width: 202px;
     */
      margin-left: 487px;
      border-radius: 5px;
      text-align: right;
      margin-right: 120px;
      margin-top: 50px;
    }

    /* 
    @page {
      size: portrait;
    } */

    div.a {
      text-indent: 77%;
    }

    td {
      height: 50px;
    }
  </style>
</head>
<!-- yema darta ko data lai rakhnu content sahit -->

<body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="page">
        <div class="header">
          <div class="header-left" style="margin-left:-24px;">
            <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
          </div>
          <div class="text-center" style="margin-left: -118px;">
            <h3 class="" style="margin-left: -850px;"><?php echo GNAME ?> </h3>
            <h4 style="margin-left: -852px;"><?php echo SLOGAN ?></h4>
            <h6 style="margin-top:-10px;margin-left: -872px;"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
            <h6 style="margin-top:-5px;margin-left: -875px;"><?php echo STATENAME ?>,नेपाल</h6>
          </div>
        </div>
        <div style="margin-top: -114px;margin-left: 607px;"><img src="<?php echo base_url() ?>assets/img/plb.png"
            style="height: 94px;width: 94px;">
        </div>
        <div class="sub-header">
          <div>
            <p style="font-size:18px;margin-top: 150px;"><b>इजाजत-पत्र नं.</b>
              <?php echo $this->mylibrary->convertedcit($row['darta_no'] . ' / ' . $row['fiscal_year'] . ' / <b>" ' . $row['warga'] . '" वर्ग </b>') ?>
            </p>
          </div>
          <!-- <div class="a" style="margin-left:60px;margin-top:-41px;">
            मिति: <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?>
          </div> -->
          <div class="title" style="float:center;margin-top: -110px;">
            <p style="margin-left:-26px;font-size:26px;"><b>इजाजत-पत्र</b></p>
          </div>
        </div>
        <br>
        <div style="margin-left:-11px; margin-top:60px; margin-right:50px;">
          <p style="text-indent: 2em;font-size:22px;text-align:justify">
            <!-- <?php echo GNAME ?>को <?php echo $row['warga'] ?> निर्माण व्यवसायी ईजाजत पत्र सम्बन्धी
          कार्यविधि २०७५ को दफा २ को उपदफा (४) बमोजिम निर्माण व्यवसाय गर्न <?php echo $row['tol'] ?>
          <?php echo $this->mylibrary->convertedcit($row['p_ward']) ?> स्थित कार्यालय भएको
          <b><?php echo $row['name'] ?></b> लाई ईजाजत
          पत्र प्रदान गरिएको छ । -->
            <b><?php echo GNAME ?></b> वडा नं
            <b><?php echo $this->mylibrary->convertedcit($row['p_ward']) ?></b> स्थित कार्यालय रही
            <b><?php echo $row['contact_person'] ?></b>को स्वामित्वमा रहेको <b><?php echo $row['name'] ?></b> फर्म /
            कम्पनीलाई
            स्थानीय सरकार संचालन ऐन २०७४ को दफा ११(२) को खण्ड छ (१०) बमोजिम निर्माण व्यवसाय गर्न <b>इजाजत-पत्र</b>
            प्रदान
            गरिएको छ l
          </p>
        </div>
        <br>
        <div class="text-right" style="margin-left: 361px;font-weight:bold;font-size:16px;margin-top: 8px;">
          <div class="text-left" style="margin-left:128px;"><u><b>इजाजत पत्र दिनेको</b></u></div>
          <div style="margin-left:126px;"><b>दस्तखत :-</b></div>
          <div style="font-size:16px;margin-left:128px;">
            <p><?php echo 'नाम:- ' . $maker['name'] ?></p>
            <p><?php echo 'पद:- ' . $maker['designation'] ?></p>
          </div>
          <div style="margin-left:128px;"><b>कार्यालय : <?php echo GNAME . ' ' . ADDRESS . ', ' . DISTRICT ?></b></div>
          <div style="margin-left:128px;"><b>मिति : <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></b>
          </div>
        </div>
      </div>
    </div>
  </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<!-- yaha samma darta ko content aaune bhayo  -->

<!-- suchikrit ho bahne content rakhnu -->

<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
  window.print();
</script>

</html>