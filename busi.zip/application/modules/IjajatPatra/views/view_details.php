 <!--main content start-->
 <style>
     .table-bordered td,
     .table-bordered th {
         border: 1px solid #3a5d7f;
     }
 </style>
 <section id="main-content">
     <section class="wrapper site-min-height">
         <nav aria-label="breadcrumb">
             <ol class="breadcrumb">
                 <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"><i class="fa fa-home"></i> ड्यासबोर्डमा</a></li>
                 <li class="breadcrumb-item active"><a href="<?php echo base_url() ?>IjajatPatra" class="bactive">इजाजतपत्र दर्ता सुचीमा जानुहोस</a></li>
                 <li class="breadcrumb-item active"><a href="javascript:;" class="bactive">विवरण हेर्नुहोस</a></li>
             </ol>
         </nav>
         <!-- page start-->
         <div class="row">
             <aside class="profile-info col-lg-9">
                 <section class="card">
                     <header class="card-header text-light " style="background-color:#4d5886">दरखास्त पेश गर्ने फर्म वा कम्पनीको विवरण: <?php echo $row['name'] ?> <span class="btn btn-success btn-circle"> दर्ता नं. <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?></span>
                     </header>
                     <div class="card-body">
                         <div class="row">
                             <div class="col-md-12">
                                 <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
                                    if (!empty($success_message)) { ?>
                                     <div class="alert alert-success">
                                         <button class="close" data-close="alert"></button>
                                         <span> <?php echo $success_message; ?> </span>
                                     </div>
                                 <?php } ?>

                                 <?php $err_message = $this->session->flashdata("MSG_ERR");
                                    if (!empty($err_message)) { ?>
                                     <div class="alert alert-danger">
                                         <button class="close" data-close="alert"></button>
                                         <span> <?php echo $err_message; ?> </span>
                                     </div>
                                 <?php } ?>
                                 <?php $err_message = $this->session->flashdata("MSG_WAR");
                                    if (!empty($err_message)) { ?>
                                     <div class="alert alert-warning">
                                         <button class="close" data-close="alert"></button>
                                         <span> <?php echo $err_message; ?> </span>
                                     </div>
                                 <?php } ?>


                                 <table class="table table-bordered">
                                     <tr>
                                         <td><strong><span>दर्ता मिति: </span><?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></strong></td>
                                         <td><strong><span>फर्म वा कम्पनीको प्रकृति:</span> <?php echo $row['firm_type'] ?></td>
                                         <td colspan=2><strong><span> ठेगाना: </span><?php echo $row['tol'] ?>-<?php echo $this->mylibrary->convertedcit($row['p_ward']) ?>,<?php echo $row['p_district']; ?>,<?php echo $row['p_pradesh']; ?></strong></td>
                                         <td><strong><span>सम्पर्क नम्वर:</span> <?php echo $this->mylibrary->convertedcit($row['contact_no']) ?></strong></td>
                                         <td><strong><span>ईमेल:</span> <?php echo $this->mylibrary->convertedcit($row['email']) ?></strong></td>
                                         <td><strong><span>इजाजतपत्र लिन चाहेको वर्ग:</span> <?php echo $this->mylibrary->convertedcit($row['warga']) ?></strong></td>
                                         <td><strong><span>समूहीकरण हुन चाहेको समुह:</span> <?php echo $this->mylibrary->convertedcit($row['samuha']) ?></strong></td>
                                     </tr>

                                 </table>
                             </div>
                         </div>
                     </div>
                 </section>
                 <section class="card">
                     <header class="card-header text-light " style="background-color:#4d5886">सम्पर्कको लागि फर्म वा कम्पनीको आधिकारीक व्यक्तिको</header>
                     <div class="card-body">
                         <div class="row">
                             <div class="col-md-12">
                                 <table class="table" id="add_new_fields">
                                     <thead>
                                         <tr>
                                             <th>नाम</th>
                                             <th>ठेगाना</th>
                                             <th>सम्पर्क नम्वर</th>
                                             <th>ईमेल</th>
                                         </tr>
                                     </thead>
                                     <tbody>
                                         <tr>
                                             <td><?php echo $this->mylibrary->convertedcit($row['contact_person']) ?></td>
                                             <td><?php echo $this->mylibrary->convertedcit($row['contact_address']) ?></td>
                                             <td><?php echo $this->mylibrary->convertedcit($row['c_number']) ?></td>
                                             <td><?php echo $this->mylibrary->convertedcit($row['c_email']) ?></td>
                                         </tr>
                                     </tbody>
                                 </table>
                             </div>
                         </div>
                     </div>
                 </section>
                 <section class="card">
                     <header class="card-header text-light " style="background-color:#4d5886">फर्म वा कम्पनीको विवरण</header>
                     <div class="card-body">
                         <div class="row">
                             <div class="col-md-12">
                                 <table class="table" id="add_new_fields">
                                     <thead style="background-color:#fff">
                                         <tr>
                                             <th>दर्ता नं</th>
                                             <th>दर्ता मिति</th>
                                             <th>अधिकृत पूँजि</th>
                                             <th>जारि पूँजी</th>
                                         </tr>
                                     </thead>
                                     <tbody>
                                         <tr>
                                             <td><?php echo $this->mylibrary->convertedcit($row['org_darta_no']) ?></td>
                                             <td><?php echo $this->mylibrary->convertedcit($row['org_darta_miti']) ?></td>
                                             <td><?php echo $this->mylibrary->convertedcit($row['a_capital']) ?></td>
                                             <td><?php echo $this->mylibrary->convertedcit($row['c_capital']) ?></td>
                                         </tr>
                                     </tbody>
                                 </table>
                             </div>
                         </div>
                     </div>
                 </section>
                 <section class="card">
                     <header class="card-header text-light " style="background-color:#4d5886">फर्म वा कम्पनीको विवरण</header>
                     <div class="card-body">
                         <div class="row">
                             <div class="col-md-12">
                                 <table class="table">
                                     <thead>
                                         <tr>
                                             <th></th>
                                             <th>रकम</th>
                                             <th>बित्तिय संस्था बैकको नाम</th>
                                         </tr>
                                     </thead>
                                     <tbody>
                                         <tr>
                                             <td>स्थायी ओभरड्राफ्ट</td>
                                             <td><?php echo $this->mylibrary->convertedcit($row['s_amount']) ?></td>
                                             <td><?php echo $this->mylibrary->convertedcit($row['s_bank']) ?></td>
                                         </tr>
                                         <tr>
                                             <td>मुद्धती खाता</td>
                                             <td><?php echo $this->mylibrary->convertedcit($row['m_amount']) ?></td>
                                             <td><?php echo $this->mylibrary->convertedcit($row['m_bank']) ?></td>
                                         </tr>
                                         <tr>
                                             <td>चल्ती खाता</td>
                                             <td><?php echo $this->mylibrary->convertedcit($row['c_amount']) ?></td>
                                             <td><?php echo $this->mylibrary->convertedcit($row['c_bank']) ?></td>
                                         </tr>
                                         <tr>
                                             <td>बचत खाता</td>
                                             <td><?php echo $this->mylibrary->convertedcit($row['b_amount']) ?></td>
                                             <td><?php echo $this->mylibrary->convertedcit($row['b_bank']) ?></td>
                                         </tr>
                                     </tbody>
                                 </table>
                             </div>
                         </div>
                     </div>
                 </section>
                 <section class="card">
                     <header class="card-header text-light " style="background-color:#4d5886">आफ्नो स्वामित्वमा रहेको निर्माण सम्बन्धी सवारी साधन मेशिनरी औजारको विवरण</header>
                     <div class="card-body">
                         <div class="row">
                             <div class="col-md-12">
                                 <table class="table" id="add_new_fields">
                                     <thead style="background-color:#fff">
                                         <tr>
                                             <th>नाम तथा विवरण</th>
                                             <th>दर्ता नम्वर</th>
                                             <th>क्षमता संख्या</th>
                                             <th>मुल्य</th>
                                             <th>खरिद मिति</th>
                                             <th>अन्य</th>
                                         </tr>
                                     </thead>
                                     <tbody>
                                         <?php if (!empty($device_details)) : foreach ($device_details as $device) : ?>
                                                 <tr>
                                                     <td><?php echo $this->mylibrary->convertedcit($device['device_name']) ?></td>
                                                     <td><?php echo $this->mylibrary->convertedcit($device['device_no']) ?></td>
                                                     <td><?php echo $this->mylibrary->convertedcit($device['device_capacity']) ?></td>
                                                     <td><?php echo $this->mylibrary->convertedcit($device['device_amount']) ?></td>
                                                     <td><?php echo $this->mylibrary->convertedcit($device['device_date']) ?></td>
                                                     <td><?php echo $this->mylibrary->convertedcit($device['other_detail']) ?></td>
                                                 </tr>
                                         <?php endforeach;
                                            endif; ?>
                                     </tbody>
                                 </table>
                             </div>
                         </div>
                     </div>
                 </section>

                 <section class="card">
                     <header class="card-header text-light " style="background-color:#4d5886">यस अघि सम्पन्न गरेको कामको विवरण</header>
                     <div class="card-body">
                         <div class="row">
                             <div class="col-md-12">
                                 <table class="table" id="add_new_fields">
                                     <thead style="background-color:#fff">
                                         <tr>
                                             <th>निर्माण सम्वन्धि कामको अनुभव</th>
                                             <th>काम गरेको साल</th>
                                             <th>रकम</th>
                                             <th>ठेक्कादाता कार्यालयको नाम</th>
                                             <th>कामको अवस्था</th>
                                         </tr>
                                     </thead>
                                     <tbody>
                                         <?php if (!empty($workdetails)) : foreach ($workdetails as $work) : ?>
                                                 <tr>
                                                     <td><?php echo $this->mylibrary->convertedcit($work['pre_work']) ?></td>
                                                     <td><?php echo $this->mylibrary->convertedcit($work['per_work_year']) ?></td>
                                                     <td><?php echo $this->mylibrary->convertedcit($work['work_amount']) ?></td>
                                                     <td><?php echo $this->mylibrary->convertedcit($work['work_office']) ?></td>
                                                     <td><?php echo $this->mylibrary->convertedcit($work['work_status']) ?></td>
                                                 </tr>
                                         <?php endforeach;
                                            endif; ?>
                                     </tbody>
                                 </table>
                             </div>
                         </div>
                     </div>
                 </section>
             </aside>
             <aside class="profile-nav col-lg-3">
                 <section class="card">
                     <div class="user-heading round">
                         <h1><?php echo !empty($row['name']) ? $row['name'] : '' ?></h1>
                         <p>(<?php echo $row['firm_type'] ?>)</p>
                         <p><?php echo $row['tol'] . '-' . $this->mylibrary->convertedcit($row['p_ward']) . ' ,' . $this->mylibrary->convertedcit($row['p_gapa']) ?>,<?php echo $row['p_district']; ?><br><?php echo $row['p_pradesh']; ?></p>
                     </div>

                     <ul class="nav nav-pills nav-stacked">
                         <li class="active nav-item"><a class="nav-link" href="<?php echo base_url() ?>IjajatPatra/edit/<?php echo $row['id'] ?>"> <i class="fa fa-pencil"></i> विवरण सम्पादन गर्नुहोस्</a></li>
                         <li class="nav-item"><a class="nav-link" href="<?php echo base_url() ?>IjajatPatra/printcertificate/<?php echo $row['id'] ?>" target="_blank"> <i class="fa fa-print"></i>प्रमाणपत्र प्रिन्ट गर्नुहोस् </a></li>
                         <!-- <li class="nav-item"><a class="nav-link" href="<?php echo base_url() ?>AgricultureDepartment/listNabikarnDetails/<?php echo $row['id'] ?>"> <i class="fa fa-file"></i>नवीकरणको विवरण </a></li> -->

                     </ul>

                 </section>
             </aside>
         </div>
     </section>
 </section>
 <!--main content end-->