    <style>
      
      body {
        background: rgb(204, 204, 204);
      }
      .page {
        background: white;
        display: block;
        margin: 0 auto;
        margin-bottom: 0.5cm;
       
        background-repeat: no-repeat;
        background-size:cover;
      
      }
      .container{
        margin-top: -20px;
      }
      /* .page {
        width: 21cm;
        height: 29.7cm;
        
      } */
     .border{
      border: 2px solid black;
      background-color: black;
      
     }
     .text-left{
      font-size:13px;
     }

      @media print {
        body,
        page {
          margin:0;
          box-shadow: 0;
        }
      }
    </style>   
 <div class="page">
    <a href="<?php echo base_url()?>IjajatPatra/printSafiris/<?php echo $row['id']?>" class="btn btn-info btn-sm btn-block" target="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a>
    <div class="margin" style="margin-left:40px; margin-right: 40px;">
    <img src="<?php echo base_url() ?>assets/img/nepal-govt.png" style="margin-top: 40px; height: 80px; width: 80px; ">
    <strong><p style="margin-top:-100px;  font-size: 22px; text-align: center; color: rgb(239, 16, 16);"><?php echo GNAME ?></p></strong>
    <br>
    <strong>  <p style="margin-top:-15px;  font-size: 30px; text-align: center; color: rgb(239, 16, 16);"><?php echo SLOGAN ?></p></strong>
    <br>
    <p style="margin-top:-20px;  font-size: 20px; text-align: center; color: rgb(239, 16, 16);"><?php echo ADDRESS . ',' . DISTRICT ?>, धादिङ </p>
    <br>
    <p style="margin-top:-20px;  font-size:18px; text-align: center; color: rgb(239, 16, 16);"><?php echo STATENAME ?>, नेपाल  </p>
    <br>
    <div class="container">
      <div class="darta" style="font-size:18px;" >पत्र संख्या :-</div>
      <div class="darta" style="font-size:18px;" >चलानी नं. :-</div>
      <div class="border"></div>
      <div class="darta" style="margin-left: 540px; font-size:15px; margin-top: 10px; " >मितिः-  <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></div>
      <div class="name" style="font-size: 15px; margin-top: -3px;">श्री <?php echo $this->mylibrary->convertedcit($row['contact_person']) ?>,</div>
      <div class="address" style="font-size: 15px;"><?php echo $this->mylibrary->convertedcit($row['p_gapa']) .'-'. $this->mylibrary->convertedcit($row['p_ward'])?>, <?php echo $this->mylibrary->convertedcit($row['p_district'])?> ।</div>
      <div style="text-align:center; font-size: 13px; margin-top: 25px; "><b><u>बिषय:- व्यवसाय दर्ता  प्रमाण पत्र पठाइएको सम्बन्धमा </u></b>।</div>
      <div style="margin-top:40px;">
        प्रस्तुत बिषयमा यस <?php echo $this->mylibrary->convertedcit($row['p_gapa'])?> वडा नं. <?php echo $this->mylibrary->convertedcit($row['p_ward'])?> स्थित कार्यलय रही <b>श्री <?php echo $row['contact_person']?></b> <?php echo $this->mylibrary->convertedcit($row['p_ward'])?> स्वमित्वमा रहेको <b><?php echo $row['name']?></b> <?php echo $row['yain']?> बमोजिम निर्माण व्यवासाय गर्ने <b>इजाजत पत्र <?php echo $this->mylibrary->convertedcit($row['darta_no'])?>/ <?php echo $this->mylibrary->convertedcit($row['fiscal_year'])?> <?php echo $row['warga']?></b> इजाजत पत्र यसै पत्र साथ पठाइएको ब्येहोरा अनुरोध छ ।
      </div>
      <div style="margin-left:535px; margin-top:80px;">..............................</div>
      <div><?php echo !empty($checker) ? $checker['name'] : ''?></div>
      <div><?php echo !empty($checker) ? $checker['designation']:''?></div>

      <div style="margin-top:80px;"> बोधार्थः–
        <?php if(!empty($row['b_detail'])) : 
            $b_detail = explode(',', $row['b_detail']);
            if(!empty($b_detail)) :$i =1; foreach($b_detail as $key => $b) :?>
            <div><?php echo $this->mylibrary->convertedcit($i++)?>. <?php echo $b ?></div>
            <?php endforeach; endif;?>
          <?php endif;?>
      </div>
    </div>
</div>