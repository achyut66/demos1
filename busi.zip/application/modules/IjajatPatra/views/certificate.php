<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>

  <style>
      .page {
        background: white;
        display: block;
        margin: 0 auto;
      }
      .page {
        /* width: 21cm; */
        height: 29.7cm;
      }
      @media print {
        * {
        -webkit-print-color-adjust: exact;
      }
      body,
        page {
          margin:0;
          box-shadow: 0;
        }
      }

      table td,
      th {
        padding: 0.1em 0.5em;
        text-align: left;
      }
      table {
        border: 1px solid black;
      }
      thead th {
        border: 1px solid black;
      }
      /* tfoot td {
        border-top: 2px solid black;
      } */
      tbody td {
      border: 1px solid black;
      }
      /* tbody tr:first-child td {
        border-top: 0;
      }
      tbody td:last-child {
        border-right: 0;
      } */
      .textButton
          {
              text-decoration: none;
              background-color: #000;
              color: #fff;
              padding: 2px 6px 2px 6px;
              border-top: 1px solid #CCCCCC;
              border-right: 1px solid #333333;
              border-bottom: 1px solid #333333;
              border-left: 1px solid #CCCCCC;
              width:100%;
              text-align:center;
              margin-left:300px;
              /* border-radius: 8px; */
          }
  </style>   
</head>

<body>
  <div class="page">
    <img src="<?php echo base_url()?>/assets/img/nepal-govt.png" style="margin-top: 0px; height: 130px; width: 150px; margin-left: 30px;">
    <strong><p style="margin-top:-130px;  font-size: 28px; text-align: center; color: rgb(239, 16, 16);"><?php echo GNAME ?></p></strong>
    <br>
    <p style="margin-top:-25px;  font-size: 20px; text-align: center; color: rgb(239, 16, 16);"><?php echo SLOGAN ?></p>
    <br>
    <p style="margin-top:-40px;  font-size: 20px; text-align: center; color: rgb(239, 16, 16);"><?php echo ADDRESS . ',' . DISTRICT ?></p>
    <br>
    <p style="margin-top:-40px;  font-size:18px; text-align: center; color: rgb(239, 16, 16);"><?php echo STATENAME ?>, नेपाल  </p>
     
      <br>
      <div class="text-center" >
        <!-- <img src="<?php //echo base_url()?>assets/img/pramad.png" style="margin-top: -20px;  height: 80px; width: 300px; margin-left:27px;"> -->
        <div style="height: 80px; width: 200px; "><h1 class="textButton">इजाजत पत्र</h1></div>
        
      </div> 
      <div class="darta" style="margin-left: 80px; font-size:18px; margin-top:50px;" >इजाजत पत्र नं:- <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?>/<?php echo $this->mylibrary->convertedcit($row['fiscal_year']) ?> <b><?php echo $row['warga']?></b></div>
      
      <div class="bbody" style="margin-left: 80px; font-size:18px; margin-top:50px;" >
        <p style="text-align:justify; margin-right: 80px;"><?php echo $row['p_gapa']?> वडा नं. <?php echo $this->mylibrary->convertedcit($row['p_ward'])?> स्थित कार्यलय रही <b>श्री <?php echo $row['contact_person']?></b> स्वमित्वमा रहेको <b><?php echo $row['name']?></b> फिर्म/कम्पनीलाई <?php echo $row['yain']?> बमोजिम निर्माण व्यवासाय गर्ने <b>इजाजत पत्र</b> प्रदान गरिएको छ।</p>
      </div><br>

      <div style="margin-left:535px; margin-top: 80px;">
        <p style="font-size:18px;margin-left:-107px;"><b>ईजाजत पत्र दिनेको:</b></p>
        <p style="font-size:18px;margin-left:-107px;margin-top:-16px;"><b>दस्तखत:</b></p>
        <p style="font-size:18px;margin-left:-107px;margin-top:-10px"><b>नाम:<?php echo !empty($maker) ? $maker['name'] :""?> </b></p>
        <p style="font-size:18px;margin-left:-107px;margin-top:-10px;"><b>पद: <?php echo !empty($maker) ? $maker['designation'] :""?></b></p>
        <p style="font-size:18px;margin-left:-107px;margin-top:-10px;"><b>कार्यालय:<?php echo !empty($maker) ? GNAME:""?></b></p>
        <p style="font-size:18px;margin-left:-107px;margin-top:-10px;"><b>मिति:<?php echo $this->mylibrary->convertedcit($row['darta_miti'])?></b></p>
      </div>

  </div>
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
window.print();
</script>

</html>