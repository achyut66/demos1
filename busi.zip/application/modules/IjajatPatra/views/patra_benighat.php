    <style>
      body {
        background: rgb(204, 204, 204);
      }
      .page {
        background: white;
        display: block;
        margin: 0 auto;
        /*margin-bottom: 0.5cm;*/
        /* background-image: url("assets/img/page0001.jpg");
        background-repeat: no-repeat;
        background-size:cover; */
      }
      .page {
        /* width: 21cm; */
        height: 29.7cm;
      }
      @media print {
        * {
        -webkit-print-color-adjust: exact;
      }
      body,
        page {
          margin:0;
          box-shadow: 0;
        }
      }

    table td,
    th {
      padding: 0.1em 0.5em;
      text-align: left;
    }
    table {
      border: 1px solid black;
    }
    thead th {
      border: 1px solid black;
    }
    /* tfoot td {
      border-top: 2px solid black;
    } */
    tbody td {
     border: 1px solid black;
    }
    /* tbody tr:first-child td {
      border-top: 0;
    }
    tbody td:last-child {
      border-right: 0;
    } */
    .textButton
        {
            text-decoration: none;
            background-color: #000;
            color: #fff;
            padding: 2px 6px 2px 6px;
            border-top: 1px solid #CCCCCC;
            border-right: 1px solid #333333;
            border-bottom: 1px solid #333333;
            border-left: 1px solid #CCCCCC;
            width:100%;
            text-align:center;
            margin-left:300px;
            /* border-radius: 8px; */
        }
    </style>   
    <a href="<?php echo base_url() ?>IjajatPatra/printFirst/<?php echo $row['id'] ?>/3" class="btn btn-sm btn-info">
      <i class="fa fa-print"> प्रिन्ट गर्नुहोस(अगाडी) </i>
    </a>
    <a href="<?php echo base_url() ?>IjajatPatra/printSecond/<?php echo $row['id'] ?>/3" class="btn btn-sm btn-danger">
      <i class="fa fa-print"> प्रमाणपत्र प्रिन्ट (पछाडी) </i>
    </a>
  <div class="page">
    <img src="<?php echo base_url()?>/assets/img/nepal-govt.png" style="margin-top: 0px; height: 130px; width: 150px; margin-left: 30px;">
    <strong><p style="margin-top:-130px;  font-size: 28px; text-align: center; color: rgb(239, 16, 16);"><?php echo GNAME ?></p></strong>
    <br>
    <p style="margin-top:-25px;  font-size: 20px; text-align: center; color: rgb(239, 16, 16);"><?php echo SLOGAN ?></p>
    <br>
    <p style="margin-top:-40px;  font-size: 20px; text-align: center; color: rgb(239, 16, 16);"><?php echo ADDRESS . ',' . DISTRICT ?></p>
    <br>
    <p style="margin-top:-40px;  font-size:18px; text-align: center; color: rgb(239, 16, 16);"><?php echo STATENAME ?>, नेपाल  </p>
     
      <br>
      <div class="text-center" >
        <!-- <img src="<?php //echo base_url()?>assets/img/pramad.png" style="margin-top: -20px;  height: 80px; width: 300px; margin-left:27px;"> -->
        <div style="height: 80px; width: 200px; "><h1 class="textButton">इजाजत पत्र</h1></div>
        
      </div> 
      <div class="darta" style="margin-left: 80px; font-size:18px; margin-top:50px;" >इजाजत पत्र नं:- <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?>/<?php echo $this->mylibrary->convertedcit($row['fiscal_year']) ?> <b><?php echo $row['warga']?></b></div>
      
      <div class="bbody" style="margin-left: 80px; font-size:18px; margin-top:80px;" >
        <p style="text-align:justify; margin-right: 80px;"><?php echo $row['p_gapa']?> वडा नं. <?php echo $this->mylibrary->convertedcit($row['p_ward'])?> स्थित कार्यलय रही <b>श्री <?php echo $row['contact_person']?></b> स्वमित्वमा रहेको <b><?php echo $row['name']?></b> फिर्म/कम्पनीलाई <?php echo $row['yain']?> बमोजिम निर्माण व्यवासाय गर्ने <b>इजाजत पत्र</b> प्रदान गरिएको छ।</p>
      </div><br>

      <div style="margin-left:535px; margin-top: 120px;">
        <p style="font-size:18px;margin-left:-107px;"><b>ईजाजत पत्र दिनेको:</b></p>
        <p style="font-size:18px;margin-left:-107px;margin-top:-16px;"><b>दस्तखत:</b></p>
        <p style="font-size:18px;margin-left:-107px;margin-top:-10px"><b>नाम:<?php echo !empty($maker) ? $maker['name'] :""?> </b></p>
        <p style="font-size:18px;margin-left:-107px;margin-top:-10px;"><b>पद: <?php echo !empty($maker) ? $maker['designation'] :""?></b></p>
        <p style="font-size:18px;margin-left:-107px;margin-top:-10px;"><b>कार्यालय:<?php echo !empty($maker) ? GNAME:""?></b></p>
        <p style="font-size:18px;margin-left:-107px;margin-top:-10px;"><b>मिति:<?php echo $this->mylibrary->convertedcit($row['darta_miti'])?></b></p>
      </div>

  </div>
<!-- second part -->
<hr style="background-color:red">
<table class="print_table">
  <thead>
    <tr>
      <th>नबिकरण गर्ने अधिकारी</th>
      <th>नबिकरण गरेको मिति</th>
      <th>नबिकरण बहाल रहने अविधि</th>
      <th>नबिकरण दस्तुर बुझाएको भौचर नं. र मिति</th>
      <th>फाटवालाको दस्तखत</th>
      <th>नबिकरण गर्ने अधिकारीको दस्तखत</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="height:50px;"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td style="height:50px;"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td style="height:50px;"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td style="height:50px;"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td style="height:50px;"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td style="height:50px;"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td style="height:50px;"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td style="height:50px;"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td style="height:50px;"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td style="height:50px;"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  </tbody>
</table>
<br>
<div>
<p style="margin-top:30px;"><b> नोट:-</b></p>
<p><b> १. यो व्यवसाय इजाजत पत्र १(एक) वर्ष अबधि सम्म मात्र बहाल रहनेछ ।</b></p>
<p><b> २. नवीकरण शुल्क पहिलो तिन महिना सम्म रु ३०००/- लाग्नेछ र चौथो, पाँचौं, छैटौं महिना सम्म १० प्रतिशत थप शुल्क लाग्नेछ ।</b></p>
<p><b> ३. छैटौं महिना सम्म नवीकरण नगरे इजाजत पत्र स्वत खारेज हुनेछ।</b></p>
</div>