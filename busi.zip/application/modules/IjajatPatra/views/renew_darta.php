<style type="text/css">
  .card-header {
    background: #1b5693;
  }
</style>
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"> ड्यासबोर्डमा जानुहोस</a></li>
        <li class="breadcrumb-item"><a href="<?php echo base_url() ?>IjajatPatra">इजाजतपत्र सुची सुचीमा जानुहोस</a></li>
        <li class="breadcrumb-item"><a href="javascript:;">नवीकरण</a></li>
      </ol>
    </nav>

    <form class="form" method="post" action="<?php echo base_url() ?>IjajatPatra/nabikaran" enctype="multipart/form-data">
      <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
      <div class="row">
        <div class="col-sm-12">
          <?php $ERR_VALIDATION = $this->session->flashdata("ERR_VALIDATION");
          if (!empty($ERR_VALIDATION)) { ?>
            <div class="alert alert-danger">
              <button class="close" data-close="alert"></button>
              <span> <?php echo $ERR_VALIDATION; ?> </span>
            </div>
          <?php } ?>
          <?php $success_message = $this->session->flashdata("MSG_EMP");
          if (!empty($success_message)) { ?>
            <div class="alert alert-success">
              <button class="close" data-close="alert"></button>
              <span> <?php echo $success_message; ?> </span>
            </div>
          <?php } ?>

          <?php $ERR_UPLOAD = $this->session->flashdata("ERR_UPLOAD");
          if (!empty($ERR_UPLOAD)) { ?>
            <div class="alert alert-success">
              <button class="close" data-close="alert"></button>
              <span> <?php echo $ERR_UPLOAD; ?> </span>
            </div>
          <?php } ?>
          <section class="card">
            <header class="card-header text-light ">समुहको विवरण</header>
            <div class="card-body">
              <div class="row">
                <input type="hidden" value="<?php echo $row['id'] ?>" name="darta_id">
                <div class="col-md-2">
                  <div class="form-group">
                    <label>आर्थिक वर्ष <span style="color:red">*</span></label>
                    <div class="">
                      <input type="text" name="fiscal_year" value="<?php echo current_fiscal_year() ?>" class="form-control" readonly>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>दरखास्त पेश गर्ने फर्म वा कम्पनीको नाम <span style="color: red">*</span></label>
                    <input type="text" class="form-control owner_name" placeholder="" name="org_name" value="<?php echo $row['name'] ?>" readonly>
                  </div>
                </div>
                <div class="col-md-2">
                  <div class="form-group">
                    <label>दर्ता मिती<span style="color: red"> *</span></label>
                    <div class="input-group">
                      <input type="text" id="nepaliDateD" name="darta_miti" class="form-control nepali-calendar" value="<?php echo $row['darta_miti'] ?>" readonly />
                      <div class="input-group-prepend">
                        <button type="button" class="input-group-text btn btn-danger" title=""><i class="fa fa-calendar"></i></button>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-2">
                  <div class="form-group">
                    <label>दर्ता नं.<span style="color: red">*</span></label>
                    <input type="text" class="form-control certificate_no" placeholder="" name="darta_no" value="<?php echo $row['darta_no'] ?>" readonly>
                  </div>
                </div>
                <div class="col-md-12">
                  <hr>
                  <h6>नवीकरणको विवरण</h6>
                  <hr>
                </div>
                <div class="col-md-2">
                  <div class="form-group">
                    <label>नवीकरण मिति <span style="color:red">*</span></label>
                    <div class="">
                      <input type="text" name="date" value="<?php echo convertDate(date('Y-m-d')) ?>" class="form-control" readonly>
                    </div>
                  </div>
                </div>
                <div class="col-md-2">
                  <div class="form-group">
                    <label>नवीकरण आ. व. देखि <span style="color:red">*</span></label>
                    <div class="">
                      <input type="text" name="fiscal_year_from" value="" class="form-control">
                    </div>
                  </div>
                </div>
                <div class="col-md-2">
                  <div class="form-group">
                    <label>नवीकरण आ. व. देखि <span style="color:red">*</span></label>
                    <div class="">
                      <input type="text" name="fiscal_year_to" value="" class="form-control">
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>रसिद नं. <span style="color:red">*</span></label>
                    <div class="">
                      <input type="text" name="rasid_no" value="" class="form-control">
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>बुझाएको दस्तुर<span style="color:red">*</span></label>
                    <div class="">
                      <input type="text" name="dastur" value="" class="form-control">
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>कैफियत<span style="color:red">*</span></label>
                    <div class="">
                      <textarea class="form-control" name="remarks"></textarea>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
        <div class="col-md-12 text-center">
          <hr>
          <button class="btn btn-primary btn-xs btn-save save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्" name="Submit" type="submit" value="Submit" id="btn_save_details"> सेभ गर्नुहोस्</button>
          <a href="<?php echo base_url() ?>NagadiRasid" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
        </div>
      </div>
    </form>
  </section>
</section>
<script type="text/javascript" src="<?php echo base_url() ?>assets/assets/select2/js/select2.min.js"></script>
<script>
  $(document).ready(function() {
    $('#b_type').change(function() {
      obj = $(this);
      var type = obj.val();
      $.ajax({
        url: base_url + 'CommonController/subtype',
        method: "POST",
        data: {
          type: type,
          '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        },
        success: function(resp) {
          if (resp.status == 'success') {
            $('#subtype').html(resp.option);
          }
        }
      });
    });

    $('.npl_state').change(function() {
      var id_selected = $(this).attr("id");
      var res = id_selected.split("-");
      var id = res[res.length - 1];
      var state = $(this).val();
      $.ajax({
        url: base_url + 'CommonController/getDistrictByState',
        method: "POST",
        data: {
          state: state,
          '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        },
        success: function(resp) {
          if (resp.status == 'success') {
            $('#district-' + id).html(resp.option);
          }
        }
      });
    });

    $('.npl_district').change(function() {
      var id_selected = $(this).attr("id");
      var res = id_selected.split("-");
      var id = res[res.length - 1];
      var district = $(this).val();
      $.ajax({
        url: base_url + 'CommonController/getGapanapaByDistricts',
        method: "POST",
        data: {
          district: district,
          '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        },
        success: function(resp) {
          if (resp.status == 'success') {
            $('#gapa-' + id).html(resp.option);
          }
        }
      });
    });

  });
</script>