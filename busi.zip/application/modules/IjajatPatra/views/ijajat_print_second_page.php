<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
    <script src="<?php echo base_url() ?>/assets/js/jquery.js"></script>
    <title><?php echo GNAME ?></title>
</head>
<style>
    /* Set the print scale to 50% for the table */
    table {
        transform: scale(0.995);
        transform-origin: top left;
    }

    #nabikaran {
        border: 2px solid #000;
        /* Border style and color */
        border-radius: 5px;
        /* Border radius */
        padding: 10px;
        /* Padding to create space between text and border */
        display: inline-block;
        width: 30%;
        /* Display as inline-block to fit content */
    }
</style>

<body>
    <div class="">
        <div class="">
            <div class="text-center" id="nabikaran" style="margin-left:277px;font-weight:bold;">
                नवीकरण
            </div>
            <table class="table table-bordered" width="100%" style="border:2px solid black;">
                <thead>
                    <tr>
                        <td width="10%">नवीकरण गर्ने अधिकारी</td>
                        <td width="8%">नवीकरण गरेको मिति</td>
                        <td width="10%">नवीकरण वहाल रहेको अवधि</td>
                        <td width="10%">नवीकरण दस्तुर बुझाएको भौचर नं. र मिति</td>
                        <td width="10%">नवीकरण गर्ने अधिकारीको दस्तखत</td>
                    </tr>
                </thead>
                <tbody>
                    <tr style="height:75px;">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr style="height:75px;">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr style="height:75px;">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr style="height:75px;">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr style="height:75px;">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr style="height:75px;">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr style="height:75px;">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr style="height:75px;">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr style="height:75px;">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr style="height:75px;">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
            <div class="text-left"><u>नोट:</u></div>
            <div>१. यो इजाजत पत्र १ (एक) आर्थिक वर्ष सम्म मात्र बहाल रहनेछ,</div>
            <div>२. नबिकरण शुल्क पहिलो तिन महिना सम्म रु.५०००/- (अक्षरुपी पाँच हजार) लाग्नेछ र चौथो, पाँचौ र छैठौं महिना
                १० प्रतिशत थप शुल्क लाग्नेछ, </div>
            <div>३. छैठौं महिना सम्म पनि नबिकरण नगरेको इजाजत पत्र स्वत: खारेज हुनेछ l</div>
        </div>
    </div>
</body>
<script type="text/javascript">
    window.print();
</script>

</html>