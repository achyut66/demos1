<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>

  <style>
      .page {
        background: white;
        display: block;
        margin: 0 auto;
      }
      .page {
        /* width: 21cm; */
        height: 29.7cm;
      }
      @media print {
        * {
        -webkit-print-color-adjust: exact;
      }
      body,
        page {
          margin:0;
          box-shadow: 0;
        }
      }

      table td,
      th {
        padding: 0.1em 0.5em;
        text-align: center;
      }
      table {
        border: 1px solid black;
      }
      thead th {
        border: 1px solid black;
      }
      /* tfoot td {
        border-top: 2px solid black;
      } */
      tbody td {
      border: 1px solid black;
      }
      /* tbody tr:first-child td {
        border-top: 0;
      }
      tbody td:last-child {
        border-right: 0;
      } */
      .textButton
          {
              text-decoration: none;
              background-color: #000;
              color: #fff;
              padding: 2px 6px 2px 6px;
              border-top: 1px solid #CCCCCC;
              border-right: 1px solid #333333;
              border-bottom: 1px solid #333333;
              border-left: 1px solid #CCCCCC;
              width:100%;
              text-align:center;
              margin-left:300px;
              /* border-radius: 8px; */
          }
  </style>   
</head>

<body>
  <table class="print_table">
    <thead>
      <tr>
        <th>नबिकरण गर्ने अधिकारी</th>
        <th>नबिकरण गरेको मिति</th>
        <th>नबिकरण बहाल रहने अविधि</th>
        <th>नबिकरण दस्तुर बुझाएको भौचर नं. र मिति</th>
        <th>फाटवालाको दस्तखत</th>
        <th>नबिकरण गर्ने अधिकारीको दस्तखत</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td style="height:50px;"></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td style="height:50px;"></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td style="height:50px;"></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td style="height:50px;"></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td style="height:50px;"></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td style="height:50px;"></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td style="height:50px;"></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td style="height:50px;"></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td style="height:50px;"></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td style="height:50px;"></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
    </tbody>
  </table>
  <div>
 <p style="margin-top:30px;"><b> नोट:-</b></p>
  <p><b> १. यो व्यवसाय इजाजत पत्र १(एक) वर्ष अबधि सम्म मात्र बहाल रहनेछ ।</b></p>
  <p><b> २. नवीकरण शुल्क पहिलो तिन महिना सम्म रु ३०००/- लाग्नेछ र चौथो, पाँचौं, छैटौं महिना सम्म १० प्रतिशत थप शुल्क लाग्नेछ ।</b></p>
  <p><b> ३. छैटौं महिना सम्म नवीकरण नगरे इजाजत पत्र स्वत खारेज हुनेछ।</b></p>
  </div>
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
window.print();
</script>

</html>