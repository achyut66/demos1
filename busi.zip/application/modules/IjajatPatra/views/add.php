<style type="text/css">
  .card-header {
    background: #1b5693;
  }
</style>
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"> ड्यासबोर्डमा</a></li>
        <li class="breadcrumb-item"><a href="<?php echo base_url() ?>IjajatPatra">इजाजतपत्र सुची </a></li>
        <li class="breadcrumb-item"><a href="javascript:;">नयाँ थप्नुहोस्</a></li>
      </ol>
    </nav>

    <form class="form" method="post" action="<?php echo base_url() ?>IjajatPatra/save" enctype="multipart/form-data">
      <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
        value="<?php echo $this->security->get_csrf_hash(); ?>">
      <div class="row">
        <div class="col-sm-12">
          <?php $ERR_VALIDATION = $this->session->flashdata("ERR_VALIDATION");
          if (!empty($ERR_VALIDATION)) { ?>
            <div class="alert alert-danger">
              <button class="close" data-close="alert"></button>
              <span> <?php echo $ERR_VALIDATION; ?> </span>
            </div>
          <?php } ?>
          <?php $success_message = $this->session->flashdata("MSG_EMP");
          if (!empty($success_message)) { ?>
            <div class="alert alert-success">
              <button class="close" data-close="alert"></button>
              <span> <?php echo $success_message; ?> </span>
            </div>
          <?php } ?>
          <section class="card">
            <header class="card-header text-light ">दरखास्त पेश गर्ने फर्म वा कम्पनीको विवरण</header>
            <div class="card-body">
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label><b>आर्थिक वर्ष</b><span style="color: red">*</span></label>
                    <select class="form-control" name="fiscal_year" style="input-hover:none;" disabled>
                      <option value=""></option>
                      <?php //if (!empty($fiscal_year)):
                      //foreach ($fy as $fys): ?>
                      <option value="<?php echo $fy; ?>" selected><?php echo $fy; ?></option>
                      <?php //endforeach; endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label><b>इजाजत पत्र नं.</b><span style="color: red">*</span></label>
                    <input type="text" class="form-control darta_no" placeholder="" name="darta_no"
                      value="<?php echo $darta_no ?>">
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label><b>ऐन</b><span style="color: red">*</span></label>
                    <select class="form-control" name="yain">
                      <option value="">छानुहोस</option>
                      <?php if (!empty($yain)):
                        foreach ($yain as $y): ?>
                          <option value="<?php echo $y['rules'] ?>"><?php echo $y['rules'] ?></option>
                        <?php endforeach; endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="">फर्म वा कम्पनीको प्रकृति </label>
                    <select class="select_option form-control firm_type" name="firm_type">
                      <option value="">छानुहोस</option>
                      <option value="प्राईभेट लिमिटेड कम्पनी">
                        प्राईभेट लिमिटेड कम्पनी</option>
                      <option value="पब्लिक लिमिटेड कम्पनी">
                        पब्लिक लिमिटेड कम्पनी</option>
                      <option value="एकलोटी व्यवसाय">
                        एकलोटी व्यवसाय</option>
                      <option value="साझेदारी व्यवसाय">
                        साझेदारी व्यवसाय</option>
                    </select>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>नाम<span style="color: red">*</span></label>
                    <input type="text" class="form-control org_name" placeholder="" name="org_name" value="">
                  </div>
                </div>

                <div class="col-md-4">
                  <div class="form-group">
                    <label>सम्पर्क नम्वर<span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="contact_no" id="contact_no" value="">
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>ईमेल<span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="email" id="email" value="">
                  </div>
                </div>

                <div class="col-md-2">
                  <div class="form-group">
                    <label class="">प्रदेश </label>
                    <select class="form-control dd_select npl_state" name="p_pardesh" required id="state-2">
                      <option value="">छान्नुहोस्</option>
                      <?php if (!empty($pradesh)):
                        foreach ($pradesh as $key => $p): //pp($p); ?>
                          <option value="<?php echo $p['Title'] ?>" <?php if ($p['Title'] == STATE) {
                               echo 'selected';
                             } ?>><?php echo $p['Title'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">जिल्ला</label>
                    <select class="form-control dd_select npl_district" id="district-2" required name="p_district">
                      <option value=""></option>
                      <?php if (!empty($districts)):
                        foreach ($districts as $d): ?>
                          <option value="<?php echo $d['name'] ?>" <?php if ($d['name'] == DISTRICT) {
                               echo 'selected';
                             } ?>><?php echo $d['name'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">ग.पा / न. पा</label>
                    <select class="form-control npl_gapana dd_select select_option" name="p_gapa" id="gapa-2" required>
                      <?php if (!empty($gapana)):
                        foreach ($gapana as $key => $gp): ?>
                          <option value="<?php echo $gp['name'] ?>" <?php if ($gp['name'] == GNAME) {
                               echo 'selected';
                             } ?>><?php echo $gp['name'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-2">
                  <div class="form-group">
                    <label class="">वडा </label>
                    <select class="select_option form-control npl_state" name="p_ward">
                      <option value="">छानुहोस</option>
                      <?php if (!empty($wards)):
                        foreach ($wards as $key => $w): ?>
                          <option value="<?php echo $w['name'] ?>"><?php echo $this->mylibrary->convertedcit($w['name']) ?>
                          </option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>टोल <span style="color: red">*</span></label>
                    <input type="text" class="form-control tol" placeholder="" name="tol" value="">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <hr>
                  <h4>सम्पर्कको लागि फर्म वा कम्पनीको आधिकारीक व्यक्तिको</h4>
                  <hr>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>नाम<span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="contact_person" id="contact_person"
                      value="">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>ठेगाना<span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="contact_address" id="contact_address"
                      value="">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>सम्पर्क नम्वर<span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="c_number" id="c_number" value="">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>ईमेल<span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="c_email" id="c_email" value="">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <hr>
                  <h4>फर्म वा कम्पनीको विवरण</h4>
                  <hr>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>दर्ता नं<span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="org_darta_no" id="org_darta_no"
                      value="">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>दर्ता मिति<span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="org_darta_miti" id="org_darta_miti"
                      value="">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>अधिकृत पूँजि<span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="a_capital" id="a_capital" value="">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>जारि पूँजी<span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="c_capital" id="c_capital" value="">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <hr>
                  <h4>दर्ता गर्ने कार्यालयको नाम र ठेगाना</h4>
                  <hr>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>इजाजतपत्र लिन चाहेको वर्ग<span style="color: red">*</span></label>
                    <select class="select_option form-control warga" name="warga">
                      <option value="">छानुहोस</option>
                      <?php if (!empty($category)):
                        foreach ($category as $warga): ?>
                          <option value="<?php echo $warga['category'] ?>"><?php echo $warga['category'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>समूहीकरण हुन चाहेको समुह<span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="samuha" id="samuha" value="">
                  </div>
                </div>
              </div>
          </section>
          <section class="card">
            <header class="card-header text-light ">आर्थिक श्रोतको विवरण</header>
            <div class="card-body">
              <div class="row">
                <div class="col-md-12">
                  <table class="table">
                    <thead>
                      <tr>
                        <th></th>
                        <th>रकम</th>
                        <th>बित्तिय संस्था बैकको नाम</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>स्थायी ओभरड्राफ्ट</td>
                        <td><input type="" class="form-control" name="s_amount"></td>
                        <td><input type="" class="form-control" name="s_bank"></td>
                      </tr>
                      <tr>
                        <td>मुद्धती खाता</td>
                        <td><input type="" class="form-control" name="m_amount"></td>
                        <td><input type="" class="form-control" name="m_bank"></td>
                      </tr>
                      <tr>
                        <td>चल्ती खाता</td>
                        <td><input type="" class="form-control" name="c_amount"></td>
                        <td><input type="" class="form-control" name="c_bank"></td>
                      </tr>
                      <tr>
                        <td>बचत खाता</td>
                        <td><input type="" class="form-control" name="b_amount"></td>
                        <td><input type="" class="form-control" name="b_bank"></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </section>
          <section class="card">
            <header class="card-header text-light ">आफ्नो स्वामित्वमा रहेको निर्माण सम्बन्धी सवारी साधन मेशिनरी औजारको
              विवरण</header>
            <div class="card-body">
              <div class="row">
                <div class="col-md-12">
                  <table class="table" id="add_new_fields">
                    <thead>
                      <tr>
                        <th>नाम तथा विवरण </th>
                        <th>दर्ता नम्वर</th>
                        <th>क्षमता संख्या</th>
                        <th>मुल्य</th>
                        <th>खरिद मिति</th>
                        <th>अन्य</th>
                        <th>#</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><input type="text" name="device_name[]" class="form-control"></td>
                        <td><input type="text" name="device_no[]" class="form-control"></td>
                        <td><input type="text" name="device_capacity[]" class="form-control"></td>
                        <td><input type="text" name="device_amount[]" class="form-control number_field"></td>
                        <td><input type="text" name="device_date[]" class="form-control number_field"></td>
                        <td><input type="text" name="other_detail[]" class="form-control"></td>
                        <td><button type="button" class="btn btn-danger remove-row" data-toggle="tooltip"
                            title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>
                      </tr>
                    </tbody>
                  </table>
                  <button type="button" class="btn btn-secondary btn-block btnAddNew"><i class="fa fa-plus"></i> नयाँ
                    विवरण थप्नुहोस</button>
                </div>
              </div>
            </div>
          </section>

          <section class="card">
            <header class="card-header text-light ">यस अघि सम्पन्न गरेको कामको विवरण</header>
            <div class="card-body">
              <div class="row">
                <div class="col-md-12">
                  <table class="table" id="add_new_fields_ii">
                    <thead>
                      <tr>
                        <th>निर्माण सम्वन्धि कामको अनुभव</th>
                        <th>काम गरेको साल</th>
                        <th>रकम</th>
                        <th>ठेक्कादाता कार्यालयको नाम</th>
                        <th>कामको अवस्था </th>
                        <th>#</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><input type="text" name="pre_work[]" class="form-control"></td>
                        <td><input type="text" name="per_work_year[]" class="form-control"></td>
                        <td><input type="text" name="work_amount[]" class="form-control"></td>
                        <td><input type="text" name="work_office[]" class="form-control number_field"></td>
                        <td><input type="text" name="work_status[]" class="form-control"></td>
                        <td><button type="button" class="btn btn-danger remove-row-ii" data-toggle="tooltip"
                            title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>
                      </tr>
                    </tbody>
                  </table>
                  <button type="button" class="btn btn-secondary btn-block btnAddNewII"><i class="fa fa-plus"></i> नयाँ
                    विवरण थप्नुहोस</button>
                </div>
              </div>
            </div>
          </section>
        </div>

        <div class="col-md-12 text-center">
          <hr>
          <button class="btn btn-primary btn-xs btn-save save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्"
            name="Submit" type="submit" value="Submit" id="btn_save_details"> सेभ गर्नुहोस्</button>
          <a href="<?php echo base_url() ?>IjajatPatra" class="btn btn-danger btn-xs" data-toggle="tooltip"
            title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
        </div>
      </div>
    </form>
  </section>
</section>
<script type="text/javascript" src="<?php echo base_url() ?>assets/assets/select2/js/select2.min.js"></script>
<script>
  $(document).ready(function () {
    $('#male_member, #female_member').keyup(function () {
      obj = $(this);
      var male_member = $('#male_member').val() || 0;
      var female_member = $('#female_member').val() || 0;
      var total = parseInt(male_member) + parseInt(female_member);
      $('#total_member').val(total);
    });
    $('.npl_state').change(function () {
      var id_selected = $(this).attr("id");
      var res = id_selected.split("-");
      var id = res[res.length - 1];
      var state = $(this).val();
      $.ajax({
        url: base_url + 'CommonController/getDistrictByStateName',
        method: "POST",
        data: {
          state: state,
          '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        },
        success: function (resp) {
          if (resp.status == 'success') {
            $('#district-' + id).html(resp.option);
          }
        }
      });
    });
    $('.npl_district').change(function () {
      var id_selected = $(this).attr("id");
      var res = id_selected.split("-");
      var id = res[res.length - 1];
      var district = $(this).val();
      $.ajax({
        url: base_url + 'CommonController/getGapaByStateName',
        method: "POST",
        data: {
          district: district,
          '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        },
        success: function (resp) {
          if (resp.status == 'success') {
            $('#gapa-' + id).html(resp.option);
          }
        }
      });
    });
    //add new row
    $('.btnAddNew').click(function (e) {
      e.preventDefault();
      var trOneNew = $('.nagadi_rasid_frm').length + 1;
      var new_row =
        '<tr>' +
        '<td><input type="text" name="device_name[]" value="" class="form-control" required></td>' +
        '<td><input type="text" name="device_no[]" value="" class="form-control" required></td>' +
        '<td><input type="text" class="form-control" placeholder="" name="device_capacity[]" required="required" value=""></td>' +
        '<td><input type="text" class="form-control" placeholder="" name="device_amount[]" required="required" value=""></td>' +
        '<td><input type="text" class="form-control" placeholder="" name="device_date[]" required="required" value=""></td>' +
        '<td><input type="text" class="form-control" placeholder="" name="other_detail[]" required="required" value=""></td>' +
        '<td><button type="button" class="btn btn-danger remove-row" data-toggle="tooltip" title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>' +
        '<tr>'
      $("#add_new_fields").append(new_row);
    });
    $("body").on("click", ".remove-row", function (e) {
      e.preventDefault();

      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        var amt = $(this).closest("tr").find('.topic_rate').val();
        var t_amt = $('#t_total').val();
        var new_amt = t_amt - amt;
        $("#t_total").val(new_amt);
        $(this).parent().parent().remove();
      }
    });
    //add new row
    $('.btnAddNewII').click(function (e) {
      e.preventDefault();
      var new_row =
        '<tr>' +
        '<td><input type="text" name="pre_work[]" value="" class="form-control" required></td>' +
        '<td><input type="text" name="per_work_year[]" value="" class="form-control" required></td>' +
        '<td><input type="text" class="form-control" placeholder="" name="work_amount[]" required="required" value=""></td>' +
        '<td><input type="text" class="form-control" placeholder="" name="work_office[]" required="required" value=""></td>' +
        '<td><input type="text" class="form-control" placeholder="" name="work_status[]" required="required" value=""></td>' +
        '<td><button type="button" class="btn btn-danger remove-row-ii" data-toggle="tooltip" title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>' +
        '<tr>'
      $("#add_new_fields_ii").append(new_row);
    });
    $("body").on("click", ".remove-row-ii", function (e) {
      e.preventDefault();

      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        var amt = $(this).closest("tr").find('.topic_rate').val();
        var t_amt = $('#t_total').val();
        var new_amt = t_amt - amt;
        $("#t_total").val(new_amt);
        $(this).parent().parent().remove();
      }
    });
  });
</script>