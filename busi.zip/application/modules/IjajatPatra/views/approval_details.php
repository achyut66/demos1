<div class="card">
  <div class="card-header">
   ईजाजत पत्र दिनेको
  </div>
  <div class="card-body">
    <form action="<?php echo base_url() ?>IjajatPatra/updateMaker" method="post" class="form save_post">
      <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
        value="<?php echo $this->security->get_csrf_hash(); ?>">
      <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
      <div class="row">
        <div class="col-md-12">
          <div class="form-group">
            <label>ईजाजत पत्र दिनेको नाम <span style="color: red"> *</span></label>
            <select class="form-control" name="maker" id="maker">
              <option value="">--छान्नुहोस्--</option>
              <?php if (!empty($staffs)) : foreach ($staffs as $staff) : ?>
              <option value="<?php echo $staff['id'] ?>"
                <?php if($staff['id'] == $row['maker']){ echo 'selected';}?>><?php echo $staff['name'] ?></option>
              <?php endforeach;
                endif; ?>
            </select>
          </div>
        </div>

        <div class="col-md-12">
          <div class="form-group">
            <label>ईजाजत पत्र दिनेको पद<span style="color: red"> *</span></label>
            <input type="text" class="form-control" id="deg_maker"
              value="<?php echo !empty($row['maker'])?$maker['designation']:''?>" readonly />
          </div>
        </div>

        <div class="col-md-2">
          <div class="form-group">
            <button class="btn btn-primary btn-xs btn-save save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्"
              name="Submit" type="submit" value="Submit" id="btn_save_details" style="margin-top:23px;"> सेभ
              गर्नुहोस्</button>
          </div>
        </div>

      </div>
    </form>
  </div>
</div>

<script type="text/javascript">
$(document).ready(function() {
  var base_url = "<?php echo base_url() ?>";
  $('#maker').change(function() {
    obj = $(this);
    var maker = obj.val();
    var id = "<?php echo $this->uri->segment(3) ?>";
    $.ajax({
      url: base_url + 'Register/updateMaker',
      method: "POST",
      data: {
        maker: maker,
        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
      },
      success: function(resp) {
        $('#deg_maker').val(resp.data.designation);
        // if (resp.status == 'success') {
        //   location.reload();
        // }
      }
    });
  });
  $('#checker').change(function() {
    obj = $(this);
    var checker = obj.val();
    var id = "<?php echo $this->uri->segment(3) ?>";
    $.ajax({
      url: base_url + 'Register/updateChecker',
      method: "POST",
      data: {
        checker: checker,
        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
      },
      success: function(resp) {
        if (resp.status == 'success') {
          $('#deg_checker').val(resp.data.designation);
        }
      }
    });
  });
});
</script>
