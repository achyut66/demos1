<html>
<style>
    body {
        background: rgb(204, 204, 204);
    }

    .page {
        background: white;
        display: block;
        margin: 0 auto;
        margin-bottom: 0.5cm;

        background-repeat: no-repeat;
        background-size: cover;

    }

    .container {
        margin-top: -20px;
    }

    /* .page {
        width: 21cm;
        height: 29.7cm;
        
      } */
    .border {
        border: 2px solid black;
        background-color: black;

    }

    .text-left {
        font-size: 13px;
    }

    .btn-warning a {
        color: white;
        text-decoration: none;
    }

    .btn-warning {
        background-color: #ffc107;
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin-bottom: 0px;
        cursor: pointer;
        border-radius: 5px;
    }

    .btn-warning:hover {
        background-color: #ffa000;
        color: white;
    }
</style>
<div class="">
    <button class="btn btn-warning" style="margin-left: 299px;margin-top: 62px;"><a
            href="<?php echo base_url() ?>IjajatPatra/IjajatTippaniPrint/<?php echo $row['id'] ?>"
            target="_blank">प्रिन्ट
            गर्नुहोस</a></button>
    <div class="text-right" style="margin-right:88px;margin-top:30px;">E-mail: info@benighatrorangmun.gov.np</div>
    <div class="margin" style="margin-left:225px; margin-right: 40px;">
        <img src="<?php echo base_url() ?>assets/img/nepal-govt.png"
            style="margin-top: 40px; height: 80px; width: 80px; margin-left: 68px; ">
        <strong>
            <p style="margin-top:-100px;  font-size: 22px; text-align: center; color: rgb(239, 16, 16);">
                <?php echo GNAME ?>
            </p>
        </strong>
        <br>
        <strong>
            <p style="margin-top:-15px;  font-size: 30px; text-align: center; color: rgb(239, 16, 16);">
                <?php echo SLOGAN ?>
            </p>
        </strong>
        <br>
        <p style="margin-top:-20px;  font-size: 20px; text-align: center; color: rgb(239, 16, 16);">
            <?php echo ADDRESS . ',' . DISTRICT ?>
        </p>
        <br>
        <p style="margin-top:-20px;  font-size:18px; text-align: center; color: rgb(239, 16, 16);">
            <?php echo STATENAME ?>, नेपाल
        </p>
        <img src="<?php echo base_url() ?>assets/img/plb.png"
            style="margin-top: -145px;margin-left: 1106px;height: 80px;width: 80px;">
        <br>
        <div class="container">
            <div class="darta" style="font-size:18px;">पत्र संख्या :-
                <?php echo $this->mylibrary->convertedcit($row['fiscal_year']) ?>
            </div>
            <div class="darta" style="font-size:18px;">चलानी नं. :-</div>
            <div class="border"></div>
            <div class="darta" style="margin-left: 996px;font-size:15px;margin-top: 10px; ">मितिः-
                <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?>
            </div>
            <div class="name" style="font-size: 15px; margin-top: -5px;">श्री
                <?php echo $this->mylibrary->convertedcit($row['name']) ?>,
            </div>
            <div class="address" style="font-size: 15px;">
                <?php echo $this->mylibrary->convertedcit($row['p_gapa']) . '-' . $this->mylibrary->convertedcit($row['p_ward']) ?>,धादिङ
            </div>
            <strong>
                <p style="text-align:center; font-size: 16px; margin-top: 5px; ">बिषय:-
                    <u><?php echo $this->mylibrary->convertedcit($row['warga']) ?> वर्गको इजाजत पत्र पठाइएको सम्बन्धमा
                        l </u>
                </p>
            </strong>
            <div class="bbody" style=" font-size:15px;">
                <p style="font-size:14px;margin-top:0px;text-indent: 2em;text-align:justify">
                    <!-- प्रस्तुत बिषयमा यस
                    <strong><?php echo GNAME ?></strong> वडा न.
                    <strong>
                        <?= $this->mylibrary->convertedcit($row['p_ward']) ?>
                    </strong> मा रहेको श्री <strong>
                        <?php echo $this->mylibrary->convertedcit($row['name'] . 'ले') ?>
                    </strong>
                    दर्ता गरि पाउँ भनि दिनु भएको निबेदन अनुसार यस <strong><?php echo GNAME ?></strong>को संस्था दर्ता
                    तथा नबिकरण ऐन,२०७६ बमोजिम
                    श्री <strong><?php echo $this->mylibrary->convertedcit($row['name']) ?></strong> दर्ता गरि
                    दर्ता नं.
                    <strong><?= $this->mylibrary->convertedcit($row['darta_no']) ?></strong> रहेको हुँदा संस्था दर्ता
                    प्रमाण – पत्र यसै पत्र साथ पठाईएको
                    व्यहोरा अनुरोध छ l -->
                    प्रस्तुत बिषयमा यस <strong><?php echo GNAME ?></strong> वडा नं <strong>
                        <?= $this->mylibrary->convertedcit($row['p_ward']) ?>
                    </strong> स्थित कार्यालय रही <strong><?= $row['contact_person'] ?></strong>ले
                    <strong><?php echo GNAME ?></strong> – <?= $this->mylibrary->convertedcit($row['p_ward']) ?>
                    <strong><?= DISTRICT ?></strong>को स्वामित्वमा रहेको
                    <strong><?php echo $this->mylibrary->convertedcit($row['name']) ?></strong> लाई स्थानीय सरकार संचालन
                    ऐन २०७४
                    को दफा ११ (२) को खण्ड छ (१०) बमोजिम निर्माण व्यवसाय गर्न इजाजत पत्र नं.
                    <?= $this->mylibrary->convertedcit($row['darta_no'] . ' / ' . $row['fiscal_year']) ?>
                    <?= $row['warga'] ?>
                    बर्गको इजाजत–पत्र यसै पत्र साथ पठाइएको व्यहोरा अनुरोध छ l
                </p>
            </div>

        </div>
        <div class="darta" style="margin-left: 1003px;margin-top: 2px; font-size:18px;">............................
            <br>प्रमुख प्रशासकीय अधिकृत<br>
            <br>
            <select class="form-control" name="maker" id="maker"
                style="font-size:18px;border-radius:4px;margin-left:-60px;">
                <option value="">--छान्नुहोस्--</option>
                <?php if (!empty($staffs)):
                    foreach ($staffs as $staff): ?>
                        <option value="<?php echo $staff['id'] ?>" <?php if ($staff['id'] == $row['maker']) {
                               echo 'selected';
                           } ?>>
                            <?php echo $staff['name'] ?>
                        </option>
                    <?php endforeach;
                endif; ?>
            </select>
        </div>
        <div style="margin-top:35px;margin-left:61px;">
            <u>बोधार्थ :–</u><br>
            १. श्री करदाता सेवा कार्यालय, गल्छी, धादिङ l
        </div>
    </div>
</div>

<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        var base_url = "<?php echo base_url() ?>";
        $('#maker').change(function () {
            obj = $(this);
            var maker = obj.val();
            var id = "<?php echo $this->uri->segment(3) ?>";
            $.ajax({
                url: base_url + 'IjajatPatra/updateMaker',
                method: "POST",
                data: {
                    maker: maker,
                    id: id,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                },
                success: function (resp) {
                    if (resp.status == 'success') {
                        location.reload();
                    }
                }
            });
        });
        $('#checker').change(function () {
            obj = $(this);
            var checker = obj.val();
            var id = "<?php echo $this->uri->segment(3) ?>";
            $.ajax({
                url: base_url + 'IjajatPatra/updateChecker',
                method: "POST",
                data: {
                    checker: checker,
                    id: id,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                },
                success: function (resp) {
                    if (resp.status == 'success') {
                        location.reload();
                    }
                }
            });
        });
    });
</script>

</html>