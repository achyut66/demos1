<?php
class CommonController extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        if(!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login','location');
        }
    }

    /**
        * This function list all the land minimun rate
        * @param NULL
        * @return void

     */
    public function Index()
    {}

    //get district by state
    public function getDistrictByState() {
        if($this->input->is_ajax_request()) {
            $state = $this->input->post('state');
            get_district_dropdown($state);
        } else {
          exit('no direct script allowed');
      }
    }

    public function getDistrictByStateName() {
        if($this->input->is_ajax_request()) {
            $state = $this->input->post('state');
            $state_details = $this->CommonModel->getWhere('provinces',array('Title' => $state));
            $district = $this->CommonModel->getWhereAll('settings_district',array('state_name'=>$state));
            if(!empty($district)){
                $option = '';
                $option .= '<option value="">छान्नुहोस्</option>';
                foreach ($district as $key => $value) :
                  $option .= "<option value = '".$value['name']."''>".$value['name']."</option>";
                endforeach;
                $response = array(
                  'status'      => 'success',
                  'option' => $option,
                  'state'  => $state_details['ID']
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
              }
        } else {
          exit('no direct script allowed');
      }
    }

    //get Gapanapa By Districts
    public function getGapanapaByDistricts() {
        if($this->input->is_ajax_request()) {
            $district = $this->input->post('district');
            get_ganapa_dropdown($district);
        } else {
          exit('no direct script allowed');
        }
    }

    public function getGapaByStateName() {
        if($this->input->is_ajax_request()) {
            $district = $this->input->post('district');
            $district_id = $this->CommonModel->getWhere('settings_district',array('name' => $district));
            $district = $this->CommonModel->getWhereAll('settings_vdc_municipality',array('district'=>$district));
            if(!empty($district)){
                $option = '';
                $option .= '<option value="">छान्नुहोस्</option>';
                foreach ($district as $key => $value) :
                  $option .= "<option value = '".$value['name']."''>".$value['name']."</option>";
                endforeach;
                $response = array(
                  'status'      => 'success',
                  'option'      => $option,
                  'district_id' => $district_id['id']
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
              }
        } else {
          exit('no direct script allowed');
      }
    }

    public function subtype() {
        $subtype = $this->input->post('type');
        $data = $this->CommonModel->getWhereAll('prakar', array('main_topic' => $subtype));
        if(!empty($data)){
            $option = '';
            $option .= '<option value="">छान्नुहोस्</option>';
            foreach ($data as $key => $value) :
              $option .= "<option value = '".$value['id']."''>".$value['sub_topic']."</option>";
            endforeach;
            $response = array(
              'status'      => 'success',
              'option' => $option,
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
        }
    }
}