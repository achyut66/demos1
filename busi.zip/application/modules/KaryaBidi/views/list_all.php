
<!--main content start-->
      <section id="main-content">
          <section class="wrapper site-min-height">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo base_url()?>"><i class="fa fa-home"></i> ड्यासबोर्डमा जानुहोस</a></li>
              </ol>
            </nav>
              <!-- page start-->
              <div class="row">
                <div class="col-sm-12">
                    <aside class="card">
                      <header class="card-header">कार्यविधि
                        <span class="tools">
                          <?php if($this->authlibrary->HasModulePermission('KARYA-BIDI', "ADD")) { ?>
                            <button type="button" data-toggle="modal" href="#addModel" class="btn btn-secondary pull-right" data-url="<?php echo base_url()?>KaryaBidi/add"><i class="fa fa-plus-circle"></i> नया कार्यविधि थप्नुहोस्</button>
                          <?php } ?>
                        </span>    
                      </header>
                        <div class="card-body">
                          
                            <table class="table table-bordered table-striped">
                              <thead>
                                <tr>
                                  <th text-aligh="right">#</th>
                                  <th>शर्तहरु </th>
                                  <th></th>
                                </tr>
                              </thead>
                             <tbody>
                              <?php if(!empty($rows)) : 
                                $i = 1; foreach ($rows as $key => $row) : ?>
                                 <tr>
                                    <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                                    <td><?php echo $this->mylibrary->convertedcit($row['detail'])?></td>
                                    <?php if($this->authlibrary->HasModulePermission('KARYA-BIDI','EDIT') && $this->authlibrary->HasModulePermission('KARYA-BIDI', 'DELETE')) { ?>
                                      <td class="center hidden-phone">
                                        <?php if($this->authlibrary->HasModulePermission('KARYA-BIDI', "EDIT")) { ?>
                                          <button type="button" data-toggle="modal" href="#editModel" class="btn btn-info"  data-url="<?php echo base_url()?>KaryaBidi/edit" data-id = "<?php echo $row['id']?>"><i class="fa fa-pencil"></i></button>
                                        <?php } ?>

                                        <?php if($this->authlibrary->HasModulePermission('KARYA-BIDI', "DELETE")) { ?>
                                         <button data-url = "<?php echo base_url()?>KaryaBidi/delete" data-id = "<?php echo $row['id']?>" class="btn btn-danger delete_data"><i class="fa fa-trash-o"></i></button>
                                        <?php } ?>
                                      </td>
                                    <?php } ?>
                                 </tr>
                              <?php endforeach;
                              else : ?>
                              <td colspan="4"><div class="alert alert-danger">no records found in database</div></td>
                            <?php endif;?>
                             </tbody>
                            </table>
                        </div>
                    </aside>
                  
                </div>
              </div>
          </section>
      </section>

    
<script src="<?php echo base_url('assets/datatable/datatables.min.js') ?>"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $(document).on('click','.btn-delete', function(e){
      //e.preventDefault();
      var id = $(this).data('id'); //Fetch id from modal trigger button
     
      var url = $(this).data('url');
      if (confirm("Are you sure want to delete?") == true) {
              $.ajax({
                type : 'POST',
                url : url, //Here you will fetch records 
                data: {id:id,'<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'}, //Pass $id
                success : function(resp){
                  console.log(resp);
                //   return;
                  if(resp.status == 'success') {
                    toastr.options = {
                      "closeButton": true,
                      "debug": true,
                      "progressBar": true,
                      "positionClass": "toast-top-right",
                      "showDuration": "200",
                      "hideDuration": "1000",
                      "timeOut": "3000",
                      "extendedTimeOut": "1000",
                      "showEasing": "swing",
                      "hideEasing": "linear",
                      "showMethod": "fadeIn",
                      "hideMethod": "fadeOut"
                    };
                    toastr.success(resp.data);
                    setTimeout(function(){ 
                      location.reload();
                    }, 2000);
                  } else {
                    toastr.options = {
                      "closeButton": true,
                      "debug": true,
                      "progressBar": true,
                      "positionClass": "toast-top-right",
                      "showDuration": "300",
                      "hideDuration": "1000",
                      "timeOut": "5000",
                      "extendedTimeOut": "1000",
                      "showEasing": "swing",
                      "hideEasing": "linear",
                      "showMethod": "fadeIn",
                      "hideMethod": "fadeOut"
                    };
                    toastr.success(resp.data);
                    setTimeout(function(){ 
                      location.reload();
                    }, 2000);
                  }
                 }
              });
      } else {
        return false;
      }
    });
  });
</script>