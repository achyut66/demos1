<?php

/**
 * Created by PhpStorm.
 * User: root
 * Date: 12/2/16
 * Time: 9:57 PM
 */
class Register extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->load->model("RegisterModel");
        $this->module_code = 'REGISTER';
        if (!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login', 'location');
        }
    }

    /** 
     * This function load add buy or sell form
     * @param NULL
     * return load view with list
     */

    public function downloadImage($id)
    {
        // $this->load->helper('download');
        // $file_name_one = $this->CommonModel->getDataByID('documents', $id);
        // $file_name = $file_name_one['doc_name'];
        // $file_path = base_url().'assets/darta_images/'.$file_name;
        // pp($file_path);

        // $mime_type = mime_content_type($file_path);
        // header('Content-Type: ' . $file_path);
        // header('Content-Disposition: attachment; filename="' . $file_name . '"');
        // header('Pragma: public');
        // header('Content-Length: ' . filesize($file_path));

        // force_download($file_name, file_get_contents($file_path));

        // Set the filename to be used for the download
        $file_name_one = $this->CommonModel->getDataByID('documents', $id);
        $file_name = $file_name_one['doc_name'];
        // file path
        $file_path = base_url() . 'assets/darta_images/' . $file_name;

        // Load the download helper to use the force_download() function
        $this->load->helper('download');

        // Use the force_download() function to send the file to the user for download
        force_download($file_name, file_get_contents($file_path));
    }
    // image view
    public function view_image($id)
    {
        $file_name_one = $this->CommonModel->getDataByID('documents', $id);
        $image_path = base_url('assets/darta_images/') . $file_name_one['doc_name'];
        $data['image_path'] = $image_path;
        $this->load->view('image_view', $data);
    }
    // ends here
// pdf download
    public function download_pdf($id)
    {
        // Load the mPDF library
        $this->load->library('M_pdf');

        // Fetch the image file from the server
        $file_name_one = $this->CommonModel->getDataByID('documents', $id);
        $file_name = $file_name_one['doc_name'];
        $image_url = base_url('assets/darta_images/') . $file_name;
        $image_data = file_get_contents($image_url);

        // Generate the PDF
        $mpdf = new M_pdf();
        $mpdf->WriteHTML('<img src="$image_url' . base64_encode($image_data) . '">');
        $mpdf->Output('image.pdf', 'D');
    }

    // ends here
    public function Index()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $data['page'] = 'list_all';
            $data['main_topic'] = $this->CommonModel->getData('main_topic');
            // $data['row']            = $this->CommonModel->getAll();
            // pp($data['row']);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }
    // display the uploaded files into views
    public function ShowFiles()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "FILES")) {
            $data['page'] = 'display_files';
            $data['documents'] = $this->CommonModel->get_image_file('Register');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }
    // display ends here

    // download files

    public function download($id)
    {
        if (!empty($id)) {
            //load download helper
            $this->load->helper('download');
            //get file info from database
            $fileInfo = $this->file->getRows(array('id' => $id));
            //file path
            $file = 'uploads/files/' . $fileInfo['file_name'];
            //download file from directory
            force_download($file, NULL);
        }
    }

    // download ends here

    /**
     * This function load add buy or sell form
     * @param NULL
     * return view
     */
    public function add()
    {
        $this->load->helper('form');
        $data['page'] = 'add';
        $data['wards'] = $this->CommonModel->getData('settings_ward', 'DESC');
        $data['districts'] = $this->CommonModel->getData('settings_district', 'DESC');
        $data['pradesh'] = $this->CommonModel->getData('provinces', 'DESC');
        $data['prakar'] = $this->CommonModel->getData('main_topic');
        $data['darta_suchikrit'] = $this->CommonModel->getData('darta_suchikrit');
        $data['category'] = $this->CommonModel->getData('category');
        $data['fiscal_year'] = $this->CommonModel->getData('fiscal_year');
        $data['gapana'] = $this->CommonModel->getWhereAll('settings_vdc_municipality', array('district' => DISTRICT));
        $darta = $this->RegisterModel->GetMaxDartaID();
        $data['darta_no'] = $darta->darta_no + 1;
        // pp($data['darta_no']);
        $this->load->view('main', $data);
    }


    //save register

    public function save()
    {
        if ($this->input->post('Submit')) {


            $fiscal_year = $this->input->post('fiscal_year');
            $darta_miti = $this->input->post('darta_miti');
            $certificate_no = $this->input->post('certificate_no');
            $business_name_np = $this->input->post('business_name_np');
            $business_name_en = $this->input->post('business_name_en');
            $b_pradesh = $this->input->post('b_pradesh');
            $darta_suchikrit = $this->input->post('darta_suchikrit');
            $b_district = $this->input->post('b_district');
            $b_gapa = $this->input->post('b_gapa');
            $b_ward = $this->input->post('b_ward');
            $b_tol = $this->input->post('b_tol');
            $b_phone_number = $this->input->post('b_phone_number');
            $b_email = $this->input->post('b_email');
            $s_phone_number = $this->input->post('s_phone_number');
            $s_email = $this->input->post('s_email');
            $road_name = $this->input->post('road_name');
            $b_captial = $this->input->post('b_captial');
            $b_aim = $this->input->post('b_aim');
            $b_type = $this->input->post('b_type');
            $b_subtype = $this->input->post('b_subtype');
            $b_capital_source = $this->input->post('b_capital_source');
            $b_darta_office = $this->input->post('b_darta_office');
            $b_odarta_miti = $this->input->post('b_odarta_miti');
            $darta_entry_date = $this->input->post('darta_entry_date');
            $b_odarta_no = $this->input->post('b_odarta_no');
            $b_pan_no = $this->input->post('b_pan_no');
            $b_workdetails = $this->input->post('b_workdetails');
            $b_owner_name = $this->input->post('b_owner_name');
            $b_ctzn_no = $this->input->post('b_ctzn_no');
            $b_ctzn_district = $this->input->post('b_ctzn_district');
            $b_ctzn_date = $this->input->post('b_ctzn_date');
            $p_pardesh = $this->input->post('p_pardesh');
            $p_district = $this->input->post('p_district');
            $p_gapa = $this->input->post('p_gapa');
            $p_ward = $this->input->post('p_ward');
            $t_pardesh = $this->input->post('t_pardesh');
            $t_district = $this->input->post('t_district');
            $t_gapa = $this->input->post('t_gapa');
            $t_ward = $this->input->post('t_ward');
            $grandfather_name = $this->input->post('grandfather_name');
            $grandfather_address = $this->input->post('grandfather_address');
            $father_name = $this->input->post('father_name');
            $father_address = $this->input->post('father_address');
            $landlord = $this->input->post('landlord');
            $landlord_address = $this->input->post('landlord_address');
            $rent = $this->input->post('rent');
            $nibedan_dastur = $this->input->post('nibedan_dastur');
            $darta_dastur = $this->input->post('darta_dastur');
            $b_kar = $this->input->post('b_kar');
            $fine_amount = $this->input->post('fine_amount');
            $total_amount = $this->input->post('total_amount');
            $rasid_date = $this->input->post('rasid_date');
            $rasid_no = $this->input->post('rasid_no');
            $fixed_capital = $this->input->post('fixed_capital');
            $chalu_capital = $this->input->post('chalu_capital');
            $category = $this->input->post('category');
            $explode = explode('-', $darta_miti);
            $submission = $explode[0] . $explode[1] . $explode[2];
            $namecount = $this->CommonModel->getNameCount($business_name_en);
            $unique = $namecount->third_sn + 1;
            $submission_no = $submission . $unique . $certificate_no;
            $b_anual_production = $this->input->post('b_anual_production');
            $b_electricity = $this->input->post('b_electricity');
            $party_size = $this->input->post('party_size');
            $doc_type = $this->input->post('image_t_name');
            $doc_file = $this->input->post('userfile');
            $fields_array = $_FILES['userfile']['name'];

            $save_array = array(
                'submission_no' => $submission_no,
                'darta_no' => $certificate_no,
                'fiscal_year' => $fiscal_year,
                'darta_miti' => $darta_miti,
                'pp_no' => $certificate_no,
                'business_name_np' => $business_name_np,
                'business_name_en' => $business_name_en,
                'b_pradesh' => $b_pradesh,
                'b_district' => $b_district,
                'b_gapa' => $b_gapa,
                'b_ward' => $b_ward,
                'b_tol' => $b_tol,
                'b_captial' => $b_captial,
                'fixed_capital' => $fixed_capital,
                'chalu_capital' => $chalu_capital,
                'b_aim' => $b_aim,
                'b_type' => $b_type,
                'b_subtype' => $b_subtype,
                'b_phone_number' => $b_phone_number,
                'b_email' => $b_email,
                's_phone_number' => $s_phone_number,
                's_email' => $s_email,
                'road_name' => $road_name,
                'category' => $category,
                'b_capital_source' => $b_capital_source,
                'b_darta_office' => $b_darta_office,
                'b_odarta_miti' => $b_odarta_miti,
                'darta_entry_date' => $darta_entry_date,
                'b_odarta_no' => $b_odarta_no,
                'b_pan_no' => $b_pan_no,
                'b_workdetails' => $b_workdetails,
                'b_owner_name' => $b_owner_name,
                'b_ctzn_no' => $b_ctzn_no,
                'b_ctzn_district' => $b_ctzn_district,
                'b_ctzn_date' => $b_ctzn_date,
                'p_pradesh' => $p_pardesh,
                'p_district' => $p_district,
                'p_gapa' => $p_gapa,
                'p_ward' => $p_ward,
                't_pradesh' => $t_pardesh,
                't_district' => $t_district,
                't_gapa' => $t_gapa,
                't_ward' => $t_ward,
                'grandfather_name' => $grandfather_name,
                'grandfather_address' => $grandfather_address,
                'father_name' => $father_name,
                'father_address' => $father_address,
                'landlord' => $landlord,
                'landlord_address' => $landlord_address,
                'rent' => $rent,
                'b_anual_production' => $b_anual_production,
                'b_electricity' => $b_electricity,
                'nibedan_dastur' => $nibedan_dastur,
                'darta_dastur' => $darta_dastur,
                'b_kar' => $b_kar,
                'fine_amount' => $fine_amount,
                'total_amount' => $total_amount,
                'rasid_date' => $rasid_date,
                'rasid_no' => $rasid_no,
                'darta_suchikrit' => $darta_suchikrit,
                'party_size' => $party_size,
                'status' => 1,
                'added_on' => date('Y-m-d'),
                'added_by' => $this->session->userdata('PRJ_USER_BID'),
                'added_ward' => $this->session->userdata('PRJ_USER_WARD'),
            );
            // pp($save_array);
            $result = $this->CommonModel->insertData('darta', $save_array);
            if ($result) {

                if (!empty($fields_array)) {
                    $path = 'darta_images';
                    $uploads = upload_multiple($path, 'userfile', $doc_type, $result, $this->uri->segment(1), 1);
                    // pp($uploads);
                    $this->CommonModel->batchInsert($uploads, 'documents');
                }

                $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                redirect('Register/viewDetails/' . $result);
            }
        }
    }

    //view details
    public function viewDetails($id = NULL)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataByID('darta', $id);
            $data['migration_darta'] = $this->CommonModel->getWhere('darta_migration', array('prev_darta_id' => $data['row']['id']));
            // pp($data['migration_darta']);
            // $data['sow']            = $this->CommonModel->getWhere('darta', array('darta_no' => $id));
            $data['bstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['b_pradesh']));
            $data['bdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['b_district']));
            $data['bgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['b_gapa']));
            $data['pstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['p_pradesh']));
            $data['pdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['p_district']));
            $data['pgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['p_gapa']));
            $data['tstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['t_pradesh']));
            $data['tdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['t_district']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['main_topic'] = $this->CommonModel->getWhere('main_topic', array('id' => $data['row']['b_type']));
            $data['subtopic'] = $this->CommonModel->getWhere('prakar', array('id' => $data['row']['b_subtype']));
            $data['renewdetails'] = $this->CommonModel->getWhereAll('renew', array('darta_id' => $id));
            $data['page'] = 'view_details';
            $this->load->view('main', $data);
        }
    }

    public function businessTippani($id = NULL)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataByID('darta', $id);
            $data['bstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['b_pradesh']));
            $data['bdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['b_district']));
            $data['bgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['b_gapa']));
            // pp($data['bgapa']);
            $data['pstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['p_pradesh']));
            $data['pdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['p_district']));
            // pp($data['pdistrict']);
            $data['pgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['p_gapa']));
            $data['tstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['t_pradesh']));
            $data['tdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['t_district']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['main_topic'] = $this->CommonModel->getWhere('main_topic', array('id' => $data['row']['b_type']));
            $data['subtopic'] = $this->CommonModel->getWhere('prakar', array('id' => $data['row']['b_subtype']));
            $data['renewdetails'] = $this->CommonModel->getWhereAll('renew', array('darta_id' => $id));
            $data['page'] = 'business_tippani';
            $this->load->view('main', $data);
        }
    }


    public function edit($id)
    {
        $data['page'] = 'edit';
        $data['wards'] = $this->CommonModel->getData('settings_ward', 'DESC');
        $data['districts'] = $this->CommonModel->getData('settings_district', 'DESC');
        $data['pradesh'] = $this->CommonModel->getData('provinces', 'DESC');
        $data['prakar'] = $this->CommonModel->getData('main_topic');
        $data['darta_suchikrit'] = $this->CommonModel->getData('darta_suchikrit');
        $data['category'] = $this->CommonModel->getData('category');
        $data['subtopic'] = $this->CommonModel->getData('prakar');
        $data['fiscal_year'] = $this->CommonModel->getData('fiscal_year');
        $data['gapana'] = $this->CommonModel->getData('settings_vdc_municipality', 'DESC');
        $data['row'] = $this->CommonModel->getDataById('darta', $id);
        // pp($data['row']);
        $this->load->view('main', $data);
    }
    public function BusinessMigration($id)
    {
        $data['page'] = 'migration';
        $data['wards'] = $this->CommonModel->getData('settings_ward', 'DESC');
        $data['districts'] = $this->CommonModel->getData('settings_district', 'DESC');
        $data['pradesh'] = $this->CommonModel->getData('provinces', 'DESC');
        $data['prakar'] = $this->CommonModel->getData('main_topic');
        $data['darta_suchikrit'] = $this->CommonModel->getData('darta_suchikrit');
        $data['category'] = $this->CommonModel->getData('category');
        $data['subtopic'] = $this->CommonModel->getData('prakar');
        $data['fiscal_year'] = $this->CommonModel->getData('fiscal_year');
        $data['gapana'] = $this->CommonModel->getData('settings_vdc_municipality', 'DESC');
        $data['row'] = $this->CommonModel->getDataById('darta', $id);
        $data['new_darta'] = $this->CommonModel->getMaxDarta('darta');
        $data['new_migration_darta'] = $this->CommonModel->getMaxDarta('darta_migration');
        if (!empty($data['new_migration_darta'])) {
            $data['new_darta_id'] = $data['new_migration_darta'] + 1;
        } else {
            $data['new_darta_id'] = $data['new_darta'] + 1;
        }

        // pp($data['new_migration_darta']);
        $this->load->view('main', $data);
    }
    // save migration data
    public function saveMigration()
    {
        if ($this->input->post('Submit')) {
            $fiscal_year = $this->input->post('fiscal_year');
            $darta_miti = $this->input->post('darta_miti');
            $certificate_no = $this->input->post('certificate_no');
            $business_name_np = $this->input->post('business_name_np');
            $business_name_en = $this->input->post('business_name_en');
            $b_pradesh = $this->input->post('b_pradesh');
            $darta_suchikrit = $this->input->post('darta_suchikrit');
            $b_district = $this->input->post('b_district');
            $b_gapa = $this->input->post('b_gapa');
            $prev_darta_id = $this->input->post('prev_darta_id');
            $b_ward = $this->input->post('b_ward');
            $b_tol = $this->input->post('b_tol');
            $b_phone_number = $this->input->post('b_phone_number');
            $b_email = $this->input->post('b_email');
            $s_phone_number = $this->input->post('s_phone_number');
            $s_email = $this->input->post('s_email');
            $road_name = $this->input->post('road_name');
            $b_captial = $this->input->post('b_captial');
            $b_aim = $this->input->post('b_aim');
            $b_type = $this->input->post('b_type');
            $b_subtype = $this->input->post('b_subtype');
            $b_capital_source = $this->input->post('b_capital_source');
            $b_darta_office = $this->input->post('b_darta_office');
            $b_odarta_miti = $this->input->post('b_odarta_miti');
            $b_odarta_no = $this->input->post('b_odarta_no');
            $b_pan_no = $this->input->post('b_pan_no');
            $b_workdetails = $this->input->post('b_workdetails');
            $b_owner_name = $this->input->post('b_owner_name');
            $b_ctzn_no = $this->input->post('b_ctzn_no');
            $b_ctzn_district = $this->input->post('b_ctzn_district');
            $b_ctzn_date = $this->input->post('b_ctzn_date');
            $p_pardesh = $this->input->post('p_pardesh');
            $p_district = $this->input->post('p_district');
            $p_gapa = $this->input->post('p_gapa');
            $p_ward = $this->input->post('p_ward');
            $t_pardesh = $this->input->post('t_pardesh');
            $t_district = $this->input->post('t_district');
            $t_gapa = $this->input->post('t_gapa');
            $t_ward = $this->input->post('t_ward');
            $grandfather_name = $this->input->post('grandfather_name');
            $grandfather_address = $this->input->post('grandfather_address');
            $father_name = $this->input->post('father_name');
            $father_address = $this->input->post('father_address');
            $landlord = $this->input->post('landlord');
            $landlord_address = $this->input->post('landlord_address');
            $rent = $this->input->post('rent');
            $nibedan_dastur = $this->input->post('nibedan_dastur');
            $darta_dastur = $this->input->post('darta_dastur');
            $b_kar = $this->input->post('b_kar');
            $fine_amount = $this->input->post('fine_amount');
            $total_amount = $this->input->post('total_amount');
            $rasid_date = $this->input->post('rasid_date');
            $rasid_no = $this->input->post('rasid_no');
            $fixed_capital = $this->input->post('fixed_capital');
            $chalu_capital = $this->input->post('chalu_capital');
            $category = $this->input->post('category');
            $explode = explode('-', $darta_miti);
            $submission = $explode[0] . $explode[1] . $explode[2];
            $namecount = $this->CommonModel->getNameCount($business_name_en);
            $unique = $namecount->third_sn + 1;
            $submission_no = $submission . $unique . $certificate_no;
            $b_anual_production = $this->input->post('b_anual_production');
            $b_electricity = $this->input->post('b_electricity');
            if (!empty($this->input->post('party_size'))) {
                $party_size = $this->input->post('party_size');
            } else {
                $party_size = 0;
            }

            $doc_type = $this->input->post('image_t_name');
            $doc_file = $this->input->post('userfile');
            $fields_array = $_FILES['userfile']['name'];

            $save_array = array(
                'submission_no' => $submission_no,
                'darta_no' => $certificate_no,
                'fiscal_year' => $fiscal_year,
                'darta_miti' => $darta_miti,
                'pp_no' => $certificate_no,
                'business_name_np' => $business_name_np,
                'business_name_en' => $business_name_en,
                'b_pradesh' => $b_pradesh,
                'b_district' => $b_district,
                'b_gapa' => $b_gapa,
                'b_ward' => $b_ward,
                'prev_darta_id' => $prev_darta_id,
                'b_tol' => $b_tol,
                'b_captial' => $b_captial,
                'fixed_capital' => $fixed_capital,
                'chalu_capital' => $chalu_capital,
                'b_aim' => $b_aim,
                'b_type' => $b_type,
                'b_subtype' => $b_subtype,
                'b_phone_number' => $b_phone_number,
                'b_email' => $b_email,
                's_phone_number' => $s_phone_number,
                's_email' => $s_email,
                'road_name' => $road_name,
                'category' => $category,
                'b_capital_source' => $b_capital_source,
                'b_darta_office' => $b_darta_office,
                'b_odarta_miti' => $b_odarta_miti,
                'b_odarta_no' => $b_odarta_no,
                'b_pan_no' => $b_pan_no,
                'b_workdetails' => $b_workdetails,
                'b_owner_name' => $b_owner_name,
                'b_ctzn_no' => $b_ctzn_no,
                'b_ctzn_district' => $b_ctzn_district,
                'b_ctzn_date' => $b_ctzn_date,
                'p_pradesh' => $p_pardesh,
                'p_district' => $p_district,
                'p_gapa' => $p_gapa,
                'p_ward' => $p_ward,
                't_pradesh' => $t_pardesh,
                't_district' => $t_district,
                't_gapa' => $t_gapa,
                't_ward' => $t_ward,
                'grandfather_name' => $grandfather_name,
                'grandfather_address' => $grandfather_address,
                'father_name' => $father_name,
                'father_address' => $father_address,
                'landlord' => $landlord,
                'landlord_address' => $landlord_address,
                'rent' => $rent,
                'b_anual_production' => $b_anual_production,
                'b_electricity' => $b_electricity,
                'nibedan_dastur' => $nibedan_dastur,
                'darta_dastur' => $darta_dastur,
                'b_kar' => $b_kar,
                'fine_amount' => $fine_amount,
                'total_amount' => $total_amount,
                'rasid_date' => $rasid_date,
                'rasid_no' => $rasid_no,
                'darta_suchikrit' => $darta_suchikrit,
                'party_size' => $party_size,
                'status' => 1,
                'added_on' => date('Y-m-d'),
                'added_by' => $this->session->userdata('PRJ_USER_BID'),
                'added_ward' => $this->session->userdata('PRJ_USER_WARD'),
            );
            // pp($save_array);
            $prev_id = $save_array['prev_darta_id'];
            $result = $this->CommonModel->insertData('darta_migration', $save_array);

            // pp($prev_id);
            if ($result) {

                if (!empty($fields_array)) {
                    $path = 'darta_images';
                    $uploads = upload_multiple($path, 'userfile', $doc_type, $result, $this->uri->segment(1), 1);
                    // pp($uploads);
                    $this->CommonModel->batchInsert($uploads, 'documents');
                }
                $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                redirect('Register/viewDetails/' . $prev_id);
            }
        }
    }
    // view pramanpatra
    public function CertificatePreviewMigration($dartano)
    {
        $id = $this->uri->segment(3);
        // pp($dartano);
        if (empty($dartano)) {
            redirect('Register');
        } else {
            $data['row'] = $this->CommonModel->getWhere('darta_migration', array('id' => $dartano));
            // print_R($data['row']);
            $data['commits'] = $this->CommonModel->getData('commitment');

            $data['bstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['b_pradesh']));
            $data['bdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['b_district']));
            $data['bgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['b_gapa']));

            $data['pstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['p_pradesh']));
            $data['pdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['p_district']));
            $data['pgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['p_gapa']));


            $data['tstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['t_pradesh']));
            $data['tdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['t_district']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['main_topic'] = $this->CommonModel->getWhere('main_topic', array('id' => $data['row']['b_type']));
            $data['checker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['checker']));
            $data['staffs'] = $this->CommonModel->getData('staff');
            // pp($data['row']);
            $data['page'] = 'certificates/certificate_migration';
            // $this->load->view('certificates/certificate_migration', $data);
            $this->load->view('main', $data);
        }
    }
    public function addAppropedDetailsMigration()
    {
        // $id = $this->uri->segment(3);
        $data['id'] = $this->input->post('id');
        $data['row'] = $this->CommonModel->getWhere('darta_migration', array('id' => $data['id']));
        // pp($data['row']);
        $data['staffs'] = $this->CommonModel->getData('staff');
        if (!empty($data['row']['checker'])) {
            redirect('Register/CertificatePreviewMigration/' . $data['id']);
        } else {
            $this->load->view('certificates/approval_details', $data);
        }
    }

    //update details 
    public function update()
    {
        if ($this->input->post('Submit')) {
            $id = $this->input->post('id');
            $business_name_np = $this->input->post('business_name_np');
            $business_name_en = $this->input->post('business_name_en');
            $darta_suchikrit = $this->input->post('darta_suchikrit');
            $b_pradesh = $this->input->post('b_pradesh');
            $b_district = $this->input->post('b_district');
            $b_gapa = $this->input->post('b_gapa');
            $b_ward = $this->input->post('b_ward');
            $b_tol = $this->input->post('b_tol');
            $b_captial = $this->input->post('b_captial');
            $b_aim = $this->input->post('b_aim');
            $b_type = $this->input->post('b_type');
            $b_subtype = $this->input->post('b_subtype');
            $b_capital_source = $this->input->post('b_capital_source');
            $b_darta_office = $this->input->post('b_darta_office');
            $b_phone_number = $this->input->post('b_phone_number');
            $b_email = $this->input->post('b_email');
            $s_phone_number = $this->input->post('s_phone_number');
            $s_email = $this->input->post('s_email');
            $road_name = $this->input->post('road_name');
            $b_odarta_miti = $this->input->post('b_odarta_miti');
            $b_odarta_no = $this->input->post('b_odarta_no');
            $b_pan_no = $this->input->post('b_pan_no');
            $b_workdetails = $this->input->post('b_workdetails');
            $b_owner_name = $this->input->post('b_owner_name');
            $b_ctzn_no = $this->input->post('b_ctzn_no');
            $b_ctzn_district = $this->input->post('b_ctzn_district');
            $b_ctzn_date = $this->input->post('b_ctzn_date');
            $p_pardesh = $this->input->post('p_pardesh');
            $p_district = $this->input->post('p_district');
            $p_gapa = $this->input->post('p_gapa');
            $p_ward = $this->input->post('p_ward');
            $t_pardesh = $this->input->post('t_pardesh');
            $t_district = $this->input->post('t_district');
            $t_gapa = $this->input->post('t_gapa');
            $t_ward = $this->input->post('t_ward');
            $grandfather_name = $this->input->post('grandfather_name');
            $grandfather_address = $this->input->post('grandfather_address');
            $father_name = $this->input->post('father_name');
            $father_address = $this->input->post('father_address');
            $landlord = $this->input->post('landlord');
            $landlord_address = $this->input->post('landlord_address');
            $rent = $this->input->post('rent');
            $nibedan_dastur = $this->input->post('nibedan_dastur');
            $darta_dastur = $this->input->post('darta_dastur');
            $b_kar = $this->input->post('b_kar');
            $fine_amount = $this->input->post('fine_amount');
            $total_amount = $this->input->post('total_amount');
            $rasid_date = $this->input->post('rasid_date');
            $rasid_no = $this->input->post('rasid_no');
            $fixed_capital = $this->input->post('fixed_capital');
            $chalu_capital = $this->input->post('chalu_capital');
            $category = $this->input->post('category');
            $b_anual_production = $this->input->post('b_anual_production');
            $b_electricity = $this->input->post('b_electricity');
            $doc_type = $this->input->post('image_t_name');
            $doc_file = $this->input->post('userfile');
            $fields_array = $_FILES['userfile']['name'];
            $save_array = array(
                'business_name_np' => $business_name_np,
                'business_name_en' => $business_name_en,
                'b_pradesh' => $b_pradesh,
                'b_district' => $b_district,
                'b_gapa' => $b_gapa,
                'b_ward' => $b_ward,
                'b_tol' => $b_tol,
                'b_captial' => $b_captial,
                'fixed_capital' => $fixed_capital,
                'chalu_capital' => $chalu_capital,
                'b_aim' => $b_aim,
                'b_phone_number' => $b_phone_number,
                'b_email' => $b_email,
                's_phone_number' => $s_phone_number,
                's_email' => $s_email,
                'road_name' => $road_name,
                'b_type' => $b_type,
                'b_subtype' => $b_subtype,
                'category' => $category,
                'b_capital_source' => $b_capital_source,
                'b_darta_office' => $b_darta_office,
                'b_odarta_miti' => $b_odarta_miti,
                'b_odarta_no' => $b_odarta_no,
                'b_pan_no' => $b_pan_no,
                'b_workdetails' => $b_workdetails,
                'b_owner_name' => $b_owner_name,
                'b_ctzn_no' => $b_ctzn_no,
                'b_ctzn_district' => $b_ctzn_district,
                'b_ctzn_date' => $b_ctzn_date,
                'p_pradesh' => $p_pardesh,
                'p_district' => $p_district,
                'p_gapa' => $p_gapa,
                'p_ward' => $p_ward,
                't_pradesh' => $t_pardesh,
                't_district' => $t_district,
                't_gapa' => $t_gapa,
                't_ward' => $t_ward,
                'grandfather_name' => $grandfather_name,
                'grandfather_address' => $grandfather_address,
                'father_name' => $father_name,
                'father_address' => $father_address,
                'landlord' => $landlord,
                'landlord_address' => $landlord_address,
                'rent' => $rent,
                'b_anual_production' => $b_anual_production,
                'b_electricity' => $b_electricity,
                'nibedan_dastur' => $nibedan_dastur,
                'darta_dastur' => $darta_dastur,
                'b_kar' => $b_kar,
                'fine_amount' => $fine_amount,
                'total_amount' => $total_amount,
                'rasid_date' => $rasid_date,
                'rasid_no' => $rasid_no,
            );
            $result = $this->CommonModel->updateData('darta', $id, $save_array);
            if ($result) {
                if (!empty($fields_array)) {
                    $path = 'darta_images';
                    $uploads = upload_multiple($path, 'userfile', $doc_type, $result, $this->uri->segment(1), 1);
                    // pp($uploads);
                    $this->CommonModel->batchInsert($uploads, 'documents');
                }
                $this->session->set_flashdata('MSG_SUCCESS', 'Successfully inserted');
                redirect('Register/viewDetails/' . $id);
            }
        }
    }

    public function veiwTemplates($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataByID('darta', $id);
            $data['maker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $data['checker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['checker']));
            $data['bstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['b_pradesh']));
            $data['bdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['b_district']));
            $data['bgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['b_gapa']));
            $data['pstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['p_pradesh']));
            $data['pdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['p_district']));
            $data['pgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['p_gapa']));
            $data['tstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['t_pradesh']));
            $data['tdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['t_district']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['main_topic'] = $this->CommonModel->getWhere('main_topic', array('id' => $data['row']['b_type']));
            $data['subtopic'] = $this->CommonModel->getWhere('prakar', array('id' => $data['row']['b_subtype']));
            $data['renewdetails'] = $this->CommonModel->getWhereAll('renew', array('darta_id' => $id));
            $data['staffs'] = $this->CommonModel->getData('staff');
            // $data['page']           = 'list_templates';
            $data['page'] = "a_certificate";
            $this->load->view('main', $data);
        }
    }

    public function addAppropedDetails()
    {
        $data['id'] = $this->input->post('id');
        $data['row'] = $this->CommonModel->getWhere('darta', array('id' => $data['id']));
        $data['staffs'] = $this->CommonModel->getData('staff');
        if (!empty($data['row']['checker'])) {
            redirect('Register/CertificatePreview/' . $data['id']);
        } else {
            $this->load->view('certificates/approval_details', $data);
        }
    }

    //certificate preview
    public function CertificatePreview($dartano)
    {
        //$id = $this->uri->segment(3);
        if (empty($dartano)) {
            redirect('Register');
        } else {
            $data['row'] = $this->CommonModel->getWhere('darta', array('id' => $dartano));
            // print_R($data['row']);
            $data['commits'] = $this->CommonModel->getData('commitment');

            $data['bstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['b_pradesh']));
            $data['bdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['b_district']));
            $data['bgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['b_gapa']));

            $data['pstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['p_pradesh']));
            $data['pdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['p_district']));
            $data['pgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['p_gapa']));


            $data['tstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['t_pradesh']));
            $data['tdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['t_district']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['main_topic'] = $this->CommonModel->getWhere('main_topic', array('id' => $data['row']['b_type']));
            $data['maker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $data['checker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['checker']));
            $data['commits'] = $this->CommonModel->getWhereAll('commitment', array('type' => 1));
            // pp($data['row']);
            $this->load->view('certificates/certificate_preview', $data);
        }
    }

    //print certificate
    public function printcertificate($id, $view_id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataByID('darta', $id);
            if (empty($data['row']['checker'])) {
                $this->session->set_flashdata('MSG_ERR', 'प्रमिणित गर्नेको नाम छान्नुहोस');
                redirect('Register/veiwTemplates/' . $id);
            }
            $data['commits'] = $this->CommonModel->getWhereAll('commitment', array('type' => 1));
            $data['bstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['b_pradesh']));
            $data['bdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['b_district']));
            $data['bgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['b_gapa']));
            $data['pstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['p_pradesh']));
            $data['pdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['p_district']));
            $data['pgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['p_gapa']));
            $data['tstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['t_pradesh']));
            // $data['ppardesh']         = $this->CommonModel->getWhere('provinces', array('id'                       => $data['row']['p_pardesh']));
            // $data['pdistrict']         = $this->CommonModel->getWhere('provinces', array('id'                       => $data['row']['p_district']));
            // $data['pgapa']         = $this->CommonModel->getWhere('provinces', array('id'                       => $data['row']['p_gapa']));
            $data['tdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['t_district']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['main_topic'] = $this->CommonModel->getWhere('main_topic', array('id' => $data['row']['b_type']));
            $data['maker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $data['checker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['checker']));
            $data['yain'] = $this->CommonModel->getWhere('sarkar_yain', array('fiscal_year' => $data['row']['fiscal_year']));
            $this->load->view('certificates/certificate_benighat', $data);
        }
    }
    // migration print
    public function printcertificateMigration($id, $view_id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataByID('darta_migration', $id);
            // if (empty($data['row']['checker'])) {
            //     $this->session->set_flashdata('MSG_ERR', 'प्रमिणित गर्नेको नाम छान्नुहोस');
            //     redirect('Register/veiwTemplates/' . $id);
            // }
            $data['commits'] = $this->CommonModel->getWhereAll('commitment', array('type' => 1));
            $data['bstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['b_pradesh']));
            $data['bdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['b_district']));
            $data['bgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['b_gapa']));
            $data['pstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['p_pradesh']));
            $data['pdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['p_district']));
            $data['pgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['p_gapa']));
            $data['tstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['t_pradesh']));
            // $data['ppardesh']         = $this->CommonModel->getWhere('provinces', array('id'                       => $data['row']['p_pardesh']));
            // $data['pdistrict']         = $this->CommonModel->getWhere('provinces', array('id'                       => $data['row']['p_district']));
            // $data['pgapa']         = $this->CommonModel->getWhere('provinces', array('id'                       => $data['row']['p_gapa']));
            $data['tdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['t_district']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['main_topic'] = $this->CommonModel->getWhere('main_topic', array('id' => $data['row']['b_type']));
            $data['maker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $data['checker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['checker']));
            $data['yain'] = $this->CommonModel->getWhere('sarkar_yain', array('fiscal_year' => $data['row']['fiscal_year']));
            $this->load->view('certificates/certificate_benighat', $data);
        }
    }

    public function PrintSecondPart()
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataByID('darta', $id);
            $data['commits'] = $this->CommonModel->getData('commitment');
            $data['bstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['b_pradesh']));
            $data['bdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['b_district']));
            $data['bgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['b_gapa']));
            $data['pstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['p_pradesh']));
            $data['pdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['p_district']));
            $data['pgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['p_gapa']));
            $data['tstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['t_pradesh']));
            $data['tdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['t_district']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['main_topic'] = $this->CommonModel->getWhere('main_topic', array('id' => $data['row']['b_type']));
            $data['maker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $data['checker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['checker']));
            //pp($data['checker']);
            //$data['staffs']         = $this->CommonModel->getData('staff');
            $this->load->view('certificates/second_part');
        }
    }
    // print certificate second page 
    public function PrintSecondPartMigration()
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataByID('darta_migration', $id);
            $data['commits'] = $this->CommonModel->getData('commitment');
            $data['bstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['b_pradesh']));
            $data['bdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['b_district']));
            $data['bgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['b_gapa']));
            $data['pstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['p_pradesh']));
            $data['pdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['p_district']));
            $data['pgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['p_gapa']));
            $data['tstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['t_pradesh']));
            $data['tdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['t_district']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['main_topic'] = $this->CommonModel->getWhere('main_topic', array('id' => $data['row']['b_type']));
            $data['maker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $data['checker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['checker']));
            //pp($data['checker']);
            //$data['staffs']         = $this->CommonModel->getData('staff');
            $this->load->view('certificates/second_part');
        }
    }

    //print printPramanparta
    public function certificate($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataByID('darta', $id);
            // if (empty($data['row']['maker'])) {
            //     redirect('Register/printcertificate/' . $id);
            // }
            // if (empty($data['row']['checker'])) {
            //     redirect('Register/printcertificate/' . $id);
            // }
            $data['commits'] = $this->CommonModel->getData('commitment');
            $data['bstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['b_pradesh']));
            $data['bdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['b_district']));
            $data['bgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['b_gapa']));
            $data['pstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['p_pradesh']));
            $data['pdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['p_district']));
            $data['pgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['p_gapa']));
            $data['tstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['t_pradesh']));
            $data['tdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['t_district']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['main_topic'] = $this->CommonModel->getWhere('main_topic', array('id' => $data['row']['b_type']));
            $this->load->view('certificates/certificate', $data);
        }
    }
    public function certificate_1($id)
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getDataByID('darta', $id);
            // if (empty($data['row']['maker'])) {
            //     redirect('Register/printcertificate/' . $id);
            // }
            // if (empty($data['row']['checker'])) {
            //     redirect('Register/printcertificate/' . $id);
            // }
            $data['commits'] = $this->CommonModel->getData('commitment');
            $data['bstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['b_pradesh']));
            $data['bdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['b_district']));
            $data['bgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['b_gapa']));
            $data['pstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['p_pradesh']));
            $data['pdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['p_district']));
            $data['pgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['p_gapa']));
            $data['tstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['t_pradesh']));
            $data['tdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['t_district']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['main_topic'] = $this->CommonModel->getWhere('main_topic', array('id' => $data['row']['b_type']));
            $this->load->view('certificate_1', $data);
        }
    }
    //datatable list
    public function GetAllList()
    {
        if ($this->input->is_ajax_request()) {
            $columns = array(0 => 'id');
            $limit = $this->input->post('length');
            $start = $this->input->post('start');

            //main_topic, business_name, darta_no, darta_miti, darta_kisim
            $main_topic = $this->input->post('main_topic');
            $business_name = $this->input->post('business_name');
            $darta_no = $this->input->post('darta_no');
            $darta_miti = $this->input->post('darta_miti');
            $darta_kisim = $this->input->post('darta_kisim');
            $sn = $start + 1;
            $order = '';
            $dir = $this->input->post('order')[0]['dir'];
            $totalData = $this->RegisterModel->CountAll($main_topic, $business_name, $darta_no, $darta_miti, $darta_kisim);
            $totalFiltered = $totalData;
            $posts = $this->RegisterModel->GetAll($limit, $start, $order, $dir, $main_topic, $business_name, $darta_no, $darta_miti, $darta_kisim);
            $posts_1 = $this->RegisterModel->GetAllMigration($limit, $start, $order, $dir, $main_topic, $business_name, $darta_no, $darta_miti, $darta_kisim);
            $data = array();
            if (!empty($posts)) {
                $i = 1;
                foreach ($posts as $post) {
                    $nestedData['sn'] = $this->mylibrary->convertedcit($sn++);
                    $nestedData['id'] = $post->id;
                    $nestedData['date'] = $this->mylibrary->convertedcit($post->darta_miti);
                    $nestedData['name'] = $this->mylibrary->convertedcit($post->business_name_np);

                    if ($post->darta_suchikrit == 1) {
                        $nestedData['darta_kisim'] = '<span class="badge badge-pill badge-warning">' . "दर्ता";
                    } else {
                        $nestedData['darta_kisim'] = '<span class="badge badge-pill badge-warning">' . "सुचिकृत";
                    }

                    $nestedData['darta_no'] = '<span class="badge badge-pill badge-danger">' . $this->mylibrary->convertedcit($post->darta_no) . "</span>";
                    $nestedData['dno'] = $post->darta_no;
                    $nestedData['is_trash'] = $post->is_trash;
                    $nestedData['owner_name'] = $this->mylibrary->convertedcit($post->b_owner_name);
                    $data[] = $nestedData;
                }
            }
            // if (!empty($posts_1)) {
            //     foreach ($posts_1 as $p1) {
            //         $nestedData1['prev_darta_id'] = $this->$p1->prev_darta_id;
            //         $data[] = $nestedData1;
            //     }
            // }
            $json_data = array(
                "draw" => intval($this->input->post('draw')),
                "recordsTotal" => intval($totalData),
                "recordsFiltered" => intval($totalFiltered),
                "data" => $data
            );
            echo json_encode($json_data);
        } else {
            exit('HTTPS!!');
        }
    }

    public function updatePhoto()
    {
        $data['id'] = $this->input->post('id');
        $this->load->view('upload_photo', $data);
    }

    //update photo
    public function updateImage()
    {
        $id = $this->input->post('id');
        $userfile = $_FILES['userfile']['name'];
        $file = preg_replace('/\s+/', '_', $userfile);
        if (!empty($userfile)) {
            $config = array(
                'upload_path' => './assets/business_owner/',
                'allowed_types' => "jpg|png|PNG|jpeg|JPEG",
                'max_size' => 1024,
                'overwrite' => TRUE,
                'file_name' => preg_replace('/\s+/', '_', $file),
            );
            $this->load->library('upload');
            $this->upload->initialize($config);
            if (!$this->upload->do_upload('userfile')) {
                $response = array(
                    'status' => 'validation_error',
                    'message' => 'Cannot upload image'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $this->upload->do_upload();
            }
            $update_array = array('image' => $file);
            $result = $this->CommonModel->updateData('darta', $id, $update_array);
            if ($result) {
                $response = array(
                    'status' => 'success',
                    'message' => 'redirect',
                    'redirect_url' => base_url() . 'Register/viewDetails/' . $id,
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        }
    }

    //renew darta
    public function renew($id)
    {
        $data['page'] = 'renew_darta';
        $data['row'] = $this->CommonModel->getDataById('darta', $id);
        $this->load->view('main', $data);
    }

    //save nabikarn details
    public function nabikaran()
    {
        if ($this->input->post('Submit')) {
            $darta_id = $this->input->post('darta_id');
            $darta_no = $this->input->post('darta_no');
            $b_type = $this->input->post('b_type');
            $b_subtype = $this->input->post('b_subtype');
            $date = $this->input->post('date');
            $fiscal_year_from = $this->input->post('fiscal_year_from');
            $fiscal_year_to = $this->input->post('fiscal_year_to');
            $rasid_no = $this->input->post('rasid_no');
            $dastur = $this->input->post('dastur');
            $remarks = $this->input->post('remarks');
            $rasid_no = $this->input->post('rasid_no');
            $save_array = array(
                'darta_id' => $darta_id,
                'date' => $date,
                'darta_no' => $darta_no,
                'b_type' => $b_type,
                'b_subtype' => $b_subtype,
                'fiscal_year_from' => $fiscal_year_from,
                'fiscal_year_to' => $fiscal_year_to,
                'rasid_no' => $rasid_no,
                'dastur' => $dastur,
                'remarks' => $remarks,
                'fiscal_year' => current_fiscal_year(),
                'created_at' => convertDate(date('Y-m-d h:i:sa')),
                'created_by' => $this->session->userdata('PRJ_USER_BID'),
                'added_ward' => $this->session->userdata('PRJ_USER_WARD'),
            );
            $darta_details = $this->CommonModel->getWhere('darta', array('id' => $darta_id));
            if ($darta_details['fiscal_year'] == current_fiscal_year()) {
                $this->session->set_flashdata('MSG_WAR', 'नवीकरण गर्न मिल्दैन');
                redirect('Register/viewDetails/' . $darta_id);
            }
            $checkIfExits = $this->CommonModel->getWhere('renew', array('darta_id', 'fiscal_year' => current_fiscal_year()));
            if (!empty($checkIfExits)) {
                $this->session->set_flashdata('MSG_ERR', 'नवीकरण गरिसकेको छ');
                redirect('Register/viewDetails/' . $darta_id);
            }
            $result = $this->CommonModel->insertData('renew', $save_array);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'तपाई नवकिरण गर्न सफल हुनुभयो');
                redirect('Register/viewDetails/' . $darta_id);
            }
        }
    }

    //list nabikaran details
    public function listNabikarnDetails($darta_id)
    {
        $data['page'] = 'renew_darta_list';
        $data['renews'] = $this->CommonModel->getWhereAll('renew', array('darta_id' => $darta_id));
        $data['darta'] = $this->CommonModel->getWhere('darta', array('id' => $darta_id));
        $this->load->view('main', $data);
    }

    //edit renew
    public function editRenew($renewid)
    {
        $data['page'] = 'renew_darta_edit';
        $data['row'] = $this->CommonModel->getDataById('renew', $renewid);
        $this->load->view('main', $data);
    }

    //update reneew details
    public function updateRenew()
    {
        if ($this->input->post('Submit')) {
            $id = $this->input->post('id');
            $darta_id = $this->input->post('darta_id');
            $fiscal_year_from = $this->input->post('fiscal_year_from');
            $fiscal_year_to = $this->input->post('fiscal_year_to');
            $rasid_no = $this->input->post('rasid_no');
            $dastur = $this->input->post('dastur');
            $remarks = $this->input->post('remarks');
            $rasid_no = $this->input->post('rasid_no');
            $save_array = array(
                'fiscal_year_from' => $fiscal_year_from,
                'fiscal_year_to' => $fiscal_year_to,
                'rasid_no' => $rasid_no,
                'dastur' => $dastur,
                'remarks' => $remarks,
                'modified_at' => convertDate(date('Y-m-d h:i:sa')),
                'modified_by' => $this->session->userdata('PRJ_USER_BID'),
            );
            $result = $this->CommonModel->updateData('renew', $id, $save_array);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'success');
                redirect('Register/listNabikarnDetails/' . $darta_id);
            }
        }
    }

    //delete renew
    public function deleteRenewDetails($id)
    {
        $row = $this->CommonModel->getDataById('renew', $id);
        if (!empty($row)) {
            $result = $this->CommonModel->deleteData('renew', $id);
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', 'success');
                redirect('Register/listNabikarnDetails/' . $row['darta_id']);
            }
        }
    }

    //print renew certificate
    public function renewCertificate($darta_id)
    {
        $data['renewDetails'] = $this->CommonModel->getWhere('renew', array('darta_id' => $darta_id));
        if (empty($data['renewDetails'])) {
            $this->session->set_flashdata('MSG_ERR', 'नवीकरण गरिएको छैन. कृपया नवीकरण गर्नुहोस');
            redirect('Register/viewDetails/' . $darta_id);
        } else {
            $data['renewdetails'] = $this->CommonModel->getWhereAll('renew', array('darta_id' => $darta_id));
            $this->load->view('renew_certificate', $data);
        }
    }

    //update maker
    public function updateMaker()
    {
        $maker = $this->input->post('maker');
        $data = $this->CommonModel->getWhere('staff', array('id' => $maker));
        $response = array(
            'status' => 'success',
            'data' => $data,
            'message' => 'success'
        );
        header("Content-type: application/json");
        echo json_encode($response);
        exit;
    }

    //update checker
    public function updateChecker()
    {
        $checker = $this->input->post('checker');
        $data = $this->CommonModel->getWhere('staff', array('id' => $checker));
        $response = array(
            'status' => 'success',
            'data' => $data,
            'message' => 'success'
        );
        header("Content-type: application/json");
        echo json_encode($response);
        exit;
    }
    // public function updateCheckerMigration()
    // {
    //     $checker = $this->input->post('checker');
    //     dd($checker);
    //     $data = $this->CommonModel->getWhere('staff', array('id' => $checker));
    //     $response = array(
    //         'status' => 'success',
    //         'data' => $data,
    //         'message' => 'success'
    //     );
    //     header("Content-type: application/json");
    //     echo json_encode($response);
    //     exit;
    // }

    public function updateMakerChecker()
    {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $maker = $this->input->post('maker');
            $checker = $this->input->post('checker');
            $data = array('maker' => $maker, 'checker' => $checker);
            $result = $this->CommonModel->updateData('darta', $id, $data);
            if ($result) {
                $response = array(
                    'status' => 'success',
                    'data' => "सफलतापूर्वक सम्मिलित गरियो",
                    'message' => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed !!!');
        }
    }
    public function updateCheckerMakerMigration()
    {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id'); // Get the ID from POST data
            $checker = $this->input->post('checker'); // Get the checker value from POST data
            $data = $this->CommonModel->getWhere('staff', array('id' => $checker));
            if ($data) {
                $update_data = array('checker' => $checker);
                $result = $this->CommonModel->updateData('darta_migration', $id, $update_data);
                if ($result) {
                    $response = array(
                        'status' => 'success',
                        'data' => array('designation' => $data['designation']), // Assuming 'designation' is part of $data
                        'message' => 'Successfully updated checker'
                    );
                } else {
                    $response = array(
                        'status' => 'error',
                        'message' => 'Failed to update database'
                    );
                }
            } else {
                $response = array(
                    'status' => 'error',
                    'message' => 'Staff data not found'
                );
            }
        } else {
            $response = array(
                'status' => 'error',
                'message' => 'No direct script access allowed'
            );
        }
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }


    /** add patra details */
    public function addPatra()
    {
        $data['id'] = $this->input->post('id');
        $setting = $this->CommonModel->getWhereAll('business_letter_settings', array('darta_no' => $data['id']));
        if (!empty($setting)) {
            redirect('Register/PrintLetterPreview/' . $data['id']);
        } else {
            $this->load->view('add_patra', $data);
        }

    }
    /** add patra details */
    public function LetterSetting()
    {
        if ($this->input->post('Submit')) {
            $darta_no = $this->input->post('darta_no');
            $business_type = $this->input->post('business_type');
            $bdetails = $this->input->post('bdetails');
            $post_array = array();
            foreach ($bdetails as $key => $index) {
                $post_array[] = array(
                    'darta_no' => $darta_no,
                    'setting_type' => $business_type,
                    'bsetting' => $bdetails[$key],
                );
            }
            $result = $this->CommonModel->batchInsert($post_array, 'business_letter_settings');
            if ($result) {
                $this->session->set_flashdata('MSG_SUCCESS', MSG_SUCCESS);
                redirect('Register/PrintLetter/' . $darta_no);
            } else {
                $this->session->set_flashdata('MSG_ERR', MSG_INSERT_ERR);
                redirect('Register');
            }
        }
    }
    public function PrintLetterPreview($id)
    {
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getWhere('darta', array('darta_no' => $id));
            $data['commits'] = $this->CommonModel->getData('commitment');
            $data['bstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['b_pradesh']));
            $data['bdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['b_district']));
            $data['bgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['b_gapa']));
            $data['pstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['p_pradesh']));
            $data['pdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['p_district']));
            $data['pgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['p_gapa']));
            $data['tstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['t_pradesh']));
            $data['tdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['t_district']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['main_topic'] = $this->CommonModel->getWhere('main_topic', array('id' => $data['row']['b_type']));
            $data['maker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $data['checker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['checker']));
            $data['commits'] = $this->CommonModel->getWhereAll('commitment', array('type' => 2));
            $data['scommits'] = $this->CommonModel->getWhereAll('commitment', array('type' => 3));
            $data['lettersetting'] = $this->CommonModel->getWhereAll('business_letter_settings', array('darta_no' => $id));
            $data['pageTitle'] = '<a href ="' . base_url() . "Register/PrintLetter/" . $id . '">प्रिन्ट गर्नुहोस</a>"';
            //$data['staffs']         = $this->CommonModel->getData('staff');
            $this->load->view('certificates/preview_letter', $data);
        }
    }
    public function PrintLetter($id)
    {
        if (empty($id)) {
            show_404();
        } else {
            $data['row'] = $this->CommonModel->getWhere('darta', array('darta_no' => $id));
            $data['commits'] = $this->CommonModel->getData('commitment');
            $data['bstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['b_pradesh']));
            $data['bdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['b_district']));
            $data['bgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['b_gapa']));
            $data['pstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['p_pradesh']));
            $data['pdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['p_district']));
            $data['pgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['p_gapa']));
            $data['tstate'] = $this->CommonModel->getWhere('provinces', array('id' => $data['row']['t_pradesh']));
            $data['tdistrict'] = $this->CommonModel->getWhere('settings_district', array('id' => $data['row']['t_district']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['tgapa'] = $this->CommonModel->getWhere('settings_vdc_municipality', array('id' => $data['row']['t_gapa']));
            $data['main_topic'] = $this->CommonModel->getWhere('main_topic', array('id' => $data['row']['b_type']));
            $data['maker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['maker']));
            $data['checker'] = $this->CommonModel->getWhere('staff', array('id' => $data['row']['checker']));
            $data['commits'] = $this->CommonModel->getWhereAll('commitment', array('type' => 2));
            $data['scommits'] = $this->CommonModel->getWhereAll('commitment', array('type' => 3));
            $data['lettersetting'] = $this->CommonModel->getWhereAll('business_letter_settings', array('darta_no' => $id));
            //$data['staffs']         = $this->CommonModel->getData('staff');
            $this->load->view('certificates/letter', $data);
        }
    }

    //cancel register
    public function disableDarta($id)
    {
        $is_trash = array('is_trash' => 1);
        $result = $this->CommonModel->updateData('darta', $id, $is_trash);
        if ($result) {
            $this->session->set_flashdata('MSG_SUCCESS', 'Removed Successfully');
            redirect('Register');
        }

    }
}//end of class