<!--main content start-->
<style>
    img {
  transition: all 0.5s ease-in-out;
}

body {
  transition: opacity 0.5s ease-in-out;
}
</style>
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"><i class="fa fa-home"></i> ड्यासबोर्डमा जानुहोस</a></li>
        <li class="breadcrumb-item active">उद्योग र व्यवसाय दर्ता सुची</li>
      </ol>
    </nav>
    <!-- page start-->
    <!--<div class="row">-->
      <div class="col-sm-12">
        <section class="card">
          <header class="card-header">
            <span style="text-align:center">उद्योग र व्यवसाय दर्ता अभिलेख ( अपलोड गरिएको फाइलको सुची )</span>
          </header>
          <div class="card-body">
            <div class="adv-table">
              <table class="table table-bordered table-striped">
                <thead style="background: #1b5693; color:#fff">
                      <tr>
                        <th>#</th>
                        <th>फाइलको नाम</th>
                        <th>फाइल</th>
                      </tr>
                </thead>
                <?php $i=1; foreach($documents as $key => $doc): 
                // pp($doc);
                ?>
                <tbody>
                    <tr>
                        <td><?=$this->mylibrary->convertedcit($i)?></td>
                        <td><?=$doc['doc_type']?></td>
                        <td><img height="100" width="200" src="<?php echo base_url('assets/darta_images/').$doc['doc_name'];?>" alt="Image"><span><a href="<?php echo base_url('Register/view_image/').$doc['id'];?>"><button class="btn btn-success" style="margin-top:-75px;"><i class="fa fa-user"></i></button></a></span>
                        <a href="<?php echo base_url('Register/downloadImage/').$doc['id']; ?>"><button style="margin-top:-75px;margin-left:10px;" class="btn btn-success"><i class="fa fa-download"></i></button></a><span>
                            <a href="<?php echo base_url('Register/download_pdf/').$doc['id']; ?>"><button style="margin-top:-75px;margin-left:10px;" class="btn btn-warning">PDF</button></a>
                            </span></div></td>
                    </tr>
                </tbody>
                <?php $i++; endforeach;?>
              </table>
            </div>
          </div>
        </section>
      </div>
    </div>
    <!-- page end-->
  </section>
</section>
<!--<script src="<?php echo base_url('assets/datatable/datatables.min.js') ?>"></script>-->
<script type="text/javascript" src="<?php echo base_url() ?>assets/nepali_datepicker/nepali.datepicker.v2.2.min.js"></script>
<!--<script type="text/javascript">-->
<!--       function enlarge() {-->
<!--          var image = document.getElementById("image_show");-->
<!--          image.style.width = "500px";-->
<!--          image.style.height = "500px";-->
<!--          document.body.style.opacity = "2";-->
<!--        }-->
<!--</script>-->
