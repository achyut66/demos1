<!DOCTYPE html>
<html>

<head>
  <title>बेनिघाट रोराङ्ग गाउँपालिका </title>
  <style>
    body {
      background: rgb(204, 204, 204);
    }


    .page {
      background: white;
      display: block;
      margin: 0 auto;
      margin-bottom: 0.5cm;

      background-repeat: no-repeat;
      background-size: cover;

    }

    .container {
      margin-top: -20px;
    }

    .page {
      width: 21cm;
      height: 29.7cm;

    }

    .border {
      border: 2px solid black;
      background-color: black;

    }

    .text-left {
      font-size: 13px;
    }

    @media print {

      body,
      page {
        margin: 0;
        box-shadow: 0;
      }
    }
  </style>

</head>

<body>
  <div class="page">
    <div class="margin" style="margin-left:40px; margin-right: 40px;margin-top: 15px;">
      <img src="<?php echo base_url() ?>assets/img/nepal-govt.png"
        style="margin-top: 40px; height: 80px; width: 80px; ">
      <strong>
        <p style="margin-top:-100px;  font-size: 22px; text-align: center; color: rgb(239, 16, 16);">
          <?php echo GNAME ?>
        </p>
      </strong>
      <br>
      <strong>
        <p style="margin-top:-45px;  font-size: 30px; text-align: center; color: rgb(239, 16, 16);">
          <?php echo SLOGAN ?>
        </p>
      </strong>
      <img src="<?php echo base_url() ?>assets/img/plb.png"
        style="margin-top: -143px;margin-left: 606px;height: 80px;width: 80px;">
      <br>
      <p style="margin-top:-50px;  font-size: 20px; text-align: center; color: rgb(239, 16, 16);">
        <?php echo ADDRESS . ',' . DISTRICT ?>, धादिङ
      </p>
      <br>
      <p style="margin-top:-40px;  font-size:18px; text-align: center; color: rgb(239, 16, 16);">
        <?php echo STATENAME ?>, नेपाल
      </p>
      <br>
      <div class="container">
        <div class="darta" style="font-size:18px;">पत्र संख्या :-
          <?php echo $this->mylibrary->convertedcit($row['fiscal_year']) ?>
        </div>
        <div class="darta" style="font-size:18px;">चलानी नं. :-</div>
        <div class="border"></div>
        <div class="darta" style="margin-left: 540px; font-size:15px; margin-top: 10px; ">मितिः-
          <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?>
        </div>
        <div class="name" style="font-size: 15px; margin-top: -5px;">श्री
          <?php echo $this->mylibrary->convertedcit($row['b_owner_name']) ?>,
        </div>
        <div class="address" style="font-size: 15px;">
          <?php echo $this->mylibrary->convertedcit($pgapa['name']) . '-' . $this->mylibrary->convertedcit($row['t_ward']) ?>,
          <?php echo $this->mylibrary->convertedcit($pdistrict['name']) ?>
        </div>
        <strong>
          <p style="text-align:center; font-size: 13px; margin-top: 5px; ">बिषय:- <u>व्यवसाय</u> <u>दर्ता </u> <u>प्रमाण
            </u> <u>पत्र </u> <u>पठाइएको </u> <u>सम्बन्धमा </u>।</p>
        </strong>
        <div class="bbody" style=" font-size:15px;">
          <p style="text-align: justify;"> &nbsp&nbsp&nbsp&nbsp&nbsp&nbspउपरोक्त विषयमा तपाईलाई स्थिर पूँजि रु.
            <?php echo $this->mylibrary->convertedcit($row['fixed_capital']) ?>।- चालु पूँजि रु.
            <?php echo $this->mylibrary->convertedcit($row['chalu_capital']) ?>।- गरी कुल पूजि
            रु.
            <?php echo $this->mylibrary->convertedcit($row['b_captial']) ?>।- लगानी गरि
            <?php echo $this->mylibrary->convertedcit($row['b_workdetails']) ?> व्यवसाय गर्ने उद्देश्यले<b>
              <?php echo $this->mylibrary->convertedcit($row['business_name_np']) ?>
            </b>नामको उद्योग व्यावसाय
            <?php echo $this->mylibrary->convertedcit($bgapa['name']) ?>
            वडा नं.
            <?php echo $this->mylibrary->convertedcit($row['b_ward']) ?>
            <?php echo $this->mylibrary->convertedcit($bdistrict['name']) ?>मा स्थापना हुने गरि
            <?php echo $lettersetting[0]['setting_type'] ?> पाउँ भनि दिनु भएको निवेदनमा कारवाही हुँदा मिति
            <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?> गतेको निर्णयानुसार निम्न लिखित शर्तहरु
            अनिवार्य रुपमा पालना गर्ने गरि स्थानीय आर्थिक ऐन
            <?php
            $nfy = explode('/', $row['fiscal_year']);
            echo $this->mylibrary->convertedcit($nfy[0]); ?>
            को
            दफा ५ अनुसार साझेदारी
            <?php echo $lettersetting[0]['setting_type'] ?> गरी तपाईको नाउमा रजिष्ट्रेशन गरिएको व्य.द.नं. <b>
              <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?>/
              <?php echo $this->mylibrary->convertedcit($row['fiscal_year']) ?>
            </b>को
            सक्कल प्रमाण पत्र पठाइएको छ।
          </p>
        </div>
        <div class="text-left">
          <b>उद्योगले पालना गर्नु पर्ने शर्तहरुः-</b><br>
          <?php $i = 1;
          if (!empty($commits)):
            foreach ($commits as $uc): ?>
              <p>
                <?php echo $this->mylibrary->convertedcit($i++) ?>)
                <?php echo $uc['commits'] ?>
              </p>
            <?php endforeach; endif; ?>
          <p><b>) विषेश शर्त </b></p>
          <?php $i = 1;
          if (!empty($scommits)):
            foreach ($scommits as $ucs): ?>
              <p>
                <?php echo $ucs['commits'] ?>
              </p>
            <?php endforeach; endif; ?>
        </div>

      </div>
      <div class="darta" style="margin-left: 480px;margin-top: 22px; font-size:14px;">............................
        <br>&nbsp(
        <?php echo $checker['name'] ?>)<br>&nbsp&nbsp
        <?php echo $checker['designation'] ?>
      </div>
      <div style="margin-top:-15px;">
        बोधार्थः– &nbsp;&nbsp;<br>
        <?php $i = 1;
        if (!empty($lettersetting)):
          foreach ($lettersetting as $bdetails): ?>
            <?php echo $this->mylibrary->convertedcit($i++) ?>
            <?php echo $bdetails['bsetting'] ?><br>
          <?php endforeach; endif; ?>
      </div>
      <div style="border-top: 2px solid black; margin-top:10px;">
        फोन नं.977-010-403192 <b><span style="padding-left:15px;">Email:</b><i>info@galchhimun.gov.np</i>
        <b>Web: </b><i>www.galchhimun.gov.np</i>
      </div>
    </div>
    <script type="text/javascript">
      window.print();
    </script>
</body>

</html>