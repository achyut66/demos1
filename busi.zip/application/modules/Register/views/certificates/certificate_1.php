<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>
</head>

<body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle">
          <p style="color:black; margin-top:-10px;">स्थानीय स्तरका व्यापारिक फर्मको दर्ता, अनुमति, नविकरण खारेजी, अनुगमन
            र नियमन
            सम्बन्धी कार्यविधि, २०७४ को अनुसूची ४ सँग सम्बन्धित</h5>
          <h3 class=""><?php echo GNAME ?> </h3>
          <h4><?php echo SLOGAN ?></h4>
          <h6 style="margin-top:-10px;"><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6 style="margin-top:-5px;"><?php echo STATENAME ?>,नेपाल</h6>
        </div>
        <div class="header-right">
          <div class="photo">
            <span>Photo</span>
          </div>
        </div>
      </div>
      <div class="sub-header">
        <p style="margin-top:5px;">प्रमाण पत्र न. <b><?php echo $this->mylibrary->convertedcit($row['darta_no']) ?></b>
        </p>
        <h5 class="gajuri-letter-title" style="width:403px;">व्यापारिक फर्म दर्ताको प्रमाण-पत्र</h5>
        <p style="text-align: right">मितिः <b><span
              style="border-bottom: 2px dotted #000"><?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></span></b>
        </p>

      </div>
      <div>
        <?php
        $darta_date = explode('-', $row['darta_miti']);
        $year = $darta_date[0];
        $month = $darta_date[1];
        $day = $darta_date[2];
        ?>
        <p style="text-align: justify;line-height: 20px;">श्री
          <b><?php echo $this->mylibrary->convertedcit($row['business_name_np']) ?></b>
          नामक प्राईभेट फर्म सम्वत <b><?php echo $this->mylibrary->convertedcit($year) ?></b> साल
          <b><?php echo getNepaliMonthName($month) ?></b> महिना
          <b><?php echo $this->mylibrary->convertedcit($day) ?></b>. गते रोज
          <?php echo $this->mylibrary->convertedcit(getDayName($day)) ?> मा स्थानीय स्तरका व्यापारिक फर्म दर्ता अनुमती
          नविकरण खारेजी अनुगमन र नियमन सम्बन्धी
          कार्यविधि २०७५ र स्थानीय सरकार सञ्चालन ऐन २०७४ को दफा ११ को उपदफा २ को ञ (६) बमोजिम दर्ता गरी यो प्रमाण
          पत्र दिइएको छ ।
        </p>
      </div>
      <div class="contents-b">
        <p>फर्मको नामः </p>
        <p style="border-bottom: 2px dotted #000;width:86%;margin-left:10px">
          <b><?php echo $this->mylibrary->convertedcit($row['business_name_np']) ?></b>
        </p>
      </div>
      <div class="contents-b">
        <p>प्रोप्राइटरको नाम: </p>
        <p style="border-bottom: 2px dotted #000;width:82%;margin-left:10px">
          <b><?php echo $this->mylibrary->convertedcit($row['b_owner_name']) ?></b>
        </p>
      </div>
      <div class="contents-b-address">
        <p>ठेगाना: <span
            style="border-bottom: 2px dotted #000;margin-left:10px"><b><?php echo $this->mylibrary->convertedcit($pgapa['name']) . '-' . $this->mylibrary->convertedcit($row['p_ward']) ?></b></span>
        </p>
        <p style="margin-left: 32px;">ना.प्र.नं: <span
            style="border-bottom: 2px dotted #000;margin-left:10px"><b><?php echo $this->mylibrary->convertedcit($row['b_ctzn_no']) ?></b>
        </p>
        <p style="margin-left: 76px;">सम्पर्क नं: <span
            style="border-bottom: 2px dotted #000;margin-left:10px"><b><?php echo $this->mylibrary->convertedcit($row['phone_no']) ?></b>
        </p>
      </div>
      <div class="contents-b">
        <p>हालको ठेगाना: </p>
        <p style="border-bottom: 2px dotted #000;width:84%;margin-left:10px">
          <b><?php echo $this->mylibrary->convertedcit($tgapa['name']) . '-' . $this->mylibrary->convertedcit($row['t_ward']) ?></b>
        </p>
      </div>
      <div class="contents-b">
        <p>फर्मको ठेगाना: </p>
        <p style="border-bottom: 2px dotted #000;width:84%;margin-left:10px">
          <b><?php echo $this->mylibrary->convertedcit($bgapa['name']) . '-' . $this->mylibrary->convertedcit($row['b_ward']) ?></b>
        </p>
      </div>
      <div class="contents-b">
        <p>फर्मको उदेश्य: </p>
        <p style="border-bottom: 2px dotted #000;width:84%;margin-left:10px">
          <b><?php echo $this->mylibrary->convertedcit($row['b_aim']) ?></b>
        </p>
      </div>
      <div class="contents-b-address">
        <p>स्थिर पूँजी रु: <span
            style="border-bottom: 2px dotted #000;margin-left:10px"><b><?php echo $this->mylibrary->convertedcit($row['fixed_capital']) ?></b></span>
        </p>
        <p style="margin-left: 111px;">चालु पूँजी रु: <span
            style="border-bottom: 2px dotted #000;margin-left:10px;"><b><?php echo $this->mylibrary->convertedcit($row['chalu_capital']) ?></b>
        </p>
        <p style="margin-left: 94px;">कूल पूँजी रु: <span
            style="border-bottom: 2px dotted #000;margin-left:10px;"><b><?php echo $this->mylibrary->convertedcit($row['b_captial']) ?></b>
        </p>
      </div>
      <div class="contents-b">
        <p>अक्षरेपी: </p>
        <p style="border-bottom: 2px dotted #000;width:83%;margin-left:10px">
          <b><?php echo $this->convertlib->convert($row['b_captial']) . 'मात्र' ?></b>
        </p>
      </div>
      <div class="contents-b">
        <p>फर्मले कारोबार गर्ने मुख्य विषय: </p>
        <p style="border-bottom: 2px dotted #000;width:63%;margin-left:10px">
          <b><?php echo $this->mylibrary->convertedcit($row['b_workdetails']) ?></b>
        </p>
      </div>
      <div class="contents-b">
        <p>फर्ममा संलग्न जनशक्ति: </p>
        <p style="border-bottom: 2px dotted #000;width:63%;margin-left:10px">
          <b><?php echo $this->mylibrary->convertedcit($row['no_of_workers']) ?></b>
        </p>
      </div>
      <div class="contents-b-address">
        <p style="">वार्षिक उत्पादान क्षमता: </p>
        <p style="margin-left: 21px;">परिमाणमा: <span
            style="border-bottom: 2px dotted #000;margin-left:10px;"><b><?php echo $this->mylibrary->convertedcit($row['b_anual_production']) ?></b>
        </p>
        <p style="margin-left: 94px;">मुल्यमा: <span
            style="border-bottom: 2px dotted #000;margin-left:10px;"><b><?php echo $this->mylibrary->convertedcit(0) ?></b>
        </p>
      </div>
      <div class="contents-b">
        <p>विधुत शक्ति (किलोवाट): </p>
        <p style="border-bottom: 2px dotted #000;width:63%;margin-left:10px">
          <b><?php echo $this->mylibrary->convertedcit($row['b_electricity']) ?></b>
        </p>
      </div>
      <div class="contents-b">
        <div style="width:350px;height:120px;border:1px solid rgb(14, 55, 116);">
          <p style="margin-left: 10px;margin-top:0px;"> अन्य निकायामा दर्ता भएको भए </p>
          <p style="margin-top: -15px; margin-left: 10px;">नाम: <span
              style="border-bottom: 2px dotted #000;margin-left:10px;"><b><?php echo $this->mylibrary->convertedcit($row['b_darta_office']) ?></b></span>
          </p>
          <p style="margin-top: -15px;margin-left: 10px;">दर्ता नं: <span
              style="border-bottom: 2px dotted #000;margin-left:10px;"><b><?php echo $this->mylibrary->convertedcit($row['b_odarta_miti']) ?></b></span>
          </p>
          <p style="margin-top: -15px;margin-left: 10px;">दर्ता मिति: <span
              style="border-bottom: 2px dotted #000;margin-left:10px;"><b><?php echo $this->mylibrary->convertedcit($row['b_odarta_no']) ?></b></span>
          </p>
          <p style="margin-top: -20px;margin-left: 10px;">पान नं. <span
              style="border-bottom: 2px dotted #000;margin-left:10px;"><b><?php echo $this->mylibrary->convertedcit($row['b_pan_no']) ?></b></span>
          </p>
        </div>
        <div style="width:350px;height:120px;margin-left:160px;">
          <p style="margin-left: 10px;margin-top:0px;"> प्रमाण पत्र जारी गर्ने अधिकारी </p>
          <p style="margin-top: -15px; margin-left: 10px;">दस्तखत ............................</p>
          <p style="margin-top: -15px;margin-left: 10px;">नाम: <span
              style="border-bottom: 2px dotted #000;margin-left:10px;"><b><?php echo $checker['name'] ?></b></span></p>
          <p style="margin-top: -15px;margin-left: 10px;">पद: <span
              style="border-bottom: 2px dotted #000;margin-left:10px;"><b><?php echo $checker['designation'] ?></b></span>
          </p>
          <p style="margin-top: -20px;margin-left: 10px;">मिति: <span
              style="border-bottom: 2px dotted #000;margin-left:10px;"><b>
                <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></b></span></p>
        </div>
      </div> <!-- endof warpper-->
    </div><!-- endof main-warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
window.print();
</script>

</html>