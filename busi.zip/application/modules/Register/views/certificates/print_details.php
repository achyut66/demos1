<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <title><?php echo GNAME ?></title>
    <link href="<?php echo base_url() ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>assets/css/bootstrap-reset.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>assets/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/css/certificates/a4size.css">
</head>

<body class="document">
    <div style="margin-left:351px;" class="hideme">
        <a href="<?php echo base_url() ?>Register/certificate/<?php echo $row['id'] ?>" target="_blank" class="btn btn-info btn-sm" style="margin-top:10px;"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस </a>
        <a href="<?php echo base_url() ?>Register" class="btn btn-success btn-sm" style="margin-top:10px;">दर्ता सुचीमा जानुहोस </a>
    </div>
    <?php echo form_open('Staff/Save', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal save_post')); ?>
    <div class="page">

        <img src="<?php echo base_url() ?>assets/img/nepal-govt.png" style="height: 100px; width: 100px;">
        <?php if (!empty(PALIKALOGO)) : ?>
            <div style="width:100px;height:100px;margin-top:-100px;margin-left:566px">
                <img src="<?php echo base_url() ?>assets/img/<?php echo PALIKALOGO ?>" style="height: 100px; width: 100px;float:right">
            </div>
        <?php endif; ?>
        <div style="font-size: 16px;margin-left: 267px;margin-top: -106px;"><b><?php echo GNAME ?></b></div>
        <div style="margin-left: 239px;margin-top: 5px;font-size: 18px;"><b>
                <?php if ($this->session->userdata('PRJ_USER_BID') == 1) {
                    echo SLOGAN;
                } else {
                    if ($this->session->userdata('PRJ_USER_WARD') == 0) {
                        echo SLOGAN;
                    } else {
                        echo $this->mylibrary->convertedcit($this->session->userdata('PRJ_USER_WARD')) . ' नं. वडा कार्यलय';
                    }
                } ?></b>
        </div>
        <div style="margin-left: 291px;margin-top:5px;font-size: 14px;"><b><?php echo ADDRESS . ',' . DISTRICT ?></b></div>
        <div style="margin-left: 282px;margin-top:5px;font-size: 14px;"><b><?php echo STATENAME ?>,नेपाल </b></div>
        <div style="margin-left: 230px;margin-top: 50px;font-size: 22px;font-style:underline">
            <p style="text-decoration:underline"><b>व्यवसाय दर्ता प्रमाण पत्र </b></p>
        </div>
        <div class="stamp"><img src="<?php echo base_url() ?>assets/business_owner/<?php echo !empty($row['image']) ? $row['image'] : 'emt.jpg' ?>" alt="" style="height:117px;width:141px"></div>
        <div style="margin-top:24px;"><span style="font-size:20px;">व्यवसाय दर्ता नं: </span>. <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?></div>
        <div style="margin-top:30px;"><span style="font-size:20px;">व्यवसाय दर्ता मिति: </span><?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></div>
        <div style="margin-top:-18px;margin-left:337px"><span style="font-size:20px;">आ. व.</span> <?php echo $this->mylibrary->convertedcit($row['fiscal_year']) ?></div>
        <div style="margin-top:30px;"><span style="font-size:20px;">उद्योग, व्यवसायको नाम:</span> <?php echo $this->mylibrary->convertedcit($row['business_name_np']) ?></div>
        <div style="margin-top:30px;"><span style="font-size:20px;">व्यवसाय रहने स्थान:</span> <?php echo $this->mylibrary->convertedcit($bgapa['name'] . '-' . $row['b_ward']) ?></div>
        <div style="margin-top:-28px;margin-left:337px"><span style="font-size:20px;">व्यवसायको किसिम:</span> <?php echo $this->mylibrary->convertedcit($main_topic['topic_name']) ?></div>
        <div style="margin-top:20px;"><span style="font-size:20px;">व्यवसायीको नाम: </span><?php echo $this->mylibrary->convertedcit($row['b_owner_name']) ?></div>
        <div style="margin-top:-28px; margin-left:258px"><span style="font-size:20px;">व्यवसायीको ठेगाना:</span> <?php echo $this->mylibrary->convertedcit($pgapa['name'] . '-' . $row['p_ward'] . ',' . $pdistrict['name']) ?></div>
        <div style="margin-top:20px;"><span style="font-size:20px;">ना.प्र.प.नं.: <?php echo $this->mylibrary->convertedcit($row['b_ctzn_no']) ?></div>
        <div style="margin-top:-30px;margin-left:232px"><span style="font-size:20px;">जारी मिति:</span> <?php echo $this->mylibrary->convertedcit($row['b_ctzn_date']) ?></div>
        <div style="margin-top:-28px; margin-left:485px"><span style="font-size:20px;">जारी जिल्ला:</span> <?php echo $this->mylibrary->convertedcit($row['b_ctzn_district']) ?></div>
        <div style="margin-top:15px;"><span style="font-size:20px;">व्यवसाय रहने घरधनीको नाम : </span><?php echo $this->mylibrary->convertedcit($row['landlord']) ?></div>
        <div style="margin-top:15px; "><span style="font-size:20px;">स्थिर पूजीँ : </span><?php echo $this->mylibrary->convertedcit($row['fixed_capital']) ?></div>
        <div style="margin-top:-30px;margin-left:232px"> <span style="font-size:20px;">चालु पूजीँ: </span><?php echo $this->mylibrary->convertedcit($row['chalu_capital']) ?></div>
        <div style="margin-top:-30px; margin-left:485px"><span style="font-size:20px;"> कुल पूजीँ:</span> <?php echo $this->mylibrary->convertedcit($row['b_captial']) ?></div>

        <div style="margin-top:70px;border-top: dotted 2px #000; width:118px; "> व्यवसायीको दस्तख</div>
        <div style="margin-top:-19px;border-top: dotted 2px #000; width:182px;margin-left:236px; ">
            <select class="" id="maker">
                <option value=""> तयार गर्नेको नाम छान्नुहोस्</option>
                <?php if (!empty($staffs)) : foreach ($staffs as $staff) : ?>
                        <option value="<?php echo $staff['name'] ?>" <?php if ($row['maker'] == $staff['name']) {
                                                                            echo 'selected';
                                                                        } ?>><?php echo $staff['name'] ?></option>
                <?php endforeach;
                endif; ?>
            </select>
        </div>
        <div style="margin-top:-19px;border-top: dotted 2px #000; width:182px;margin-left:476px; ">
            <select id="checker">
                <option value=""> प्रमाणित गर्नेको नाम छान्नुहोस्</option>
                <?php if (!empty($staffs)) : foreach ($staffs as $staff) : ?>
                        <option value="<?php echo $staff['name'] ?>" <?php if ($row['checker'] == $staff['name']) {
                                                                            echo 'selected';
                                                                        } ?>><?php echo $staff['name'] ?></option>
                <?php endforeach;
                endif; ?>
            </select>
        </div>
        <div style="margin-top:39px;"><b>शर्तहरु</b></div>
        <div>
            <?php $i = 1;
            if (!empty($commits)) : foreach ($commits as $shart) : ?>
                    <div>
                        <p style="font-size:14px;font-style:italic"><?php echo $this->mylibrary->convertedcit($i++) ?>. <?php echo $shart['commits'] ?></p>
                    </div>
            <?php endforeach;
            endif; ?>
        </div>
    </div>

    <?php if (!empty($renewdetails)) : ?>
        <div class="page">
            <table class="table">
                <thead>
                    <tr>
                        <th>नवीकरण मिति </th>
                        <th>नवीकरण अवधि</th>
                        <th>रसिद नं.</th>
                        <th>दस्तुर</th>
                        <th>दस्तख</th>
                        <th>कैफियत</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($renewdetails)) : foreach ($renewdetails as $renew) : ?>
                            <tr>
                                <td><?php echo $this->mylibrary->convertedcit($renew['date']) ?></td>
                                <td><?php echo $this->mylibrary->convertedcit($renew['fiscal_year_from']) . '-' . $this->mylibrary->convertedcit($renew['fiscal_year_to']) ?></td>
                                <td><?php echo $this->mylibrary->convertedcit($renew['rasid_no']) ?></td>
                                <td><?php echo $this->mylibrary->convertedcit($renew['dastur']) ?></td>
                                <td></td>
                                <td><?php echo $this->mylibrary->convertedcit($renew['remarks']) ?></td>
                            </tr>
                    <?php endforeach;
                    endif; ?>

                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            var base_url = "<?php echo base_url() ?>";
            $('#maker').change(function() {
                obj = $(this);
                var maker = obj.val();
                var id = "<?php echo $this->uri->segment(3) ?>";
                $.ajax({
                    url: base_url + 'Register/updateMaker',
                    method: "POST",
                    data: {
                        maker: maker,
                        id: id,
                        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                    },
                    success: function(resp) {
                        if (resp.status == 'success') {
                            location.reload();
                        }
                    }
                });
            });
            $('#checker').change(function() {
                obj = $(this);
                var checker = obj.val();
                var id = "<?php echo $this->uri->segment(3) ?>";
                $.ajax({
                    url: base_url + 'Register/updateChecker',
                    method: "POST",
                    data: {
                        checker: checker,
                        id: id,
                        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                    },
                    success: function(resp) {
                        if (resp.status == 'success') {
                            location.reload();
                        }
                    }
                });
            });
        });
    </script>
</body>

</html>