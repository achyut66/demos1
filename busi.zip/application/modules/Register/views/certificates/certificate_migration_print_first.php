<!DOCTYPE html>
<html>

<head>
    <title>गल्छी गाउँपालिका</title>
    <style>
        body {
            background: rgb(204, 204, 204);
        }

        .page {
            background: white;
            display: block;
            margin: 0 auto;
            /*margin-bottom: 0.5cm;*/
            background-image: url("../../../assets/img/page0001.jpg");
            background-repeat: no-repeat;
            background-size: cover;
        }

        .page {
            width: 21cm;
            height: 29.7cm;
        }

        @media print {
            * {
                -webkit-print-color-adjust: exact;
            }

            body,
            page {
                margin: 0;
                box-shadow: 0;
            }
        }

        .rectangle {
            border: 2px solid black;
            margin-left: -356px;
            margin-top: 30px;
            width: 610px;
            /* Width of the rectangle */
            height: 129px;
            /* Height of the rectangle */
            background-color: white;
            /* Background color of the rectangle */
        }
    </style>

</head>

<body>
    <div class="page">
        <img src="<?php echo base_url() ?>/assets/img/nepal-govt.png"
            style="margin-top: 100px; height: 150px; width: 150px; margin-left: 80px;">
        <strong>
            <p style="margin-top:-170px;  font-size: 28px; text-align: center; color: rgb(239, 16, 16);">
                <?php echo GNAME ?>
            </p>
        </strong>
        <br>
        <p style="margin-top:-45px;  font-size: 20px; text-align: center; color: rgb(239, 16, 16);">
            <?php echo SLOGAN ?>
        </p>
        <br>
        <p style="margin-top:-40px;  font-size: 20px; text-align: center; color: rgb(239, 16, 16);">
            <?php echo ADDRESS . ',' . DISTRICT ?>
        </p>
        <br>
        <p style="margin-top:-40px;  font-size:18px; text-align: center; color: rgb(239, 16, 16);">
            <?php echo STATENAME ?>, नेपाल
        </p>
        <img src="<?php echo base_url() ?>/assets/img/p.png"
            style="margin-top: -220px; height: 130px; width: 130px; margin-left: 580px;">
        <br>
        <div class="text-center" style="margin-top:40px;">
            <img src="<?php echo base_url() ?>assets/img/pramad.png"
                style="margin-top: -20px;  height: 49px; width: 215px; margin-left:270px;">
        </div>
        <div class="" style="margin-top:43px;">
            <div class="darta" style="margin-left: 80px; font-size:18px; margin-top:10px;">व्यवसाय दर्ता नं.
                <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?>/
                <?php echo $this->mylibrary->convertedcit($row['fiscal_year']) ?>
            </div>
            <div class="darta" style="margin-left: 550px;margin-top: -22px; font-size:18px; ">दर्ता मितिः
                <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?>
            </div>
            <div class="bbody" style="margin-left: 80px; font-size:16px;">
                <p style="text-align:justify; margin-right: 80px;"> तपसिलमा उल्लेखित व्यवसाय स्थानीय सरकार संचालन ऐन,
                    २०७४ को
                    दफा ११(२)(ञ)(६), प्रादेशिक ब्यापार तथा व्यवसाय सम्बन्धि
                    ऐन, २०७६ दफा ३ तथा गल्छी गाउँपालिका व्यवसाय दर्ता तथा नवीकरण कार्यविधि, २०७६ को दफा ३ प्रयोजनको लागि
                    व्यवसाय दर्ता गरि यो प्रमाणपत्र प्रदान गरिएको छ l</p>
            </div>
        </div>
        <br>
        <div class="bbbody" style="margin-left: 120px;margin-top:-20px; font-size:15px;">
            <b>१. व्यक्ति/फर्म/कम्पनीको नामः- <span style="margin-left:25px;">
                    <?php echo $this->mylibrary->convertedcit($row['business_name_np']) ?><span></b><br><br>
            <b>२. ठेगानाः <span style="margin-left:152px;">
                    <?php echo $bgapa['name'] ?>-
                    <?php echo $this->mylibrary->convertedcit($row['b_ward']) ?>,
                    <?php echo $bdistrict['name'] ?>,
                    <?php echo $bstate['Title'] ?>
                </span></b><br><br>
            <b>३. कारोवारको किसिमः <span style="margin-left:74px;">
                    <?php echo $row['b_workdetails'] ?>
                </span></b><br><br>
            <b>४. मालिक/साझेदार/संचालक मुख्य व्यक्तिको नामः- <span style="margin-left:25px;">
                    <?php echo $this->mylibrary->convertedcit($row['b_owner_name']) ?>
                </span></b><br><br>
            <b>५. ठेगानाःः <span style="margin-left:148px;">
                    <?php echo $pgapa['name'] ?>-
                    <?php echo $this->mylibrary->convertedcit($row['p_ward']) ?>,
                    <?php echo $pdistrict['name'] ?>,
                    <?php echo $pstate['Title'] ?>
                </span></b></b><br><br>
            <b>६. कारोवारको मुख्य स्थानः- <span style="margin-left:45px;">
                    <?php echo $bgapa['name'] . ', ' . $this->mylibrary->convertedcit($row['b_ward']) . ', ' . $bdistrict['name'] ?>
                </span></b><br><br>
            <b>७. कूल पूँजिः- <span style="margin-left:131px;">
                    <?php echo $this->mylibrary->convertedcit($row['b_captial']) ?>/- <span>चालु पूँजिः-
                        <?php echo $this->mylibrary->convertedcit($row['chalu_capital']) ?>/-
                    </span><span>स्थिर पूँजिः-
                        <?php echo $this->mylibrary->convertedcit($row['fixed_capital']) ?>/-
                    </span></b><br><br>
            <b>८. बिद्युत शक्ति (किलोवाट):-
                <?php echo $this->mylibrary->convertedcit($row['b_electricity']) ?>
            </b><br><br>
        </div>
        <div class="" style="margin-top:50px;">
            <div class="darta" style="margin-left: 80px; font-size:14px;">
                &nbsp&nbsp&nbsp...................................<br>
                (प्रमाण–पत्र पाउनेको सही) </div>
            <div class="darta" style="margin-left: 475px;margin-top: -35px; font-size:14px; "> &nbsp&nbsp&nbsp&nbsp&nbsp
                <?php echo !empty($row['checker']) ? $checker['name'] : '' ?><br>(प्रमाण–पत्र जारी गर्नेको सही)
            </div>

            <div class="text" style="margin-left:446px;">
                <?php if (!empty($commits)):
                    foreach ($commits as $commit): ?>
                        <p>
                            <?php echo $commit['commits'] ?>।
                        </p>
                    <?php endforeach; endif; ?>
                <div class="rectangle" style="margin-top:13px;">
                    <div class="text-left" style="font-weight:bold;"><u>द्रष्टब्य</u></div><br>
                    <div class="text-left" style="font-weight:bold;font-size:14px;">क) यो प्रमाणपत्र पसल वा कार्यालयमा
                        देखिने गरि
                        राख्नुपर्नेछ l
                    </div>
                    <div class="text-left" style="font-weight:bold;font-size:14px;">ख) यो प्रमाणपत्र प्रत्येक बर्षको
                        श्रावन देखि
                        कार्तिक मसान्त
                        सम्ममा नवीकरण गरिसक्नु पर्नेछ l</div>
                    <div class="text-left" style="font-weight:bold;font-size:14px;">ग) अन्य निकायको अनुमति लिनु पर्ने
                        भएमा अनुमति
                        लिएर कारोबार
                        गर्नुपर्ने छ l</div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
    <script type="text/javascript">
        window.print();
    </script>
</body>

</html>