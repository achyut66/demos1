<!--main content start-->
<section id="main-content">
    <section class="wrapper site-min-height">
        <!-- <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"><i class="fa fa-home"></i> ड्यासबोर्डमा
                        जानुहोस</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo base_url() ?>Register" class="bactive">उद्योग र
                        व्यवसाय दर्ता अभिलेखमा जानुहोस </a></li>
                <li class="breadcrumb-item active"><a href="javascript:;" class="bactive">नवीकरण विवरण</a></li>
            </ol>
        </nav> -->
        <!-- page start-->
        <div class="" style="font-weight:bold;font-size:18px;text-align:center;">पहिलो पृष्ट</div>
        <div style="margin-left:1160px;margin-top:-22px;">
            <a href="<?= base_url() ?>Register/printcertificateMigration/<?php echo $row['id'] ?>/3"
                class="btn btn-warning"><i class="fa fa-print">
                    PRINT</i></a>
        </div>
        <hr style="border:2px solid;margin-top:15px;width:1202px;">
        <div class="row">
            <div class="col-sm-12">
                <div class="page">


                    <img src="<?php echo base_url() ?>/assets/img/nepal-govt.png"
                        style="margin-top: 80px; height: 150px; width: 150px; margin-left: 70px;">
                    <strong>
                        <p style="margin-top:-130px;  font-size: 28px; text-align: center; color: rgb(239, 16, 16);">
                            <?php echo GNAME ?>
                        </p>
                    </strong>
                    <br>
                    <p style="margin-top:-25px;  font-size: 20px; text-align: center; color: rgb(239, 16, 16);">
                        <?php echo SLOGAN ?>
                    </p>
                    <br>
                    <p style="margin-top:-40px;  font-size: 20px; text-align: center; color: rgb(239, 16, 16);">
                        <?php echo ADDRESS . ',' . DISTRICT ?>
                    </p>
                    <br>
                    <p style="margin-top:-40px;  font-size:18px; text-align: center; color: rgb(239, 16, 16);">
                        <?php echo STATENAME ?>, नेपाल
                    </p>
                    <img src="<?php echo base_url() ?>/assets/img/p.png" alt="hhh"
                        style="margin-top: -140px;height: 130px;width: 130px;margin-left: 1062px;">
                    <br>
                    <div class="text-center" style="margin-top:40px;">
                        <img src="<?php echo base_url() ?>assets/img/pramad.png"
                            style="margin-top: -20px;  height: 80px; width: 300px; margin-left:27px;">
                    </div>
                    <div class="darta" style="margin-left: 80px; font-size:18px; margin-top:20px;">व्यवसाय दर्ता नं.
                        <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?>/
                        <?php echo $this->mylibrary->convertedcit($row['fiscal_year']) ?>
                    </div>
                    <div class="darta" style="margin-left: 1033px;margin-top: -11px;font-size:18px;">दर्ता मितिः
                        <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?>
                    </div>
                    <div class="bbody" style="margin-left: 80px; font-size:18px; margin-top:20px;">

                        <p style="text-align:justify; margin-right: 80px;">
                            तपसिलमा उल्लेखित व्यवसाय स्थानीय सरकार संचालन ऐन, २०७४ को दफा ११(२)(ञ)(६), प्रादेशिक ब्यापार
                            तथा व्यवसाय
                            सम्बन्धि
                            ऐन, २०७६ दफा ३ तथा <strong><?php echo GNAME ?></strong> व्यवसाय दर्ता तथा नवीकरण कार्यविधि,
                            २०७६ को दफा ३
                            प्रयोजनको लागि
                            व्यवसाय दर्ता गरि यो प्रमाणपत्र प्रदान गरिएको छ l</p>
                    </div><br>
                    <div class="bbbody" style="margin-left: 100px; font-size:15px;">
                        <b>१. व्यक्ति/फर्म/कम्पनीको नामः-
                            <?php echo $this->mylibrary->convertedcit($row['business_name_np']) ?>
                        </b><br><br>
                        <b>२. ठेगानाः
                            <?php echo $bgapa['name'] ?>-
                            <?php echo $this->mylibrary->convertedcit($row['b_ward']) ?>,
                            <?php echo $bdistrict['name'] ?>,
                            <?php echo $bstate['Title'] ?>
                        </b><br><br>
                        <b>३. कारोवारको किसिमः
                            <?php echo $row['b_workdetails'] ?>
                        </b><br><br>
                        <b>४. मालिक/साझेदार/संचालक मुख्य व्यक्तिको नामः-
                            <?php echo $this->mylibrary->convertedcit($row['b_owner_name']) ?>
                        </b><br><br>
                        <b>५. ठेगानाःः
                            <?php echo $pgapa['name'] ?>-
                            <?php echo $this->mylibrary->convertedcit($row['p_ward']) ?>,
                            <?php echo $pdistrict['name'] ?>,
                            <?php echo $pstate['Title'] ?>
                        </b></b><br><br>
                        <b>६. कारोवारको मुख्य स्थानः-
                            <?php echo $bgapa['name'] ?>
                        </b><br><br>
                        <b>७. कूल पूँजिः-
                            <?php echo $this->mylibrary->convertedcit($row['b_captial']) ?>/- <span>चालु पूँजिः-
                                <?php echo $this->mylibrary->convertedcit($row['chalu_capital']) ?>/-
                            </span><span>स्थिर पूँजिः-
                                <?php echo $this->mylibrary->convertedcit($row['fixed_capital']) ?>/-
                            </span>
                        </b><br><br>
                        <b>८. बिद्युत शक्ति (किलोवाट):-
                            <?php echo $this->mylibrary->convertedcit($row['b_electricity']) ?>
                        </b><br><br>

                    </div><br>
                    <div class="darta" style="margin-left: 80px; font-size:18px;">
                        &nbsp&nbsp&nbsp...................................<br>
                        (प्रमाण–पत्र पाउनेको सही) </div>
                    <form action="<?php echo base_url() ?>Register/updateMakerCheckerMigration" method="post"
                        class="form save_post">
                        <div class="darta" style="margin-left: 970px;margin-top: -35px;font-size:18px;">
                            (प्रमाण–पत्र जारी गर्नेको सही)<br>
                            <select class="form-control" name="checker" id="checker">
                                <option value="">--छान्नुहोस्--</option>
                                <?php if (!empty($staffs)):
                                    foreach ($staffs as $staff): ?>
                                        <option value="<?php echo $staff['id'] ?>" <?php if ($staff['id'] == $row['checker']) {
                                               echo 'selected';
                                           } ?>><?php echo $staff['name'] ?></option>
                                    <?php endforeach;
                                endif; ?>
                            </select>
                            <div class="form-group">
                                <input type="text" class="form-control" id="deg_checker"
                                    value="<?php echo !empty($row['checker']) ? $checker['designation'] : '' ?>"
                                    readonly />
                            </div>
                            <!-- Add ID field if necessary -->
                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>" />
                            <div class="form-group">
                                <button class="btn btn-primary btn-xs btn-save save_btn" data-toggle="tooltip"
                                    title=" सेभ  गर्नुहोस्" name="Submit" type="submit" value="Submit"
                                    id="btn_save_details" style="margin-top:23px;"> सेभ
                                    गर्नुहोस्</button>
                            </div>
                        </div>
                    </form>

                    <div class="text-left" style="margin-left:80px;">
                        <!--<b><u>द्रष्टब्य </u></b><br>-->
                        <?php if (!empty($commits)):
                            foreach ($commits as $commit): ?>
                                <p>
                                    <?php echo $commit['commits'] ?>।
                                </p>
                            <?php endforeach; endif; ?>

                    </div>
                </div>
            </div>
        </div>
        <!-- <hr style="border:2px solid;margin-top:78px;"> -->
        <div class="" style="font-weight:bold;font-size:18px;text-align:center;margin-top:100px;">दोश्रो पृष्ट</div>
        <div style="margin-left:1160px;margin-top:-22px;">
            <a href="<?= base_url() ?>Register/PrintSecondPartMigration/<?php echo $row['id'] ?>/3"
                class="btn btn-warning"><i class="fa fa-print">
                    PRINT</i></a>
        </div>
        <hr style="border:2px solid;margin-top:15px;width:1202px;">
        <table class="table table-responsive" style="margin-left:65px;">
            <thead>
                <tr>
                    <th rowspan="2">क्र स्.</th>
                    <th rowspan="2">नबिकरण गरेको मिति</th>
                    <th rowspan="2">इजाजत-पत्र बहाल रहने अविधि</th>
                    <th colspan="7" class="text-center">व्यवसाय कर रकम सम्बम्धि विवरण</th>
                </tr>
                <tr>
                    <th>व्यवसाय कर वापत लाग्ने रकम</th>
                    <th>छुट रकम</th>
                    <th>बक्यौता रकम</th>
                    <th>जरिवाना</th>
                    <th>प्रमाण पत्र दस्तुर</th>
                    <th>जम्मा असुली भएको रकम</th>
                    <th>दस्तखत</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>१</td>
                    <td></td>
                    <td>.... असार मसान्तसम्म</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>२</td>
                    <td></td>
                    <td>.... असार मसान्तसम्म</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>३</td>
                    <td></td>
                    <td>.... असार मसान्तसम्म</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>४</td>
                    <td></td>
                    <td>.... असार मसान्तसम्म</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>५</td>
                    <td></td>
                    <td>.... असार मसान्तसम्म</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>६</td>
                    <td></td>
                    <td>.... असार मसान्तसम्म</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>७</td>
                    <td></td>
                    <td>.... असार मसान्तसम्म</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>८</td>
                    <td></td>
                    <td>.... असार मसान्तसम्म</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>९</td>
                    <td></td>
                    <td>.... असार मसान्तसम्म</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>१०</td>
                    <td></td>
                    <td>.... असार मसान्तसम्म</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>११</td>
                    <td></td>
                    <td>.... असार मसान्तसम्म</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>१२</td>
                    <td></td>
                    <td>.... असार मसान्तसम्म</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            </tbody>
        </table>
        <!-- page end-->
    </section>
</section>
<script type="text/javascript">
    $(document).ready(function () {
        var base_url = "<?php echo base_url() ?>";

        $('#checker').change(function () {
            var obj = $(this);
            var checker = obj.val();
            var id = "<?php echo $this->uri->segment(3) ?>";

            $.ajax({
                url: base_url + 'Register/updateCheckerMakerMigration',
                method: "POST",
                data: {
                    id: id,
                    checker: checker,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                },
                success: function (resp) {
                    if (resp.status == 'success') {
                        $('#deg_checker').val(resp.data.designation);
                    } else {
                        console.error('Error:', resp.message); // Log error to console for debugging
                        // Optionally handle error in UI or notify user in a non-intrusive way
                    }
                },
                error: function (xhr, status, error) {
                    console.error('XHR Error:', status, error); // Log XHR error to console for debugging
                    // Optionally handle error in UI or notify user in a non-intrusive way
                }
            });
        });

        // Optionally prevent default form submission
        $('form.save_post').submit(function (e) {
            e.preventDefault(); // Prevent default form submission
            // You can add further handling if needed
        });
    });
</script>