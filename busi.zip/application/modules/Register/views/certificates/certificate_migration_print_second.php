<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
    <script src="<?php echo base_url() ?>/assets/js/jquery.js"></script>
    <title><?php echo GNAME ?></title>
</head>
<style>
    /* Set the print scale to 50% for the table */
    table {
        transform: scale(0.995);
        transform-origin: top left;
    }
</style>

<body>
    <div class="">
        <div class="">
            <table class="table table-bordered" width="100%">
                <thead>
                    <tr>
                        <th rowspan='2' width="2%">क्र स्.</th>
                        <th rowspan='2' width="10%">नबिकरण गरेको मिति</th>
                        <th rowspan='4' width="15%">इजाजत-पत्र बहाल रहने अविधि</th>
                        <th colspan="7" style="text-align:center">व्यवसाय कर रकम सम्बम्धि विवरण</th>
                    </tr>
                    <tr>
                        <th width="10%">व्यवसाय कर वापत लाग्ने रकम</th>
                        <th width="8%">छुट रकम</th>
                        <th width="10%">बक्यौता रकम</th>
                        <th width="10%">जरिवाना</th>
                        <th width="10%">प्रमाण पत्र दस्तुर</th>
                        <th width="10%">जम्मा असुली भएको रकम</th>
                        <th width="15%">दस्तखत</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>१</td>
                        <td></td>
                        <td>.... असार मसान्तसम्म</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>२</td>
                        <td></td>
                        <td>.... असार मसान्तसम्म</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>३</td>
                        <td></td>
                        <td>.... असार मसान्तसम्म</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>४</td>
                        <td></td>
                        <td>.... असार मसान्तसम्म</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>५</td>
                        <td></td>
                        <td>.... असार मसान्तसम्म</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>६</td>
                        <td></td>
                        <td>.... असार मसान्तसम्म</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>७</td>
                        <td></td>
                        <td>.... असार मसान्तसम्म</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>८</td>
                        <td></td>
                        <td>.... असार मसान्तसम्म</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>९</td>
                        <td></td>
                        <td>.... असार मसान्तसम्म</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>१०</td>
                        <td></td>
                        <td>.... असार मसान्तसम्म</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>११</td>
                        <td></td>
                        <td>.... असार मसान्तसम्म</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>१२</td>
                        <td></td>
                        <td>.... असार मसान्तसम्म</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</body>
<script type="text/javascript">
    window.print();
</script>

</html>