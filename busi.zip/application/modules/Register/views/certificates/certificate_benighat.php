<!DOCTYPE html>
<html>

<head>
  <title>गल्छी गाउँपालिका</title>
  <style>
    body {
      background: rgb(204, 204, 204);
    }

    .page {
      background: white;
      display: block;
      margin: 0 auto;
      /*margin-bottom: 0.5cm;*/
      background-image: url("../../../assets/img/page0001.jpg");
      background-repeat: no-repeat;
      background-size: cover;
    }

    .page {
      width: 21cm;
      height: 29.7cm;
    }

    @media print {
      * {
        -webkit-print-color-adjust: exact;
      }

      body,
      page {
        margin: 0;
        box-shadow: 0;
      }
    }

    .rectangle {
      border: 2px solid black;
      margin-left: -356px;
      margin-top: 30px;
      width: 610px;
      /* Width of the rectangle */
      height: 129px;
      /* Height of the rectangle */
      background-color: white;
      /* Background color of the rectangle */
    }
  </style>

</head>

<body>
  <div class="page">
    <img src="<?php echo base_url() ?>/assets/img/nepal-govt.png"
      style="margin-top: 100px; height: 150px; width: 150px; margin-left: 80px;">
    <strong>
      <p style="margin-top:-170px;  font-size: 28px; text-align: center; color: rgb(239, 16, 16);">
        <?php echo GNAME ?>
      </p>
    </strong>
    <br>
    <p style="margin-top:-45px;  font-size: 20px; text-align: center; color: rgb(239, 16, 16);">
      <?php echo SLOGAN ?>
    </p>
    <br>
    <p style="margin-top:-40px;  font-size: 20px; text-align: center; color: rgb(239, 16, 16);">
      <?php echo ADDRESS . ',' . DISTRICT ?>
    </p>
    <br>
    <p style="margin-top:-40px;  font-size:18px; text-align: center; color: rgb(239, 16, 16);">
      <?php echo STATENAME ?>, नेपाल
    </p>
    <img src="<?php echo base_url() ?>/assets/img/p.png"
      style="margin-top: -220px; height: 130px; width: 130px; margin-left: 580px;">
    <br>
    <div class="text-center" style="margin-top:40px;">
      <img src="<?php echo base_url() ?>assets/img/pramad.png"
        style="margin-top: -20px;  height: 49px; width: 215px; margin-left:270px;">
    </div>
    <div class="" style="margin-top:43px;">
      <div class="darta" style="margin-left: 80px; font-size:18px; margin-top:10px;">व्यवसाय दर्ता नं.
        <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?>/
        <?php echo $this->mylibrary->convertedcit($row['fiscal_year']) ?>
      </div>
      <div class="darta" style="margin-left: 550px;margin-top: -22px; font-size:18px; ">दर्ता मितिः
        <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?>
      </div>
      <div class="bbody" style="margin-left: 80px; font-size:16px;">
        <p style="text-align:justify; margin-right: 80px;">
          <!-- तपसिलमा उल्लेखित व्यवसाय स्थानीय सरकार संचालन ऐन, २०७४ को -->
          <!-- दफा ११(२)(ञ)(६), प्रादेशिक ब्यापार तथा व्यवसाय सम्बन्धि
          ऐन, २०७६ दफा ३ तथा गल्छी गाउँपालिका व्यवसाय दर्ता तथा नवीकरण कार्यविधि, २०७६ को दफा ३ प्रयोजनको लागि
          व्यवसाय दर्ता गरि यो प्रमाणपत्र प्रदान गरिएको छ l -->
          गल्छी गाउँपालिकाको आर्थिक ऐन २०८१ को अनुसूची ७ बमोजिम देहायको उद्योग/ब्यापार/पेशा/सेवा व्यवसायलाई दर्ता गरि यो
          प्रमाण–पत्र दिईएको छ |
        </p>
      </div>
    </div>
    <br>
    <div class="bbbody" style="margin-left: 85px;margin-top:-10px; font-size:16px;">
      १. व्यक्ति/फर्म/कम्पनीको नाम :- <span style="margin-left:3px;">
        <?php echo $this->mylibrary->convertedcit($row['business_name_np']) ?><span><br><br>
          २. ठेगाना/कारोबारको मुख्य स्थान :- <span style="margin-left:3px;">
            <?php echo $bgapa['name'] ?>-
            <?php echo $this->mylibrary->convertedcit($row['b_ward']) ?>,
            <?php echo $bdistrict['name'] ?>,
            <?php echo $bstate['Title'] ?>
          </span><br><br>
          ३. कारोवारको किसिम :- <span style="margin-left:3px;">
            <?php echo $row['b_workdetails'] ?>
          </span><br><br>
          ४. मालिक/साझेदार/संचालक मुख्य व्यक्तिको नाम :- <span style="margin-left:3px;">
            <?php echo $this->mylibrary->convertedcit($row['b_owner_name']) ?>
          </span><br><br>
          ५. ठेगाना :- <span style="margin-left:3px;">
            <?php echo $pgapa['name'] ?>-
            <?php echo $this->mylibrary->convertedcit($row['p_ward']) ?>,
            <?php echo $pdistrict['name'] ?>,
            <?php echo $pstate['Title'] ?>
          </span><br><br>
          ६. व्यवसाय रहने घर / कारोवारको मुख्य स्थान / जग्गा धनीको नाम:- <span style="margin-left:3px;">
            <?php echo $bgapa['name'] . ', ' . $this->mylibrary->convertedcit($row['b_ward']) . ', ' . $bdistrict['name'] ?>
          </span><br><br>
          ७. सम्पर्क नं:- <?php echo $this->mylibrary->convertedcit($row['s_phone_number']) ?> <span
            style="margin-left:3px;">मोबाइल नं:-
            <?php echo $this->mylibrary->convertedcit($row['b_phone_number']) ?></span><br><br>
          ८. इमेल:- <?php echo $this->mylibrary->convertedcit($row['s_email']) ?><br><br>
          ९. कूल पूँजिः- <span style="margin-left:3px;">
            <?php echo $this->mylibrary->convertedcit(number_format($row['b_captial'])) ?>/- <span>चालु पूँजिः-
              <?php echo $this->mylibrary->convertedcit(number_format($row['chalu_capital'])) ?>/-
            </span><span>स्थिर पूँजिः-
              <?php echo $this->mylibrary->convertedcit(number_format($row['fixed_capital'])) ?>/-
            </span><br><br>
            <!-- <b>८. बिद्युत शक्ति (किलोवाट):-
        <?php echo $this->mylibrary->convertedcit($row['b_electricity']) ?>
      </b><br><br> -->
    </div>
    <div class="" style="margin-top:50px;">
      <div class="darta" style="margin-left: 80px; font-size:14px;">
        &nbsp&nbsp&nbsp...................................<br>
        (प्रमाण–पत्र पाउनेको सही) </div>
      <div class="darta" style="margin-left: 475px;margin-top: -35px; font-size:14px; "> &nbsp&nbsp&nbsp&nbsp&nbsp
        <?php echo !empty($row['checker']) ? $checker['name'] : '' ?><br>(प्रमाण–पत्र जारी गर्नेको सही)
      </div>

      <div class="text-left" style="margin-left:80px;marfin-top:10px;">
        <b><u>द्रष्टब्य </u></b><br>
        <?php if (!empty($commits)):
          foreach ($commits as $commit): ?>
            <li>
              <?php echo $commit['commits'] ?>
            </li>
          <?php endforeach; endif; ?>
      </div>
    </div>
  </div>
  </div>
  <script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
  <script type="text/javascript">
    window.print();
  </script>
</body>

</html>