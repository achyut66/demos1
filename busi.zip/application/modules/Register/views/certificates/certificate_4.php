<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="<?php echo base_url() ?>/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>
</head>

<body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle">
          <h1 class=""><?php echo GNAME ?></h1>
          <h5 style="color: black;"><?php echo SLOGAN ?></h5>
          <h5 style="color: black;"><?php echo ADDRESS . ',' . DISTRICT ?></h5>
          <h5 style="color: black;"><?php echo STATENAME ?>,नेपाल</span>
        </div>
        <div class="header-right">
          <div class="photo">
            <span>Photo</span>
          </div>
        </div>
      </div>


      <h2 class="letter-title">व्यवसाय दर्ता प्रमाण-पत्र</h2>
      <br>
      <div>
        <p>आर्थिक वर्षः <b><?php echo $this->mylibrary->convertedcit($row['fiscal_year']) ?></b></p>

        <div class="data_and_designation">
          <p>व्यवसाय दर्ता नं.: ..................................</p>
          <p style="margin-top:-6px; margin-left:-115px;"><b><?php echo $this->mylibrary->convertedcit($row['darta_no']) ?></b></p>
          <p style="margin-left: 300px;;">व्यवसाय मिति : .........................</p>
          <p style="margin-top:-6px; margin-left:-90px;"><b><?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></b></p>
        </div>
      </div>
      <div class="name_address_puji_bibarand">
        <p style="margin-top:10px;">व्यवसायको नाम :
          ....................................................................................
        </p>
        <p style=" margin-top:-46px;margin-left:120px"><b><?php echo $this->mylibrary->convertedcit($row['business_name_np']) ?></b></p>
        <div class="data_and_designation" style="margin-top: 30px;">
          <p> व्यवसाय गर्ने ठेगाना : ..............................................</p>
          <p>
          <p style=" margin-top:-8px;margin-left:-150px"><b><?php echo $this->mylibrary->convertedcit($row['b_tol']) ?></b></p>
          </p>
          <p style="margin-left: 107px;"> व्यवसायको किसिम : .............................................</p>
          <p style=" margin-top:-8px;margin-left:-140px"><b><?php echo $this->mylibrary->convertedcit($main_topic['topic_name']) ?></b></p>

        </div>

        <div class="data_and_designation" style="margin-top:10px;">
          <p> व्यवसायीको नाम: ............................</p>
          <p style=" margin-top:-8px;margin-left:-93px"><b><?php echo $this->mylibrary->convertedcit($row['b_owner_name']) ?></b></p>

          <p style="margin-left:40px;"> व्यवसायीको ठेगाना: ..........................</p>
          <p style=" margin-top:-8px;margin-left:-70px"><b><?php echo $this->mylibrary->convertedcit($pgapa['name']) . '-' . $this->mylibrary->convertedcit($row['p_ward']) ?></b></p>
        </div>
        <div class="data_and_designation" style="margin-top:10px;">
          <p>ना.प्र.प.नं.: ..........................</p>
          <p style=" margin-top:-8px;margin-left:-93px"><b><?php echo $this->mylibrary->convertedcit($row['b_ctzn_no']) ?></b></p>

          <p style="margin-left: 50px;">जारी मिति: ..............................</p>
          <p style=" margin-top:-8px;margin-left:-100px"><b><?php echo $this->mylibrary->convertedcit($row['b_ctzn_date']) ?></b></p>

          <p style="margin-left:50px;">जारी जिल्ला: ..............................</p>
          <p style=" margin-top:-8px;margin-left:-100px"><b><?php echo $this->mylibrary->convertedcit($row['b_ctzn_district']) ?></b></p>
        </div>
        <div class="data_and_designation" style="margin-top:10px;">
          <p> कुल पूँजी रु ..........................</p>
          <p style=" margin-top:-8px;margin-left:-93px"><b><?php echo $this->mylibrary->convertedcit($row['b_captial']) ?></b></p>

          <p style="margin-left:54px;"> चालू पूँजी रु. .......................</p>
          <p style=" margin-top:-8px;margin-left:-70px"><b><?php echo $this->mylibrary->convertedcit($row['chalu_capital']) ?></b></p>

          <p style="margin-left:63px;"> स्थिर पूँजी रु. ..........................</p>
          <p style=" margin-top:-8px;margin-left:-90px"><b><?php echo $this->mylibrary->convertedcit($row['fixed_capital']) ?></b></p>
        </div>

        <div class="data_and_designation" style="margin-top:40px;">
          <p> ..................................<br>व्यवसायीको दस्तख</p>
          <p style="margin-left:120px;"> ..................................<br>तयार गर्नेको नाम</p>
          <p style="margin-top: -10px;margin-left: -108px;"><b><?php echo $checker['name'] ?></b></p>
          <p style="margin-left:120px;"> ...................................... <br>प्रमाणित गर्नेको नाम</p>
          <p style="margin-top: -10px;margin-left: -108px;"><b><?php echo $maker['name'] ?></b></p>

        </div>

        <div>
          <br>
          <p style="font-size:x-large; text-decoration: underline;">शर्तहरु</p>
          <br>

          <p>१. विदेशी नागरिक संस्थापक तथा शेयरधनी रहने गरी स्थापना हुने संयुक्त लगानी वा पूर्ण विदेशी लगानी हुने कम्पनीको लागी आवश्यक थप कागजपत्र |</p>
          <p>२. म्याद सूचना जारी हुदा कम्पनीको तर्फ बाट वुझिलिने आधिकारिक व्यक्तिको नाम ठेगाना खुलेको विवरण ।</p>
          <p>३. कम्पनीका संचालक प्रवन्धक कम्पनी सचिव वा प्रमुख पदाधिकारीको नाम ठेगाना र निजहरुको नागरिकता सम्वन्धि विवरण ।</p>
          <p>४. व्यवसाय वा कारोवार संचालनको लागी अधिकारप्राप्त अधिकारीबाट प्राप्त अनुमतिपत्र । </p>
          <p>५. कम्पनी संस्थापनको अधिकार पत्र प्रमाणपत्र प्रवन्धपत्र तथा नियमावलीको प्रतिलिपि र सोको नेपाली अनुवाद ।</p>
          <p>६. कम्पनीको मूल कार्यालय र कारोवार गर्ने मुख्य ठेगाना कम्पनी संस्थापना भएको मिति जारी पूजी र मूख्य उद्देश्य खुलेको ।</p>
        </div>
      </div>
    </div>
  </div>
  </div>




  </ul>


</body>
<script type="text/javascript">
  window.print();
</script>

</html>