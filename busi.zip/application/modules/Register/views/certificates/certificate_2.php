<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="<?php echo base_url() ?>/assets/js/jquery.js"></script>

  <title><?php echo GNAME ?></title>
</head>

<body>
  <div class="bidur-wrapper">
    <div class="wrapper">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle">
          <p style="color:black">अनुसूची ३
            (दफा ४ को उपदफा (२) सँग सम्बन्धित)</h5>
          <h2 class=""><?php echo GNAME ?></h2>
          <h2><?php echo SLOGAN ?></h2>
          <h6><?php echo ADDRESS . ',' . DISTRICT ?></h6>
          <h6><?php echo STATENAME ?>,नेपाल</h6>
        </div>
        <div class="header-right">

        </div>
      </div>
      <div>
        <p>पप्रा. फ/ सा.फ. नं. ................ </p>
        <p style="margin-top: -44px;margin-left: 123px;">
          <b><?php echo $this->mylibrary->convertedcit($row['darta_no']) ?></b>
        </p>
      </div>

      <h3 class="bidur-letter-title" style="width:400px;">उद्योग/व्यापार व्यवसाय प्रमाण-पत्र</h3>
      <br>

      <p style="text-align: justify;">निम्न लेखिएको विवरण भएको प्राइभेट साफेदारी फर्म मिति
        <b><span><?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></b></span> मा विदुर नगरपालिकाको
        प्राइभेट / साझेदारी फर्मको दर्ता, नवीकरण, सञ्चालन सम्बन्धी कार्यविधि २०७७ बमोजिम दर्ता गरी यो प्रमाण-पत्र
        दिइएको छ ।
      </p>
      <div class="name_address_puji_bibarand">

        <p style="font-weight: bold;font-size: larger ;">विवरण</p>
        <div>
          <p>फर्मको नाम : <b><?php echo $this->mylibrary->convertedcit($row['business_name_np']) ?></b></p>
          <p>फर्मको ठेगाना: <b><?php echo $bgapa['name'] ?></b> वडा नं.
            <b><?php echo $this->mylibrary->convertedcit($row['b_ward']) ?></b>
          </p>
          <p>स्थापना सञ्चालन हुने स्थानः <b><?php echo $row['b_tol'] ?></b></p>
          <p>कित्ता नं.</p>
          <p>धनी (प्रोप्राइटर) साझेदारी : </p>
          <p>नाम, थरः <b><?php echo $row['landlord'] ?></b></p>
          <p>वतनः नेपाली</p>
          <div>
            <div class="gajuri_propiter_info ">
              <li> पूँजी, चालु रू : <b><?php echo $this->mylibrary->convertedcit($row['chalu_capital']) ?></b></li>
              <li style="margin-left: 200px;"> स्थिर रू :
                <b><?php echo $this->mylibrary->convertedcit($row['fixed_capital']) ?></b>
              </li>
              <li style="margin-left: 100px;"> कुल रु :
                <b><?php echo $this->mylibrary->convertedcit($row['b_captial']) ?></b>
              </li>
            </div>
            <div class="gajuri_propiter_info " style="padding-top: 22px;">
              <li> वार्षिक उत्पादन क्षमताः <b><?php echo $row['b_anual_production'] ?></b></li>
              <li style="margin-left: 150px;"> विद्युतशक्ति (किलोवाट): <b><?php echo $row['b_electricity'] ?></b></li>
            </div>
            <br>
            <p>नामसारी/ ठाउँसारीको विवरण (यदी):</p>
            <p>यो उद्योग विदुर नगरपालिकाको उद्योग व्यवसाय सम्बन्धी कार्यविधि २०७७ को दफा ५ र सो कार्यविधिको दफा ९ को
              उपदफा .................... अनुसार लघु घरेलु साना उद्योग दर्ता गरिएको छ ।</p>
            <br>
            <p style="text-align: right;">.............................................</p>
            <p style="text-align: right; margin-top:-49px;margin-right:50px;"><b><?php echo $checker['name'] ?></b></p>
            <p style="text-align: right;"><?php echo $checker['designation']?></p>
          </div>
        </div>
</body>
<script type="text/javascript">
window.print();
</script>

</html>