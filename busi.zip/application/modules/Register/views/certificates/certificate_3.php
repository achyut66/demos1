<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="<?php echo base_url() ?>/assets/js/jquery.js"></script>
  <title><?php echo GNAME ?></title>
</head>

<body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle">
          <h1 class=""><?php echo GNAME ?></h1>
          <h5><?php echo SLOGAN ?></h3>
            <h5><?php echo ADDRESS . ',' . DISTRICT ?></h3>
              <h5><?php echo STATENAME ?>,नेपाल</span>
        </div>
        <div class="header-right" >
          <div class="photo" style="margin-top:20px;">
            <span>Photo</span>
          </div>
        </div>
      </div>
      <div>
        <p>आर्थिक वर्षः <?php echo $this->mylibrary->convertedcit($row['fiscal_year']) ?></p>
        <p>दर्ता नं. <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?></p>
      </div>

      <h2 class="letter-title"><b>व्यवसाय दर्ता प्रमाण-पत्र</b></h2>
      <br>
      <p>श्री. <b><?php echo $this->mylibrary->convertedcit($row['business_name_np']) ?></b></p>
        <p style="margin-left: 510px;margin-top:-56px" >मितिः<b><?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></b>..</p>
        <div><b><?php echo GNAME?></b></div> 
      <div class="oda_number">
        <p> <b>वडा नं <?php echo $this->mylibrary->convertedcit($row['b_ward']) ?>, <?php echo DISTRICT ?></b> </p>
        
      </div>
      <p style="text-align: justify; margin-top:20px;"> तपशिलमा उल्लेखित व्यवसाय प्रादेशिक व्यापार तथा व्यवसाय सम्बन्धी ऐन, २०७६ दफा (३), स्थानीय सरकार संचालन ऐन, २०७४ को दफा ११ उपदफा २ (ञ) ६ तथा बेनीघाट रोराङ गाउँपालिका आर्थिक ऐन, <?php echo !empty($yain['rules'])?$yain['rules']:''?>साय दर्ता प्रमाण-पत्र दिईएको छ ।</p>
      <div class="name_address_puji_bibarand" style="margin-top:10px;">
        <p>१. व्यवसायको
          नामः ............................................................................................................................
        </p>
        <p style="margin-top:-46px;margin-left:173px;">
          <b><?php echo $this->mylibrary->convertedcit($row['business_name_np']) ?></b>
        </p>
        <p style="margin-top:20px;">२. व्यवसाय गर्ने
          ठेगाना: ........................................................................................................................
        </p>
        <p style="margin-top:-46px;margin-left:173px;">
          <b><?php echo $this->mylibrary->convertedcit($row['b_tol'] . '-' . $this->mylibrary->convertedcit($row['b_ward'])) ?></b>
        </p>

        <div>
          <p style="margin-top:10px;">३. कुल पूँजी रु ..........................................................</p>
          <p style="margin-top:-46px;margin-left:173px;">
            <b><?php echo $this->mylibrary->convertedcit($row['b_captial']) ?></b>
          </p>

          <div class="total_investment" style="margin-top: 40px;margin-left:20px;">
            <p style="width:401px; ">क) चालू पूँजी रु: ............................</p>
            <p style="margin-top:-20px;margin-left:-294px;">
              <b><?php echo $this->mylibrary->convertedcit($row['chalu_capital']) ?></b>
            </p>
            <p style="margin-left:150px;">ख) स्थिर पूँजी रु: ..............................................</p>
            <p style="margin-top:-20px;margin-left:-153px;">
              <b><?php echo $this->mylibrary->convertedcit($row['fixed_capital']) ?></b>
            </p>
          </div>
          <br>
          <div>
            <p style="margin-top:-20px;">४. व्यवसाय संचालकको विवरण:</p>
            <div class="bebasaya_bibarand">
              <p>क) नाम: ............................................................</p>
              <p style="margin-top:-10px;margin-left:-105px;">
                <b><?php echo $this->mylibrary->convertedcit($row['b_owner_name']) ?></b>
              </p>
              <p style="margin-left:50px;margin-left:214px">ख) साविक
                ठेगाना: ...................................................</p>
            </div>
            <br>
            <div class="bebasaya_bibarand">
              <p>ग) हालको ठेगाना: ................................................</p>
              <p style="margin-top:-10px;margin-left:-155px;">
                <b><?php echo $this->mylibrary->convertedcit($tgapa['name']) .'-'. $this->mylibrary->convertedcit($row['t_ward'])?></b>
              </p>
              <p style="margin-left:40px;">घ) बाबुको नाम: ............................................</p>
              <p style="margin-top:-10px;margin-left:-155px;">
                <b><?php echo $this->mylibrary->convertedcit($row['father_name']) ?></b>
              </p>

            </div>
            <br>
            <div class="bebasaya_bibarand">
              <p>ङ) बाजेको नाम: ..............................................</p>
              <p style="margin-top:-10px;margin-left:-155px;">
                <b><?php echo $this->mylibrary->convertedcit($row['grandfather_name']) ?></b>
              </p>

              <p style="margin-left:244px;">च) आमाको नामः ..........................................</p>
              <p style="margin-top:-10px;margin-left:-165px;"><b></b></p>

            </div>
            <br>
            <h5 class="letter-title" style="margin-top:10px;">प्रमाण पत्र दिने अधिकारीको</h5>
          </div>
          <div class="centre_text">
            <p>नाम थर: .....................................................</p>
            <p style="margin-top:-45px;margin-left:-27px;">
              <b><?php echo !empty($checker['name']) ? $checker['name'] : '' ?></b>
            </p>

            <p>दस्तखतः .......................................................</p>
            <p>मितिः ...........................................................</p>
            <p style="margin-top:-45px;margin-left:-27px;">
              <b><?php echo $this->mylibrary->convertedcit(convertDate(date('Y-m-d'))) ?></b>
            </p>

          </div>




          </ul>

        </div>
      </div>
    </div>
</body>
<script type="text/javascript">
window.print();
</script>

</html>