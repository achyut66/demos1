<!--main content start-->
<style>
  .table-bordered td,
  .table-bordered th {
    border: 1px solid #3a5d7f;
  }

  .disabled {
    pointer-events: none;
    /* Disables click events */
    color: #ccc;
    /* Change text color to gray */
    text-decoration: none;
    /* Remove underline */
    cursor: not-allowed;
    /* Change cursor to indicate it's not clickable */
  }
</style>
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"><i class="fa fa-home"></i> ड्यासबोर्डमा</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo base_url() ?>Register" class="bactive">उद्योग र व्यवसाय
            दर्ता अभिलेख </a></li>
        <li class="breadcrumb-item active"><a href="javascript:;" class="bactive">विवरण हेर्नुहोस</a></li>
      </ol>
    </nav>
    <!-- page start-->
    <div class="row">
      <aside class="profile-info col-lg-9">
        <section class="card">
          <header class="card-header text-light " style="background-color:#4d5886">व्यवसाय विवरण- <span
              class="btn btn-success btn-circle"> दर्ता नं.
              <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?></span>
            <?php if (!empty($renewdetails)): ?><a href="javascript:;" class="btn btn-outline-warning pull-right">नवीकरण
                गरिएको</a><?php endif; ?>
          </header>
          <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
                if (!empty($success_message)) { ?>
                  <div class="alert alert-success">
                    <button class="close" data-close="alert"></button>
                    <span> <?php echo $success_message; ?> </span>
                  </div>
                <?php } ?>

                <?php $err_message = $this->session->flashdata("MSG_ERR");
                if (!empty($err_message)) { ?>
                  <div class="alert alert-danger">
                    <button class="close" data-close="alert"></button>
                    <span> <?php echo $err_message; ?> </span>
                  </div>
                <?php } ?>
                <?php $err_message = $this->session->flashdata("MSG_WAR");
                if (!empty($err_message)) { ?>
                  <div class="alert alert-warning">
                    <button class="close" data-close="alert"></button>
                    <span> <?php echo $err_message; ?> </span>
                  </div>
                <?php } ?>
                <?php if ($row['darta_suchikrit'] == 1) {
                  $a = "दर्ता ";
                } else {
                  $a = "सुचिकृत ";
                }
                ?>
                <table class="table table-bordered">
                  <tr>
                    <td><strong><span>दर्ता मिति:</span>
                        <hr><?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?>
                      </strong></td>
                    <td><strong><span>उद्योग, व्यवसायको पुरा नाम (np):</span> <?php echo $row['business_name_np'] ?>
                    </td>
                    <td><strong><span>उद्योग, व्यवसायको पूरा नाम(en):
                        </span><?php echo $row['business_name_en'] ?></strong></td>
                    <td><strong><span> दर्ता /सुचिकृत :
                          <br>
                        </span><?php echo $a ?> </strong></td>
                    <td><strong><span>उद्योग, व्यवसायको पुरा ठेगाना:
                        </span><?php echo $bgapa['name'] ?>-<?php echo $this->mylibrary->convertedcit($row['b_ward']) ?>,<?php echo $bdistrict['name']; ?>,<?php echo $bstate['Title']; ?></strong>
                    </td>
                  </tr>
                  <tr>
                    <td><strong><span>उद्योग, व्यवसायको शिर्षक:</span>
                        <?php echo !empty($row['b_type_']) ? $main_topic['topic_name'] : '' ?></strong>
                    </td>
                    <td><strong><span>उद्योग, व्यवसायको उप शिर्षक:</span>
                        <?php echo !empty($row['b_subtype']) ? $subtopic['sub_topic'] : '' ?></strong>
                    </td>
                    <td><strong><span>व्यवसायको वर्ग:</span> <?php echo $row['category'] ?></strong></td>
                    <td><strong><span>उद्योग, व्यवसायमा लगाउने पूजीँको श्रोत:
                        </span><?php echo $row['b_capital_source'] ?></strong></td>
                    <td><strong><span>परिचय पाटीको साइज:
                        </span><?php echo $row['party_size'] ?></strong></td>
                  </tr>
                  <tr>
                    <td><strong><span>उद्योग, व्यवसायमा लगाउने स्थिर पूजीँ रु: </span>
                        <?php echo $this->mylibrary->convertedcit($row['fixed_capital']) ?></strong></td>
                    <td><strong><span>उद्योग, व्यवसायमा लगाउने चालु पूजीँ रु: </span>
                        <?php echo $this->mylibrary->convertedcit($row['chalu_capital']) ?></strong></td>
                    <td><strong><span>उद्योग, व्यवसायमा लगाउने कुल पूजीँ रु: </span>
                        <?php echo $this->mylibrary->convertedcit($row['b_captial']) ?></strong></td>
                    <td><strong><span>उद्योग, व्यवसायको उद्देश्य:</span><?php echo $row['b_aim'] ?></strong></td>
                  </tr>

                </table>
                <table class="table table-bordered">
                  <tr>
                    <td colspan=3><strong><span>उद्योग, व्यवसायले कारोवार गर्ने मुख्य चीज वस्तु विवरण:</span>
                        <?php echo $row['b_workdetails'] ?></strong></td>
                  </tr>
                </table>
                <table class="table table-bordered">
                  <tr>
                    <td><strong><span>उद्योग, व्यवसाय दर्ता भएको निकाय (अन्यत्र दर्ता भए):</span>
                        <?php echo $row['b_darta_office'] ?></strong></td>
                    <td colspan=3><strong><span>दर्ता नं. र मिति:
                        </span><?php echo $this->mylibrary->convertedcit($row['b_odarta_miti']) ?></strong></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
        </section>
        <section class="card">
          <header class="card-header text-light " style="background-color:#4d5886">व्यवसायीको विवरण</header>
          <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                <table class="table table-bordered">
                  <tr>
                    <td><strong><span>व्यवसायीको पुरा नाम:</span><?php echo $row['b_owner_name'] ?></strong></td>
                    <td><strong><span>स्थायी ठेगाना:
                        </span><?php echo $pgapa['name'] ?>-<?php echo $this->mylibrary->convertedcit($row['b_ward']) ?>,<?php echo $pdistrict['name']; ?>,<?php echo $pstate['Title']; ?></strong>
                    </td>
                    <td colspan=3><strong><span>अस्थायी ठेगाना:
                        </span><?php echo $tgapa['name'] ?>-<?php echo $this->mylibrary->convertedcit($row['t_ward']) ?>,<?php echo $tdistrict['name']; ?>,<?php echo $tstate['Title']; ?></strong>
                    </td>
                  </tr>
                  <tr>
                    <td><strong><span>ना.प्र.प.नं.:
                        </span><?php echo $this->mylibrary->convertedcit($row['b_ctzn_no']) ?></strong></td>
                    <td><strong><span>जारी जिल्ला: </span> <?php echo $row['b_ctzn_district'] ?></strong></td>
                    <td colspan=3><strong><span>जारी
                          मिति:</span><?php echo $this->mylibrary->convertedcit($row['b_ctzn_date']) ?></strong></td>
                  </tr>
                  <tr>
                    <td><strong><span>बाजेको नाम:</span><?php echo $row['grandfather_name'] ?></strong></td>
                    <td><strong><span>ठेगाना: </span><?php echo $row['grandfather_address'] ?></strong></td>
                    <td><strong><span>बावुको नाम:</span><?php echo $row['father_name'] ?></strong></td>
                    <td><strong><span>ठेगाना: </span><?php echo $row['father_address'] ?></strong></td>
                  </tr>

                </table>
              </div>
            </div>
          </div>
        </section>
        <section class="card">
          <header class="card-header text-light " style="background-color:#4d5886">फर्म संचालन हुने घर वा जग्गाको
            स्वामित्व रहेको व्यक्ति विवरण</header>
          <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                <table class="table table-bordered">
                  <tr>
                    <td><strong><span>घर / जग्गा धनिको नाम:</span>
                        <hr><?php echo $row['landlord'] ?>
                      </strong></td>
                    <td><strong><span>ठेगाना: </span>
                        <hr><?php echo $row['landlord_address'] ?>
                      </strong></td>
                    <td colspan=3><strong><span>मासिक भाडा रकम: </span>
                        <hr><?php echo $this->mylibrary->convertedcit($row['rent']) ?>
                      </strong></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
        </section>
        <section class="card">
          <header class="card-header text-light " style="background-color:#4d5886">कार्यालय प्रयोजन</header>
          <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                <table class="table table-bordered">
                  <tr>
                    <td><strong><span>निवेदन
                          दस्तुर:</span><br><?php echo $this->mylibrary->convertedcit($row['nibedan_dastur']) ?></strong>
                    </td>
                    <td><strong><span>दर्ता दस्तुर:
                        </span><br><?php echo $this->mylibrary->convertedcit($row['darta_dastur']) ?></strong></td>
                    <td colspan=3><strong><span>व्यवसाय कर:
                        </span><br><?php echo $this->mylibrary->convertedcit($row['b_kar']) ?></strong></td>
                    <td colspan=3><strong><span>जरिवाना दस्तुर:
                        </span><br><?php echo $this->mylibrary->convertedcit($row['fine_amount']) ?></strong></td>
                    <td colspan=3><strong><span>जम्मा:
                        </span><br><?php echo $this->mylibrary->convertedcit($row['total_amount']) ?></strong></td>
                    <td colspan=3><strong><span>मिति:
                        </span><br><?php echo $this->mylibrary->convertedcit($row['rasid_date']) ?></strong></td>
                    <td colspan=3><strong><span>रसिद नं:
                        </span><br><?php echo $this->mylibrary->convertedcit($row['rasid_no']) ?></strong></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
        </section>

      </aside>
      <aside class="profile-nav col-lg-3">
        <section class="card">
          <div class="user-heading round">
            <a href="#" data-toggle="modal" data-target="#editModel"
              data-url="<?php echo base_url() ?>Register/updatePhoto" data-id="<?php echo $row['id'] ?>">
              <img
                src="<?php echo base_url() ?>assets/business_owner/<?php echo !empty($row['image']) ? $row['image'] : 'emt.jpg' ?>"
                alt="">
            </a>
            <h1><?php echo !empty($row['business_name_np']) ? $row['business_name_np'] : '' ?></h1>
            <p>
              <?php echo $bgapa['name'] ?>-<?php echo $this->mylibrary->convertedcit($row['b_ward']) ?>,<?php echo $bdistrict['name']; ?><br><?php echo $bstate['Title']; ?>
            </p>
          </div>
          <?php //pp($migration_darta['prev_darta_id']) ?>
          <ul class="nav nav-pills nav-stacked">
            <li class="active nav-item"><a class="nav-link"
                href="<?php echo base_url() ?>Register/Edit/<?php echo $row['id'] ?>"> <i class="fa fa-pencil"></i>
                विवरण
                सम्पादन गर्नुहोस्</a></li>
            <?php if (empty($migration_darta['id'])) { ?>
              <li class="nav-item"><a class="nav-link"
                  href="<?php echo base_url() ?>Register/BusinessMigration/<?php echo $row['id'] ?>"> <i
                    class="fa fa-pencil"></i> नाम/ठाउ (सारी)/शाखा बिस्तार गर्नुहोस्</a></li>
            <?php } else { ?>
              <li class="nav-item"><a class="nav-link disabled"
                  href="<?php echo base_url() ?>Register/BusinessMigration/<?php echo $row['id'] ?>"> <i
                    class="fa fa-pencil"></i> नाम/ठाउ (सारी)/शाखा बिस्तार गर्नुहोस्</a></li>
            <?php } ?>
            <!-- <li class="nav-item"><a data-toggle="modal" href="#previewModel" class="nav-link"
                data-url="<?php echo base_url() ?>Register/addAppropedDetailsMigration"
                data-id="<?php echo $migration_darta['id'] ?>" style="margin-left:5px"><i class="fa fa-file"></i>
                नाम/ठाउ
                (सारी)/शाखा बिस्तारको प्रमाण पत्र प्रिन्ट गर्नुहोस</a></li> -->
            <?php if (!empty($migration_darta['id'])) { ?>
              <li class="nav-item"><a class="nav-link"
                  href="<?php echo base_url() ?>Register/CertificatePreviewMigration/<?php echo $migration_darta['id'] ?>">
                  <i class="fa fa-file"></i>नाम/ठाउ
                  (सारी)/शाखा बिस्तारको प्रमाण पत्र प्रिन्ट गर्नुहोस </a></li>
            <?php } else {
            } ?>
            <li class="nav-item"><a data-toggle="modal" href="#previewModel" class="nav-link"
                data-url="<?php echo base_url() ?>Register/addAppropedDetails" data-id="<?php echo $row['id'] ?>"
                style="margin-left:5px"><i class="fa fa-file"></i> प्रमाण पत्र प्रिन्ट गर्नुहोस</a></li>
            <!-- <li class="nav-item"><a data-toggle="modal" href="#previewModel" class="nav-link" data-url="<?php echo base_url() ?>Register/addPatra" data-id="' +row.dno+'" style="margin-left:5px"><i class="fa fa-file"></i> सिफारिस पत्र</a></li> -->
            <li class="nav-item"><a class="nav-link"
                href="<?php echo base_url() ?>Register/listNabikarnDetails/<?php echo $row['id'] ?>"> <i
                  class="fa fa-file"></i>नवीकरणको विवरण </a></li>
            <li class="nav-item"><a class="nav-link"
                href="<?php echo base_url() ?>Register/ShowFiles/<?php echo $row['id'] ?>"><i
                  class="fa fa-file"></i>अपलोड
                फाइल हेर्नुहोस</a></li>
            <!-- <li class="nav-item"><a class="nav-link" href="<?php echo base_url() ?>Register/addPatra"><i class="fa fa-file"></i><span style="color:yellow;font-weight:bold;">व्यवसाय दर्ता प्रमाणपत्र पठाइएको चिठी</span></a></li> -->
            <li class="nav-item"><a class="nav-link" type="button" data-toggle="modal" href="#previewModel"
                class="btn btn btn-warning  btn-sm" data-url="<?php echo base_url() ?>Register/addPatra"
                data-id="<?php echo urlencode('+row.dno+') ?>" style="margin-left:5px">व्यवसाय दर्ता प्रमाणपत्र पठाइएको
                चिठी</a></li>
          </ul>

        </section>
      </aside>
    </div>
  </section>
</section>
<!--main content end-->