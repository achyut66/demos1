<style type="text/css">
  .card-header {
    background: #1b5693;
  }
</style>
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"> ड्यासबोर्डमा</a></li>
        <li class="breadcrumb-item"><a href="<?php echo base_url() ?>Register">उद्योग र व्यवसाय दर्ता सुचीमा जानुहोस</a></li>
        <li class="breadcrumb-item"><a href="javascript:;">नयाँ थप्नुहोस्</a></li>
      </ol>
    </nav>

    <form class="form" method="post" action="<?php echo base_url() ?>Register/update" enctype="multipart/form-data">
      <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
      <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
      <div class="row">
        <div class="col-sm-12">
          <?php $ERR_VALIDATION = $this->session->flashdata("ERR_VALIDATION");
          if (!empty($ERR_VALIDATION)) { ?>
            <div class="alert alert-danger">
              <button class="close" data-close="alert"></button>
              <span> <?php echo $ERR_VALIDATION; ?> </span>
            </div>
          <?php } ?>
          <?php $success_message = $this->session->flashdata("MSG_EMP");
          if (!empty($success_message)) { ?>
            <div class="alert alert-success">
              <button class="close" data-close="alert"></button>
              <span> <?php echo $success_message; ?> </span>
            </div>
          <?php } ?>

          <?php $ERR_UPLOAD = $this->session->flashdata("ERR_UPLOAD");
          if (!empty($ERR_UPLOAD)) { ?>
            <div class="alert alert-success">
              <button class="close" data-close="alert"></button>
              <span> <?php echo $ERR_UPLOAD; ?> </span>
            </div>
          <?php } ?>
          <section class="card">
            <header class="card-header text-light ">व्यवसाय विवरण</header>
            <div class="card-body">
              <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                      <label>आर्थिक वर्ष </label>
                      <div class="">
                        <!-- <input type = "text" name="fiscal_year" value="<?php echo current_fiscal_year() ?>" class="form-control" readonly> -->
                        <select class="form-control" name="fiscal_year">  
                          <option value = "">आर्थिक वर्ष छान्नुहोस</option>
                          <?php if(!empty($fiscal_year)) : foreach($fiscal_year as $fy) : ?>
                            <option value = "<?php echo $fy['year']?>" <?php if($fy['year'] == $row['fiscal_year']){ echo 'selected';}?>><?php echo $this->mylibrary->convertedcit($fy['year'])?></option>
                          <?php endforeach; endif;?>
                      </select>
                      </div>
                    </div>
                  </div>

                <div class="col-md-2">
                    <div class="form-group">
                      <label>दर्ता मिती</label>
                      <div class="input-group">
                        <input type="text" id="nepaliDateD" name="darta_miti" class="form-control nepali-calendar" value="<?php echo $row['darta_miti'] ?>"/>
                        <div class="input-group-prepend">
                          <button type="button" class="input-group-text btn btn-danger" title=""><i class="fa fa-calendar"></i></button>
                        </div>
                      </div>
                    </div>
                  </div>

                <div class="col-md-2">
                    <div class="form-group">
                      <label>प्रमाणपत्र नं<span style="color: red">*</span></label>
                      <input type="text" class="form-control certificate_no" placeholder=""  name="certificate_no" value="<?php echo $row['darta_no'] ?>">
                    </div>
                  </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label> दर्ता/ सुचिकृत  <span style="color: red">*</span></label>
                   <select class="form-control" name="darta_suchikrit" id="darta_suchikrit">
                      <option value="">छान्नुहोस्</option>
                      <?php if (!empty($darta_suchikrit)) : foreach ($darta_suchikrit as $type) : ?>
                      <option value="<?php echo $type['id'] ?>"<?php if($row['darta_suchikrit'] == $type['id']) { echo 'selected'; }?>><?php echo $type['name'] ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>उद्योग, व्यवसायको पुरा नाम (नेपालीमा) <span style="color: red">*</span></label>
                    <input type="text" class="form-control owner_name" placeholder="" name="business_name_np" value="<?php echo $row['business_name_np'] ?>">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>उद्योग, व्यवसायको पुरा नाम (ENGLISH) <span style="color: red">*</span></label>
                    <input type="text" class="form-control owner_name" placeholder="" name="business_name_en" value="<?php echo $row['business_name_en'] ?>">
                  </div>
                </div>
                

                <div class="col-md-12">
                  <hr>
                  <h6>उद्योग, व्यवसायको ठेगाना</h6>
                  <hr>
                </div>
                <div class="col-md-2">
                  <div class="form-group">
                    <label class="">प्रदेश </label>
                    <select class="form-control select2 npl_state" name="b_pradesh" required id="state-1">
                      <option value="">छान्नुहोस्</option>
                      <?php if (!empty($pradesh)) :
                        foreach ($pradesh as $key => $p) : ?>
                          <option value="<?php echo $p['ID'] ?>" <?php if ($p['ID'] == $row['b_pradesh']) {
                                                                    echo 'selected';
                                                                  } ?>><?php echo $p['Title'] ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-2">
                  <div class="form-group">
                    <label class="">जिल्ला</label>
                    <select class="form-control select2 npl_district" id="district-1" required name="b_district">
                      <option value=""></option>
                      <?php if (!empty($districts)) :
                        foreach ($districts as $d) : ?>
                          <option value="<?php echo $d['id'] ?>" <?php if ($d['id'] == $row['b_district']) {
                                                                    echo 'selected';
                                                                  } ?>><?php echo $d['name'] ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">ग.पा / न. पा</label>
                    <select class="form-control npl_gapana select2 select_option" name="b_gapa" id="gapa-1" required>
                      <?php if (!empty($gapana)) :
                        foreach ($gapana as $key => $gp) : ?>
                          <option value="<?php echo $gp['id'] ?>" <?php if ($gp['id'] == $row['b_gapa']) {
                                                                    echo 'selected';
                                                                  } ?>><?php echo $gp['name'] ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-2">
                  <div class="form-group">
                    <label class="">वडा </label>
                    <select class="select_option form-control" name="b_ward">
                      <option value="">छानुहोस</option>
                      <?php if (!empty($wards)) :
                        foreach ($wards as $key => $w) : ?>
                          <option value="<?php echo $w['name'] ?>" <?php if ($row['b_ward'] == $w['name']) {
                                                                      echo 'selected';
                                                                    } ?>><?php echo $this->mylibrary->convertedcit($w['name']) ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">टोल </label>
                    <input type="text" name="b_tol" class="form-control" value="<?php echo $row['b_tol'] ?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <hr>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>स्थिर पूजीँ रु</label>
                    <input type="text" name="fixed_capital" value="<?php echo $row['fixed_capital'] ?>" id="fixed_capital" class="form-control">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>चालु पूजीँ रु</label>
                    <input type="text" name="chalu_capital" value="<?php echo $row['chalu_capital'] ?>" id="chalu_capital" class="form-control">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>कुल पूजीँ रु</label>
                    <input type="text" name="b_captial" value="<?php echo $row['b_captial'] ?>" class="form-control" id="b_capital">
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>उद्योग, व्यवसायको उद्देश्य</label>
                    <select class="form-control" name="b_aim">
                      <option value="">छान्नुहोस्</option>
                      <option value="स्थानीय व्यापार" <?php if ($row['b_aim'] == 'स्थानीय व्यापार') {
                                                        echo 'selected';
                                                      } ?>>स्थानीय व्यापार </option>
                      <option value="आयात / निर्यात" <?php if ($row['b_aim'] == 'आयात / निर्यात') {
                                                        echo 'selected';
                                                      } ?>>आयात / निर्यात</option>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>उद्योग, व्यवसायमा लगाउने पूजीँको श्रोत</label>
                    <input type="text" class="form-control owner_number" placeholder="" name="b_capital_source" value="<?php echo $row['b_capital_source'] ?>">
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>उद्योग, व्यवसायको किसिम<span style="color: red"> *:</span></label>
                    <select class="form-control" name="b_type" id="b_type">
                      <option value="">छान्नुहोस्</option>
                      <?php if (!empty($prakar)) : foreach ($prakar as $type) : ?>
                          <option value="<?php echo $type['id'] ?>" <?php if ($type['id'] == $row['b_type']) {
                                                                      echo 'selected';
                                                                    } ?>><?php echo $type['topic_name'] ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>किसिम<span style="color: red"> *:</span></label>
                    <select class="form-control" name="b_subtype" id="subtype">
                      <option value="">छान्नुहोस्</option>
                      <?php if (!empty($subtopic)) : foreach ($subtopic as $subtype) : ?>
                          <option value="<?php echo $subtype['id'] ?>" <?php if ($subtype['id'] == $row['b_subtype']) {
                                                                          echo 'selected';
                                                                        } ?>><?php echo $subtype['sub_topic'] ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>व्यवसायको वर्ग <span style="color: red"> *:</span></label>
                    <select class="form-control" name="category" id="category">
                      <option value="">छान्नुहोस्</option>
                      <?php if (!empty($category)) : foreach ($category as $ct) : ?>
                          <option value="<?php echo $ct['category'] ?>" <?php if ($ct['category'] == $row['category']) {
                                                                          echo 'selected';
                                                                        } ?>><?php echo $ct['category'] ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="form-group">
                    <label>उद्योग, व्यवसायले कारोवार गर्ने मुख्य चीज वस्तु विवरण</label>
                    <textarea class="form-control" name="b_workdetails" required><?php echo $row['b_workdetails'] ?></textarea>
                  </div>
                </div>

                <div class="col-md-6">
                  <label>वार्षिक उत्पादन क्षमता</label>
                  <input type="text" class="form-control " placeholder="" name="b_anual_production" value="<?php echo $row['b_anual_production'] ?>">
                </div>
                <div class="col-md-6">
                  <label>विद्युतशक्ति (किलोवाट)</label>
                  <input type="text" class="form-control " placeholder="" name="b_electricity" value="<?php echo $row['b_electricity'] ?>">
                </div>

                <div class="col-md-12">
                  <hr>
                  <h6>अन्य निकायामा दर्ता भएको भए</h6>
                  <hr>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>उद्योग, व्यवसाय दर्ता भएको निकाय (अन्यत्र दर्ता भए)</label>
                    <input type="text" class="form-control owner_number" placeholder="" name="b_darta_office" value="<?php echo $row['b_darta_office'] ?>">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>दर्ता नं. र मिति</label>
                    <input type="text" class="form-control" placeholder="" name="b_odarta_miti" value="<?php echo $row['b_odarta_miti'] ?>">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>दर्ता नं.</label>
                    <input type="text" class="form-control" placeholder="" name="b_odarta_no" value="<?php echo $row['b_odarta_no'] ?>">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>पान नं.</label>
                    <input type="text" class="form-control" placeholder="" name="b_pan_no" value="<?php echo $row['b_pan_no'] ?>">
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
        <div class="col-md-12">
          <section class="card">
            <header class="card-header text-light ">व्यवसायीको विवरण</header>
            <div class="card-body">
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>व्यवसायीको पुरा नाम</label>
                    <div class="">
                      <input type="text" name="b_owner_name" value="<?php echo $row['b_owner_name'] ?>" class="form-control">
                    </div>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>ना.प्र.प.नं.</label>
                    <div class="">
                      <input type="text" name="b_ctzn_no" value="<?php echo $row['b_ctzn_no'] ?>" class="form-control">
                    </div>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>जारी जिल्ला</label>
                    <select class="form-control select2" name="b_ctzn_district">
                      <option value="">छान्नुहोस्</option>
                      <?php if (!empty($districts)) : foreach ($districts as $d) : ?>
                          <option value="<?php echo $d['name'] ?>" <?php if ($d['name'] == $row['b_ctzn_district']) {
                                                                      echo 'selected';
                                                                    } ?>><?php echo $d['name'] ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                    <!-- <div class="">
                        <input type = "text" name="b_ctzn_district" value="<?php //echo $row['b_ctzn_district']
                                                                            ?>" class="form-control">
                      </div> -->
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>जारी मिति</label>
                    <div class="">
                      <input type="text" name="b_ctzn_date" value="<?php echo $row['b_ctzn_date'] ?>" class="form-control">
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <h6>स्थायी ठेगाना</h6>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">प्रदेश </label>
                    <select class="form-control select2 npl_state" name="p_pardesh" required id="state-2">
                      <option value="">छान्नुहोस्</option>
                      <?php if (!empty($pradesh)) :
                        foreach ($pradesh as $key => $p) : ?>
                          <option value="<?php echo $p['ID'] ?>" <?php if ($p['ID'] == $row['p_pradesh']) {
                                                                    echo 'selected';
                                                                  } ?>><?php echo $p['Title'] ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">जिल्ला</label>
                    <select class="form-control select2 npl_district" id="district-2" required name="p_district">
                      <option value=""></option>
                      <?php if (!empty($districts)) :
                        foreach ($districts as $d) : ?>
                          <option value="<?php echo $d['id'] ?>" <?php if ($d['id'] == $row['p_district']) {
                                                                    echo 'selected';
                                                                  } ?>><?php echo $d['name'] ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">ग.पा / न. पा</label>
                    <select class="form-control npl_gapana select2 select_option" name="p_gapa" id="gapa-2" required>
                      <?php if (!empty($gapana)) :
                        foreach ($gapana as $key => $gp) : ?>
                          <option value="<?php echo $gp['id'] ?>" <?php if ($gp['id'] == $row['p_gapa']) {
                                                                    echo 'selected';
                                                                  } ?>><?php echo $gp['name'] ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">वडा </label>
                    <select class="select_option form-control npl_state" name="p_ward">
                      <option value="">छानुहोस</option>
                      <?php if (!empty($wards)) :
                        foreach ($wards as $key => $w) : ?>
                          <option value="<?php echo $w['name'] ?>" <?php if ($w['name'] == $row['p_ward']) {
                                                                      echo 'selected';
                                                                    } ?>><?php echo $this->mylibrary->convertedcit($w['name']) ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-12">
                  <h6>अस्थायी ठेगाना</h6>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">प्रदेश </label>
                    <select class="form-control select2 npl_state" name="t_pardesh" required id="state-3">
                      <option value="">छान्नुहोस्</option>
                      <?php if (!empty($pradesh)) :
                        foreach ($pradesh as $key => $p) : ?>
                          <option value="<?php echo $p['ID'] ?>" <?php if ($p['ID'] == $row['t_pradesh']) {
                                                                    echo 'selected';
                                                                  } ?>><?php echo $p['Title'] ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">जिल्ला</label>
                    <select class="form-control select2 npl_district" id="district-3" required name="t_district">
                      <option value=""></option>
                      <?php if (!empty($districts)) :
                        foreach ($districts as $d) : ?>
                          <option value="<?php echo $d['id'] ?>" <?php if ($d['id'] == $row['t_district']) {
                                                                    echo 'selected';
                                                                  } ?>><?php echo $d['name'] ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">ग.पा / न. पा</label>
                    <select class="form-control npl_gapana select2 select_option" name="t_gapa" id="gapa-3" required>
                      <?php if (!empty($gapana)) :
                        foreach ($gapana as $key => $gp) : ?>
                          <option value="<?php echo $gp['id'] ?>" <?php if ($gp['id'] == $row['t_gapa']) {
                                                                    echo 'selected';
                                                                  } ?>><?php echo $gp['name'] ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">वडा </label>
                    <select class="select_option form-control" name="t_ward">
                      <option value="">छानुहोस</option>
                      <?php if (!empty($wards)) :
                        foreach ($wards as $key => $w) : ?>
                          <option value="<?php echo $w['name'] ?>" <?php if ($row['t_ward'] == $w['name']) {
                                                                      echo 'selected';
                                                                    } ?>><?php echo $this->mylibrary->convertedcit($w['name']) ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-12">
                  <h6>व्यवसायीको ३ पुस्ते विवरण</h6>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>बाजेको नाम</label>
                    <div class="">
                      <input type="text" name="grandfather_name" value="<?php echo $row['grandfather_name'] ?>" class="form-control">
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>ठेगाना</label>
                    <div class="">
                      <input type="text" name="grandfather_address" value="<?php echo $row['grandfather_address'] ?>" class="form-control">
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>बावुको नाम</label>
                    <div class="">
                      <input type="text" name="father_name" value="<?php echo $row['father_name'] ?>" class="form-control">
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>ठेगाना</label>
                    <div class="">
                      <input type="text" name="father_address" value="<?php echo $row['father_address'] ?>" class="form-control">
                    </div>
                  </div>
                </div>

                <!-- //बावुको नामः -->
              </div>
            </div>
          </section>
        </div>
        <div class="col-md-6">
          <section class="card">
            <header class="card-header text-light ">फर्म संचालन हुने घर वा जग्गाको स्वामित्व रहेको व्यक्ति विवरण</header>
            <div class="card-body">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>घर / जग्गा धनिको नाम</label>
                    <div class="">
                      <input type="text" name="landlord" value="<?php echo $row['landlord'] ?>" class="form-control">
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="form-group">
                    <label>ठेगाना</label>
                    <div class="">
                      <input type="text" name="landlord_address" value="<?php echo $row['landlord_address'] ?>" class="form-control">
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="form-group">
                    <label>मासिक भाडा रकम</label>
                    <div class="">
                      <input type="text" name="rent" value="<?php echo $row['rent'] ?>" class="form-control">
                    </div>
                  </div>
                </div>
                <!-- //बावुको नामः -->
              </div>
            </div>
          </section>
        </div>
        <div class="col-md-6">
          <section class="card">
            <header class="card-header text-light ">कार्यालय प्रयोजन</header>
            <div class="card-body">
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label>निवेदन दस्तुर</label>
                    <div class="">
                      <input type="text" name="nibedan_dastur" value="<?php echo $row['nibedan_dastur'] ?>" class="form-control">
                    </div>
                  </div>
                </div>

                <div class="col-md-4">
                  <div class="form-group">
                    <label>दर्ता दस्तुर</label>
                    <div class="">
                      <input type="text" name="darta_dastur" value="<?php echo $row['darta_dastur'] ?>" class="form-control">
                    </div>
                  </div>
                </div>

                <div class="col-md-4">
                  <div class="form-group">
                    <label>व्यवसाय कर</label>
                    <div class="">
                      <input type="text" name="b_kar" value="<?php echo $row['b_kar'] ?>" class="form-control">
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>जरिवाना दस्तुर</label>
                    <div class="">
                      <input type="text" name="fine_amount" value="<?php echo $row['fine_amount'] ?>" class="form-control">
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>जम्मा</label>
                    <div class="">
                      <input type="text" name="total_amount" value="<?php echo $row['total_amount'] ?>" class="form-control">
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>मिति</label>
                    <div class="">
                      <input type="text" name="rasid_date" value="<?php echo $row['rasid_date'] ?>" class="form-control">
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>रसिद नं</label>
                    <div class="">
                      <input type="text" name="rasid_no" value="<?php echo $row['rasid_no'] ?>" class="form-control">
                    </div>
                  </div>
                </div>
                <!-- //बावुको नामः -->
              </div>
              
            </div>
          </section>
          
        </div>
        <div class="col-md-12">
                    <hr>
                    <table class="table" id="add_new_image">
                      <thead>
                        <tr>
                          <th>फाइल अपलोड गर्नुहोस</th>
                          <th>फाइलको नाम</th>
                          <th>#</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><input class="form-control" type="file" name="userfile[]" value=""></td>
                          <td><input class="form-control" name="image_t_name[]"value=""></td>
                          <td>#</td>
                        </tr>
                      </tbody>
                    </table>
                    <button type="button" class="btn btn-secondary btn-block NewImg"><i class="fa fa-plus-circle"></i> add new </button>
                </div>
        <div class="col-md-12 text-center">
          <hr>
          <button class="btn btn-primary btn-xs btn-save save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्" name="Submit" type="submit" value="Submit" id="btn_save_details"> सेभ गर्नुहोस्</button>
          <a href="<?php echo base_url() ?>Register" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
        </div>
      </div>
    </form>
  </section>
</section>
<script type="text/javascript" src="<?php echo base_url() ?>assets/assets/select2/js/select2.min.js"></script>
<script>
  $(document).ready(function() {
    $('.select2').select2();
    $('#b_type').change(function() {
      obj = $(this);
      var type = obj.val();
      $.ajax({
        url: base_url + 'CommonController/subtype',
        method: "POST",
        data: {
          type: type,
          '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        },
        success: function(resp) {
          if (resp.status == 'success') {
            $('#subtype').html(resp.option);
          }
        }
      });
    });

    $('.npl_state').change(function() {
      var id_selected = $(this).attr("id");
      var res = id_selected.split("-");
      var id = res[res.length - 1];
      var state = $(this).val();
      $.ajax({
        url: base_url + 'CommonController/getDistrictByState',
        method: "POST",
        data: {
          state: state,
          '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        },
        success: function(resp) {
          if (resp.status == 'success') {
            $('#district-' + id).html(resp.option);
          }
        }
      });
    });

    $('.npl_district').change(function() {
      var id_selected = $(this).attr("id");
      var res = id_selected.split("-");
      var id = res[res.length - 1];
      var district = $(this).val();
      $.ajax({
        url: base_url + 'CommonController/getGapanapaByDistricts',
        method: "POST",
        data: {
          district: district,
          '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        },
        success: function(resp) {
          if (resp.status == 'success') {
            $('#gapa-' + id).html(resp.option);
          }
        }
      });
    });
    
    $(document).on('input','#fixed_capital, #chalu_capital',function() {
    var fc = $('#fixed_capital').val() || 0;
    var cc = $('#chalu_capital').val() || 0;
    var total = parseFloat(fc) + parseFloat(cc);
    $('#b_capital').val(total);
  });

  });
   $('.NewImg').click(function(e) {
      e.preventDefault();
        var new_row = 
        '<tr>'+
          '<td><input class="form-control" type="file" name="userfile[]"></td>'+
          '<td><input type="text" name="image_t_name[]" class="form-control">'+
          '<td><button type="button" class="btn btn-danger remove-row" data-toggle="tooltip" title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>'+
        '<tr>'
        $("#add_new_image").append(new_row);
    });
    $("body").on("click",".remove-row", function(e){
      e.preventDefault();
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });
</script>