<!--main content start-->
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"><i class="fa fa-home"></i> ड्यासबोर्डमा
            जानुहोस</a></li>
        <li class="breadcrumb-item active">उद्योग र व्यवसाय दर्ता सुची</li>
      </ol>
    </nav>
    <!-- page start-->
    <div class="row">
      <div class="col-sm-12">
        <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
        if (!empty($success_message)) { ?>
          <div class="alert alert-success">
            <button class="close" data-close="alert"></button>
            <span>
              <?php echo $success_message; ?>
            </span>
          </div>
        <?php } ?>

        <section class="card">
          <header class="card-header">
            <span style="text-align:center">उद्योग र व्यवसाय दर्ता अभिलेख</span>
            <span class="tools">
              <?php if ($this->authlibrary->HasModulePermission('REGISTER', "ADD")) { ?>
                <a href="<?php echo base_url() ?>Register/add" class=" btn btn-secondary pull-right" title=""><i
                    class="fa fa-plus-circle"></i> नयाँ व्यवसाय दर्ता थप्नुहोस् </a>
              <?php } ?>
            </span>
          </header>

          <div class="card-body">
            <div class="row">
              <div class="col-md-3">
                <select class="form-control" id="main_topic">
                  <option value="">प्रकार छानुहोस</option>
                  <?php if (!empty($main_topic)):
                    foreach ($main_topic as $type): ?>
                      <option value="<?php echo $type['id'] ?>">
                        <?php echo $type['topic_name'] ?>
                      </option>
                    <?php endforeach;
                  endif; ?>
                </select>
              </div>
              <div class="col-md-3">
                <input type="text" class="form-control" id="business_name" placeholder="उद्योग / व्यावसायको नाम">
              </div>
              <div class="col-md-2">
                <input type="text" class="form-control" id="darta_no" placeholder="दर्ता नं.">
              </div>
              <div class="col-md-2">
                <div class="input-group">
                  <input type="text" name="date" class="form-control " value="" placeholder="दर्ता मिति "
                    autocomplete="off" id="darta_miti">
                  <div class="input-group-prepend">
                    <button type="button" class="input-group-text btn btn-secondary" title=""><i class="fa fa-calendar"
                        style="color:##6c757d;background: radial-gradient(#ffffff, transparent);"></i></button>
                  </div>
                </div>
              </div>
              <div class="col-md-2">
                <button type="button" class="btn btn-warning" title="खोजी गर्नुहोस्" id="filter"><i
                    class="fa fa-search"></i> खोज्नुहोस</button>
              </div>
            </div>
            <hr>
            <div class="adv-table">
              <table class="display table table-bordered table-striped" id="dartalist">
                <thead style="background: #1b5693; color:#fff">
                  <tr>
                    <th>#</th>
                    <th>दर्ता नं</th>
                    <th>दर्ता मिति</th>
                    <th>उद्योग / व्यावसायको नाम</th>
                    <th>दर्ता किसिम (दर्ता / सुचिकृत)</th>
                    <th>व्यावसायीको नाम</th>
                    <?php if ($this->authlibrary->HasModulePermission('REGISTER', 'VIEW')) { ?>
                      <th class="hidden-phone"></th>
                    <?php } ?>
                  </tr>
                </thead>
                <tbody>

                </tbody>
              </table>
            </div>
          </div>
        </section>
      </div>
    </div>
    <!-- page end-->
  </section>
</section>
<script src="<?php echo base_url('assets/datatable/datatables.min.js') ?>"></script>
<script type="text/javascript"
  src="<?php echo base_url() ?>assets/nepali_datepicker/nepali.datepicker.v2.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function () {
    $('#darta_miti').nepaliDatePicker();
    fetch_all_data();
    function fetch_all_data(main_topic, business_name, darta_no, darta_miti, darta_kisim) {
      var oTable = $('#dartalist').DataTable({
        "order": [
          [0, "desc"]
        ],
        "searching": false,
        'lengthChange': false,
        "processing": true,
        "serverSide": true,
        'language': {
          'loadingRecords': '&nbsp;',
          'processing': '<div class="spinner"></div>'
        },
        "ajax": {
          "url": "<?php echo base_url('Register/GetAllList') ?>",
          "dataType": "json",
          "type": "POST",
          "data": {
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>',
            main_topic: main_topic,
            business_name: business_name,
            darta_kisim: darta_kisim,
            darta_no: darta_no,
            darta_miti: darta_miti
          }
        },
        "columns": [{
          "data": "sn"
        },
        {
          "data": "darta_no"
        },
        {
          "data": "date"
        },
        {
          "data": "name"
        },
        {
          "data": "darta_kisim"
        },
        {
          "data": "owner_name"
        },
          <?php if ($this->authlibrary->HasModulePermission('REGISTER', 'VIEW')) { ?> {
            "data": "",
            render: function (data, type, row) {
              // console.log(row);
              if (row.is_trash == 1) {
                var res = "<div class='alert alert-danger'>रद्ध भएको</div>";
                return res;
              } else {
                var res = '<a href="<?php echo base_url() ?>Register/viewDetails/' + row.id + '"' + ' class="btn btn-secondary btn-sm" alt="पुरा विवरण हेर्नुहोस " title="पुरा विवरण हेर्नुहोस "><i class="fa fa-eye"></i></a> <a href="<?php echo base_url() ?>Register/edit/' + row.id + '"' + '  class="btn btn-primary btn-sm" alt="विवरण सम्पादन गर्नुहोस" title="विवरण सम्पंदा गर्नुहोस"><i class="fa fa-pencil"></i></a> <a href="<?php echo base_url() ?>Register/listNabikarnDetails/' + row.id + '"' + '  class="btn btn-warning btn-sm" alt="नबिकरण गर्नुहोस " title="नबिकरण गर्नुहोस"><i class="fa fa- fa-unlock-alt"></i></a> <button type="button" title="प्रमाण पत्र "data-toggle="modal" href="#previewModel" class="btn btn-info btn-sm" data-url="<?php echo base_url() ?>Register/addAppropedDetails" data-id="' + row.id + '" style="margin-left:5px"><i class="fa fa-asterisk"></i></button><button type="button" title="व्यवसाय दर्ता प्रमाण-पत्र पठाइएको सम्बन्धमा" data-toggle="modal" href="#previewModel" class="btn btn btn-primary  btn-sm" data-url="<?php echo base_url() ?>Register/addPatra" data-id="' + row.dno + '" style="margin-left:5px">प्रमाणपत्र टिप्पणी</button>  <a href="<?php echo base_url() ?>Register/ShowFiles/' + row.id + '"' + '" class="btn btn-success btn-sm" title="View & Download"><i class="fa fa-download"></i></a><a href="<?php echo base_url() ?>Register/disableDarta/' + row.id + '"' + '" class="btn btn-danger btn-sm delete_row" title="रद्ध गर्नुहोस" id="delete_row"><i class="fa fa-times-circle"></i></a> ';
                return res;
              }
            },
          },
          <?php } ?>
        ],
      });
    }
    $('#filter').click(function () {
      var main_topic = $('#main_topic').val();
      var business_name = $('#business_name').val();
      var darta_no = $('#darta_no').val();
      var darta_miti = $('#darta_miti').val();
      $('#dartalist').DataTable().destroy();
      fetch_all_data(main_topic, business_name, darta_no, darta_miti);
    });

    $(document).on('click', '.delete_row', function (e) {
      return confirm("Are you sure?");
    });

  });
</script>