<style type="text/css">
.card-header {
  background: #1b5693;
}
</style>
<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/css/a4size.css">
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"> ड्यासबोर्डमा जानुहोस</a></li>
        <li class="breadcrumb-item"><a href="<?php echo base_url() ?>Register">उद्योग र व्यवसाय दर्ता सुचीमा जानुहोस</a>
        </li>
        <li class="breadcrumb-item"><a href="javascript:;">प्रमाणपत्र</a></li>
      </ol>
    </nav>
    <div class="row">
      <?php //if (!empty($checker)) : ?>
      <div class="col-md-12">
        <div class="alert alert-info">कृपाय तयार / प्रमाणित गर्ने को नाम छनोट गर्नुहोस</div>
      </div>

      <div class="col-md-12">
        <form action="<?php echo base_url() ?>Register/updateMakerChecker" method="post" class="form save_post">
          <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
            value="<?php echo $this->security->get_csrf_hash(); ?>">
          <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
          <div class="row">
            <div class="col-md-3">
              <div class="form-group">
                <label>तयार गर्नेको नाम <span style="color: red"> *</span></label>
                <select class="form-control" name="maker" id="maker">
                  <option value="">--छान्नुहोस्--</option>
                  <?php if (!empty($staffs)) : foreach ($staffs as $staff) : ?>
                  <option value="<?php echo $staff['id'] ?>"
                    <?php if($staff['id'] == $row['maker']){ echo 'selected';}?>><?php echo $staff['name'] ?></option>
                  <?php endforeach;
                    endif; ?>
                </select>
              </div>
            </div>

            <div class="col-md-2">
              <div class="form-group">
                <label>तयार गर्नेको पद<span style="color: red"> *</span></label>
                <input type="text" class="form-control" id="deg_maker"
                  value="<?php echo !empty($row['maker'])?$maker['designation']:''?>" readonly />
              </div>
            </div>

            <div class="col-md-3">
              <div class="form-group">
                <label>प्रमाणित गर्नेको नाम<span style="color: red"> *</span></label>
                <select class="form-control" name="checker" id="checker">
                  <option value="">--छान्नुहोस्--</option>
                  <?php if (!empty($staffs)) : foreach ($staffs as $staff) : ?>
                  <option value="<?php echo $staff['id'] ?>"
                    <?php if($staff['id'] == $row['checker']){ echo 'selected';}?>><?php echo $staff['name'] ?></option>
                  <?php endforeach;
                    endif; ?>
                </select>
              </div>
            </div>

            <div class="col-md-2">
              <div class="form-group">
                <label>प्रमाणित गर्नेको पद<span style="color: red"> *</span></label>
                <input type="text" class="form-control" id="deg_checker"
                  value="<?php echo !empty($row['maker'])?$checker['designation']:''?>" readonly />
              </div>
            </div>

            <div class="col-md-2">
              <div class="form-group">
                <button class="btn btn-primary btn-xs btn-save save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्"
                  name="Submit" type="submit" value="Submit" id="btn_save_details" style="margin-top:23px;"> सेभ
                  गर्नुहोस्</button>
              </div>
            </div>

          </div>
        </form>
        <hr>
      </div>
      <?php //endif; ?>
      <div class="col-md-12">
        <div class="alert alert-info">प्रमाण पत्रको नमुना छान्नुहोस्</div>
      </div>
      <!--<div class="col-md-3">-->
      <!--  <section class="card">-->
      <!--    <div class="pro-img-box">-->
      <!--      <img src="<?php echo base_url() ?>assets/img/s1.png" style="width:100%">-->
      <!--      <a href="<?php echo base_url() ?>Register/PrintCertificate/<?php echo $row['id'] ?>/1" class="adtocart">-->
      <!--        <i class="fa fa-print"></i>-->
      <!--      </a>-->
      <!--    </div>-->
      <!--  </section>-->
      <!--</div>-->

      <!--<div class="col-md-3">-->
      <!--  <section class="card">-->
      <!--    <div class="pro-img-box">-->
      <!--      <img src="<?php echo base_url() ?>assets/img/bidur.png" style="width:100%">-->
      <!--      <a href="<?php echo base_url() ?>Register/PrintCertificate/<?php echo $row['id'] ?>/2" class="adtocart">-->
      <!--        <i class="fa fa-print"></i>-->
      <!--      </a>-->
      <!--    </div>-->
      <!--  </section>-->
      <!--</div>-->

      <div class="col-md-12">
        <section class="card">
          <div class="pro-img-box">
            <img src="<?php echo base_url() ?>assets/img/s3.png" style="width:100%">
            <a href="<?php echo base_url() ?>Register/PrintCertificate/<?php echo $row['id'] ?>/3" class="adtocart">
              <i class="fa fa-print"></i>
            </a>
          </div>
        </section>
      </div>

      <!--<div class="col-md-3">-->
      <!--  <section class="card">-->
      <!--    <div class="pro-img-box">-->
      <!--      <img src="<?php echo base_url() ?>assets/img/s4.png" style="width:100%">-->
      <!--      <a href="<?php echo base_url() ?>Register/PrintCertificate/<?php echo $row['id'] ?>/4" class="adtocart">-->
      <!--        <i class="fa fa-print"></i>-->
      <!--      </a>-->
      <!--    </div>-->
      <!--  </section>-->
      <!--</div>-->

    </div>
  </section>
</section>

<script type="text/javascript">
$(document).ready(function() {
  var base_url = "<?php echo base_url() ?>";
  $('#maker').change(function() {
    obj = $(this);
    var maker = obj.val();
    var id = "<?php echo $this->uri->segment(3) ?>";
    $.ajax({
      url: base_url + 'Register/updateMaker',
      method: "POST",
      data: {
        maker: maker,
        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
      },
      success: function(resp) {
        $('#deg_maker').val(resp.data.designation);
        // if (resp.status == 'success') {
        //   location.reload();
        // }
      }
    });
  });
  $('#checker').change(function() {
    obj = $(this);
    var checker = obj.val();
    var id = "<?php echo $this->uri->segment(3) ?>";
    $.ajax({
      url: base_url + 'Register/updateChecker',
      method: "POST",
      data: {
        checker: checker,
        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
      },
      success: function(resp) {
        if (resp.status == 'success') {
          $('#deg_checker').val(resp.data.designation);
        }
      }
    });
  });
});
</script>