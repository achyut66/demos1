<style type="text/css">
  .card-header {
    background: #1b5693;
  }
</style>
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"> ड्यासबोर्डमा</a></li>
        <li class="breadcrumb-item"><a href="<?php echo base_url() ?>Register">उद्योग र व्यवसाय दर्ता सुचीमा जानुहोस</a>
        </li>
        <li class="breadcrumb-item"><a href="javascript:;">नयाँ थप्नुहोस्</a></li>
      </ol>
    </nav>

    <form class="form" method="post" action="<?php echo base_url() ?>Register/save" enctype="multipart/form-data">
      <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
        value="<?php echo $this->security->get_csrf_hash(); ?>">
      <div class="row">
        <div class="col-sm-12">
          <?php $ERR_VALIDATION = $this->session->flashdata("ERR_VALIDATION");
          if (!empty($ERR_VALIDATION)) { ?>
            <div class="alert alert-danger">
              <button class="close" data-close="alert"></button>
              <span> <?php echo $ERR_VALIDATION; ?> </span>
            </div>
          <?php } ?>
          <?php $success_message = $this->session->flashdata("MSG_EMP");
          if (!empty($success_message)) { ?>
            <div class="alert alert-success">
              <button class="close" data-close="alert"></button>
              <span> <?php echo $success_message; ?> </span>
            </div>
          <?php } ?>

          <?php $ERR_UPLOAD = $this->session->flashdata("ERR_UPLOAD");
          if (!empty($ERR_UPLOAD)) { ?>
            <div class="alert alert-success">
              <button class="close" data-close="alert"></button>
              <span> <?php echo $ERR_UPLOAD; ?> </span>
            </div>
          <?php } ?>
          <section class="card">
            <header class="card-header text-light ">व्यवसाय विवरण</header>
            <div class="card-body">
              <div class="row">
                <div class="col-md-2">
                  <div class="form-group">
                    <label>आर्थिक वर्ष </label>
                    <div class="">
                      <!--<input type="text" name="fiscal_year" value="<?php echo current_fiscal_year() ?>"-->
                      <!--  class="form-control" readonly>-->
                      <select class="form-control" name="fiscal_year">
                        <option value="">आर्थिक वर्ष छान्नुहोस</option>
                        <?php if (!empty($fiscal_year)):
                          foreach ($fiscal_year as $fy): ?>
                            <option value="<?php echo $fy['year'] ?>" <?php if ($fy['year'] == current_fiscal_year()) {
                                 echo 'selected';
                               } ?>><?php echo $this->mylibrary->convertedcit($fy['year']) ?></option>
                          <?php endforeach; endif; ?>
                      </select>
                    </div>
                  </div>
                </div>

                <div class="col-md-2">
                  <div class="form-group">
                    <label>दर्ता मिती<span style="color: red"> *</span></label>
                    <div class="input-group">
                      <input type="text" id="nepaliDateD" name="darta_miti"
                        class="form-control nepali-calendar nepaliDateD"
                        value="<?php echo convertDate(date("y-m-d")) ?>" />
                      <div class="input-group-prepend">
                        <button type="button" class="input-group-text btn btn-danger" title=""><i
                            class="fa fa-calendar"></i></button>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-2">
                  <div class="form-group">
                    <label>प्रबिस्ट मिती<span style="color: red"> *</span></label>
                    <div class="input-group">
                      <input type="text" id="darta_entry_date" name="darta_entry_date"
                        class="form-control nepali-calendar nepaliDateD"
                        value="<?php echo convertDate(date("y-m-d")) ?>" />
                      <div class="input-group-prepend">
                        <button type="button" class="input-group-text btn btn-danger" title=""><i
                            class="fa fa-calendar"></i></button>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-2">
                  <div class="form-group">
                    <label>प्रमाणपत्र नं<span style="color: red">*</span></label>
                    <input type="text" class="form-control certificate_no" placeholder="" name="certificate_no"
                      value="<?php echo $darta_no ?>">
                  </div>
                </div>
                <div class="col-md-2">
                  <div class="form-group">
                    <label> दर्ता/ सुचिकृत <span style="color: red">*</span></label>
                    <select class="form-control" name="darta_suchikrit" id="darta_suchikrit">
                      <option value="">छान्नुहोस्</option>
                      <?php if (!empty($darta_suchikrit)):
                        foreach ($darta_suchikrit as $type): ?>
                          <option value="<?php echo $type['id'] ?>"><?php echo $type['name'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-2">
                  <div class="form-group">
                    <label>उद्योग, व्यवसायको पुरा नाम (नेपालीमा) <span style="color: red">*</span></label>
                    <input type="text" class="form-control owner_name" placeholder="" name="business_name_np" value=""
                      required>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>उद्योग, व्यवसायको पुरा नाम (ENGLISH) <span style="color: red">*</span></label>
                    <input type="text" class="form-control owner_name" placeholder="" name="business_name_en" value=""
                      required>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>उद्योग,व्यवसायको फोन नम्बर <span style="color: red">*</span></label>
                    <input type="text" class="form-control s_phone_number" placeholder="" name="s_phone_number"
                      value="">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>उद्योग, व्यवसायको इमेल <span style="color: red">*</span></label>
                    <input type="text" class="form-control s_email" placeholder="" name="s_email" value="">
                  </div>
                </div>


                <div class="col-md-12">
                  <hr>
                  <h6>उद्योग, व्यवसायको ठेगाना</h6>
                  <hr>
                </div>
                <div class="col-md-2">
                  <div class="form-group">
                    <label class="">प्रदेश </label>
                    <select class="form-control dd_select npl_state" name="b_pradesh" required id="state-1">
                      <option value="">छान्नुहोस्</option>
                      <?php if (!empty($pradesh)):
                        foreach ($pradesh as $key => $p): ?>
                          <option value="<?php echo $p['ID'] ?>" <?php if ($p['Title'] == STATE) {
                               echo 'selected';
                             } ?>><?php echo $p['Title'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-2">
                  <div class="form-group">
                    <label class="">जिल्ला</label>
                    <select class="form-control dd_select npl_district" id="district-1" required name="b_district">
                      <option value=""></option>
                      <?php if (!empty($districts)):
                        foreach ($districts as $d): ?>
                          <option value="<?php echo $d['id'] ?>" <?php if ($d['name'] == DISTRICT) {
                               echo 'selected';
                             } ?>><?php echo $d['name'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">ग.पा / न. पा</label>
                    <select class="form-control npl_gapana dd_select select_option" name="b_gapa" id="gapa-1" required>
                      <?php if (!empty($gapana)):
                        foreach ($gapana as $key => $gp): ?>
                          <option value="<?php echo $gp['id'] ?>" <?php if ($gp['name'] == GNAME) {
                               echo 'selected';
                             } ?>><?php echo $gp['name'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-2">
                  <div class="form-group">
                    <label class="">वडा </label>
                    <select class="select_option form-control" name="b_ward">
                      <option value="">छानुहोस</option>
                      <?php if (!empty($wards)):
                        foreach ($wards as $key => $w): ?>
                          <option value="<?php echo $w['name'] ?>"><?php echo $this->mylibrary->convertedcit($w['name']) ?>
                          </option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">टोल </label>
                    <input type="text" name="b_tol" class="form-control">
                  </div>
                </div>

                <div class="col-md-12">
                  <hr>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>स्थिर पूजीँ रु<span style="color: red"> *</span></label>
                    <input type="text" name="fixed_capital" value="0" class="form-control" id="fixed_capital" required>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>चालु पूजीँ रु<span style="color: red"> *</span></label>
                    <input type="text" name="chalu_capital" value="0" class="form-control" id="chalu_capital" required>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>कुल पूजीँ रु<span style="color: red"> *</span></label>
                    <input type="text" name="b_captial" value="0" class="form-control" id="b_capital" required>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>उद्योग, व्यवसायको उद्देश्य</label>
                    <select class="form-control" name="b_aim">
                      <option value="">छान्नुहोस्</option>
                      <option value="स्थानीय व्यापार">स्थानीय व्यापार </option>
                      <option value="आयात / निर्यात">आयात / निर्यात</option>
                      <option value="अन्य">अन्य</option>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>उद्योग, व्यवसायको शीर्षक</label>
                    <select class="form-control" name="b_type" id="b_type">
                      <option value="">छान्नुहोस्</option>
                      <?php if (!empty($prakar)):
                        foreach ($prakar as $type): ?>
                          <option value="<?php echo $type['id'] ?>"><?php echo $type['topic_name'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>उद्योग, व्यवसायको उप शीर्षक</label>
                    <select class="form-control select2" name="b_subtype" id="subtype">
                      <option value="">छान्नुहोस्</option>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>व्यवसायको वर्ग</label>
                    <select class="form-control" name="category" id="category">
                      <option value="">छान्नुहोस्</option>
                      <?php if (!empty($category)):
                        foreach ($category as $ct): ?>
                          <option value="<?php echo $ct['category'] ?>"><?php echo $ct['category'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>उद्योग, व्यवसायमा लगाउने पूजीँको श्रोत</label>
                    <input type="text" class="form-control owner_number" placeholder="" name="b_capital_source"
                      value="">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>उद्योग, व्यवसायले कारोवार गर्ने मुख्य चीज वस्तु विवरण</label>
                    <textarea class="form-control" name="b_workdetails" required></textarea>
                  </div>
                </div>
                <div class="col-md-6">
                  <label>वार्षिक उत्पादन क्षमता</label>
                  <input type="text" class="form-control " placeholder="" name="b_anual_production" value="">
                </div>
                <div class="col-md-6">
                  <label>व्यवसाय रहेको बाटोको नाम </label>
                  <input type="text" class="form-control " placeholder="" name="road_name" value="">
                </div>
                <div class="col-md-6">
                  <label>विद्युतशक्ति (किलोवाट)</label>
                  <input type="text" class="form-control " placeholder="" name="b_electricity" value="">
                </div>
                <div class="col-md-6">
                  <label>परिचय पाटीको साइज </label>
                  <input type="text" class="form-control " placeholder="" name="party_size" value="">
                </div>

                <div class="col-md-12">
                  <hr>
                  <header class="card-header text-light ">अन्य निकायामा दर्ता भए /सुचिकृत भएको</header>
                  <hr>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>उद्योग, व्यवसाय दर्ता भएको निकाय नाम </label>
                    <input type="text" class="form-control" placeholder="" name="b_darta_office" value="">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>दर्ता मिति</label>
                    <input type="text" class="form-control nepaliDateD" id="b_odarta_miti" placeholder=""
                      name="b_odarta_miti" value="">
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>दर्ता नं.</label>
                    <input type="text" class="form-control" placeholder="" name="b_odarta_no" value="">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>पान नं.</label>
                    <input type="text" class="form-control" placeholder="" name="b_pan_no" value="">
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
        <div class="col-md-12">
          <section class="card">
            <header class="card-header text-light ">व्यवसायीको विवरण</header>
            <div class="card-body">
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>व्यवसायीको पुरा नाम</label>
                    <div class="">
                      <input type="text" name="b_owner_name" value="" class="form-control" required>
                    </div>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>ना.प्र.प.नं.</label>
                    <div class="">
                      <input type="text" name="b_ctzn_no" value="" class="form-control" required>
                    </div>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>जारी जिल्ला</label>
                    <div class="">
                      <select class="form-control" name="b_ctzn_district" required>
                        <option value="">छान्नुहोस्</option>
                        <?php if (!empty($districts)):
                          foreach ($districts as $d): ?>
                            <option value="<?php echo $d['name'] ?>" <?php if ($d['name'] == DISTRICT) {
                                 echo 'selected';
                               } ?>><?php echo $d['name'] ?></option>
                          <?php endforeach;
                        endif; ?>
                      </select>
                      <!-- <input type = "text" name="b_ctzn_district" value="" class="form-control"> -->
                    </div>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label>जारी मिति</label>
                    <div class="">
                      <input type="text" name="b_ctzn_date" id="b_ctzn_date" value="" class="form-control nepaliDateD"
                        required>
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>ब्यबसायी को नम्बर</label>
                    <div class="">
                      <input type="text" name="b_phone_number" id="b_phone_number" value="" class="form-control"
                        required>
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>ब्यबसायी को इमेल</label>
                    <div class="">
                      <input type="text" name="b_email" id="b_email" value="" class="form-control">
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <h6>स्थायी ठेगाना</h6>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">प्रदेश </label>
                    <select class="form-control dd_select npl_state" name="p_pardesh" required id="state-2">
                      <option value="">छान्नुहोस्</option>
                      <?php if (!empty($pradesh)):
                        foreach ($pradesh as $key => $p): ?>
                          <option value="<?php echo $p['ID'] ?>" <?php if ($p['Title'] == STATE) {
                               echo 'selected';
                             } ?>><?php echo $p['Title'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">जिल्ला</label>
                    <select class="form-control dd_select npl_district" id="district-2" required name="p_district">
                      <option value=""></option>
                      <?php if (!empty($districts)):
                        foreach ($districts as $d): ?>
                          <option value="<?php echo $d['id'] ?>" <?php if ($d['name'] == DISTRICT) {
                               echo 'selected';
                             } ?>><?php echo $d['name'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">ग.पा / न. पा</label>
                    <select class="form-control npl_gapana dd_select select_option" name="p_gapa" id="gapa-2" required>
                      <?php if (!empty($gapana)):
                        foreach ($gapana as $key => $gp): ?>
                          <option value="<?php echo $gp['id'] ?>" <?php if ($gp['name'] == GNAME) {
                               echo 'selected';
                             } ?>><?php echo $gp['name'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">वडा </label>
                    <select class="select_option form-control npl_state" name="p_ward" required>
                      <option value="">छानुहोस</option>
                      <?php if (!empty($wards)):
                        foreach ($wards as $key => $w): ?>
                          <option value="<?php echo $w['name'] ?>"><?php echo $this->mylibrary->convertedcit($w['name']) ?>
                          </option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-12">
                  <h6>अस्थायी ठेगाना</h6>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">प्रदेश </label>
                    <select class="form-control dd_select npl_state" name="t_pardesh" required id="state-3">
                      <option value="">छान्नुहोस्</option>
                      <?php if (!empty($pradesh)):
                        foreach ($pradesh as $key => $p): ?>
                          <option value="<?php echo $p['ID'] ?>" <?php if ($p['Title'] == STATE) {
                               echo 'selected';
                             } ?>><?php echo $p['Title'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">जिल्ला</label>
                    <select class="form-control dd_select npl_district" id="district-3" required name="t_district">
                      <option value=""></option>
                      <?php if (!empty($districts)):
                        foreach ($districts as $d): ?>
                          <option value="<?php echo $d['id'] ?>" <?php if ($d['name'] == DISTRICT) {
                               echo 'selected';
                             } ?>><?php echo $d['name'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">ग.पा / न. पा</label>
                    <select class="form-control npl_gapana dd_select select_option" name="t_gapa" id="gapa-3" required>
                      <?php if (!empty($gapana)):
                        foreach ($gapana as $key => $gp): ?>
                          <option value="<?php echo $gp['id'] ?>" <?php if ($gp['name'] == GNAME) {
                               echo 'selected';
                             } ?>><?php echo $gp['name'] ?></option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">वडा </label>
                    <select class="select_option form-control" name="t_ward" required>
                      <option value="">छानुहोस</option>
                      <?php if (!empty($wards)):
                        foreach ($wards as $key => $w): ?>
                          <option value="<?php echo $w['name'] ?>"><?php echo $this->mylibrary->convertedcit($w['name']) ?>
                          </option>
                        <?php endforeach;
                      endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-12">
                  <h6>व्यवसायीको ३ पुस्ते विवरण</h6>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>बाजेको नाम</label>
                    <div class="">
                      <input type="text" name="grandfather_name" value="" class="form-control">
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>ठेगाना</label>
                    <div class="">
                      <input type="text" name="grandfather_address" value="" class="form-control">
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>बावुको नाम</label>
                    <div class="">
                      <input type="text" name="father_name" value="" class="form-control" required>
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>ठेगाना</label>
                    <div class="">
                      <input type="text" name="father_address" value="" class="form-control" required>
                    </div>
                  </div>
                </div>

                <!-- //बावुको नामः -->
              </div>
            </div>
          </section>
        </div>
        <div class="col-md-6">
          <section class="card">
            <header class="card-header text-light ">फर्म संचालन हुने घर वा जग्गाको स्वामित्व रहेको व्यक्ति विवरण
            </header>
            <div class="card-body">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>घर / जग्गा धनिको नाम</label>
                    <div class="">
                      <input type="text" name="landlord" value="" class="form-control" required>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="form-group">
                    <label>ठेगाना</label>
                    <div class="">
                      <input type="text" name="landlord_address" value="" class="form-control" required>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="form-group">
                    <label>मासिक भाडा रकम</label>
                    <div class="">
                      <input type="text" name="rent" value="" class="form-control" required>
                    </div>
                  </div>
                </div>
                <!-- //बावुको नामः -->
              </div>
            </div>
          </section>
        </div>
        <div class="col-md-6">
          <section class="card">
            <header class="card-header text-light ">कार्यालय प्रयोजन</header>
            <div class="card-body">
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label>निवेदन दस्तुर</label>
                    <div class="">
                      <input type="text" name="nibedan_dastur" value="" class="form-control" required>
                    </div>
                  </div>
                </div>

                <div class="col-md-4">
                  <div class="form-group">
                    <label>दर्ता दस्तुर</label>
                    <div class="">
                      <input type="text" name="darta_dastur" value="" class="form-control" required>
                    </div>
                  </div>
                </div>

                <div class="col-md-4">
                  <div class="form-group">
                    <label>व्यवसाय कर</label>
                    <div class="">
                      <input type="text" name="b_kar" value="" class="form-control" required>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>जरिवाना दस्तुर</label>
                    <div class="">
                      <input type="text" name="fine_amount" value="" class="form-control" required>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>जम्मा</label>
                    <div class="">
                      <input type="text" name="total_amount" value="" class="form-control" required>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>मिति</label>
                    <div class="">
                      <input type="text" id="rasid_date" name="rasid_date" value="" class="form-control nepaliDateD"
                        required>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>रसिद नं</label>
                    <div class="">
                      <input type="text" name="rasid_no" value="" class="form-control" required>
                    </div>
                  </div>
                </div>
                <!-- //बावुको नामः -->
              </div>
            </div>
          </section>
        </div>
        <!--<form class="form" method="post" action="<?php echo base_url() ?>Register/upload" enctype="multipart/form-data">-->
        <div class="col-md-12">
          <hr>
          <table class="table" id="add_new_image">
            <thead>
              <tr>
                <th>फाइल अपलोड गर्नुहोस</th>
                <th>फाइलको नाम</th>
                <th>#</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><input class="form-control" type="file" name="userfile[]"><span
                    style="color:red;margin-top:3px;font-size:14px;">Supported Format : only::jpg,png,pdf</span></td>
                <td><input class="form-control" name="image_t_name[]"></td>
                <td>#</td>
              </tr>
            </tbody>
          </table>
          <button type="button" class="btn btn-secondary btn-block NewImg"><i class="fa fa-plus-circle"></i> add new
          </button>
        </div>
        <!--</form>-->
        <div class="col-md-12 text-center">
          <hr>
          <button class="btn btn-primary btn-xs btn-save save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्"
            name="Submit" type="submit" value="Submit" id="btn_save_details"> सेभ गर्नुहोस्</button>
          <a href="<?php echo base_url() ?>Register" class="btn btn-danger btn-xs" data-toggle="tooltip"
            title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
        </div>
      </div>
    </form>
  </section>
</section>
<script type="text/javascript" src="<?php echo base_url() ?>assets/assets/select2/js/select2.min.js"></script>

<script type="text/javascript" src="<?php echo base_url() ?>assets/nepali_datepicker/nepali.datepicker.v2.2.min.js">
</script>
<script>
  $(document).ready(function () {
    $('#nepaliDateD').nepaliDatePicker();
    $('#rasid_date').nepaliDatePicker();
    $('#b_odarta_miti').nepaliDatePicker();
    $('#b_ctzn_date').nepaliDatePicker();
    $('#darta_entry_date').nepaliDatePicker();

    $('#b_type').change(function () {
      obj = $(this);
      var type = obj.val();
      $.ajax({
        url: base_url + 'CommonController/subtype',
        method: "POST",
        data: {
          type: type,
          '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        },
        success: function (resp) {
          if (resp.status == 'success') {
            $('#subtype').html(resp.option);
          }
        }
      });
    });

    $('.npl_state').change(function () {
      var id_selected = $(this).attr("id");
      var res = id_selected.split("-");
      var id = res[res.length - 1];
      var state = $(this).val();
      $.ajax({
        url: base_url + 'CommonController/getDistrictByState',
        method: "POST",
        data: {
          state: state,
          '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        },
        success: function (resp) {
          if (resp.status == 'success') {
            $('#district-' + id).html(resp.option);
          }
        }
      });
    });

    $('.npl_district').change(function () {
      var id_selected = $(this).attr("id");
      var res = id_selected.split("-");
      var id = res[res.length - 1];
      var district = $(this).val();
      $.ajax({
        url: base_url + 'CommonController/getGapanapaByDistricts',
        method: "POST",
        data: {
          district: district,
          '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        },
        success: function (resp) {
          if (resp.status == 'success') {
            $('#gapa-' + id).html(resp.option);
          }
        }
      });
    });

    //add new row
    $('.NewImg').click(function (e) {
      e.preventDefault();
      var new_row =
        '<tr>' +
        '<td><input class="form-control" type="file" name="userfile[]"></td>' +
        '<td><input type="text" name="image_t_name[]" class="form-control">' +
        '<td><button type="button" class="btn btn-danger remove-row" data-toggle="tooltip" title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>' +
        '<tr>'
      $("#add_new_image").append(new_row);
    });
    $("body").on("click", ".remove-row", function (e) {
      e.preventDefault();
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });

    $(document).on('input', '#fixed_capital, #chalu_capital', function () {
      var fc = $('#fixed_capital').val() || 0;
      var cc = $('#chalu_capital').val() || 0;
      var total = parseFloat(fc) + parseFloat(cc);
      $('#b_capital').val(total);
    });

  });
</script>