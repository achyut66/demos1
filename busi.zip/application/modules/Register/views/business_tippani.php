<style type="text/css">
.card-header {
  background: #1b5693;
}
</style>
<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/preview.css">
<section id="main-content">
    <section class="wrapper site-min-height">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"> ड्यासबोर्डमा जानुहोस</a></li>
          <li class="breadcrumb-item"><a href="<?php echo base_url() ?>Register">उद्योग र व्यवसाय दर्ता सुचीमा जानुहोस</a>
          </li>
          <li class="breadcrumb-item"><a href="javascript:;">प्रमाणपत्र</a></li>
        </ol>
      </nav>
      <div class="row">
        <div class="col-md-12">
          <section class="card" id="background-warpper">
            <?php $success_message = $this->session->flashdata("MSG_ERR");
              if (!empty($success_message)) { ?>
              <div class="alert alert-danger">
                <button class="close" data-close="alert"></button>
                <span> <?php echo $success_message; ?> </span>
              </div>
            <?php } ?>
            <div class="pro-img-box">
              <div class="row">
                <div class="col-md-4">
                  <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="" style="width:200px;height: 100px; padding-left:50px;">
                </div>
                <div class="col-md-4">
                    <h1 style="margin-top:10px;"><?php echo GNAME ?></h1>
                    <h5 style="margin-top:-12px; margin-left:40px;"><?php echo SLOGAN ?></h3>
                    <h5 style="margin-top:-12px; margin-left:60px;"><?php echo ADDRESS . ',' . DISTRICT ?></h3>
                    <h5 style="margin-top:-12px; margin-left:60px;"><?php echo STATENAME ?>,नेपाल</span>
                </div>
                <div class="col-md-12">
                  <!-- <div style="padding-left:50px;">
                    <p>आर्थिक वर्षः <?php echo $this->mylibrary->convertedcit($row['fiscal_year']) ?></p>
                    <p>दर्ता नं. <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?></p>
                  </div> -->
                  <!-- <h2 class="letter-title">व्यवसाय दर्ता प्रमाण-पत्र</h2> -->
                  <br>
                  <hr style="border:2px solid black;">
                  <div class="text-center"><h2 class="letter-title">व्यवसाय दर्ता प्रमाण-पत्र पठाइएको सम्बन्धमा</h2></div>

                  <div class="data_and_designation" style="padding-left:50px;">
                    <p>श्री. <b><?php echo $this->mylibrary->convertedcit($row['business_name_np']) ?></b></p>
                  </div>

                  <div class="pull-right" style="margin-top:20px;margin-right:50px;">मितिः <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></b></div>
                  
                  <div style="padding-left:50px;"><?php echo GNAME?></div>
                  <div class="oda_number" style="padding-left:50px;">
                    <p style="margin-top: 6px;">
                      <b>वडा नं. <?php echo $this->mylibrary->convertedcit($row['b_ward']) ?>, <?php echo DISTRICT ?> ।</b>
                    </p>
                  </div>
                  <p></p>
                </div>
                <div class="col-md-12">
                  <p style="text-align: justify;padding-left:50px;padding-right:50px; margin-top:50px;">उपरोक्त बिषयमा तपाईलाई स्थिर पूँजि रु.
                  <b><?=$this->mylibrary->convertedcit($row['fixed_capital'])?></b>/- चालु पूँजि रु. 
                  <b><?=$this->mylibrary->convertedcit($row['chalu_capital'])?></b>/- गरी कुल पूजि रु. 
                  <b><?=$this->mylibrary->convertedcit($row['b_captial'])?></b>/-
                  लगानी गरि 
                  <b><?=$this->mylibrary->convertedcit($row['b_workdetails'])?></b>
                  व्यवसाय गर्ने उद्देश्यले 
                  <b><?=$this->mylibrary->convertedcit($row['business_name_np'])?></b> नामको उद्योग व्यावसाय 
                  <b><?=$this->mylibrary->convertedcit(isset($bgapa['name']) ? $bgapa['name'] : '').' - वडा नं.'.$this->mylibrary->convertedcit($row['b_ward']).' '.$this->mylibrary->convertedcit(DISTRICT)?></b> मा 
                  स्थापना हुने गरि लघु उद्योग रजिष्ट्रेशन गरी पाउँ भनि दिनु भएको निवेदनमा कारवाही हुँदा मिति 
                  <b><?=$this->mylibrary->convertedcit($row['darta_miti'])?></b> गतेको निर्णयानुसार निम्न लिखित शर्तहरु अनिवार्य रुपमा पालना गर्ने गरि स्थानीय आर्थिक ऐन २०८० को दफा ५ अनुसार साझेदारी लघु 
                  उद्योग रजिष्ट्रेशन गरी तपाईको नाममा रजिष्ट्रेशन गरिएको व्य.द.नं. 
                  <b><?=$this->mylibrary->convertedcit($row['darta_no'].' / '.$this->mylibrary->convertedcit($row['fiscal_year']))?></b> को सक्कल प्रमाण पत्र पठाइएको छ ।</p>
                </div>
                <div class="text-left" style="margin-top:12px;padding-left: 63px;">
                    <p style="font-weight:bold;"><u>उद्योगले पालना गर्नु पर्ने शर्तहरु :</u></p>
                </div>
                <br>
                    <div class="text-left" style="margin-top:40px;margin-left: -132px;">
                    <ul>
                        <li>१) उद्योग संचालन गर्दा आवश्यक पर्ने सम्पूर्ण कच्चा पदार्थ उद्योगले स्वंय व्यवस्था गर्नु पर्नेछ ।</li>
                        <li>२) उद्योगको साइनबोर्ड र फर्मको प्याडमा रजिष्ट्रेशन नम्बर अनिवार्य रुपमा राख्नुपर्नेछ ।</li>
                        <li>३) उद्योग सञ्चालन गर्दा छर छिमेक कसैलाई पीर मर्का बाधा नपर्ने गरी उद्योग सञ्चालन गर्नु पर्नेछ । बाधा विरोध हुन आएमा उक्त उद्योग कार्यालयले आदेश दिएको मिति भित्र अन्यत्र ठाउँसारी गर्नुपर्नेछ ।</li>
                        <li>४) रात्रि शिफ्ट संचालन गर्नु पर्ने भएमा पूर्व स्वीकृति लिएर मात्र संचालन गर्न सकिनेछ ।</li>
                        <li>५) उद्योगलाई आवश्यक पर्ने जनशक्ति नेपाली नागरिकबाटै पूर्ति गर्नु पर्नेछ । विदेशी जनशक्ति विना उद्योग सञ्चालन हुन नसक्ने भएमा श्रम विभाग समेतको पूर्व स्वीकृति लिएर मात्र काममा लगाउन सकिनेछ ।</li>
                        <li>६) उद्योगको विस्तार, विविधिकरण वा स्तर परिवर्तन गर्दा पूर्व स्वीकृति गर्नु पर्नेछ ।</li>
                        <li>७) उद्योग दर्ता भएको ६ महिना भित्र वा कार्य योजना अनुसार अन्य म्याद तोकिएकोमा सो भित्र सञ्चालन हुन नसकेमा म्याद थप गराउनु पर्नेछ ।</li>
                        <li>८) उद्योग सञ्चालन गर्दा वातावरण प्रदुषण हुन नदिने गरी आवश्यक व्यवस्था गर्नु पर्नेछ ।</li>
                        <li>९) तोकिएको शर्तहरु पालना नभएकोमा वा प्रदत्त सुविधा तथा सहुलियतहरु दुरुपयोग भएको पाइएमा प्रचलित ऐन अनुसार कारबाही हुनेछ ।</li>
                        <li>१०) उद्योगको वार्षिक प्रगति विवरण आर्थिक वर्ष व्यतित भएको १५ दिन भित्र नियमित रुपमा पेश गर्नु पर्नेछ साथै सरकारी निकायबाट माग भएमा उद्योगसंग सम्बन्धित विवरणहरु यथा समयमा उपलब्ध गराउनु पर्नेछ ।</li>
                        <li>११) उद्योग दर्ता प्रमाणपत्रमा उल्लेखित उद्देश्य विपरीत कार्य गर्न पाइने छैन ।</li>
                        <li>१२) यसै नामबाट यस अघि अर्को उद्योग दर्ता भै सकेको देखिएमा यस उद्योगमा नाम परिवर्तन गर्नु पर्नेछ ।</li>
                        <li>१३) माथि उल्लेखित भए अनुसारका शर्तहरु पालना नगरेमा वा प्रगती विवरण नभएमा उद्योगले पाउने सुविधा तथा सहुलियतहरु उपलब्ध गराइने छैन ।</li>
                        <li>१४) विषेश शर्त :
                            <ul>
                                <li style="padding-left:15px;">क) अन्य निकायबाट अनुमति लिनु पर्ने भए अनुमति लिएर मात्र उद्योग संचालन गर्नु पर्ने छ ।</li>
                            </ul>
                        </li>
                    </ul>
                    </div>
                    <div class="text-right">
                    <form action="<?php echo base_url() ?>Register/updateMakerChecker" method="post" class="form save_post">
                        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                        value="<?php echo $this->security->get_csrf_hash(); ?>">
                        <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                        <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                            <label>तयार गर्नेको नाम <span style="color: red"> *</span></label>
                            <select class="form-control" name="maker" id="maker">
                                <option value="">--छान्नुहोस्--</option>
                                <?php if (!empty($staffs)) : foreach ($staffs as $staff) : ?>
                                <option value="<?php echo $staff['id'] ?>"
                                <?php if($staff['id'] == $row['maker']){ echo 'selected';}?>><?php echo $staff['name'] ?></option>
                                <?php endforeach;
                                endif; ?>
                            </select>
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                            <label>तयार गर्नेको पद<span style="color: red"> *</span></label>
                            <input type="text" class="form-control" id="deg_maker"
                                value="<?php echo !empty($row['maker'])?$maker['designation']:''?>" readonly />
                            </div>
                        </div>
                    </div>
                </form>
                <!-- <div class="col-md-12">
                  <div class="name_address_puji_bibarand" style="margin-top:20px;padding-left:50px;">
                    <p>१. व्यवसायको नामः <b><?php echo $this->mylibrary->convertedcit($row['business_name_np']) ?></b></p>
                    <p style="margin-top:20px;">२. व्यवसाय गर्ने ठेगाना:  <b><?php echo $this->mylibrary->convertedcit($row['b_tol'] . '-' .$this->mylibrary->convertedcit($row['b_ward'])) ?></b></p> 
                  <div>
                  <p style="margin-top:20px;">३. कुल पूँजी रु. <b><?php echo $this->mylibrary->convertedcit($row['b_captial']) ?></b> </p>
                  <div class="total_investment" style="margin-top: 20px;padding-left:50px;">
                  <p style="width:250px; ">क) चालू पूँजी रु: <b><?php echo $this->mylibrary->convertedcit($row['chalu_capital']) ?></b></p>
                  <p style="margin-left:65px;">ख) <b><?php echo $this->mylibrary->convertedcit($row['fixed_capital']) ?></b></p>
                </div> -->
              <!-- <div>
              <p style="margin-top:10px;">४. व्यवसाय संचालकको विवरण:</p>
              <div class="bebasaya_bibarand">
                <p>क) नाम: <b><?php echo $this->mylibrary->convertedcit($row['b_owner_name']) ?></b></p>
                <p style="margin-left:243px">ख) साविक ठेगाना: ...................................................</p>
              </div>
              <br>
              <div class="bebasaya_bibarand">
                <p style="margin-top:10px;">ग) हालको ठेगाना: <b><?php echo $this->mylibrary->convertedcit($tgapa['name']) .'-'. $this->mylibrary->convertedcit($row['t_ward'])?></b></p>
                <p style="margin-top:10px; margin-left:167px;">घ) बाबुको नामः <b><?php echo $this->mylibrary->convertedcit($row['father_name']) ?></b></p>
              </div>
              <br>
              <div class="bebasaya_bibarand">
                <p style="margin-top:10px;">ङ) बाजेको नाम:. <b><?php echo $this->mylibrary->convertedcit($row['grandfather_name']) ?></b></p>
                <p style="margin-top:10px;margin-left:321px;">च) आमाको नामः </p>
              </div>
              <br>
              <h5 class="letter-title">प्रमाण पत्र दिने अधिकारीको</h5>
            </div> -->
            <!-- <div class="centre_text">
              <p>नाम थर: .....................................................</p>
              <p style="margin-top:-32px;margin-left:-32px;"><b><?php echo !empty($checker['name']) ? $checker['name'] :'' ?></b></p>
              <p style="margin-top:10px;">दस्तखतः.......................................................</p>
              <p>मितिः...........................................................</p>
              <p style="margin-top:-32px;margin-left:-27px;"><b><?php echo $this->mylibrary->convertedcit(convertDate(date('Y-m-d'))) ?></b></p>
            </div>
            <hr>
            <div class="col-md-12">
              <form action="<?php echo base_url() ?>Register/updateMakerChecker" method="post" class="form save_post">
                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                  value="<?php echo $this->security->get_csrf_hash(); ?>">
                <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                <div class="row">
                  <div class="col-md-3">
                    <div class="form-group">
                      <label>तयार गर्नेको नाम <span style="color: red"> *</span></label>
                      <select class="form-control" name="maker" id="maker">
                        <option value="">--छान्नुहोस्--</option>
                        <?php if (!empty($staffs)) : foreach ($staffs as $staff) : ?>
                        <option value="<?php echo $staff['id'] ?>"
                          <?php if($staff['id'] == $row['maker']){ echo 'selected';}?>><?php echo $staff['name'] ?></option>
                        <?php endforeach;
                          endif; ?>
                      </select>
                    </div>
                  </div>

                  <div class="col-md-2">
                    <div class="form-group">
                      <label>तयार गर्नेको पद<span style="color: red"> *</span></label>
                      <input type="text" class="form-control" id="deg_maker"
                        value="<?php echo !empty($row['maker'])?$maker['designation']:''?>" readonly />
                    </div>
                  </div>

                  <div class="col-md-3">
                    <div class="form-group">
                      <label>प्रमाणित गर्नेको नाम<span style="color: red"> *</span></label>
                      <select class="form-control" name="checker" id="checker">
                        <option value="">--छान्नुहोस्--</option>
                        <?php if (!empty($staffs)) : foreach ($staffs as $staff) : ?>
                        <option value="<?php echo $staff['id'] ?>"
                          <?php if($staff['id'] == $row['checker']){ echo 'selected';}?>><?php echo $staff['name'] ?></option>
                        <?php endforeach;
                          endif; ?>
                      </select>
                    </div>
                  </div>

                  <div class="col-md-2">
                    <div class="form-group">
                      <label>प्रमाणित गर्नेको पद<span style="color: red"> *</span></label>
                      <input type="text" class="form-control" id="deg_checker"
                        value="<?php echo !empty($row['checker'])?$checker['designation']:''?>" readonly />
                    </div>
                  </div>

                  <div class="col-md-2">
                    <div class="form-group">
                      <button class="btn btn-primary btn-xs btn-save save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्"
                        name="Submit" type="submit" value="Submit" id="btn_save_details" style="margin-top:23px;"> सेभ
                        गर्नुहोस्</button>
                    </div>
                  </div>

                </div>
              </form>
              <hr>
            </div>
            <a href="<?php echo base_url() ?>Register/PrintCertificate/<?php echo $row['id'] ?>/3" class="adtocart">
              <i class="fa fa-print"></i>
            </a>
          </section>
        </div>
      </div>
      <hr>
      <div class="row">
        <div class="col-md-12">
          <section class="card" id="background-warpper">
            <table class="">
              <thead>
                <tr>
                  <th rowspan = '2'>क्र स्.</th>
                  <th rowspan = '2'>नबिकरण गरेको मिति</th>
                  <th rowspan = '2'>इजाजत-पत्र बहाल रहने अविधि</th>
                  <th colspan = "7" style="text-align:center">व्यवसाय कर रकम सम्बम्धि विवरण</th>
                </tr>
                <tr>
                  <th>व्यवसाय कर वापत लाग्ने रकम</th>
                  <th>छुट रकम</th>
                  <th>बक्यौता रकम</th>
                  <th>जरिवाना</th>
                  <th>प्रमाण पत्र दस्तुर</th>
                  <th>जम्मा असुली भएको रकम</th>
                  <th>दस्तखत</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>१</td>
                  <td></td>
                  <td>.... असार मसान्तसम्म</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td>२</td>
                  <td></td>
                  <td>.... असार मसान्तसम्म</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td>३</td>
                  <td></td>
                  <td>.... असार मसान्तसम्म</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td>४</td>
                  <td></td>
                  <td>.... असार मसान्तसम्म</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td>५</td>
                  <td></td>
                  <td>.... असार मसान्तसम्म</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td>६</td>
                  <td></td>
                  <td>.... असार मसान्तसम्म</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td>७</td>
                  <td></td>
                  <td>.... असार मसान्तसम्म</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td>८</td>
                  <td></td>
                  <td>.... असार मसान्तसम्म</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td>९</td>
                  <td></td>
                  <td>.... असार मसान्तसम्म</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td>१०</td>
                  <td></td>
                  <td>.... असार मसान्तसम्म</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td>११</td>
                  <td></td>
                  <td>.... असार मसान्तसम्म</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td>१२</td>
                  <td></td>
                  <td>.... असार मसान्तसम्म</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
              </tbody>
            </table>
            <a href="<?php echo base_url() ?>Register/PrintSecondPart/<?php echo $row['id'] ?>/3" class="adtocart">
              <i class="fa fa-print"></i>
            </a>
          </section>
        </div>
      </div> -->
    </section>
  </section>
</section>

<script type="text/javascript">
$(document).ready(function() {
  var base_url = "<?php echo base_url() ?>";
  $('#maker').change(function() {
    obj = $(this);
    var maker = obj.val();
    var id = "<?php echo $this->uri->segment(3) ?>";
    $.ajax({
      url: base_url + 'Register/updateMaker',
      method: "POST",
      data: {
        maker: maker,
        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
      },
      success: function(resp) {
        $('#deg_maker').val(resp.data.designation);
        // if (resp.status == 'success') {
        //   location.reload();
        // }
      }
    });
  });
  $('#checker').change(function() {
    obj = $(this);
    var checker = obj.val();
    var id = "<?php echo $this->uri->segment(3) ?>";
    $.ajax({
      url: base_url + 'Register/updateChecker',
      method: "POST",
      data: {
        checker: checker,
        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
      },
      success: function(resp) {
        if (resp.status == 'success') {
          $('#deg_checker').val(resp.data.designation);
        }
      }
    });
  });
});
</script>