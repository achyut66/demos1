<!DOCTYPE html>
<html>
  <head>
    <title>Full-Screen Image</title>
    <style>
     .image{
        height:837px;
        width:842px;
        margin-top:5px;
        margin-left:331px;
     }
    </style>
  </head>
  <body>
      <?php //pp($image_path);?>
    <div class="image-container">
      <img class="image" src="<?php echo $image_path?>" alt="Full-Screen Image">
    </div>
  </body>
</html>
