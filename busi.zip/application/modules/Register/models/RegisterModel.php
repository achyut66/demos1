<?php

/**
 * Created by PhpStorm.
 * User: root
 */
class RegisterModel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    //get distinct data
    public function getDistinctParkar()
    {
        $this->db->distinct();
        $this->db->select('main_topic');
        $this->db->from('prakar');
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function getSubTopic()
    {
        $this->db->select('sub_topic');
        $this->db->from('prakar');
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function GetMaxDartaID()
    {
        $maxid = 0;
        $row = $this->db->query("SELECT MAX(`id`) AS `darta_no` FROM `darta`")->row();
        return $row;
    }

    public function GetAll($limit, $start, $col, $dir, $main_topic = NULL, $business_name = NULL, $darta_no = NULL, $darta_miti = NULL)
    {
        $this->db->select('*')->from('darta');
        if (!empty($main_topic)) {
            $this->db->where('b_type', $main_topic);
        }
        if (!empty($business_name)) {
            $this->db->like('business_name_np', $business_name);
        }
        if (!empty($darta_no)) {
            $this->db->where('darta_no', $darta_no);
        }
        if (!empty($darta_miti)) {
            $this->db->where('darta_miti', $darta_miti);
        }

        if ($this->session->userdata('PRJ_USER_BID') != 1) {
            $this->db->where('added_ward', $this->session->userdata('PRJ_USER_WARD'));
        }
        $this->db->where('is_trash', 0);
        $this->db->limit($limit, $start);
        $this->db->order_by('darta_no', 'desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return null;
        }
    }
    public function GetAllMigration($limit, $start, $col, $dir, $main_topic = NULL, $business_name = NULL, $darta_no = NULL, $darta_miti = NULL, $prev_darta_id)
    {
        $this->db->select('*')->from('darta_migration');
        if (!empty($main_topic)) {
            $this->db->where('b_type', $main_topic);
        }
        if (!empty($business_name)) {
            $this->db->like('business_name_np', $business_name);
        }
        if (!empty($darta_no)) {
            $this->db->where('darta_no', $darta_no);
        }
        if (!empty($darta_miti)) {
            $this->db->where('darta_miti', $darta_miti);
        }

        if ($this->session->userdata('PRJ_USER_BID') != 1) {
            $this->db->where('added_ward', $this->session->userdata('PRJ_USER_WARD'));
        }
        $this->db->where('is_trash', 0);
        $this->db->limit($limit, $start);
        $this->db->order_by('darta_no', 'desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return null;
        }
    }

    /**
     * This function on ajax call get list of land owner profile
     * This function is used for datatables for server side uses
     * @param INT $limit, INT $start, INT $col, INT $fiscal, INT $fiscal_year
     * @return json
     */
    public function CountAll($main_topic = NULL, $business_name = NULL, $darta_no = NULL, $darta_miti = NULL)
    {
        $this->db->select('*')->from('darta');
        if (!empty($main_topic)) {
            $this->db->where('b_type', $main_topic);
        }
        if (!empty($business_name)) {
            $this->db->like('business_name_np', $business_name);
        }
        if (!empty($darta_no)) {
            $this->db->where('darta_no', $darta_no);
        }
        if (!empty($darta_miti)) {
            $this->db->where('darta_miti', $darta_miti);
        }
        if ($this->session->userdata('PRJ_USER_BID') != 1) {
            $this->db->where('added_ward', $this->session->userdata('PRJ_USER_WARD'));
        }
        $query = $this->db->get();
        return $query->num_rows();
    }

    //check for darta details 
    // public function checkDartaDetails($darta_id) {
    //     $this->db->select('*')
    // }
}