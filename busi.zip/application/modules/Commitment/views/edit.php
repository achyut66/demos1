<div class="valid_errors"></div>

<form action="<?php echo base_url()?>Commitment/Update" method="post" class="form save_post">

  <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">

  <div class="form-group">

    <div class="col-md-12">

       <input type="hidden" class="form-control" placeholder=""  name="id" value="<?php echo $row['id']?>">

     

      <div class="form-group">

       <label><b>शर्त</b></label>
       <textarea class="form-control" name="commits" required><?php echo $row['commits']?></textarea>

      </div>
      <div class="form-group">
       <label><b>किसिम</b></label>
        <select class="form-control" name="type">
          <option value="">छानुहोस</option>
          <option value="1" <?php if($row['type'] == 1 ){ echo 'selected'; }?>>द्रष्टब्य</option>
          <option value="2" <?php if($row['type'] == 2 ){ echo 'selected'; }?>>उद्योगले पालना गर्नु पर्ने शर्तहरु</option>
          <option value="3" <?php if($row['type'] == 3 ){ echo 'selected'; }?>>विषेश शर्त</option>
        </select>
      </div>
    </div>

  </div>

  <div class="modal-footer">

    <button class="btn btn-primary btn-xs save_btn" data-toggle="tooltip" title="सम्पादन गर्नुहोस्" name="Submit" type="submit" value="Submit">सम्पादन गर्नुहोस्</button>

    <button type="button" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्" data-dismiss="modal">रद्द गर्नुहोस्</button>

  </div>

</form>