<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/landscape_print.css"> -->
    <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
    <!-- Bootstrap CSS -->

    <title>
        <?php echo GNAME ?>
    </title>

    <style>
        .title {
            height: 45px;
            width: 485px;
            border: 1px solid #555;
            margin-left: 312px;
            border-radius: 25px;
            text-align: center;
            /* border-radius: 25px; */
            margin-top: 30px;
        }

        .stamp {
            /* border: 2px solid #555; */
            /* height: 62px;
    width: 202px;
     */
            margin-left: 487px;
            border-radius: 5px;
            text-align: right;
            margin-right: 120px;
            margin-top: 50px;
        }

        @media print {
            @page {
                size: landscape;
            }
        }

        .title {
            margin-left: 355px;
            border: 2px solid black;
            padding: 10px;
            display: inline-block;
        }
    </style>
</head>

<body>
    <div class="main-wrapper">
        <div class="wrapper">
            <div class="text title" style="margin-left:237px;font-size:16px;font-weight:bold;">नवीकरण सम्बन्धि विवरण
            </div>
            <br>
            <br>

            <table class="table table-bordered table-responsive" style="border:1px solid black;">
                <tr class="text-center" style="font-weight:bold;">
                    <td rowspan="2">क्र.स</td>
                    <td rowspan="2">नवीकरण गरेको मिति</td>
                    <td rowspan="2">प्रमाण-पत्र बहाल रहने अवधि</td>
                    <td colspan="8">प्रमाण-पत्र सम्बन्धि विवरण</td>
                </tr>
                <tr class="text-center" style="font-weight:bold;">
                    <td>प्रमाण-पत्र वापत रकम</td>
                    <td>छुट रकम</td>
                    <td>बक्यौता रकम</td>
                    <td>जरिवाना</td>
                    <td>प्रमाण-पत्र दस्तुर</td>
                    <td>जम्मा असुली भएको रकम</td>
                    <td>दस्तखत</td>

                </tr>
                <tr>
                    <td>१.</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>२.</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>३.</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>४.</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>५.</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>६.</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>७.</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>८.</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>९.</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>१०.</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>११.</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>१२.</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            </table>
        </div> <!-- endof warpper-->
    </div><!-- endof main-warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
    window.print();
</script>

</html>