 <!--main content start-->
 <style>
thead {
  background: red;
}

.table-bordered td,
.table-bordered th {
  border: 1px solid #3a5d7f;
}
 </style>
 <section id="main-content">
   <section class="wrapper site-min-height">
     <nav aria-label="breadcrumb">
       <ol class="breadcrumb">
         <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"><i class="fa fa-home"></i> ड्यासबोर्डमा</a></li>
         <li class="breadcrumb-item active"><a href="<?php echo base_url() ?>Khanepani" class="bactive">खानेपानी
             मुल/खानेपानी तथा सरसफाई उपभोक्ता संस्था दर्ता</a></li>
         <li class="breadcrumb-item active"><a href="javascript:;" class="bactive">विवरण हेर्नुहोस</a></li>
       </ol>
     </nav>
     <!-- page start-->
     <div class="row">
       <aside class="profile-info col-lg-9">
         <section class="card">
           <header class="card-header text-light " style="background-color:#4d5886">उपभोक्ता समितिको नामः:
             <?php echo $row['name'] ?> <span class="btn btn-success btn-circle"> दर्ता नं.
               <?php echo $this->mylibrary->convertedcit($row['darta_no']) ?></span>
           </header>
           <div class="card-body">
             <div class="row">
               <div class="col-md-12">
                 <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
                                    if (!empty($success_message)) { ?>
                 <div class="alert alert-success">
                   <button class="close" data-close="alert"></button>
                   <span> <?php echo $success_message; ?> </span>
                 </div>
                 <?php } ?>

                 <?php $err_message = $this->session->flashdata("MSG_ERR");
                                    if (!empty($err_message)) { ?>
                 <div class="alert alert-danger">
                   <button class="close" data-close="alert"></button>
                   <span> <?php echo $err_message; ?> </span>
                 </div>
                 <?php } ?>
                 <?php $err_message = $this->session->flashdata("MSG_WAR");
                                    if (!empty($err_message)) { ?>
                 <div class="alert alert-warning">
                   <button class="close" data-close="alert"></button>
                   <span> <?php echo $err_message; ?> </span>
                 </div>
                 <?php } ?>


                 <table class="table table-bordered">
                   <tr>
                     <td><strong><span>दर्ता मिति:
                         </span><?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?></strong></td>
                     <td><strong><span>कार्यक्षेत्र:</span>
                         <?php echo $this->mylibrary->convertedcit($row['working_area']) ?></strong></td>
                     <td><strong><span>आर्थिक श्रोतको विवरण:</span>
                         <?php echo $this->mylibrary->convertedcit($row['sorot']) ?></strong></td>

                   </tr>
                 </table>
               </div>
             </div>
           </div>
         </section>
         <section class="card">
           <header class="card-header text-light " style="background-color:#4d5886">उद्देश्यहरु</header>
           <div class="card-body">
             <div class="row">
               <div class="col-md-12">
                 <table class="table table-hover personal-task">
                   <tbody>
                     <?php $amis = explode('<>', $row['aim']);
                                            if (!empty($amis)) : $i = 1;
                                                foreach ($amis as $key => $ami) : ?>
                     <tr>
                       <td style="width:50px;"><?php echo $this->mylibrary->convertedcit($i++) ?></td>
                       <td style="text-align:left"><?php echo $this->mylibrary->convertedcit($ami) ?></td>
                     </tr>
                     <?php endforeach;
                                            endif; ?>
                   </tbody>
                 </table>
               </div>
             </div>
           </div>
         </section>

         <section class="card">
           <header class="card-header text-light " style="background-color:#4d5886">सदस्यहरुको विवरण</header>
           <div class="card-body">
             <div class="row">
               <div class="col-md-12">
                 <table class="table table-hover">
                   <thead style="background-color:#fff;color:#000">
                     <tr>
                       <th>क्र.स.</th>
                       <th>नाम</th>
                       <th>ठेगाना</th>
                       <th>पेशा</th>
                       <th>ना.प्र.प.नं.</th>
                       <th>सम्पर्क नं.</th>
                     </tr>
                   </thead>
                   <tbody>
                     <?php
                                            if (!empty($members)) : $i = 1;
                                                foreach ($members as $key => $member) : ?>
                     <tr>
                       <td style="width:50px;"><?php echo $this->mylibrary->convertedcit($i++) ?></td>
                       <td style="text-align:left"><?php echo $this->mylibrary->convertedcit($member['name']) ?></td>
                       <td style="text-align:left"><?php echo $this->mylibrary->convertedcit($member['address']) ?></td>
                       <td style="text-align:left"><?php echo $this->mylibrary->convertedcit($member['occupation']) ?>
                       </td>
                       <td style="text-align:left"><?php echo $this->mylibrary->convertedcit($member['czn_no']) ?></td>
                       <td style="text-align:left"><?php echo $this->mylibrary->convertedcit($member['contact_no']) ?>
                       </td>
                     </tr>
                     <?php endforeach;
                                            endif; ?>
                   </tbody>
                 </table>
               </div>
             </div>
           </div>
         </section>

         <section class="card">
           <header class="card-header text-light " style="background-color:#4d5886">उपयोग गरिने जलश्रोतको विवरण</header>
           <div class="card-body">
             <div class="row">
               <div class="col-md-12">
                 <table class="table table-hover">
                   <thead>
                     <tr>
                       <th>क्र.स.</th>
                       <th>जलश्रोतको नाम</th>
                       <th>जलश्रोत रहेको ठाउँ</th>
                       <th>जलश्रोतबाट गरिने प्रयोग</th>
                       <th>उपभोक्ता संस्थाले उपयोग गर्न चाहेको जलश्रोतको परिमाण</th>
                       <th>उक्त जलश्रोतको हाल भईरहेको उपयोग</th>
                     </tr>
                   </thead>
                   <tbody>
                     <?php
                                            if (!empty($jalsorots)) : $i = 1;
                                                foreach ($jalsorots as $key => $jalsorot) : ?>
                     <tr>
                       <td style="width:50px;"><?php echo $this->mylibrary->convertedcit($i++) ?></td>
                       <td style="text-align:left">
                         <?php echo $this->mylibrary->convertedcit($jalsorot['jalsorot_name']) ?></td>
                       <td style="text-align:left">
                         <?php echo $this->mylibrary->convertedcit($jalsorot['jalsorot_address']) ?></td>
                       <td style="text-align:left">
                         <?php echo $this->mylibrary->convertedcit($jalsorot['jalsorot_usages']) ?></td>
                       <td style="text-align:left">
                         <?php echo $this->mylibrary->convertedcit($jalsorot['jalsorot_amount']) ?></td>
                       <td style="text-align:left">
                         <?php echo $this->mylibrary->convertedcit($jalsorot['jalsorot_current_usages']) ?></td>
                     </tr>
                     <?php endforeach;
                                            endif; ?>
                   </tbody>
                 </table>
               </div>
             </div>
           </div>
         </section>

         <section class="card">
           <header class="card-header text-light " style="background-color:#4d5886">उपभोक्ता समितिले पु¥याउन चाहेको सेवा
             सम्बन्धी विवरणः</header>
           <div class="card-body">
             <div class="row">
               <div class="col-md-12">
                 <table class="table table-hover">
                   <thead>
                     <tr>
                       <th>क्र.स.</th>
                       <th>सेवाको किसिम</th>
                       <th>सेवा पु¥याउने क्षेत्र</th>
                       <th>सेवाबाट लाभान्वित हुने उपभोक्ताहरुको संख्या</th>
                       <th>भविष्यमा सेवा विस्तार गर्न सकिने सम्भावना</th>
                     </tr>
                   </thead>
                   <tbody>
                     <?php
                                            if (!empty($sewas)) : $i = 1;
                                                foreach ($sewas as $key => $sewa) : ?>
                     <tr>
                       <td style="width:50px;"><?php echo $this->mylibrary->convertedcit($i++) ?></td>
                       <td style="text-align:left"><?php echo $this->mylibrary->convertedcit($sewa['sewa']) ?></td>
                       <td style="text-align:left"><?php echo $this->mylibrary->convertedcit($sewa['sewa_area']) ?></td>
                       <td style="text-align:left"><?php echo $this->mylibrary->convertedcit($sewa['total_user']) ?>
                       </td>
                       <td style="text-align:left"><?php echo $this->mylibrary->convertedcit($sewa['has_enanchment']) ?>
                       </td>
                     </tr>
                     <?php endforeach;
                                            endif; ?>
                   </tbody>
                 </table>
               </div>
             </div>
           </div>
         </section>

         <section class="card">
           <header class="card-header text-light " style="background-color:#4d5886">नवीकरणको विवरण</header>
           <div class="card-body">
             <div class="row">
               <div class="col-md-12">
                 <table class="table" id="add_new_fields">
                   <thead style="background:#000">
                     <tr>
                       <th>मिति</th>
                       <th>आ. व. देखि</th>
                       <th>आ. व. देखि</th>
                       <th>रसिद नं</th>
                       <th>बुझाएको दस्तुर</th>
                       <th>कैफियत</th>
                     </tr>
                   </thead>
                   <tbody>
                     <?php if (!empty($renew_details)) : foreach ($renew_details as $renew) : ?>
                     <tr>

                       <td><?php echo $this->mylibrary->convertedcit($renew['date']) ?></td>
                       <td><?php echo $this->mylibrary->convertedcit($renew['fiscal_year_from']) ?></td>
                       <td><?php echo $this->mylibrary->convertedcit($renew['fiscal_year_to']) ?></td>
                       <td><?php echo $this->mylibrary->convertedcit($renew['rasid_no']) ?></td>
                       <td><?php echo $this->mylibrary->convertedcit($renew['dastur']) ?></td>
                       <td><?php echo $this->mylibrary->convertedcit($renew['remarks']) ?></td>
                     </tr>
                     <?php endforeach;
                                            endif; ?>
                   </tbody>
                 </table>
               </div>
             </div>
           </div>
         </section>
       </aside>
       <aside class="profile-nav col-lg-3">
         <section class="card">
           <div class="user-heading round">
             <!-- <a href="#" data-toggle="modal" data-target="#editModel" data-url="<?php //echo base_url()
                                                                                                    ?>Register/updatePhoto" data-id = "<?php //echo $row['id']
                                                                                                                                        ?>">
                            <img src="<?php //echo base_url()
                                        ?>assets/business_owner/<?php //echo !empty($row['image'])?$row['image']:'emt.jpg'
                                                                ?>" alt="">
                        </a>  -->
             <h1><?php echo !empty($row['name']) ? $row['name'] : '' ?></h1>
             <p>
               <?php echo $row['tol'] . '-' . $this->mylibrary->convertedcit($row['p_ward']) . ' ,' . $this->mylibrary->convertedcit($row['p_gapa']) ?>,<?php echo $row['p_district']; ?><br><?php echo $row['p_pardesh']; ?>
             </p>
           </div>

           <ul class="nav nav-pills nav-stacked">
             <li class="active nav-item"><a class="nav-link"
                 href="<?php echo base_url() ?>Khanepani/edit/<?php echo $row['id'] ?>"> <i class="fa fa-pencil"></i>
                 विवरण सम्पादन गर्नुहोस्</a></li>
             <li class="nav-item"><a class="nav-link"
                 href="<?php echo base_url() ?>Khanepani/printcertificate/<?php echo $row['id'] ?>" target="_blank"> <i
                   class="fa fa-print"></i>प्रमाणपत्र प्रिन्ट गर्नुहोस् </a></li>
             <!-- <li class="nav-item"><a class="nav-link" href="<?php echo base_url() ?>Khanepani/listNabikarnDetails/<?php echo $row['id'] ?>"> <i class="fa fa-file"></i>नवीकरणको विवरण </a></li> -->
 <li class="nav-item"><a class="nav-link" href="<?php echo base_url()?>Khanepani/ShowFiles/<?php echo $row['id']?>"><i class="fa fa-file"></i>अपलोड फाइल हेर्नुहोस</a></li>

           </ul>
         </section>
       </aside>
     </div>
   </section>
 </section>
 <!--main content end-->