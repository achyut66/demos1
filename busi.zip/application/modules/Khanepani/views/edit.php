<style type="text/css">
.card-header {
  background: #1b5693;
}
</style>
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url()?>"> ड्यासबोर्डमा</a></li>
        <li class="breadcrumb-item"><a href="<?php echo base_url()?>Khanepani">खानेपानी मुल/खानेपानी तथा सरसफाई उपभोक्ता
            संस्था दर्ता सुची </a></li>
        <li class="breadcrumb-item"><a href="javascript:;">नयाँ थप्नुहोस्</a></li>
      </ol>
    </nav>

    <form class="form" method="post" action="<?php echo base_url()?>Khanepani/update" enctype="multipart/form-data">
      <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
        value="<?php echo $this->security->get_csrf_hash(); ?>">
      <div class="row">
        <div class="col-sm-12">
          <?php $ERR_VALIDATION = $this->session->flashdata("ERR_VALIDATION");
              if(!empty($ERR_VALIDATION)) { ?>
          <div class="alert alert-danger">
            <button class="close" data-close="alert"></button>
            <span> <?php echo $ERR_VALIDATION;?> </span>
          </div>
          <?php } ?>
          <?php $success_message = $this->session->flashdata("MSG_EMP");
              if(!empty($success_message)) { ?>
          <div class="alert alert-success">
            <button class="close" data-close="alert"></button>
            <span> <?php echo $success_message;?> </span>
          </div>
          <?php } ?>

          <?php $ERR_UPLOAD = $this->session->flashdata("ERR_UPLOAD");
              if(!empty($ERR_UPLOAD)) { ?>
          <div class="alert alert-success">
            <button class="close" data-close="alert"></button>
            <span> <?php echo $ERR_UPLOAD;?> </span>
          </div>
          <?php } ?>
          <section class="card">
            <header class="card-header text-light ">खानेपानी मुल/खानेपानी तथा सरसफाई उपभोक्ता संस्था दर्ता फारम</header>
            <div class="card-body">
              <div class="row">
                <input type="hidden" name="id" value="<?php echo $row['id']?>">
                <input type="hidden" name="darta_no" value="<?php echo $row['darta_no']?>">
                <div class="col-md-3">
                  <div class="form-group">
                    <label><b>मिति</b><span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name=""
                      value="<?php echo $row['darta_miti']?>" readonly>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>उपभोक्ता समितिको नाम<span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="name"
                      value="<?php echo $row['name']?>">
                  </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                      <label>समिति अध्यक्षको नाम<span style="color: red">*</span></label>
                      <input type="text" class="form-control" placeholder=""  name="ad_name" value="<?php echo $row['ad_name']?>">
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>समिति अध्यक्षको पद<span style="color: red">*</span></label>
                      <input type="text" class="form-control" name="ad_pad" placeholder="अध्यक्ष" value="<?php echo $row['ad_pad']?>">
                    </div>
                  </div>

                <div class="col-md-4">
                  <div class="form-group">
                    <label>कार्यक्षेत्र<span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="working_area"
                      value="<?php echo $row['working_area']?>">
                  </div>
                </div>
                <!-- //कार्यक्षेत्रः -->
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">प्रदेश </label>
                    <select class="form-control dd_select npl_state" name="p_pardesh" required id="state-2">
                      <option value="">छान्नुहोस्</option>
                      <?php if(!empty($pradesh)) : 
                            foreach ($pradesh as $key => $p) : ?>
                      <option value="<?php echo $p['Title']?>"
                        <?php if($p['Title'] == $row['p_pardesh']) {echo 'selected';}?>><?php echo $p['Title']?>
                      </option>
                      <?php endforeach;endif;?>
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">जिल्ला</label>
                    <select class="form-control dd_select npl_district" id="district-2" required name="p_district">
                      <option value=""></option>
                      <?php if(!empty($districts)) : 
                            foreach($districts as $d) :?>
                      <option value="<?php echo $d['name']?>"
                        <?php if($d['name'] == $row['p_district']) {echo 'selected';}?>><?php echo $d['name']?></option>
                      <?php endforeach;endif;?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">ग.पा / न. पा</label>
                    <select class="form-control npl_gapana dd_select select_option" name="p_gapa" id="gapa-2" required>
                      <?php if(!empty($gapana)) :
                          foreach ($gapana as $key => $gp) : ?>
                      <option value="<?php echo $gp['name']?>" <?php if($gp['name'] == $row['p_gapa']){
                                echo 'selected';
                              } ?>><?php echo $gp['name']?></option>
                      <?php endforeach;endif;?>
                    </select>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-group">
                    <label class="">वडा </label>
                    <select class="select_option form-control npl_state" name="p_ward">
                      <option value="">छानुहोस</option>
                      <?php if(!empty($wards)) : 
                          foreach ($wards as $key => $w) : ?>
                      <option value="<?php echo $w['name']?>"
                        <?php if($w['name'] == $row['p_ward']){ echo 'selected';}?>>
                        <?php echo $this->mylibrary->convertedcit($w['name'])?></option>
                      <?php endforeach;endif;?>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>टोल<span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="tol" id="tol"
                      value="<?php echo $row['tol']?>">
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>आर्थिक श्रोतको विवरण <span style="color: red">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="sorot" id="sorot"
                      value="<?php echo $row['sorot']?>">
                  </div>
                </div>

              </div>
              <div class="row">
                <div class="col-md-12">
                  <hr>
                  <h4>संस्थाको उद्देश्यहरु</h4>
                  <table class="table" id="add_new_fields">
                    <thead>
                      <tr>
                        <th>उद्देश्य</th>
                        <th style="width:50px;">#</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $amis = explode('<>',$row['aim']);
                          if(!empty($amis)) :$i=1; foreach($amis as $key => $ami) : ?>
                      <tr>
                        <td><textarea class="form-control" name="aim[]"><?php echo $ami?></textarea></td>
                        <td><button type="button" class="btn btn-danger remove-row" data-toggle="tooltip"
                            title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>
                      </tr>
                      <?php endforeach;endif;?>
                    </tbody>
                  </table>
                  <button type="button" class="btn btn-secondary btnAddNew"><i class="fa fa-plus-circle"></i> नयाँ
                    संस्थाको उद्देश्य थप्नुहोस </button>
                </div>

                <div class="col-md-12">
                  <hr>
                  <h4>सदस्यहरुको विवरण</h4>
                  <table class="table" id="add_new_members">
                    <thead>
                      <tr>
                        <th>नाम</th>
                        <th>ठेगाना</th>
                        <th>पेशा</th>
                        <th>ना.प्र.प.नं.</th>
                        <th>सम्पर्क नं.</th>
                        <th style="width:50px;">#</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if(!empty($members)) : 
                          foreach($members as $member) :
                    //   pp($member);
                      ?>
                      <tr>
                        <input type="hidden" name="member_id[]" value="<?php echo $member['id']?>">
                        <td><input type="text" class="form-control" name="member_name[]"
                            value="<?php echo $member['name']?>"></td>
                        <td><input type="text" class="form-control" name="address[]"
                            value="<?php echo $member['address']?>"></td>
                        <td><input type="text" class="form-control" name="occupation[]"
                            value="<?php echo $member['occupation']?>"></td>
                        <td><input type="text" class="form-control" name="czn_no[]"
                            value="<?php echo $member['czn_no']?>"></td>
                        <td><input type="text" class="form-control" name="contact_no[]"
                            value="<?php echo $member['contact_no']?>"></td>
                        <td><button type="button" class="btn btn-danger remove-row-member" data-toggle="tooltip"
                            title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>
                      </tr>
                      <?php endforeach;endif;?>
                    </tbody>
                  </table>
                  <button type="button" class="btn btn-secondary btnaddmember"><i class="fa fa-plus-circle"></i> नयाँ
                    सदस्यको विवरण थप्नुहोस </button>
                </div>
                <div class="col-md-12">
                  <hr>
                  <h4>उपयोग गरिने जलश्रोतको विवरण</h4>
                  <table class="table" id="add_new_sorot">
                    <thead>
                      <tr>
                        <th>जलश्रोतको विवरण</th>
                        <th>जलश्रोत रहेको ठाउँ</th>
                        <th>जलश्रोतबाट गरिने प्रयोग</th>
                        <th>गर्न चाहेको जलश्रोतको परिमाण</th>
                        <th>हाल भईरहेको उपयोग</th>
                        <th style="width:50px;">#</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if(!empty($jalsorots)) : foreach($jalsorots as $sorot) : ?>
                      <tr>
                        <input type="hidden" name="jalasorot_id[]" value="<?php echo $sorot['id']?>">
                        <td><input type="text" class="form-control" name="jalsorot_name[]"
                            value="<?php echo $sorot['jalsorot_name']?>"></td>
                        <td><input type="text" class="form-control" name="jalsorot_address[]"
                            value="<?php echo $sorot['jalsorot_address']?>"></td>
                        <td><input type="text" class="form-control" name="jalsorot_usages[]"
                            value="<?php echo $sorot['jalsorot_usages']?>"></td>
                        <td><input type="text" class="form-control" name="jalsorot_amount[]"
                            value="<?php echo $sorot['jalsorot_amount']?>"></td>
                        <td><input type="text" class="form-control" name="jalsorot_current_usages[]"
                            value="<?php echo $sorot['jalsorot_current_usages']?>"></td>
                        <td><button type="button" class="btn btn-danger remove-row-sorot" data-toggle="tooltip"
                            title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>
                      </tr>
                      <?php endforeach;endif;?>
                    </tbody>
                  </table>
                  <button type="button" class="btn btn-secondary btnAddSort"><i class="fa fa-plus-circle"></i> नयाँ
                    संस्थाको उद्देश्य थप्नुहोस </button>
                </div>
                <div class="col-md-12">
                  <hr>
                  <h4>उपभोक्ता समितिले पु¥याउन चाहेको सेवा सम्बन्धी विवरण</h4>
                  <table class="table" id="add_new_sewa">
                    <thead>
                      <tr>
                        <th>सेवाको किसिम</th>
                        <th>सेवा पु¥याउने क्षेत्र</th>
                        <th>सेवाबाट लाभान्वित हुने उपभोक्ताहरुको संख्या</th>
                        <th>भविष्यमा सेवा विस्तार गर्न सकिने सम्भावना</th>
                        <th style="width:50px;">#</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if(!empty($sewas)) : foreach($sewas as $sewa) : ?>
                      <tr>
                        <input type="hidden" name="sewa_id[]" value="<?php echo $sewa['id']?>">
                        <td><input type="text" class="form-control" name="sewa[]" value="<?php echo $sewa['sewa']?>">
                        </td>
                        <td><input type="text" class="form-control" name="sewa_area[]"
                            value="<?php echo $sewa['sewa_area']?>"></td>
                        <td><input type="text" class="form-control" name="total_user[]"
                            value="<?php echo $sewa['total_user']?>"></td>
                        <td><input type="text" class="form-control" name="has_enanchment[]"
                            value="<?php echo $sewa['has_enanchment']?>"></td>
                        <td><button type="button" class="btn btn-danger remove-row-sorot" data-toggle="tooltip"
                            title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>
                      </tr>
                      <?php endforeach;endif;?>
                    </tbody>
                  </table>
                  <button type="button" class="btn btn-secondary btnAddSewa"><i class="fa fa-plus-circle"></i> नयाँ
                    संस्थाको उद्देश्य थप्नुहोस </button>
                </div>
              </div>
          </section>
        </div>

        <div class="col-md-12 text-center">
          <hr>
          <button class="btn btn-primary btn-xs btn-save save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्"
            name="Submit" type="submit" value="Submit" id="btn_save_details"> सेभ गर्नुहोस्</button>
          <a href="<?php echo base_url()?>Khanepani" class="btn btn-danger btn-xs" data-toggle="tooltip"
            title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
        </div>
      </div>
    </form>
  </section>
</section>
<script type="text/javascript" src="<?php echo base_url()?>assets/assets/select2/js/select2.min.js"></script>
<script>
$(document).ready(function() {
  $('#male_member, #female_member').keyup(function() {
    obj = $(this);
    var male_member = $('#male_member').val() || 0;
    var female_member = $('#female_member').val() || 0;
    var total = parseInt(male_member) + parseInt(female_member);
    $('#total_member').val(total);
  });

  $('.npl_state').change(function() {
    var id_selected = $(this).attr("id");
    var res = id_selected.split("-");
    var id = res[res.length - 1];
    var state = $(this).val();
    $.ajax({
      url: base_url + 'CommonController/getDistrictByStateName',
      method: "POST",
      data: {
        state: state,
        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
      },
      success: function(resp) {
        if (resp.status == 'success') {
          $('#district-' + id).html(resp.option);
        }
      }
    });
  });

  $('.npl_district').change(function() {
    var id_selected = $(this).attr("id");
    var res = id_selected.split("-");
    var id = res[res.length - 1];
    var district = $(this).val();
    $.ajax({
      url: base_url + 'CommonController/getGapaByStateName',
      method: "POST",
      data: {
        district: district,
        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
      },
      success: function(resp) {
        if (resp.status == 'success') {
          $('#gapa-' + id).html(resp.option);
        }
      }
    });
  });

  //add new row
  $('.btnAddNew').click(function(e) {
    e.preventDefault();
    var new_row =
      '<tr>' +
      '<td><textarea class="form-control" name="aim[]"></textarea></td>' +
      '<td><button type="button" class="btn btn-danger remove-row" data-toggle="tooltip" title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>' +
      '<tr>'
    $("#add_new_fields").append(new_row);
  });
  $("body").on("click", ".remove-row", function(e) {
    e.preventDefault();
    if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
      $(this).parent().parent().remove();
    }
  });

  //add new work details
  $('.btnaddmember').click(function(e) {
    e.preventDefault();
    var new_row = '<tr>' +
      '<td><input type="text" class="form-control" name="member_name_new[]" value=""></td>' +
      '<td><input type="text" class="form-control" name="address_new[]" value=""></td>' +
      '<td><input type="text" class="form-control" name= "occupation_new[]" value=""></td>' +
      '<td><input type="text" class="form-control" name="czn_no_new[]" value=""></td>' +
      '<td><input type="text" class="form-control" name="contact_no_new[]" value=""></td>' +
      '<td><button type="button" class="btn btn-danger remove-row-member" data-toggle="tooltip" title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>' +
      '<tr>'
    $("#add_new_members").append(new_row);
  });
  $("body").on("click", ".remove-row-member", function(e) {
    e.preventDefault();
    if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
      $(this).parent().parent().remove();
    }
  });

  //sorot
  $('.btnAddSort').click(function(e) {
    e.preventDefault();
    var new_row = '<tr>' +
      '<td><input type="text" class="form-control" name="jalsorot_name_new[]"></td>' +
      '<td><input type="text" class="form-control" name="jalsorot_address_new[]"></td>' +
      '<td><input type="text" class="form-control" name="jalsorot_usages_new[]"></td>' +
      '<td><input type="text" class="form-control" name="jalsorot_amount_new[]"></td>' +
      '<td><input type="text" class="form-control" name="jalsorot_current_usages_new[]"></td>' +
      '<td><button type="button" class="btn btn-danger remove-row-sewa" data-toggle="tooltip" title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>' +
      '<tr>'
    $("#add_new_sorot").append(new_row);
  });
  $("body").on("click", ".remove-row-sorot", function(e) {
    e.preventDefault();
    if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
      $(this).parent().parent().remove();
    }
  });


  //sewa
  $('.btnAddSewa').click(function(e) {
    e.preventDefault();
    var new_row = '<tr>' +
      '<td><input type="text" class="form-control" name="sewa_new[]"></td>' +
      '<td><input type="text" class="form-control" name="sewa_area_new[]"></td>' +
      '<td><input type="text" class="form-control" name="total_user_new[]"></td>' +
      '<td><input type="text" class="form-control" name="has_enanchment_new[]"></td>' +
      '<td><button type="button" class="btn btn-danger remove-row-sewa" data-toggle="tooltip" title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>' +
      '<tr>'
    $("#add_new_sewa").append(new_row);
  });
  $("body").on("click", ".remove-row-sewa", function(e) {
    e.preventDefault();
    if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
      $(this).parent().parent().remove();
    }
  });
});
</script>