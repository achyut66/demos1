<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/landscape_print.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title>
    <?php echo GNAME ?>
  </title>

  <style>
    .title {
      height: 45px;
      width: 485px;
      border: 1px solid #555;
      margin-left: 312px;
      border-radius: 25px;
      text-align: center;
      /* border-radius: 25px; */
      margin-top: 30px;
    }

    .stamp {
      /* border: 2px solid #555; */
      /* height: 62px;
    width: 202px;
     */
      margin-left: 487px;
      border-radius: 5px;
      text-align: right;
      margin-right: 120px;
      margin-top: 50px;
    }

    @media print {
      @page {
        size: landscape;
      }
    }
  </style>
</head>

<body>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle">
          <h3 class="">
            <?php echo GNAME ?>
          </h3>
          <h4>
            <?php echo SLOGAN ?>
          </h4>
          <h6 style="margin-top:-10px;">
            <?php echo ADDRESS . ',' . DISTRICT ?>
          </h6>
          <h6 style="margin-top:-5px;">
            <?php echo STATENAME ?>,नेपाल
          </h6>
          <img src="<?php echo base_url() ?>assets/img/plb.png"
            style="margin-top: -100px;margin-left: 755px;height: 94px;width: 94px;">
        </div>
        <div class="header-right">
          <div class="">

          </div>
        </div>
      </div>
      <div class="sub-header" style="margin-left: -97px;margin-bottom:90px;">
        <div class="title">
          <p style="margin-left:11px;font-size:26px;margin-top:3px;"><b>जल उपभोक्ता संस्था दर्ता
              प्रमाण-पत्र</b></p>
        </div>

      </div>
      <div>

        <div class="text-left" style="margin-top: -45px;">
          <div class="">दर्ता नं.
            <?php echo $this->mylibrary->convertedcit($row['darta_no'] . '/' . $row['fiscal_year']) ?>
          </div>
          <div class="">श्री.
            <?php echo $this->mylibrary->convertedcit($row['name']) ?>
          </div>
          <div class="">
            <?php echo $this->mylibrary->convertedcit($row['p_gapa']) . '-' . $this->mylibrary->convertedcit($row['p_ward']) . ' ,' . $row['tol'] . ' ,' . $row['p_district'] ?>
          </div>
        </div>

        <div class="text-right" style="margin-left: 706px;margin-top:-65px;">
          <div class="">दर्ता मिति:
            <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?>
          </div>
        </div>
        <?php $dateString = $row['darta_miti'];
        $dateComponents = date_parse($dateString);
        $dateyear = $dateComponents['year'];
        $datemonth = $dateComponents['month'];
        $dateday = $dateComponents['day'];
        if ($datemonth == 1) {
          $monthname = "बैशाख";
        } elseif ($datemonth == 2) {
          $monthname = "जेष्ठ";
        } elseif ($datemonth == 3) {
          $monthname = "असाढ";
        } elseif ($datemonth == 4) {
          $monthname = "श्रावन";
        } elseif ($datemonth == 5) {
          $monthname = "भाद्र";
        } elseif ($datemonth == 6) {
          $monthname = "असोज";
        } elseif ($datemonth == 7) {
          $monthname = "कार्तिक";
        } elseif ($datemonth == 8) {
          $monthname = "मंग्सिर";
        } elseif ($datemonth == 9) {
          $monthname = "पौष";
        } elseif ($datemonth == 10) {
          $monthname = "मार्ग";
        } elseif ($datemonth == 11) {
          $monthname = "फाल्गुन";
        } else {
          $monthname = "चैत्र";
        }
        ?>
        <div style="margin-left:20px; margin-top:105px; margin-right:50px;">
          <p style="font-size:16px;margin-top:-20px;text-indent: 2em;text-align:justify">
            <strong>
              <?= $this->mylibrary->convertedcit($row['name']) ?>
            </strong>
            स्थानीय सरकार संचालन ऐन २०७४, तथा
            <strong>
              <?php echo $row['p_gapa'] . 'को' ?>
            </strong> जलस्रोत ऐन,२०७६ को दफा ५ को १ र २ तथा
            जलस्रोत नियमावली २०७६ को नियम ६ को उपनियम १ र खानेपानी नियमावली २०७६ को दफा ६ उपनियम १ बमोजिम
            <strong>
              <?php echo $this->mylibrary->convertedcit($dateyear) ?>
            </strong> साल <strong>
              <?php echo $this->mylibrary->convertedcit($monthname) ?>
            </strong>महिना
            <?php echo $this->mylibrary->convertedcit($dateday) ?>
            </strong>
            गतेमा
            <strong>
              <?php echo $row['p_gapa'] . 'द्वारा' ?>
            </strong> दर्ता गरि यो प्रमाण-पत्र प्रदान गरिएको छ l
            प्रचलित ऐन नियम बमोजिम कार्य संचालन गर्नु हुन बिनम्र अनुरोध छ l
          </p>

          <!-- <div style="margin-top:15px;"></div>
             <div class="text">१. संस्था / समितिको नाम : 
             <span><strong><?php echo $row['name'] ?></strong></span>
             </div>
             <div class="text">२. जलस्रोत / मूलको उपयोगको उदेश्य :
             <span><strong><?= $row['aim'] ?></strong></span>
             </div>
             <div class="text">३. जलस्रोत / मूलको नाम किसिम र रहेको स्थान :
             <span><strong><?= $jala_sorot['jalsorot_name'] . ', ' . $jala_sorot['jalsorot_address'] ?></strong></span>
             </div>
             <div class="text">४. जलस्रोत उपयोगको परिमाण : 
             <span><strong><?= $jala_sorot['jalsorot_amount'] ?></strong></span>
             </div>
             <div class="text">५. जलस्रोत उपयोग गर्ने क्षेत्र , टोल : 
             <span><strong><?= $row['tol'] ?></strong></span>
             </div>
             <div class="text">६. जलस्रोत उपयोगको तरिका : 
             <span><strong><?= $jala_sorot['jalsorot_usages'] ?></strong></span>
             </div>
             <div class="text">७. लाभान्वित घरधुरी संख्या : 
             <span><strong><?= $this->mylibrary->convertedcit($khane_pani['total_user']) ?></strong></span>
             </div> -->
        </div>
        <div class="text-left" style="margin-top:16px;">
          <div class="" style="font-weight:bold;"><u>प्रमाण-पत्र पाउनेको सहि</u></div><br>
          <div class="">दस्तखत : -----------------------</div><br>
          <div class="">नाम :
            <?= $row['ad_name'] ?>
          </div><br>
        </div>
        <div class="text-right" style="margin-left: 667px;margin-top:-163px;">
          <div class="text-right" style="font-weight:bold;underline;"><u></u></div><br />
          <div>दस्तखत : ------------------------</div><br>
          <div>नाम :
            <?php echo $maker['name'] ?>
          </div><br>
          <div>पद :
            <?php echo $maker['designation'] ?>
          </div>
        </div>
      </div>
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
  window.print();
</script>

</html>