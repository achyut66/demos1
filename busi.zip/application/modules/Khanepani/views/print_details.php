<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/certificates/certificate_1.css">
  <script src="https://localhost/sbusinessregister/assets/js/jquery.js"></script>
  <title>
    <?php echo GNAME ?>
  </title>

  <style>
    .title {
      height: 45px;
      width: 425px;
      border: 1px solid #555;
      margin-left: 320px;
      /* border-radius: 25px; */
      /* border-radius: 25px; */
      margin-top: 50px;
    }

    .stamp {
      /* border: 2px solid #555; */
      height: 62px;
      /* width: 202px; */
      margin-top: 50px;
      margin-left: 487px;
      border-radius: 5px;
      text-align: right;
    }
  </style>
</head>
<?php $fiscal = current_fiscal_year(); ?>

<body>
  <div class="text-right" style="margin-left:797px;">
    <div class="">
      <a href="<?php echo base_url() ?>Khanepani/certificate/<?php echo $row['id'] ?>" target="_blank"
        class="btn btn-info btn-sm" style="margin-top:10px;"><i class="fa fa-print"></i>पहिलो प्रिन्ट गर्नुहोस </a>
      <a href="<?php echo base_url() ?>Khanepani/printcertificateSecond/<?php echo $row['id'] ?>" target="_blank"
        class="btn btn-warning btn-sm" style="margin-top:10px;"><i class="fa fa-print"></i>दोश्रो पृष्ट प्रिन्ट
        गर्नुहोस </a>
      <a href="<?php echo base_url() ?>Khanepani" class="btn btn-success btn-sm" style="margin-top:10px;">दर्ता
        सुचीमा जानुहोस </a>
    </div>
  </div>
  <div class="main-wrapper">
    <div class="wrapper">
      <div class="header">
        <div class="header-left">
          <img class="emblem_of_nepal" src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </div>
        <div class="header-middle" style="margin-right:216px;">

          <h3 class="">
            <?php echo GNAME ?>
          </h3>
          <h4>
            <?php echo SLOGAN ?>
          </h4>
          <h6 style="margin-top:-10px;">
            <?php echo ADDRESS . ',' . DISTRICT ?>
          </h6>
          <h6 style="margin-top:-5px;">
            <?php echo STATENAME ?>,नेपाल
          </h6>

          <img src="<?php echo base_url() ?>assets/img/plb.png"
            style="margin-top: -100px;margin-left: 552px;height: 94px;width: 94px;">
        </div>

      </div>
      <!-- <div class="sub-header"> -->
      <div class="title" style="margin-left: 155px;border-radius:5px;">
        <p style="margin-left:11px;font-size:26px;margin-top:3px;"><b>जल उपभोक्ता संस्था दर्ता
            प्रमाण-पत्र</b></p>
      </div>

      <!-- </div> -->
      <div>

        <div style="margin-left:50px;">
          <p style="font-size:18px;margin-top:50px;">दर्ता नं.
            <?php echo $this->mylibrary->convertedcit($row['darta_no'] . ' / ' . $fiscal) ?>
          </p>
        </div>

        <div style="margin-left:50px;margin-top:-10px;">
          <p style="font-size:18px;margin-top:10px;">श्री.
            <?php echo $this->mylibrary->convertedcit($row['name']) ?>
          </p>
        </div>
        <div style="margin-left:50px; margin-top:-10px;">
          <p style="font-size:18px;margin-top:0px;">
            <?php echo $this->mylibrary->convertedcit($row['p_gapa']) . '-' . $this->mylibrary->convertedcit($row['p_ward']) . ' ,' . $row['tol'] . ' ,' . $row['p_district'] ?>
            ।
          </p>
        </div>
        <div style="margin-left:485px; margin-top:-110px;">
          <p style="font-size:18px; text-align:right;margin-top:0px;margin-right:80px;">दर्ता मिति:
            <?php echo $this->mylibrary->convertedcit($row['darta_miti']) ?>
          </p>
        </div>
        <?php $dateString = $row['darta_miti'];
        $dateComponents = date_parse($dateString);
        $dateyear = $dateComponents['year'];
        $datemonth = $dateComponents['month'];
        $dateday = $dateComponents['day'];
        if ($datemonth == 1) {
          $monthname = "बैशाख";
        } elseif ($datemonth == 2) {
          $monthname = "जेष्ठ";
        } elseif ($datemonth == 3) {
          $monthname = "असाढ";
        } elseif ($datemonth == 4) {
          $monthname = "श्रावन";
        } elseif ($datemonth == 5) {
          $monthname = "भाद्र";
        } elseif ($datemonth == 6) {
          $monthname = "असोज";
        } elseif ($datemonth == 7) {
          $monthname = "कार्तिक";
        } elseif ($datemonth == 8) {
          $monthname = "मंग्सिर";
        } elseif ($datemonth == 9) {
          $monthname = "पौष";
        } elseif ($datemonth == 10) {
          $monthname = "मार्ग";
        } elseif ($datemonth == 11) {
          $monthname = "फाल्गुन";
        } else {
          $monthname = "चैत्र";
        }
        ?>
        <div style="margin-left:50px; margin-top:105px; margin-right:50px;">
          <p style="font-size:18px;margin-top:0px;text-indent: 2em;text-align:justify">
            <strong>
              <?= $this->mylibrary->convertedcit($row['name']) ?>
            </strong>
            स्थानीय सरकार संचालन ऐन २०७४, तथा
            <strong>
              <?php echo $row['p_gapa'] . 'को' ?>
            </strong> जलस्रोत ऐन,२०७६ को दफा ५ को १ र २ तथा
            जलस्रोत नियमावली २०७६ को नियम ६ को उपनियम १ र खानेपानी नियमावली २०७६ को दफा ६ उपनियम १ बमोजिम
            <strong>
              <?php echo $this->mylibrary->convertedcit($dateyear) ?>
            </strong> साल <strong>
              <?php echo $this->mylibrary->convertedcit($monthname) ?>
            </strong>महिना
            <?php echo $this->mylibrary->convertedcit($dateday) ?>
            </strong>
            गतेमा
            <strong>
              <?php echo $row['p_gapa'] . 'द्वारा' ?>
            </strong> दर्ता गरि यो प्रमाण-पत्र प्रदान गरिएको छ l
            प्रचलित ऐन नियम बमोजिम कार्य संचालन गर्नु हुन बिनम्र अनुरोध छ l
          </p>
          <!-- <br> -->
          <!-- <div class="text">१. संस्था / समितिको नाम :
            <span><strong>
                <?php echo $row['name'] ?>
              </strong></span>
          </div>
          <div class="text">२. जलस्रोत / मूलको उपयोगको उदेश्य :
            <span><strong>
                <?= $row['aim'] ?>
              </strong></span>
          </div>
          <div class="text">३. जलस्रोत / मूलको नाम किसिम र रहेको स्थान :
            <span><strong>
                <?= $jala_sorot['jalsorot_name'] . ', ' . $jala_sorot['jalsorot_address'] ?>
              </strong></span>
          </div>
          <div class="text">४. जलस्रोत उपयोगको परिमाण :
            <span><strong>
                <?= $jala_sorot['jalsorot_amount'] ?>
              </strong></span>
          </div>
          <div class="text">५. जलस्रोत उपयोग गर्ने क्षेत्र , टोल :
            <span><strong>
                <?= $row['tol'] ?>
              </strong></span>
          </div>
          <div class="text">६. जलस्रोत उपयोगको तरिका :
            <span><strong>
                <?= $jala_sorot['jalsorot_usages'] ?>
              </strong></span>
          </div>
          <div class="text">७. लाभान्वित घरधुरी संख्या :
            <span><strong>
                <?= $this->mylibrary->convertedcit($khane_pani['total_user']) ?>
              </strong></span>
          </div> -->
        </div>

        <div style="width:307px;margin-left:445px; margin-top: 80px;">
          <div class="text-right" style="font-weight:bold;underline;"><u></u></div><br />
          <select class="form-control" name="maker" id="maker">
            <option value="">--छान्नुहोस्--</option>
            <?php if (!empty($staffs)):
              foreach ($staffs as $staff): ?>
                <option value="<?php echo $staff['id'] ?>" <?php if ($staff['id'] == $row['maker']) {
                     echo 'selected';
                   } ?>>
                  <?php echo $staff['name'] ?>
                </option>
              <?php endforeach;
            endif; ?>
          </select>
        </div>

        <div style="width:307px;margin-left:55px; margin-top: -87px;">
          <div class="text-left" style="font-weight:bold;underline;"><u>प्रमाण-पत्र पाउनेको सहि</u></div><br />
          <div class="text-left">
            <div class="">दस्तखत : ---------------------------</div><br>
            <div class="">नाम :
              <?= $row['ad_name'] ?>
            </div><br>
          </div>
        </div>
      </div>
    </div> <!-- endof warpper-->
  </div><!-- endof main-warpper-->
</body>
<script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
<script type="text/javascript">
  $(document).ready(function () {
    var base_url = "<?php echo base_url() ?>";
    $('#maker').change(function () {
      obj = $(this);
      var maker = obj.val();
      var id = "<?php echo $this->uri->segment(3) ?>";
      $.ajax({
        url: base_url + 'Khanepani/updateMaker',
        method: "POST",
        data: {
          maker: maker,
          id: id,
          '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        },
        success: function (resp) {
          if (resp.status == 'success') {
            location.reload();
          }
        }
      });
    });
    $('#checker').change(function () {
      obj = $(this);
      var checker = obj.val();
      var id = "<?php echo $this->uri->segment(3) ?>";
      $.ajax({
        url: base_url + 'Khanepani/updateChecker',
        method: "POST",
        data: {
          checker: checker,
          id: id,
          '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        },
        success: function (resp) {
          if (resp.status == 'success') {
            location.reload();
          }
        }
      });
    });
  });
</script>

</html>