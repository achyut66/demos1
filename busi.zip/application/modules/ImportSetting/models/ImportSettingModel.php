<?php



/**

 * Created by PhpStorm.

 * User: root

 */

class ImportSettingModel extends CI_Model

{

    public function __construct()

    {

        parent::__construct();

    }
    public function getMinlandRate($road_name, $land_area_type,$present_ward) {
        $this->db->select('*')->from('settings_road');
        $this->db->where('id', $road_name);
        $this->db->where('land_area_type', $land_area_type);
        $this->db->where('ward', $present_ward);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function getRoads($road_name, $land_area_type, $present_ward) {
        $this->db->select('*')->from('settings_road');
        $this->db->where('road_name', $road_name);
        $this->db->where('land_area_type', $land_area_type);
        $this->db->where('ward', $present_ward);
        $query = $this->db->get();
        return $query->row_array();
    }

}