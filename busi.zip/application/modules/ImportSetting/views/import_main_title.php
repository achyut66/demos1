<!--main content start-->
  <section id="main-content">
      <section class="wrapper site-min-height">
      
          <!-- page start-->
          <div class="row">
            <div class="col-sm-12">
              <section class="card">

                 <header class="card-header" style="background: #1b5693;color:#fff">
                   <?php echo !empty($title)?$title:'';?> इम्पोर्ट गर्नुहोस
                  </header>

                <div class="card-body">
                    <form action="<?php echo base_url()?>ImportSetting/SaveNagadiMainTitle" enctype="multipart/form-data" method="post">
        							<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
        							<input type="file" name="userfile">
        							<input type="submit" name="submit" value="submit">
        						</form>
                </div>
              </section>
            </div>
          </div>
          <!-- page end-->
      </section>
  </section>
