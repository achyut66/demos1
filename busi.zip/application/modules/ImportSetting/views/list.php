
<!--main content start-->
      <section id="main-content">
          <section class="wrapper site-min-height">
          
              <!-- page start-->
              <div class="row">
                <div class="col-sm-12">
                 <section class="card">
                        <div class="card-body">
                            <ul class="summary-list">
                                <li>
                                    <a href="<?php echo base_url()?>ImportSetting/PersonalProfile">
                                        <i class=" fa fa-cogs text-primary"></i>
                                      व्यक्तिगत अभिलेख
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url()?>ImportSetting/importLandDetails">
                                        <i class="fa fa-cogs text-info"></i>
                                       जग्गाको विवरण
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url()?>ImportSetting/importSanrachanaDetails">
                                        <i class=" fa fa-cogs text-muted"></i>
                                        संरचनाको विवरण
                                    </a>
                                </li>
                                <li>
                                    <a href="">
                                      <i class="fa fa-cogs text-success"></i>
                                       सडकको नाम
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url()?>ImportSetting/ImportNagadiMainTitle">
                                        <i class="fa fa-cogs text-danger"></i>
                                       नगदी मुख्य शिसक
                                    </a>
                                </li>
                                  <li>
                                    <a href="<?php echo base_url()?>ImportSetting/ImportNagadiSubTitle">
                                        <i class="fa fa-cogs text-danger"></i>
                                       नगदी सह शिसक
                                    </a>
                                </li>
                                  <li>
                                    <a href="<?php echo base_url()?>ImportSetting/ImportNagadiTitle">
                                        <i class="fa fa-cogs text-danger"></i>
                                       नगदी सिर्सक र दर
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </section>
                </div>
              </div>
              <!-- page end-->
          </section>
      </section>

    <script type="text/javascript" src="<?php echo base_url()?>assets/js/customjs.js"></script>
    <script src="<?php echo base_url('assets/datatable/datatables.min.js') ?>"></script>
    <script type="text/javascript">
      $(document).ready(function(){
        $('#listtable').DataTable({
           'order': false,
        });
      })
    </script>
