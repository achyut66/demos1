<?php

/**
 * This class export data.
 */
require_once FCPATH.'/vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
class ImportSetting extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->load->model("ImportSettingModel");
    }
 
    /**
        * This function list all the land minimun rate
        return void
     */
    public function Index()
    {
        $data['page'] = 'list';
        $data['fiscal_year'] = $this->CommonModel->getData('fiscal_year', "ASC");
        $this->load->view('main', $data);
      
    }

    public function PersonalProfile() {
        $data['page'] = 'import_profile';
        $data['fiscal_year'] = $this->CommonModel->getData('fiscal_year', "ASC");
        $this->load->view('main', $data);
    }
    public function saveProfile() {
        header('Content-Type: text/html; charset=UTF-8');
         $file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        if(isset($_FILES['userfile']['name']) && in_array($_FILES['userfile']['type'], $file_mimes)) {
          $arr_file = explode('.', $_FILES['userfile']['name']);
          $extension = end($arr_file);
          if('csv' == $extension) {
              $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
          } else {
              $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
          }
          $spreadsheet = $reader->load($_FILES['userfile']['tmp_name']);
          $sheetData = $spreadsheet->getActiveSheet()->toArray();
          pp($sheetData);
          foreach ($sheetData as $key => $value) {
              $explode = explode('/', $value[11]);
              $file_no = $value[38].'-'.$explode[1];
              $data[] = array(
                'fiscal_year'               => $value[0],
                'land_own_type'             => $value[1],
                'land_owner_name_np'        => $value[2],
                'land_owner_name_en'        => $value[3],
                'land_owner_father_name'    => $value[4],
                'land_owner_grandpa_name'   => $value[5],
                'land_owner_occupation'     => $value[6],
                'land_owner_gender'         => $value[7],
                'nationality'               => $value[8],
                'land_owner_email'          => $value[9],
                'land_owner_contact_no'     => $value[10],
                'file_no'                   => $file_no,
                'status'                    => $value[12],
                'remarks'                   => $value[13],
                'lo_state'                  => $value[14],
                'lo_district'               => $value[15],
                'lo_gapa_napa'              => $value[16],
                'lo_ward'                   => $value[17],
                'lo_land_lac_ward'          => $value[18],
                'lo_house_no'               => $value[19],
                'lo_tol'                    => $value[20],
                'lo_temp_state'             => $value[21],
                'lo_temp_dis'               => $value[22],
                'lo_temp_gapanapa'          => $value[23],
                'lo_czn_no'                 => $value[24],
                'lo_pan_no'                 => $value[25],
                'lo_temp_ward'              => $value[26],
                'lo_temp_tol'               => $value[27],
                'lo_temp_house_no'          => $value[28],
                'lo_fi_state'               => $value[29],
                'lo_fi_district'            => $value[30],
                'lo_fi_gapa_napa'           => $value[31],
                'lo_fi_ward'                => $value[32],
                'lo_fi_relation'            => $value[33],
                'lo_fi_name'                => $value[34],
                'lo_fi_date'                => $value[35],
                'added_by'                  => $value[36],
                'added_on'                  => $value[37],
                'form_type'                 => 2,
                'suchak_name'               => $value[11],
                'added_ward'                => $value[38],
            );

          }
          //pp($data);
          $this->db->insert_batch('land_owner_profile_basic', $data);
          redirect('PersonalProfile');
        }
    }

    public function importLandDetails() {
      $data['page'] = 'import_land';
      $this->load->view('main', $data);
    }



    public function importLand() {
        header('Content-Type: text/html; charset=UTF-8');
         $file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        if(isset($_FILES['userfile']['name']) && in_array($_FILES['userfile']['type'], $file_mimes)) {
          $arr_file = explode('.', $_FILES['userfile']['name']);
          $extension = end($arr_file);
          if('csv' == $extension) {
              $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
          } else {
              $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
          }
          $spreadsheet = $reader->load($_FILES['userfile']['tmp_name']);
          $sheetData = $spreadsheet->getActiveSheet()->toArray();
         // pp($sheetData);
          foreach ($sheetData as $key => $value) {
            //$road_details = $this->CommonModel->getDataBySelectedFields('settings_road', 'road_name', $value[4]);
            $road_name = $this->ImportSettingModel->getRoads($value[4], $value[5],$value[3]);
           // pp($road_name);
            $land_category = $this->CommonModel->getDataBySelectedFields('land_category', 'category', $value[6]);
            $file_no = $this->CommonModel->getDataBySelectedFields('land_owner_profile_basic', 'suchak_name', $value[20]);
            $min_land_rate = $this->ImportSettingModel->getMinlandRate($road_name['id'], $value[5],$value[3]);
            // pp($min_land_rate['min_rate']);
            $a_biga = $value[9] * 72900;
            $a_biga = $value[9] * 72900;
            $a_kattha = $value[10] * 3645;
            $a_dhur = $value[11] * 182.25;
            $total_land_area_sqft = $a_biga + $a_kattha + $a_dhur;
            $tax_rate = $total_land_area_sqft /3645;
            $total_tax = $tax_rate * $min_land_rate['min_rate'];
            $data[] =array(
                'old_gapa_napa'         => $value[0],
                'old_ward'              => $value[1],
                'present_gapa_napa'     => $value[2],
                'present_ward'          => $value[3],
                'road_name'             => $road_name['id'],
                'land_area_type'        => $value[5],
                'land_category'         => $value[6],
                'nn_number'             => $value[7],
                'k_number'              => $value[8],
                'a_ropani'              => $value[9],
                'a_ana'                 => $value[10],
                'a_paisa'               => $value[11],
                'a_dam'                 => $value[12],
                'a_unit'                => 1,
                'total_square_feet'     => $total_land_area_sqft,
                'min_land_rate'         => $min_land_rate['min_rate'],
                'max_land_rate'         => 0,
                'k_land_rate'           => $min_land_rate['min_rate'],
                't_rate'                => $total_tax,
                'fiscal_year'           => '',
                'ld_file_no'            => $file_no['file_no'],
                'added_by'              => '',
                'added_on'              => '',
            );
          }
        //  pp($data);
          //pp($data); SELECT t1.present_ward,t1.road_name,t1.land_area_type, t2.min_rate FROM land_description_details as t1 join settings_road as t2 on t2.id = t1.road_name where t1.min_land_rate is NULL
          $this->db->insert_batch('land_description_details', $data);
          redirect('ImportSetting');
        }
    }

    public function importSanrachanaDetails() {
      $data['page'] = 'import_sanrachana';
      $this->load->view('main', $data);
    }

    public function importSarachana() {
        header('Content-Type: text/html; charset=UTF-8');
         $file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        if(isset($_FILES['userfile']['name']) && in_array($_FILES['userfile']['type'], $file_mimes)) {
          $arr_file       = explode('.', $_FILES['userfile']['name']);
          $extension      = end($arr_file);
          if('csv'        == $extension) {
              $reader     = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
          } else {
              $reader     = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
          }
          $spreadsheet    = $reader->load($_FILES['userfile']['tmp_name']);
          $sheetData        = $spreadsheet->getActiveSheet()->toArray();
          //pp($sheetData);
          foreach ($sheetData as $key => $value) {
            $file_no = $this->CommonModel->getDataBySelectedFields('land_owner_profile_basic', 'suchak_name', $value[18]);
            $land_details = $this->CommonModel->getDataBySelectedFields('land_description_details', 'k_number', $value[0]);

            $a_ropani = !empty($land_details['a_ropani'])?$land_details['a_ropani']:0;
            $a_ana = !empty($land_details['a_ana'])?$land_details['a_ana']:0;
            $a_paisa = !empty($land_details['a_paisa'])?$land_details['a_paisa']:0;
            $a_dam = !empty($land_details['a_dam'])?$land_details['a_dam']:0;
            $total_land_area = $a_ropani.'-'.$a_ana.'-'.$a_paisa.'-'.$a_dam;

            $min_amount = $this->CommonModel->getDataByID('settings_structure_minimum_amount',$value['7']);
            $total_area_san = $value[12] * 2;

            if($total_area_san <= $land_details['total_square_feet']) {
              $total_land_area_c = $total_area_san * $land_details['min_land_rate']; 
            } else {
                $total_land_area_c = $land_details['total_square_feet'] * $land_details['min_land_rate'];
            }
            $samrachan_ko_land_tax_amount = $value[12] * 2;
            $land_into_kattha = $samrachan_ko_land_tax_amount / 3645;
            $per_kattha = $land_into_kattha * $land_details['min_land_rate'];
            $r_land_area = $land_details['total_square_feet'] - $samrachan_ko_land_tax_amount;
            //pp($r_land_area);
            if($r_land_area < 1 ) {
              $r_bhumi_kar_land = 0;
            } else {
              $r_bhumi_kar_land = $r_land_area;
            }
            $r_bhumikarland = $r_bhumi_kar_land / 3645 ;
            $final_bhumi_kar = $r_bhumikarland * $land_details['min_land_rate'];
            //$khud = $min_amount['minimum_amount'] * $value[12];
            //$khud_amount = $value[14]/ 100 * $khud;
            //$net_amount = $khud_amount + $total_land_area_c;
            $r_bhumi_area = $land_details['total_square_feet'] - $total_area_san;

            //$r_bhumi_kar = $r_bhumi_area * $land_details['min_land_rate'];
            $data[] =array(
                'k_no'                                      => $value[0],
                'toal_land_area'                            => $total_land_area,
                'total_land_area_sqft'                      => $land_details['total_square_feet'],
                'total_land_min_amount'                     => $land_details['min_land_rate'],
                'total_land_tax_amount'                     => $land_details['t_rate'],
                'sanrachana_n_no'                           => $value[5],

                'sanrachana_prakar'                         => 3,

                'sanrachana_banot_kisim'                    => $value[7],

                'sanrachana_usages'                         => $value[8],

                'sanrachana_floor'                          => $value[9],

                'sanrachana_ground_lenth'                   => $value[10],

                'sanrachana_ground_width'                   => $value[11],

                'sanrachana_ground_area_sqft'               => $value[12],

                'sanrachana_ground_housing_area_sqft'       => $value[12] * $value[9],

                'contructed_year'                           => $value[13],

                'sanrachana_dep_rate'                       => $value[14],

                'sanrachana_min_amount'                     => $value[15],

                'sanrachana_kubul_amount'                   => $value[16],

                'sanrachana_khud_amount'                    => $value[17],

                'sanrachana_ground_area_ropani'             => $land_details['total_square_feet']/3645,

                'sanrachana_land_tax_amount'                => $per_kattha,

                'net_tax_amount'                            => $per_kattha + $value[17],

                'ls_file_no'                                => $file_no['file_no'],

                'added_on'                                  => '2077-05-07',

                'added_by'                                  => '1',

                'r_bhumi_area'                              => $r_bhumi_kar_land,

                'r_bhumi_kar'                               => round($final_bhumi_kar,2),

                'fiscal_year'                               => '2077/078',

                'initial_flag'                              => $value[18],
            );
          }
           //pp($data);
          $this->db->insert_batch('sanrachana_details', $data);
        }
    }
    public function ImportNagadiMainTitle() {
        $data['pageTitle'] = 'नगदी रशिद विवरण';
        $data['page'] = 'import_main_title';
        $this->load->view('main', $data);
    }
    
    public function SaveNagadiMainTitle() {
         header('Content-Type: text/html; charset=UTF-8');
         $file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        if(isset($_FILES['userfile']['name']) && in_array($_FILES['userfile']['type'], $file_mimes)) {
          $arr_file = explode('.', $_FILES['userfile']['name']);
          $extension = end($arr_file);
          if('csv' == $extension) {
              $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
          } else {
              $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
          }
          $spreadsheet = $reader->load($_FILES['userfile']['tmp_name']);
          $sheetData = $spreadsheet->getActiveSheet()->toArray();
          pp($sheetData);
            foreach ($sheetData as $key => $value) {
                $data[] =array(
                    'fiscal_year'       => get_current_fiscal_year(),
                    'topic_no'          => $value[0],
                    'topic_name'        => $value[1],
                );
            }
            $this->db->trans_start();
            $this->db->insert_batch('main_topic', $data);
            $this->db->trans_complete();
            redirect('SetTitle');
            
        }
    }
    
    public function ImportNagadiSubTitle() {
         $data['title'] = 'नगदी';
        $data['page'] = 'import_subtitle';
        $this->load->view('main', $data);
    }
    
    public function SaveNagadiSubTitle() {
        header('Content-Type: text/html; charset=UTF-8');
         $file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        if(isset($_FILES['userfile']['name']) && in_array($_FILES['userfile']['type'], $file_mimes)) {
          $arr_file = explode('.', $_FILES['userfile']['name']);
          $extension = end($arr_file);
          if('csv' == $extension) {
              $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
          } else {
              $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
          }
          $spreadsheet = $reader->load($_FILES['userfile']['tmp_name']);
          $sheetData = $spreadsheet->getActiveSheet()->toArray();
                foreach ($sheetData as $key => $value) {
                $data[] =array(
                    'main_topic' => $value[0],
                    'topic_no'  => '',
                    'sub_topic' => $value[1],
                    'parent_id' => $value[0]
                   
                );
            }
            $this->db->insert_batch('topic', $data);
            redirect('SetTitle');
        }
    }
    


    public function ImportNagadiTitle() {
        $data['title'] = 'नगदी';
        $data['page'] = 'import_nagadi_rate';
        $this->load->view('main', $data);
    }
    
    public function SaveNagadiTitleRate() {
          header('Content-Type: text/html; charset=UTF-8');
         $file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        if(isset($_FILES['userfile']['name']) && in_array($_FILES['userfile']['type'], $file_mimes)) {
          $arr_file = explode('.', $_FILES['userfile']['name']);
          $extension = end($arr_file);
          if('csv' == $extension) {
              $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
          } else {
              $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
          }
          $spreadsheet = $reader->load($_FILES['userfile']['tmp_name']);
          $sheetData = $spreadsheet->getActiveSheet()->toArray();
            //pp($sheetData);
            foreach ($sheetData as $key => $value) {
                $data[] =array(
                    'sub_topic'     => $value[1],
                    'parent_id'     => $value[0],
                    'topic_title'   => $value[2],
                    'rate'          => $value[3],
                    'is_percent'    => $value[4],
                    'fiscal_year'   => get_current_fiscal_year()
                );
            }
           
            $this->db->insert_batch('sub_topic', $data);
            redirect('SetTitle');
            
        }
    }

    //import roads
    public function importRoads() {
        $data['pageTitle'] = '';
        $this->load->view('import_roads');
    }

    public function SaveRoads() {
        header('Content-Type: text/html; charset=UTF-8');
        $file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        if(isset($_FILES['userfile']['name']) && in_array($_FILES['userfile']['type'], $file_mimes)) {
          $arr_file = explode('.', $_FILES['userfile']['name']);
          $extension = end($arr_file);
          if('csv' == $extension) {
              $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
          } else {
              $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
          }
          $spreadsheet = $reader->load($_FILES['userfile']['tmp_name']);
          $sheetData = $spreadsheet->getActiveSheet()->toArray();
            //pp($sheetData);
            foreach ($sheetData as $key => $value) {
                $data[] =array(
                    'id' => $value[0],
                    'road_name'    => $value[1],
                    'road_type' => $value[2],
                    'ward'  => $value[4],
                    'tole' => $value[3],
                    'fiscal_year' => '2077/078'
                );
                $min_amount[] = array(
                    'id' => $value[0],
                    'ward' => $value[4],
                    'road_name'=>$value[0],
                    'land_area_type'=>1,
                    'minimal_cost' => $value[6],
                    'fiscal_year' => '2077/078'
                );
            }
           
            $this->db->insert_batch('settings_road', $data);
            $this->db->insert_batch('settings_area_minimal_cost', $min_amount);
            
        }
    }

    public function uploadFineRate() {
        header('Content-Type: text/html; charset=UTF-8');
        $file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        if(isset($_FILES['userfile']['name']) && in_array($_FILES['userfile']['type'], $file_mimes)) {
            $arr_file = explode('.', $_FILES['userfile']['name']);
            $extension = end($arr_file);
            if('csv' == $extension) {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
            } else {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            }
            $spreadsheet = $reader->load($_FILES['userfile']['tmp_name']);
            $sheetData = $spreadsheet->getActiveSheet()->toArray();
            pp($sheetData);
            foreach ($sheetData as $key => $value) {
                $data[] =array(
                    'fiscal_year'       => get_current_fiscal_year(),
                    'topic_no'          => $value[0],
                    'topic_name'        => $value[1],
                );
            }
            $this->db->trans_start();
            $this->db->insert_batch('fine_rate', $data);
            $this->db->trans_complete();
            redirect('SetTitle');
       }
   }
}
