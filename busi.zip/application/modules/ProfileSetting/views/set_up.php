<!--main content start-->
<section id="main-content">
    <section class="wrapper site-min-height">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url() ?>">ड्यासबोर्डमा जानुहोस </a></li>
                <li class="breadcrumb-item"><a href="javascrip:;">पालिकाको प्रोफाइल</a></li>
            </ol>
        </nav>
        <!-- page start-->
        <div class="row">
            <div class="col-sm-12">
                <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
                if (!empty($success_message)) { ?>
                    <div class="alert alert-success">
                        <button class="close" data-close="alert"></button>
                        <span> <?php echo $success_message; ?> </span>
                    </div>
                <?php } ?>
                <section class="card">
                    <header class="card-header">पालिकाको प्रोफाइल</header>
                    <div class="card-body">
                        <form class="save_post" action="<?php echo base_url() ?>ProfileSetting/save" method="post">
                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                            <input type="hidden" name="id" value="<?php echo !empty($profile['id']) ? $profile['id'] : '' ?>">
                            <input type="hidden" name="state_id" value="" id="state_id">
                            <input type="hidden" name="district_id" value="" id="district_id">

                            <div class="form-group row">
                                <label class="col-form-label col-sm-4" for=""> प्रदेश<span class="text-danger">&nbsp;*</span></label>
                                <div class="col-sm-8">
                                    <select class="form-control select2 npl_state select2" name="state_np" id="state-1">
                                        <?php if (!empty($states)) :
                                            foreach ($states as $state) : ?>
                                                <option value="<?php echo $state['Title'] ?>" <?php if ($profile['state_np'] == $state['Title']) {
                                                                                                    echo 'selected';
                                                                                                } ?>><?php echo $state['Title'] ?></option>
                                        <?php endforeach;
                                        endif; ?>
                                        <option></option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">जिल्ला<span class="text-danger">&nbsp;*</span></label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <select class="form-control select2 npl_district" name="district_np" id="district-1">
                                            <?php if (!empty($districts)) :
                                                foreach ($districts as $d) : ?>
                                                    <option value="<?php echo $d['name'] ?>" <?php if ($d['name'] == $profile['district_np']) {
                                                                                                    echo 'selected';
                                                                                                } ?>><?php echo $d['name'] ?></option>
                                            <?php endforeach;
                                            endif; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">पालिकाको नाम<span class="text-danger">&nbsp;*</span></label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <select class="form-control select2" name="palika_name_np" id="gapa-1">
                                            <?php if (!empty($locals)) :
                                                foreach ($locals as $l) : ?>
                                                    <option value="<?php echo $l['name'] ?>" <?php if ($profile['palika_name'] == $l['name']) {
                                                                                                    echo 'selected';
                                                                                                } ?>><?php echo $l['name'] ?></option>
                                            <?php endforeach;
                                            endif; ?>
                                            <option></option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-form-label col-sm-4" for=""><span class="text-danger">&nbsp;*</span>कार्यालयको ठेगाना</label>
                                <div class="col-sm-8">
                                    <input type="text" name="office_address" class="form-control" required value="<?php echo !empty($profile['office_address']) ? $profile['office_address'] : '' ?>" />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-form-label col-sm-4" for="">गाउँ/नगर कार्यपालिका<span class="text-danger">&nbsp;*</span></label>
                                <div class="col-sm-8">
                                    <input type="text" name="karay_palika_np" class="form-control" required value="<?php echo !empty($profile['karay_palika_np']) ? $profile['karay_palika_np'] : '' ?>" />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">पालिकाको लोगो</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="file" name="palika_logo" class="form-control" <?php if (empty($profile['palika_logo'])) {
                                                                                                        echo 'required';
                                                                                                    } ?> />
                                    </div>
                                    <input type="hidden" name="old_palika_logo" value="<?php echo $profile['palika_logo'] ?>">
                                    <?php if (!empty($profile['palika_logo'])) : ?>
                                        <img src="<?php echo base_url() ?>assets/img/<?php echo $profile['palika_logo'] ?>" style="height:50px;width:50px;"><br>
                                        <a href="<?php echo base_url() ?>ProfileSetting/RemovePalikaLogo" style="color:red" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i> REMOVE</a>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">पालिकाको नारा(slogan)</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" name="palika_slogan" class="form-control" required value="<?php echo $profile['palika_slogan'] ?>" />
                                    </div>
                                </div>
                            </div>

                            <!-------------------------------- -->
                            <div class="form-group row">
                                <label class="col-form-label col-sm-4" for=""> State Name<span class="text-danger">&nbsp;*</span></label>
                                <div class="col-sm-8">
                                   <input type="text" name="state_en" class="form-control" required value="<?php echo !empty($profile['state_en']) ? $profile['state_en'] : '' ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">District Name<span class="text-danger">&nbsp;*</span></label>
                                <div class="col-sm-8">
                                     <input type="text" name="district_en" class="form-control" required value="<?php echo !empty($profile['district_en']) ? $profile['district_en'] : '' ?>" />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">English Name(M/RM)<span class="text-danger">&nbsp;*</span></label>
                                <div class="col-sm-8">
                                    <input type="text" name="palika_name_en" class="form-control" required value="<?php echo !empty($profile['palika_name_en']) ? $profile['palika_name_en'] : '' ?>" /> 
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-form-label col-sm-4" for=""><span class="text-danger">&nbsp;*</span>English Address</label>
                                <div class="col-sm-8">
                                    <input type="text" name="office_address_en" class="form-control" required value="<?php echo !empty($profile['office_address_en']) ? $profile['office_address_en'] : '' ?>" />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-form-label col-sm-4" for="">English Slogan<span class="text-danger">&nbsp;*</span></label>
                                <div class="col-sm-8">
                                    <input type="text" name="karay_palika_en" class="form-control" required value="<?php echo !empty($profile['karay_palika_en']) ? $profile['karay_palika_en'] : '' ?>" />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">पालिकाको लोगो</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="file" name="palika_logo" class="form-control" <?php if (empty($profile['palika_logo'])) {
                                                                                                        echo 'required';
                                                                                                    } ?> />
                                    </div>
                                    <input type="hidden" name="old_palika_logo" value="<?php echo $profile['palika_logo'] ?>">
                                    <?php if (!empty($profile['palika_logo'])) : ?>
                                        <img src="<?php echo base_url() ?>assets/img/<?php echo $profile['palika_logo'] ?>" style="height:50px;width:50px;"><br>
                                        <a href="<?php echo base_url() ?>ProfileSetting/RemovePalikaLogo" style="color:red" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i> REMOVE</a>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">पालिकाको नारा(slogan)</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" name="palika_slogan" class="form-control" required value="<?php echo $profile['palika_slogan'] ?>" />
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">website</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" name="website" class="form-control" value="<?php echo $profile['website'] ?>" required />
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">phone no<span class="text-danger">&nbsp;*</span></label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="number" name="phone_no" class="form-control" required value="<?php echo $profile['phone_no'] ?>" />
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Email<span class="text-danger">&nbsp;*</span></label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="email" name="email" class="form-control" value="<?php echo $profile['email'] ?>" required />
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Facebook</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" name="facebook" class="form-control" value="<?php echo $profile['facebook'] ?>" required />
                                    </div>
                                </div>
                            </div>

                            <div class="form-buttons-w">
                                <button type="submit" class='btn btn-block btn-submit btn-primary save_btn' name="submit">सम्पादन गर्नुहोस्</button>
                            </div>
                        </form>
                    </div>
                </section>
            </div>
        </div>
        <!-- page end-->
    </section>
</section>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>
<script>
    $(document).ready(function() {
        $('.npl_state').change(function() {
            var id_selected = $(this).attr("id");
            var res = id_selected.split("-");
            var id = res[res.length - 1];
            var state = $(this).val();
            $.ajax({
                url: base_url + 'CommonController/getDistrictByStateName',
                method: "POST",
                data: {
                    state: state,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                },
                success: function(resp) {
                    if (resp.status == 'success') {
                        $('#district-' + id).html(resp.option);
                        $('#state_id').val(resp.state);
                    }
                }
            });
        });

        $('.npl_district').change(function() {
            var id_selected = $(this).attr("id");
            var res = id_selected.split("-");
            var id = res[res.length - 1];
            var district = $(this).val();
            $.ajax({
                url: base_url + 'CommonController/getGapaByStateName',
                method: "POST",
                data: {
                    district: district,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                },
                success: function(resp) {
                    if (resp.status == 'success') {
                        $('#gapa-' + id).html(resp.option);
                        $('#district_id').val(resp.district_id);
                    }
                }
            });
        });

    });
</script>