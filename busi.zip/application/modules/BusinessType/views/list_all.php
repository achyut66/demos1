<!--main content start-->
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url()?>">ड्यासबोर्डमा जानुहोस </a></li>
        <li class="breadcrumb-item" ><a href="<?php echo base_url()?>BusinessType/">व्यवसाय प्रकार</a></li>
      </ol>
    </nav>
    <!-- page start-->
    <div class="row">
      <div class="col-sm-12">
        <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
            if(!empty($success_message)) { ?>
            <div class="alert alert-success">
                <button class="close" data-close="alert"></button>
                <span> <?php echo $success_message;?> </span>
            </div>
          <?php } ?>
        <section class="card">
          <header class="card-header">
          व्यवसाय प्रकार सूची
          <span class="tools">
            <?php if($this->authlibrary->HasModulePermission('BTYPE', "ADD")) { ?>
            <a class="btn btn-secondary pull-right" href="<?php echo base_url()?>BusinessType/add"><i class="fa fa-plus-circle"></i> नयाँ प्रकार थप्नुहोस् </a>
            <?php } ?>
          </span>
          </header>
          <div class="card-body">
            <div class="adv-table">
              <table class="table table-bordered print_table">
                <thead>
                    <tr>
                      <th text-aligh="right">#</th> 
                      <th>शिर्षक</th>
                      <th>उप शिर्षक</th>
                      <th>दर्ता दस्तुर </th>
                      <th>नवीकरण दस्तुर </th>
                        <?php if($this->authlibrary->HasModulePermission('SET-TITLE', "EDIT") || $this->authlibrary->HasModulePermission('SET-TITLE', "DELETE") ) { ?>
                        <th class="hidden-phone">.....</th>
                      <?php } ?>
                    </tr>
                </thead>
                <tbody>
                  <?php $i=1;if(!empty($prakar)) : foreach($prakar as $type) : ?>
                    <tr>
                      <td style="width:50px;"><?php echo $this->mylibrary->convertedcit($i++)?></td>
                      <td><?php echo $type['main_topic']?></td>
                      <td><?php echo $type['sub_topic']?></td>
                      <td><?php echo $type['darta_dastur']?></td>
                      <td><?php echo $type['renew_dastur']?></td>
                      <td style="width:100px;">
                        <?php if($this->authlibrary->HasModulePermission('BTYPE', "EDIT")) { ?>
                          <a href="<?php echo base_url()?>BusinessType/edit/<?php echo $type['id']?>" class="btn btn-info"><i class="fa fa-pencil"></i></a>
                        <?php } ?>
                        <?php if($this->authlibrary->HasModulePermission('BTYPE', "DELETE") ) { ?>
                          <a href="<?php echo base_url()?>BusinessType/delete/<?php echo $type['id']?>" class="btn btn-danger" onclick= "return confirm('Confirm to delete')"><i class="fa fa-trash-o"></i></a>
                        <?php } ?>
                      </td>
                    </tr>
                  <?php endforeach;endif;?>
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </div>
    </div>
    <!-- page end-->
  </section>
</section>