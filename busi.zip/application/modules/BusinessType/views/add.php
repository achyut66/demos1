<!--main content start-->
<section id="main-content">
  <section class="wrapper site-min-height">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo base_url()?>"><i class="fa fa-home"></i> ड्यासबोर्डमा</a></li>
        <li class="breadcrumb-item"><a href="<?php echo base_url()?>BusinessType">व्यवसाय प्रकार सूचीमा जानुहोस </a></li>
        <li class="breadcrumb-item"><a href="javascript:;"> नयाँ थप्नुहोस् </a></li>
      </ol>
    </nav>
    <!-- page start-->
    <div class="row">
      <div class="col-sm-12">
        <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
          if(!empty($success_message)) { ?>
          <div class="alert alert-success">
            <button class="close" data-close="alert"></button>
            <span> <?php echo $success_message;?> </span>
          </div>
        <?php } ?>
        <section class="card">
          <header class="card-header" style="background: #1b5693;color:#FFF">व्यवसाय प्रकार थप्नुहोस्
           <?php if($this->authlibrary->HasModulePermission('CATEGORY', "ADD")) { ?>
            <button type="button" data-toggle="modal" href="#addModel" class="btn btn-secondary pull-right" data-url="<?php echo base_url()?>BusinessType/addMainTopic"><i class="fa fa-plus-circle"></i> नया शिर्षक थप्नुहोस्</button>
            <?php } ?></header>
          <div class="card-body">
            <form role="form" action="<?php echo base_url()?>BusinessType/save" method="post">
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <div class="row">
                <table class="table table-bordered" id="add_new_fields">
                  <thead>
                    <tr>
                      <th>शिर्षक</th>
                      <th>उप शिर्षक</th>
                      <th>दर्ता दस्तुर</th>
                      <th>नविकरण दस्तुर</th>
                      <th>#</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <select class="form-control" name="main_topic[]">
                          <option value= "" >छानुहोस</option>
                          <?php if(!empty($main_topic)): foreach($main_topic as $mt) : ?>
                            <option value="<?php echo $mt['id']?>"><?php echo $mt['topic_name']?></option>
                          <?php endforeach; endif;?>
                        </select>
                      </td>
                      
                      <td>
                          <input type="text" class="form-control" placeholder="" name="sub_topic[]" required="required" value="">
                      </td>
                      <td>
                          <input type="text" class="form-control" placeholder="" name="darta_dastur[]" required="required" value="">
                      </td>
                      <td>
                          <input type="text" class="form-control" placeholder="" name="renew_dastur[]" required="required" value="">
                      </td>
                      <td style="width:50px;"><button class="btn btn-secondary btn-block btnAddNew"><i class="fa fa-plus"></i></button></td>
                    </tr>
                  </tbody>
                </table>
                
                <div class="col-md-12 text-center">
                  <hr>
                  <button class="btn btn-primary btn-xs save_button" data-toggle="tooltip"
                    title=" सेभ  गर्नुहोस्" name="Submit" type="submit" value="Save"> सेभ
                    गर्नुहोस्</button>
                  <a href="<?php echo base_url()?>SetTitle" class="btn btn-danger btn-xs"
                        data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
                </div>
              </div>
            </form>
          </div>
        </section>
      </div>
      <!-- page end-->
    </section>
  </section>

  <script type="text/javascript">
    $(document).ready(function(){
      
      //add new row
      $('.btnAddNew').click(function(e) {
        e.preventDefault();
        var trOneNew = $('.nagadi_rasid_frm').length+1;
        var new_row = 
        '<tr>'+
          '<td>'+
          '<select class="form-control" name="main_topic[]">'+
          '<option value= "" >छानुहोस</option><?php if(!empty($main_topic)): foreach($main_topic as $mt) : ?><option value="<?php echo $mt['id']?>"><?php echo $mt['topic_name']?></option><?php endforeach; endif;?></select>'+'</td>'+
          '<td><input type="text" name="sub_topic[]" value="" class="form-control" required></td>'+
          '<td><input type="text" class="form-control" placeholder="" name="darta_dastur[]" required="required" value=""></td>'+
          '<td><input type="text" class="form-control" placeholder="" name="renew_dastur[]" required="required" value=""></td>'+
          '<td><button type="button" class="btn btn-danger btn-block remove-row" data-toggle="tooltip" title="हटाउनुहोस्"><span class="fa fa-times" tabindex="-1"></span></button></td>'+
          '<tr>'
          $("#add_new_fields").append(new_row);
          $('.main_topics-').select2();
        });
        $("body").on("click",".remove-row", function(e){
          e.preventDefault();
          
          if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
           var amt = $(this).closest("tr").find('.topic_rate').val();
           var t_amt = $('#t_total').val();
           var new_amt = t_amt-amt;
           $("#t_total").val(new_amt);
           $(this).parent().parent().remove();
          }
        });
        $(document).on('change','.parent_title', function() {
          obj = $(this);
          var main_topic = obj.val();
          $.ajax({
            method:"POST",
            url:base_url+"SetTitle/getSubTopic",
            data: {main_topic:main_topic},
            success:function(resp) {
              console.log(resp);
              if(resp.status == 'success') {
                obj.closest("tr").find(".sub_topic").html(resp.data);
              }
            }
          });
        });

    });
  </script>
  