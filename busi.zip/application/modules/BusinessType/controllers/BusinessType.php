<?php
/**
 * Created by PhpStorm.
 * User: root
 */
class BusinessType extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->load->model('SetTitleModel');
        $this->module_code = 'BTYPE';
        if(!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login','location');
        }
    }

    /*
        *This function list all the land minimun rate
        @param 
        return array of all land_minimum rate

     */
    public function Index()
    {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $data['page']           = 'list_all';
            $data['fiscal_year']    = $this->CommonModel->getData('fiscal_year','DESC');
            $data['prakar']         = $this->SetTitleModel->getPrakar('prakar','ASC');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    //add main topic
    public function addMainTopic() {
        $this->load->view('add_main_topic');
    }
    public function saveMainTopic() {
        if($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('main_topic', '', 'required');
            if($this->form_validation->run() == false) {
                $response = array(
                    'status'        => 'validation_error',
                    'message'       => validation_errors(),
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $post_data = array(
                'topic_name'        => $this->input->post('main_topic'),
            );
            $result                 = $this->CommonModel->insertData('main_topic',$post_data);
            if($result) {
                $response = array(
                    'status'        => 'success',
                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } 
        } else {
            exit('no direct script allowed');
        }
    }
    /** 
        *This function display all topic detials with rate and related parent topic and subtopic
        @param nul
        return add topic details form
    */
    public function add() {
        if($this->authlibrary->HasModulePermission($this->module_code, "ADD")){
            $data['page']           = 'add';
            $data['main_topic']     = $this->CommonModel->getData('main_topic');
            $data['category']       = $this->CommonModel->getData('category');
            $this->load->view('main', $data);
        }else{
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }
    //save new kar details
    public function save() {
        if($this->input->post('Submit')) {
            $main_topic                     = $this->input->post('main_topic');
            $sub_topic                      = $this->input->post('sub_topic');
            $darta_dastur                   = $this->input->post('darta_dastur');
            $renew_dastur                   = $this->input->post('renew_dastur');
            $post_array                     = array();
            foreach ($main_topic as $key    => $index ) {
                $post_array[] = array(
                    'fiscal_year'           => current_fiscal_year(),
                    'main_topic'            => $main_topic[$key],
                    'sub_topic'             => $sub_topic[$key],
                    'darta_dastur'          => $darta_dastur[$key],
                    'renew_dastur'          => $renew_dastur[$key],
                    'status'                => 1,
                    'added_by'              => $this->session->userdata('PRJ_USER_BID'),
                    'added_on'              => convertDate(date('Y-m-d')),
                    'modified_by'           => '',
                    'modified_on'           => '',
                );
            }
            $result = $this->CommonModel->batchInsert($post_array,'prakar');
            if($result) {
                $this->session->set_flashdata('MSG_SUCCESS', MSG_SUCCESS);
                redirect('BusinessType');
            } else {
                $this->session->set_flashdata('MSG_SUCCESS', MSG_INSERT_ERR);
                redirect('BusinessType');
            }
        }
    }
    //edit details
    public function edit($id = NULL ) {
        $id = $this->uri->segment(3);
        if(empty($id)) {
            show_404();
        } else {
            if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
                $data['page']           = 'edit';
                $data['row']            = $this->CommonModel->getDataById('prakar',$id);
                $data['main_topic']     = $this->CommonModel->getData('main_topic');
                $this->load->view('main', $data);
            } else {
                $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
                redirect('Dashboard');
            }
        }
    }

     //save new kar details
    public function update() {
        if($this->input->post('Submit')) {
            $main_topic                 = $this->input->post('main_topic');
            $sub_topic                  = $this->input->post('sub_topic');
            $id                         = $this->input->post('id');
            $darta_dastur               = $this->input->post('darta_dastur');
            $renew_dastur               = $this->input->post('renew_dastur');
            $post_array                 = array(
                'main_topic'            => $main_topic,
                'sub_topic'             => $sub_topic,
                'darta_dastur'          => $darta_dastur,
                'renew_dastur'          => $renew_dastur,
                'modified_by'           => $this->session->userdata('PRJ_USER_BID'),
                'modified_on'           => convertDate(date('Y-m-d')),
            );
            $result = $this->CommonModel->updateData('prakar', $id, $post_array);
            if($result) {
                $this->session->set_flashdata('MSG_SUCCESS', MSG_UPDATE);
                redirect('BusinessType');
            } else {
                $this->session->set_flashdata('MSG_SUCCESS', MSG_INSERT_ERR);
                redirect('BusinessType');
            }
        }
    }

    public function delete($id) {
        if(empty($id)) {
            show_404();
        } else {
            $result = $this->CommonModel->deleteData('prakar', $id);
            if($result) {
                $this->session->set_flashdata('MSG_SUCCESS', MSG_DELETE);
                redirect('BusinessType');
            } else {
                $this->session->set_flashdata('MSG_SUCCESS', MSG_INSERT_ERR);
                redirect('BusinessType');
            }
        }
    }
}