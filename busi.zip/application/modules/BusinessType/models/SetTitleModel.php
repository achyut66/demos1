<?php 

class SetTitleModel extends CI_Model {

    /**
        *this function get topic rate
        @param int sub topic
        return result array
    */
    public function getPrakar() {
        $this->db->select('t1.*, t2.topic_name as main_topic');
        $this->db->from('prakar as t1');
        $this->db->join('main_topic as t2', 't2.id = t1.main_topic','left');
        $query = $this->db->get();
        return $query->result_array();
    }
}