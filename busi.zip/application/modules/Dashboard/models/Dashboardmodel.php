<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/*This class load model for dashboard*/

class Dashboardmodel extends CI_Model
{
	public function __construct()
	{
		parent:: __construct();
        $this->fy = current_fiscal_year();
	}
	public function getDartaCount() {
		if($this->session->userdata('PRJ_USER_BID') != 1) {
			$this->db->where('added_by', $this->session->userdata('PRJ_USER_BID'));
		}
        $this->db->from("darta");
        $count = $this->db->count_all_results();
        return $count;
	}

	public function getKrishiSamuhaCount() {
		if($this->session->userdata('PRJ_USER_BID') != 1) {
			$this->db->where('created_by', $this->session->userdata('PRJ_USER_BID'));
		}
        $this->db->from("krishi_samuha_darta");
        $count = $this->db->count_all_results();
        return $count;
	}
	public function getKhanepaniCount() {
		if($this->session->userdata('PRJ_USER_BID') != 1) {
			$this->db->where('created_by', $this->session->userdata('PRJ_USER_BID'));
		}
        $this->db->from("khanepani");
        $count = $this->db->count_all_results();
        return $count;
	}
	public function getIpCount() {
		if($this->session->userdata('PRJ_USER_BID') != 1) {
			$this->db->where('created_by', $this->session->userdata('PRJ_USER_BID'));
		}
        $this->db->from("ijajat_patra");
        $count = $this->db->count_all_results();
        return $count;
	}
	public function getSahakariCount() {
		if($this->session->userdata('PRJ_USER_BID') != 1) {
			$this->db->where('created_by', $this->session->userdata('PRJ_USER_BID'));
		}
        $this->db->from("sahakari_darta");
        $count = $this->db->count_all_results();
        return $count;
	}

	public function getRmCount() {
		if($this->session->userdata('PRJ_USER_BID') != 1) {
			$this->db->where('created_by', $this->session->userdata('PRJ_USER_BID'));
		}
        $this->db->from("rasayenik_maal");
        $count = $this->db->count_all_results();
        return $count;
	}

	public function getMmCount() {
		if($this->session->userdata('PRJ_USER_BID') != 1) {
			$this->db->where('created_by', $this->session->userdata('PRJ_USER_BID'));
		}
        $this->db->from("mel_milap");
        $count = $this->db->count_all_results();
        return $count;
	}

	public function getACount() {
		if($this->session->userdata('PRJ_USER_BID') != 1) {
			$this->db->where('created_by', $this->session->userdata('PRJ_USER_BID'));
		}
        $this->db->from("affiliation");
        $count = $this->db->count_all_results();
        return $count;
	}

	public function getPlCount() {
		if($this->session->userdata('PRJ_USER_BID') != 1) {
			$this->db->where('created_by', $this->session->userdata('PRJ_USER_BID'));
		}
        $this->db->from("permission_letter");
        $count = $this->db->count_all_results();
        return $count;
	}


	public function getCountRenew() {
		if($this->session->userdata('PRJ_USER_BID') != 1) {
			$this->db->where('added_ward', $this->session->userdata('PRJ_USER_WARD'));
		}
        $this->db->from("renew");
        return $this->db->count_all_results();
	}

	public function countByParkar($main_topic) {
		$this->db->where('b_type',$main_topic);
		if($this->session->userdata('PRJ_USER_BID') != 1) {
			$this->db->where('added_ward', $this->session->userdata('PRJ_USER_WARD'));
		}
        $this->db->from("darta");
        return $this->db->count_all_results();
	}
	public function countRenewByParkar($main_topic) {
		$this->db->where('b_type',$main_topic);
		if($this->session->userdata('PRJ_USER_BID') != 1) {
			$this->db->where('added_ward', $this->session->userdata('PRJ_USER_WARD'));
		}
        $this->db->from("renew");
        return $this->db->count_all_results();
	}

	public function getParkarCount() {
        $this->db->distinct();
        $this->db->select('id');
        $this->db->from('main_topic');
		return $this->db->count_all_results();
    }

	public function countByupaParkar($topic) {
		$this->db->where('b_subtype',$topic);
		if($this->session->userdata('PRJ_USER_BID') != 1) {
			$this->db->where('added_ward', $this->session->userdata('PRJ_USER_WARD'));
		}
        $this->db->from("darta");
        return $this->db->count_all_results();
	}
	public function countRenewByupaParkar($topic) {
		$this->db->where('b_subtype',$topic);
		if($this->session->userdata('PRJ_USER_BID') != 1) {
			$this->db->where('added_ward', $this->session->userdata('PRJ_USER_WARD'));
		}
        $this->db->from("renew");
        return $this->db->count_all_results();
	}
}