<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-md-2">
                <a href="#">
                    <img src="assets/img/nepal-govt.png" style="height: 100px">
                </a>
            </div>
            <div class="col-md-8">
                <div style="text-align: center;">
                <h4 style="color:#000"><?php echo GNAME?></h4>
                    <h6 style="color:#000"><b><?php echo SLOGAN?></b></h6>
                    <h6 style="color:#000"><?php echo ADDRESS?>,<?php echo DISTRICT?></h6>
                    <h6 style="color:#000"><?php echo STATENAME?>, नेपाल</h6>
                </div>
            </div>
            <?php if(!empty(PALIKALOGO)) : ?>
            <div class="col-md-2">
                <a href="#">
                    <img src="assets/img/<?php echo PALIKALOGO;?>" alt="" style="height: 100px">
                </a>
            </div>
            <?php endif;?>
        </div>
        <hr>
        
        <div class="row state-overview">
            <div class="col-lg-6 col-sm-6">
                <section class="card">
                    <div class="symbol terques ">
                    <a href="<?php echo base_url()?>Register"><i class="fa fa-info-circle"></i></a>
                    </div>
                    <div class="value">
                    <h1 class=""><?php echo !empty($DartaCount)? $this->mylibrary->convertedcit(number_format($DartaCount)):$this->mylibrary->convertedcit(0)?></h1>
                    <p><a href="<?php echo base_url()?>Register">जम्मा व्यवसाय दर्ता</a> </p>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-sm-6">
                <section class="card">
                    <div class="symbol blue">
                    <a href="<?php echo base_url()?>AgricultureDepartment"><i class="fa fa-info-circle"></i></a>
                    </div>
                    <div class="value">
                    <h1 class=" count4 dark"><?php echo !empty($RenewCount)? $this->mylibrary->convertedcit(number_format($krishicount)):$this->mylibrary->convertedcit(0)?></h1>
                    <p><a href="<?php echo base_url()?>AgricultureDepartment"> जम्मा कृषि समूह दर्ता</a></p>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 col-sm-6">
                <section class="card">
                    <div class="symbol yellow">
                    <a href="<?php echo base_url()?>Khanepani"> <i class="fa fa-info-circle"></i></a>
                    </div>
                    <div class="value">
                    <h1 class=" count4 dark"><?php echo !empty($khanepanicount)? $this->mylibrary->convertedcit(number_format($khanepanicount)):$this->mylibrary->convertedcit(0)?></h1>
                    <p> <a href="<?php echo base_url()?>Khanepani">जम्मा खानेपानी समूह दर्ता</a> </p>
                    </div>
                </section>
            </div>

            <div class="col-lg-6 col-sm-6">
                <section class="card">
                    <div class="symbol" style="background:#ab3030">
                    <a href="<?php echo base_url()?>SahakariDarta"> <i class="fa fa-info-circle"></i></a>
                    </div>
                    <div class="value">
                    <h1 class=" count4 dark"><?php echo !empty($sahakaricount)? $this->mylibrary->convertedcit(number_format($sahakaricount)):$this->mylibrary->convertedcit(0)?></h1>
                    <p><a href="<?php echo base_url()?>SahakariDarta"> जम्मा सहकारी दर्ता </a></p>
                    </div>
                </section>
            </div>

            <div class="col-lg-6 col-sm-6">
                <section class="card">
                    <div class="symbol" style="background:#3067ab"">
                    <a href="<?php echo base_url()?>SahakariDarta"> <i class="fa fa-info-circle"></i></a>
                    </div>
                    <div class="value">
                    <h1 class=" count4 dark"><?php echo !empty($ipcount)? $this->mylibrary->convertedcit(number_format($ipcount)):$this->mylibrary->convertedcit(0)?></h1>
                    <p><a href="<?php echo base_url()?>IjajatPatra"> जम्मा इजाजतपत्र दर्ता </a></p>
                    </div>
                </section>
            </div>

            <div class="col-lg-6 col-sm-6">
                <section class="card">
                    <div class="symbol" style="background:#196B6B">
                    <a href="<?php echo base_url()?>SahakariDarta"> <i class="fa fa-info-circle"></i></a>
                    </div>
                    <div class="value">
                    <h1 class=" count4 dark"><?php echo !empty($rmcount)? $this->mylibrary->convertedcit(number_format($rmcount)):$this->mylibrary->convertedcit(0)?></h1>
                    <p><a href="<?php echo base_url()?>RasaynikMaal"> जम्मा रासायनिक मल बिक्रेता प्रमाण पत्र </a></p>
                    </div>
                </section>
            </div>

            <div class="col-lg-6 col-sm-6">
                <section class="card">
                    <div class="symbol" style="background:#6b3051">
                    <a href="<?php echo base_url()?>SahakariDarta"> <i class="fa fa-info-circle"></i></a>
                    </div>
                    <div class="value">
                    <h1 class=" count4 dark"><?php echo !empty($mmcount)? $this->mylibrary->convertedcit(number_format($mmcount)):$this->mylibrary->convertedcit(0)?></h1>
                    <p><a href="<?php echo base_url()?>Melmilap"> जम्मा मेलमलिाप कर्ताको प्रमाणपत्र </a></p>
                    </div>
                </section>
            </div>

            <div class="col-lg-6 col-sm-6">
                <section class="card">
                    <div class="symbol" style="background:#2986CC">
                    <a href="<?php echo base_url()?>SahakariDarta"> <i class="fa fa-info-circle"></i></a>
                    </div>
                    <div class="value">
                    <h1 class=" count4 dark"><?php echo !empty($acount)? $this->mylibrary->convertedcit(number_format($acount)):$this->mylibrary->convertedcit(0)?></h1>
                    <p><a href="<?php echo base_url()?>Affiliation"> जम्मा आवद्धताको प्रमाण-पत्र </a></p>
                    </div>
                </section>
            </div>

            <div class="col-lg-6 col-sm-6">
                <section class="card">
                    <div class="symbol" style="background:#2B2303">
                    <a href="<?php echo base_url()?>SahakariDarta"> <i class="fa fa-info-circle"></i></a>
                    </div>
                    <div class="value">
                    <h1 class=" count4 dark"><?php echo !empty($plcount)? $this->mylibrary->convertedcit(number_format($plcount)):$this->mylibrary->convertedcit(0)?></h1>
                    <p><a href="<?php echo base_url()?>PermissionLetter"> जम्मा भारि उपकरण संचालन अनुमति पत्र </a></p>
                    </div>
                </section>
            </div>

        </div>
        <!-- <hr> -->
        <!-- <div class="row">
            <div class="col-md-6">
                <section class="card">
                    <header class="card-header text-light" style="background-color:#015C92;">व्यवसायीको प्रकार अनुसार दर्ता विवरण
                        <span class="tools">
                            <a href="<?php echo base_url()?>businessregister/Register/add" class=" btn btn-secondary pull-right" title=""><i class="fa fa-plus-circle"></i> नयाँ व्यवसाय दर्ता गर्नुहोस</a>
                        </span>
                    </header>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>प्रकार</th>
                                    <th>जम्मा दर्ता </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $total = 0;$i=1;if(!empty($prakar)): foreach($prakar as $type): ?>
                                <tr>
                                    <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                                    <td><a href=""><?php echo $type['topic_name']?></a></td>
                                    <td>
                                    <?php 
                                    $count = $this->DashboardModel->countByParkar($type['id']); echo $this->mylibrary->convertedcit($count);
                                    $total += $count;
                                    ?></td>
                                </tr>
                                <?php endforeach;endif;?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan = "2" class="text-right">जम्मा</td>
                                    <td><?php echo $this->mylibrary->convertedcit($total);?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </section>
            </div>
            <div class="col-md-6">
                <section class="card">
                    <header class="card-header text-light" style="background-color:#015C92;">व्यवसायको प्रकार अनुसार नवीकरण विवरण </header>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>प्रकार</th>
                                    <th>जम्मा नवीकरण </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $total=0;$i=1;if(!empty($prakar)): foreach($prakar as $type): ?>
                                <tr>
                                    <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                                    <td><?php echo $type['topic_name']?></td>
                                    <td><?php $count = $this->DashboardModel->countRenewByParkar($type['id']); echo $this->mylibrary->convertedcit($count);$total += $count;?></td>
                                </tr>
                                <?php endforeach;endif;?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan = "2" class="text-right">जम्मा</td>
                                    <td><?php echo $this->mylibrary->convertedcit($total);?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </section>
            </div>
        </div> -->

        <!-- <div class="row">
            <div class="col-md-6">
                <section class="card">
                    <header class="card-header text-light" style="background-color:#015C92;">व्यवसायीको उप शिर्षक अनुसार दर्ता विवरण विवरण</header>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>उप शिर्षक</th>
                                    <th>जम्मा दर्ता </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $total= 0;$i=1;if(!empty($upaprakar)): foreach($upaprakar as $utype): ?>
                                <tr>
                                    <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                                    <td><?php echo $utype['sub_topic']?></td>
                                    <td><?php $count = $this->DashboardModel->countByupaParkar($utype['id']); echo $this->mylibrary->convertedcit($count);$total +=$count;?></td>
                                </tr>
                                <?php endforeach;endif;?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan = "2" class="text-right">जम्मा</td>
                                    <td><?php echo $this->mylibrary->convertedcit($total);?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </section>
            </div>
            <div class="col-md-6">
                <section class="card">
                    <header class="card-header text-light" style="background-color:#015C92;">व्यवसायको उप शिर्षक अनुसार नवीकरण विवरण 
                    
                    </header>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>प्रकार</th>
                                    <th>जम्मा नवीकरण </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $total=0;$i=1;if(!empty($upaprakar)): foreach($upaprakar as $type): ?>
                                <tr>
                                    <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                                    <td><?php echo $type['sub_topic']?></td>
                                    <td><?php $count = $this->DashboardModel->countRenewByParkar($type['id']); echo $this->mylibrary->convertedcit($count);$total += $count;?></td>
                                </tr>
                                <?php endforeach;endif;?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan = "2" class="text-right">जम्मा</td>
                                    <td><?php echo $this->mylibrary->convertedcit($total);?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </section>
            </div>
        </div> -->

    </section>
</section>