<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Dashboard extends MX_Controller
{	
	public function __construct()
	{
		parent:: __construct();
        $this->load->model('DashboardModel');
        $this->load->model('CommonModel');
        if(!$this->authlibrary->IsLoggedIn()){
            $this->session->set_userdata('return_url', current_url());
            redirect('Login');
        }
		$this->container='main';
	}
	public function Index()
	{
        $data['page']               = 'dashboard';
        $data['prakar']             = $this->CommonModel->getData('main_topic');
        $data['upaprakar']          = $this->CommonModel->getData('prakar');
        $data['DartaCount']         = $this->DashboardModel->getDartaCount(); // business register.
        $data['krishicount']        = $this->DashboardModel->getKrishiSamuhaCount(); //krishi.
        $data['khanepanicount']     = $this->DashboardModel->getKhanepaniCount(); //  khanepani.
        $data['sahakaricount']      = $this->DashboardModel->getSahakariCount(); // sahakari.
        $data['ipcount']            = $this->DashboardModel->getIpCount(); // ijajat patra.
        $data['rmcount']            = $this->DashboardModel->getRmCount(); // rasayanik maal.
        $data['mmcount']            = $this->DashboardModel->getMmCount(); // melmilap.
        $data['acount']            = $this->DashboardModel->getACount(); // affiliation.
        $data['plcount']            = $this->DashboardModel->getPlCount(); // pl.
        // $data['RenewCount']     = $this->DashboardModel->getCountRenew();
        // $data['ParkarCount']    = $this->DashboardModel->getParkarCount();
        $this->load->view('main', $data);
	}
}