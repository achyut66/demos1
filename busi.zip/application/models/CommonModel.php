<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class CommonModel extends CI_Model
{

    public function getCurrentUser($userid)
    {
        return $this->db->select('*')->from('users')
            ->where('userid', $userid)
            ->get()
            ->row_array();
    }
    /**
     * This function get land details with id reference.
     * @param string $table , table name
     * @param array $data, post data
     * @return row array
     */
    public function insertData($table, $data)
    {
        $this->db->insert($table, $data);
        if ($this->db->affected_rows() > 0) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    /**
     * This fetch entries from given table
     * @param string $table , table name
     * @param string $order_by, order
     * @param string $order_by_field, order column
     * @return array
     */
    public function getData($table, $order_by = null, $order_by_field = NULL)
    {
        if (!empty($order_by) && !empty($order_by_field)) {
            $this->db->order_by($order_by_field, $order_by);
        }
        $query = $this->db->get($table);
        $result = $query->result_array();
        return !empty($result) ? $result : false;
    }
    // get darta_no max
    public function getMaxDarta($table)
    {
        $query = $this->db->query("SELECT max(darta_no) AS max_darta_no FROM $table");
        $row = $query->row_array();
        return $row['max_darta_no']; // Return the max darta_no directly
    }

    /**
     * This fetch row from given table
     * @param string $table , table name
     * @param string $fieldName, column
     * @param string $fieldData, where condition.aaa
     * @return result array
     */
    public function getAllDataByField($table, $FieldName, $FieldData)
    {
        $this->db->where($FieldName, $FieldData);
        $query = $this->db->get($table);
        $result = $query->result_array();
        return !empty($result) ? $result : false;
    }

    /**
     * This fetch row from given table
     * @param string $table , table name
     * @param int $id
     * @return row array
     */
    //get data by id
    public function getDataByID($table, $ID)
    {
        $query = $this->db->query("SELECT * FROM $table  WHERE `id` = '$ID'");
        return $query->row_array();
    }
    public function getMIgrationId($table, $ID)
    {
        $query = $this->db->query("SELECT * FROM $table  WHERE `prev_darta_id` = '$ID'");
        return $query->row_array();
    }
    /**
     * This fetch row by selected fields
     * @param string $table , table name
     * @param string $fieldName, column
     * @param string $fieldData, where condition.aaa
     * @return row array
     */
    public function getDataBySelectedFields($table, $fieldName, $field)
    {
        $this->db->select('*')->from($table);
        $this->db->where($fieldName, $field);
        $query = $this->db->get();
        $result = $query->row_array();
        return !empty($result) ? $result : false;
    }

    /**
     * This fetch row by selected fields
     * @param string $table , table name
     * @param string $fieldName, column
     * @param string $fieldData, where condition.aaa
     * @return row array
     */
    public function getAllDataBySelectedFields($table, $fieldName, $field)
    {
        $this->db->select('*')->from($table);
        $this->db->where($fieldName, $field);
        $query = $this->db->get();
        $result = $query->result_array();
        return !empty($result) ? $result : false;
    }
    //update Data
    public function UpdateData($table, $ID, $data)
    {
        $this->db->where('id', $ID);
        $this->db->update($table, $data);
        return true;
    }

    public function updateDataByField($table, $fieldName, $fieldData, $data)
    {
        $this->db->where($fieldName, $fieldData);
        $this->db->update($table, $data);
        return true;
    }
    public function updataMultipleData($table, $fieldName, $fieldData, $data)
    {
        $this->db->where_in($fieldName, $fieldData);
        $this->db->update($table, $data);
        return true;
    }

    public function deleteMultipleData($table, $fieldName, $fieldData)
    {
        $this->db->where_in($fieldName, $fieldData);
        $this->db->delete($table);
        return true;
    }

    //remove data
    public function deleteData($table, $ID)
    {
        $query = $this->db->query("DELETE FROM $table  WHERE `id` = '$ID'");
        return $this->db->affected_rows();
    }

    public function deleteDataBySelectedFields($table, $fieldName, $fieldData)
    {
        $this->db->where($fieldName, $fieldData);
        $this->db->delete($table);
        return true;
    }
    //select max id
    // public function GetMaxID($table, $invoice)
    // {
    // 	$maxid = 0;
    // 	$row = $this->db->query("SELECT MAX(id) AS `maxid` FROM $table WHERE `sales_by` = '$invoice'")->row();
    // 	return $row;
    // }

    public function checkAreadyExits($table, $fieldName, $fieldData)
    {
        $this->db->where($fieldName, $fieldData, $table);
        $query = $this->db->get($table);
        return $query->row_array();
    }


    //get current fiscal year
    public function getCurrentFiscalYear()
    {
        return $this->db->select('year')
            ->from('fiscal_year')
            ->where('is_current', 1)
            ->get()
            ->row_array();
    }

    //get gapana
    public function getGapaNapa()
    {
        return $this->db->select('*')
            ->from('settings_vdc_municipality')
            ->where('district', DISTRICT)
            ->get()
            ->result_array();
    }

    //get districts
    public function getDistrictsByState($state)
    {
        return $this->db->select('*')
            ->from('settings_district')
            ->where('state', $state)
            ->get()
            ->result_array();
    }

    //get districts
    public function getDistrictsByID($ID)
    {
        return $this->db->select('*')
            ->from('settings_district')
            ->where('id', $ID)
            ->get()
            ->row_array();
    }


    public function getGapanaByDistrict($district)
    {
        return $this->db->select('*')
            ->from('settings_vdc_municipality')
            ->where('district_id', $district)
            ->get()
            ->result_array();
    }

    //get old fiscal year
    public function getDepFiscalYear()
    {
        $current_fy = current_fiscal_year();
        $this->db->select('*')->from('fiscal_year');
        $this->db->where('year !=', $current_fy['year']);
        $sql = $this->db->get();
        return $sql->result_array();
    }

    public function getBFiscalYear()
    {
        $current_fiscal_year = current_fiscal_year();
        $year = $current_fiscal_year['year'];
        $this->db->select('*')->from('fiscal_year');
        $this->db->where('year !=', $year);
        $query = $this->db->get();
        return $query->result_array();
    }
    //update fiscal year
    public function updateFiscalYear($post_data, $id)
    {
        $this->db->where('id !=', $id);
        $this->db->update('fiscal_year', $post_data);
    }
    public function remove($id, $table)
    {
        $this->db->where('id', $id);
        $del = $this->db->delete($table);
        if ($del) {
            return TRUE;
        } else {
            return FALSE;
        }
    }


    public function bulkDelete($data, $table, $condition)
    {
        $this->db->trans_start();
        $this->db->where($condition);
        $this->db->delete($table);
        $this->db->trans_complete();
        return ($this->db->trans_status() === FALSE) ? FALSE : TRUE;
    }
    /**
     * This function get land details with id reference.
     * @param int $alpha
     * @return row
     */
    public function getNameCount($alpha)
    {
        $this->db->select('count(id) as third_sn');
        $this->db->from('darta');
        $this->db->where('SUBSTRING(business_name_en, 1, 1)=', $alpha);
        $query = $this->db->get();
        return $query->row();
    }

    public function getWhereAll($table, $array)
    {
        $this->db->select('*')->from($table);
        $this->db->where($array);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function getWhere($table, $array)
    {
        $this->db->select('*')->from($table);
        $this->db->where($array);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function get_image_file($doc_slug)
    {
        // Build the query to fetch the image file from the database based on the id parameter
        $this->db->select('*');
        $this->db->from('documents');
        $this->db->where('doc_slug', $doc_slug);

        // Execute the query and fetch the image file
        $query = $this->db->get();
        return $query->result_array();
    }


    //insert members
    public function batchInsert($post_data, $table)
    {
        $this->db->trans_start();
        $this->db->insert_batch($table, $post_data);
        $this->db->trans_complete();
        return ($this->db->trans_status() === FALSE) ? FALSE : TRUE;
    }

    public function batchUpdate($table, $id, $post_array)
    {
        $this->db->trans_start();
        $this->db->update_batch($table, $post_array, 'id');
        $this->db->trans_complete();
        if ($this->db->affected_rows() > 0) {
            return TRUE;
        } else {
            // any trans error?
            if ($this->db->trans_status() === FALSE) {
                return false;
            }
            return true;
        }
    }

    //get distinct data
    public function getDistinctParkar()
    {
        $this->db->distinct();
        $this->db->select('main_topic');
        $this->db->from('prakar');
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function getSubTopic()
    {
        $this->db->select('sub_topic');
        $this->db->from('prakar');
        $query = $this->db->get()->result_array();
        return $query;
    }
}
