<?php 
function upload_multiple($path,$field_name,$doc_type, $reg_id, $slug,$status){
        $ci =& get_instance();
        $ci->load->library('upload');
        $path = 'assets/darta_images';
        $files = $_FILES;
        $cpt = count($_FILES[$field_name]['name']);//count for number of image files
        // pp($cpt);
        $image_name =array();
        for($i=0; $i<$cpt; $i++)
        {         
            
            $_FILES[$field_name]['name']= $files[$field_name]['name'][$i];
            $_FILES[$field_name]['type']= $files[$field_name]['type'][$i];
            $_FILES[$field_name]['tmp_name'] = $files[$field_name]['tmp_name'][$i];
            $_FILES[$field_name]['error']= $files[$field_name]['error'][$i]; 
            $_FILES[$field_name]['size'] = $files[$field_name]['size'][$i];
           // print_r($files);  
            $ci->upload->initialize(set_upload_options($path));
            // Upload file to server 
            if($ci->upload->do_upload($field_name)){ 
                // Uploaded file data 
                $fileData = $ci->upload->data();
               
                $files[$i]['file_name'] = $fileData['file_name']; 
                $files[$i]['uploaded_on'] = date("Y-m-d H:i:s");
                $image_name[] = array(
                    'doc_name' => $fileData['file_name'],
                    'doc_type' => $doc_type[$i],
                    'reg_id' => $reg_id, 
                    'doc_slug' => $slug, 
                    'status' => $status
                );
            } else {
                $image_name[]  = array(
                    'message' => 'error',
                    'error_message' => $ci->upload->display_errors()
                );
            }
            //store file name into array
        }
        // pp($image_name);
        return $image_name;//all images name which is uploaded
    }
    
    function file_upload() {
        
    }
    
    function set_upload_options($path)
    {   
        $config = array();
        $config['upload_path'] = $path;
        $config['allowed_types'] = 'pdf|jpg|png|jpeg|JPEG|PNG';
        $config['max_size'] = 2100; // 2MB max file size
        $config['overwrite']     = FALSE;
        return $config;
    }
    ?>