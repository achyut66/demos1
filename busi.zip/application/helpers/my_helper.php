<?php if (!defined('BASEPATH')) {
	exit('No direct script access allowed');
}
date_default_timezone_set('Asia/Katmandu');
require APPPATH . '/libraries/NepaliCalendar.php';
if (!function_exists('convertDate')) {
	/**
	 * @param  date $date Date in english format
	 * @return date       Date in Nepali format 
	 */
	function convertDate($date)
	{
		$calendar = new NepaliCalendar();
		$timestamp  = strtotime($date);
		$year 		= date('Y', $timestamp);
		$month 		= date('m', $timestamp);
		$day 		= date('d', $timestamp);
		$nepdate = $calendar->eng_to_nep($year, $month, $day);
		$nepali_month = $nepdate['month'];
		$nepali_date  = $nepdate['date'];
		if (strlen($nepali_month) == 1) {
			$nepali_month = '0' . $nepali_month;
		} elseif (strlen($nepali_month) == 2) {
			$nepali_month;
		}
		if (strlen($nepali_date) == 1) {
			$nepali_date = '0' . $nepali_date;
		} elseif (strlen($nepali_date) == 2) {
			$nepali_date;
		}
		$finaldate = $nepdate['year'] . '-' . $nepali_month . '-' . $nepali_date;
		return $finaldate;
	}
}

function convertNepDate($date)
{
	$calendar = new NepaliCalendar();
	$timestamp  = strtotime($date);
	$year 		= date('Y', $timestamp);
	$month 		= date('m', $timestamp);
	$day 		= date('d', $timestamp);
	$endDate = $calendar->nep_to_eng($year, $month, $day);
	$eng_month = $endDate['month'];
	$eng_date  = $endDate['date'];
	if (strlen($eng_month) == 1) {
		$eng_month = '0' . $eng_month;
	} elseif (strlen($eng_month) == 2) {
		$eng_month;
	}
	if (strlen($eng_date) == 1) {
		$nepali_date = '0' . $eng_date;
	} elseif (strlen($eng_date) == 2) {
		$eng_date;
	}
	$finaldate = $endDate['year'] . '-' . $eng_month . '-' . $eng_date;
	return $finaldate;
}

if (!function_exists('get_current_year')) {
	function get_current_year()
	{
		$current_date = convertDate(date('Y-m-d'));
		$exp = explode('-', $current_date);
		$year = $exp[0];
		return $year;
	}
}

//get current month
if (!function_exists('get_current_month')) {
	function get_current_month()
	{
		$current_date = convertDate(date('Y-m-d'));
		$exp = explode('-', $current_date);
		$month = $exp[1];
		return $month;
	}
}
if (!function_exists('get_current_day')) {
	function get_current_day()
	{
		$current_date = convertDate(date('Y-m-d'));
		$exp = explode('-', $current_date);
		$month = $exp[2];
		return $month;
	}
}

if (!function_exists('getNepaliMonthName')) {
	function getNepaliMonthName($num)
	{
		if ($num == 1) {
			$month = 'वैशाख';
		} elseif ($num == 2) {
			$month = 'ज्येष्ठ';
		} elseif ($num == 3) {
			$month = 'आषाढ';
		} elseif ($num == 4) {
			$month = 'श्रावण';
		} elseif ($num == 5) {
			$month = 'भाद्र';
		} elseif ($num == 6) {
			$month = 'आश्विन';
		} elseif ($num == 7) {
			$month = 'कार्तिक';
		} elseif ($num == 8) {
			$month = 'मार्ग';
		} elseif ($num == 9) {
			$month = 'पौष';
		} elseif ($num == 10) {
			$month = 'माघ';
		} elseif ($num == 11) {
			$month = 'फाल्गुन';
		} elseif ($num == 12) {
			$month = 'चैत्र';
		}
		return $month;
	}
}

//get day
if (!function_exists('getDay')) {
	function getDay()
	{
		$num =  date("l");
		if ($num == 'Sunday') {
			$day = '01';
		} elseif ($num == 'Monday') {
			$day = '02';
		} elseif ($num == 'Tuesday') {
			$day = '03';
		} elseif ($num == 'Wednesday') {
			$day = '04';
		} elseif ($num == 'Thrusday') {
			$day = '05';
		} elseif ($num == 'Friday') {
			$day = '06';
		} elseif ($num == 'Saturday') {
			$day = '07';
		} else {
			$day = '';
		}
		return $day;
	}
}

if (!function_exists('getDayName')) {
	function getDayName($num)
	{
		if ($num == '01') {
			$day = 'आइतबार';
		} elseif ($num == '02') {
			$day = 'सोमबार';
		} elseif ($num == '03') {
			$day = 'मंगलबार';
		} elseif ($num == '04') {
			$day = 'बुधबार';
		} elseif ($num == '05') {
			$day = 'बिहिबार';
		} elseif ($num == '06') {
			$day = 'शुक्रबार';
		} elseif ($num == '07') {
			$day = 'शनिबार';
		} else {
			$day = '';
		}
		return $day;
	}
}








if (!function_exists('get_colors')) {



	function get_colors()

	{

		$color	= array("#1E90FF", "#DC143C", "#F0FFFF", "#0000FF", "#8A2BE2", "#A52A2A", "#DEB887", "#5F9EA0", "#7FFF00", "#D2691E", "#FF7F50", "#6495ED", "#7FFFD4", "#00FFFF", "#008B8B", "#B8860B", "#A9A9A9", "#006400", "#BDB76B", "#8B008B", "#556B2F", "#FF8C00", "#9932CC", "#8B0000", "#E9967A", "#8FBC8F", "#483D8B", "#2F4F4F", "#9400D3", "#FF1493", "#CD5C5C", "#B22222", "#228B22", "#FF00FF", "#FFD700", "#00008B", "#FF69B4", "#4B0082");



		$color_json	= json_encode($color);



		return $color_json;
	}
}

if (!function_exists('moneyFormat')) {

	function moneyFormat($num)

	{

		$explrestunits = "";



		if (strrchr($num, ".")) {

			$dec = strrchr($num, ".");

			$int = $num - $dec;



			if (strlen($int) > 3) {



				$num = $num - $dec;

				$lastthree = substr($num, strlen($num) - 3, strlen($num));

				$restunits = substr($num, 0, strlen($num) - 3); // extracts the last three digits

				$restunits = (strlen($restunits) % 2 == 1) ? "0" . $restunits : $restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.

				$expunit = str_split($restunits, 2);

				for ($i = 0; $i < sizeof($expunit); $i++) {

					// creates each of the 2's group and adds a comma to the end

					if ($i == 0) {

						$explrestunits .= (int)$expunit[$i] . ","; // if is first value , convert into integer

					} else {

						$explrestunits .= $expunit[$i] . ",";
					}
				}



				$thecash = $explrestunits . $lastthree . $dec;
			} else {

				$thecash = $num;
			}
		} else {

			if (strlen($num) > 3) {

				$lastthree = substr($num, strlen($num) - 3, strlen($num));



				$restunits = substr($num, 0, strlen($num) - 3); // extracts the last three digits

				$restunits = (strlen($restunits) % 2 == 1) ? "0" . $restunits : $restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.

				$expunit = str_split($restunits, 2);

				for ($i = 0; $i < sizeof($expunit); $i++) {

					// creates each of the 2's group and adds a comma to the end

					if ($i == 0) {

						$explrestunits .= (int)$expunit[$i] . ","; // if is first value , convert into integer

					} else {

						$explrestunits .= $expunit[$i] . ",";
					}
				}



				$thecash = $explrestunits . $lastthree;
			} else {

				$thecash = $num;
			}
		}



		return $thecash; // writes the final format where $currency is the currency symbol.

	}
}



if (!function_exists('time_since')) {



	function time_since($since)

	{

		$chunks = array(

			array(60 * 60 * 24 * 365, 'year'),

			array(60 * 60 * 24 * 30, 'month'),

			array(60 * 60 * 24 * 7, 'week'),

			array(60 * 60 * 24, 'day'),

			array(60 * 60, 'hr'),

			array(60, 'min'),

			array(1, 'sec')

		);



		for ($i = 0, $j = count($chunks); $i < $j; $i++) {

			$seconds = $chunks[$i][0];

			$name = $chunks[$i][1];

			if (($count = floor($since / $seconds)) != 0) {

				break;
			}
		}



		$print = ($count == 1) ? '1 ' . $name : "$count {$name}s";

		return $print;
	}
}







if (!function_exists('remaining_days')) {



	function remaining_days($eventdate)

	{

		$date = date('Y-m-d');

		$date = strtotime($date);



		$datediff = $eventdate - $date;

		$status = floor($datediff / (60 * 60 * 24));



		if ($status == 0) {

			$message = "Today is the event day.";
		} elseif ($status > 0) {

			$message = $status . " day/s to go.";
		} else {

			$message = "Event finished";
		}



		return $message;
	}
}



if (!function_exists('pp')) {

	function pp($data)
	{

		echo '<pre>' . print_r($data, true) . '</pre>';

		exit;
	}
}



if (!function_exists('current_fiscal_year')) {

	function current_fiscal_year()
	{

		$CI = &get_instance();

		$CI->db->where('is_current', 1);

		$year = $CI->db->get('fiscal_year');

		$data =  $year->row_array();

		return $data['year'];

	}
}

if (!function_exists('get_year')) {

	function get_year($dob = false)
	{
		$date 		= convertDate(date('Y-m-d'));
		$date1 		= new DateTime($date);
		$date2 		= new DateTime($dob);
		$interval 	= $date1->diff($date2);
		if ($interval->y == 0) {
			$year = 1;
		} else {
			$year = $interval->y;
		}
		return $year;
		// 		echo "difference " . $interval->y . " years, " . $interval->m." months, ".$interval->d." days "; 

		// // shows the total amount of days (not divided into years, months and days like above)
		// 		echo "difference " . $interval->days . " days ";


		// $date 	= convertDate(date('Y-m-d'));
		// $date1 	= date_create('2078-04-29');
		// $date2 	= date_create('2075-02-26');
		// $diff 	= date_diff($date1,$date2);
		//return $diff;

		// 		$date1=date_create("2013-03-15");
		// $date2=date_create("2013-12-12");
		// $diff=date_diff($date1,$date2);
		// return $diff;
	}
}
