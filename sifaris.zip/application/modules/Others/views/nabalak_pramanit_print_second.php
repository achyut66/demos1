<?php
 $p_local_body     = Modules::run("Settings/getLocal",$result->p_local_body);
    $p_ward           = Modules::run("Settings/getWard",$result->p_ward);
    $p_state          = Modules::run("Settings/getState",$result->p_state);
    $p_district     = Modules::run("Settings/getDistrict",$result->p_district);
     $birthdate_eng = explode("-",$result->eng_dob);
     $current_session    = Modules::run('Settings/getCurrentSession',$result->session_id);
$worker_post        = Modules::run('Settings/getPost',$ward_worker->post_id);
     ?>
<div class="letter_print">
    <div>
        <div class="text-center"><p style="font-size:18px;"><u><strong>वडाको  सिफारिस</strong></u></p></div>
        <div class="text-justify mt-5">
            <p style="font-size:18px; text-align: justify;"><?=$p_district->name?> जिल्ला <?=$p_local_body->name." वडा नं ".$p_ward->name?>( साबिकको
            ठेगाना ............... ) वडामा स्थायी बसोबास गरि बस्ने यसमा
            लेखिएको
            श्री/सुश्री/श्रीमती <?= $result->applicant_name ?> को
            सम्बन्ध श्री/सुश्री/श्रीमती <?=$result->nep_first_name.' '.$result->nep_middle_name.' '.$result->nep_last_name ?> लाई म
            राम्ररी
            चिन्दछु। माथि लेखिए बमोजिम निजको
            व्यहोरा मैले
            बुझेसम्म साँचो हो। निजलाई नाबालक परिचयपत्र उपलब्ध गराउने सिफारिस
            गर्दछु।
            उक्त्त्त विवरण झुठ्ठा ठहरे
            कानुन बमोजिम सहुँला बुझाउला।</p>
        </div>
    </div>
    <div class="space3"></div>
    <div class="row mt-5">
        <div class="col-4">
            <div class="" style="font-size:20px;"> मिति :- </div>
            <div class="" style="font-size:20px;"> कार्यालयको छाप :- </div>
        </div>
        <div class="col-3 offset-5">
            <div class="b" style="margin-left:40px; font-size:20px;"> सिफारिस गर्नेको :- </div>
            <div class="my-3">
        </div>
                <div class="mt-5 signature" style="font-size:20px;">
                    <?= $ward_worker->name?><br/>
                    <?= $worker_post->name?>
                </div>
        </div>
    </div>
    <hr>
    <div class="text-justify mt-5">
            <p style="font-size:18px; text-align: justify;">
            यसमा लेखिएका नाबालक श्री .............................................................. मेरो एकाघर सगोलका ........................................ हुन । यस आवेदनमा लेखिएका सम्पूर्ण विवरण ठीक साँचो हो निजलाई नाबालक परिचय पत्र दिएमा कुनै फरक पर्दैन । फरक परेमा कानुन बमाजिम सहुँला बुझाउँला ।
            </p>
        </div>
        <span class="b" style="font-size:20px;">सनाखत गर्नेको औंठा छाप: </span>
            <div class="row mt-3">
                <div class="col-4 text-center">
                    <table class="finger-table table">
                        <tr>
                            <td>
                                दायाँ
                            </td>
                            <td>
                                बायाँ
                            </td>
                        </tr>
                        <tr>
                            <td style="height: 150px;">

                            </td>
                            <td>

                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div style="margin-top:-154px; margin-left:470px; font-size:20px;">
            <p>
                दस्तखत :  ..............................................
            </p>
            <p>
                नामथर: .................................................
            </p>
            <p>
                नाता सम्बन्ध: ..........................................
            </p>
            </div>
            <div class="space1"></div>
            <hr>
        <div class="text-justify mt-5" style="font-size:20px;">
                 श्रीमान्,
                 <br>
                 यसमा लेखिएका श्री ......................................................... लाई निम्न कागजातका आधारमा नाबालक परिचय पत्र प्रदान गर्न निर्णयार्थ पेश गरेको छु ।
        </div>
        <div class="text-justify mt-5" style="font-size:20px;">
                <u>संलग्न कागजात</u>
                <br>
                १. नाबालकको पिताको ना.प्र.को फोटोकपी
                <br>
                २. नाबालकको माताको ना.प्र.को फोटोकपी
                <br>
                ३. नाबालकको पिता/माता बीचको विवाह दर्ता प्रमाण पत्रको फोटोकपी
                <br>
                ४. नाबालकको जन्म दर्ता प्रमाण पत्र
                <br>
                ५. अन्य
        </div>
        <div class="space3"></div>
        <div class="col-3 offset-5" style="margin-left:10px;">
                <div class="signature" style="font-size:20px;">
                    सनाखत गराई पेश गर्ने
                </div>
        </div>
        <div class="col-3 offset-5" style="margin-left:390px; margin-top:-41px;">
                <div class="signature" style="font-size:20px;">
                    सिफारिस गर्ने
                </div>
        </div>
        <div class="col-3 offset-5" style="margin-left:733px; margin-top:-41px;">
                <div class="signature" style="font-size:20px;">
                    सदर गर्ने
                </div>
        </div>
        <!--<div class="row">-->
        <!--<div class="col-md-12">-->
            
        <!--                    <div class="col-md-4">-->
        <!--                        ..................................-->
        <!--                        सनाखत गराई पेश गर्ने-->
        <!--                    </div>-->
        <!--                    <div class="col-md-4" style="mar">-->
        <!--                        ...............................-->
        <!--                        सिफारिस गर्ने-->
        <!--                    </div>-->
        <!--                    <div class="col-md-4">-->
        <!--                        ................................-->
        <!--                        सदर गर्ने-->
        <!--                    </div>-->
        <!--</div>-->
        <!--</div>-->
</div>
