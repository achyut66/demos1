<section class="content ">

        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                </div>
            </div>
        </div>



            <div class="container-fluid ">
                <nav aria-label="breadcrumb" class="bg-shadow">
                    <ol class="breadcrumb px-3 py-2">
                        <li class="breadcrumb-item ml-1"><a href="<?= base_url()?>dashboard">गृह</a></li>

                            <li class="breadcrumb-item active">सम्पत्ति सम्बन्धित</li>

                    </ol>
                </nav>
            </div>





    <div class="container-fluid font-kalimati">
        <div class="row">
            <div class="col-12">

                <div class="dainik-prashasan ">


                    <div class="row">

                            <div class="col-lg-3 col-6 mb-4">
                                <!-- small box -->
                                <div class="small-box bg-alt-yellow">
                                    <a href="<?= base_url()?>income-verification">
                                        <div class="inner text-center ">
                                            <h5>वार्षिक आय प्रमाणिकरण<br>(<?php echo $income_verification?>)</h5>
                                        </div>
                                    </a>
                                    <a href="<?= base_url()?>income-verification" class="small-box-footer">अगाडी बढ्नुहोस <i
                                            class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>

                            <div class="col-lg-3 col-6 mb-4">
                                <!-- small box -->
                                <div class="small-box bg-alt-yellow">
                                    <a href="<?= base_url()?>property-valuation">
                                        <div class="inner text-center ">
                                            <h5>सम्पत्ति मूल्यांकन<br>(<?php echo $property_valuation?>)</h5>
                                        </div>
                                    </a>
                                    <a href="<?= base_url()?>property-valuation" class="small-box-footer">अगाडी बढ्नुहोस <i
                                            class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                            <div class="col-lg-3 col-6 mb-4">
                                <!-- small box -->
                                <div class="small-box bg-alt-yellow">
                                    <a href="<?= base_url()?>tax-clearance">
                                        <div class="inner text-center ">
                                            <h5>कर सम्बन्धि प्रमाणपत्र<br>(<?php echo $tax_clearance?>)</h5>
                                        </div>
                                    </a>
                                    <a href="<?= base_url()?>tax-clearance" class="small-box-footer">अगाडी बढ्नुहोस <i
                                            class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>

                    </div>
                </div>

            </div>
        </div>
    </div>


    </section>
</div>
