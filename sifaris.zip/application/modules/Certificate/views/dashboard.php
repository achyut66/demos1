<section class="content ">

        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="django-messages">

                    </div>
                </div>
            </div>
        </div>



            <div class="container-fluid ">
                <nav aria-label="breadcrumb" class="bg-shadow">
                    <ol class="breadcrumb px-3 py-2">
                        <li class="breadcrumb-item ml-1"><a href="<?=  base_url()?>dashboard">गृह</a></li>

    <li class="breadcrumb-item active">नागरिकता सम्बन्धित</li>

                    </ol>
                </nav>
            </div>





    <div class="container-fluid font-kalimati">
        <div class="row">
            <div class="col-12">

                <div class="dainik-prashasan ">


                    <div class="row">
							<div class="col-lg-3 col-6 mb-4">
                                <!-- small box -->
                                <div class="small-box bg-brown">
                                    <a href="<?=  base_url()?>citizenship-sifaris">
                                        <div class="inner text-center ">
                                            <h5>नागरिकता सिफारिस<br>(<?php echo $citizenship_sifaris?>)</h5>
                                        </div>
                                    </a>
                                    <a href="<?=  base_url()?>citizenship-sifaris" class="small-box-footer">अगाडी बढ्नुहोस <i
                                            class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                            <div class="col-lg-3 col-6 mb-4">
                                <!-- small box -->
                                <div class="small-box bg-brown">
                                    <a href="<?=  base_url()?>citizenship-certificate">
                                        <div class="inner text-center ">
                                            <h5>नागरिकता प्रमाण पत्र <br>(<?php echo $citizenship_certificate?>)</h5>
                                        </div>
                                    </a>
                                    <a href="<?=  base_url()?>citizenship-certificate" class="small-box-footer">अगाडी बढ्नुहोस <i
                                            class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>

                            <div class="col-lg-3 col-6 mb-4">
                                <!-- small box -->
                                <div class="small-box bg-brown">
                                    <a href="<?=  base_url()?>citizenship-certificate-pratilipi">
                                        <div class="inner text-center ">
                                            <h5>नागरिकता प्रमाण पत्रको प्रतिलिपि<br>(<?php echo $citizenship_certificate_pratilipi?>)</h5>
                                        </div>
                                    </a>
                                    <a href="<?=  base_url()?>citizenship-certificate-pratilipi" class="small-box-footer">अगाडी बढ्नुहोस <i
                                            class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>

                    </div>
                </div>

            </div>
        </div>
    </div>


    </section>
</div>
