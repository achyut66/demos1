<section class="content ">

        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="django-messages">

                    </div>
                </div>
            </div>
        </div>



            <div class="container-fluid ">
                <nav aria-label="breadcrumb" class="bg-shadow">
                    <ol class="breadcrumb px-3 py-2">
                        <li class="breadcrumb-item ml-1"><a href="<?=  base_url()?>dashboard">गृह</a></li>

    <li class="breadcrumb-item active">जग्गा सम्बन्धित</li>

                    </ol>
                </nav>
            </div>





    <div class="container-fluid font-kalimati">
        <div class="row">
            <div class="col-12">

                <div class="dainik-prashasan ">


                    <div class="row">

                            <div class="col-lg-3 col-6 mb-4">
                                <!-- small box -->
                                <div class="small-box bg-alt-red">
                                    <a href="<?=base_url()?>lalpurja-pratilipi">
                                        <div class="inner text-center ">
                                            <h5>जग्गाधनी लाल पुर्जा प्रतिलिपि <br>(<?php echo $lalpurja_pratilipi?>)</h5>
                                        </div>
                                    </a>
                                    <a href="lalpurja-pratilipi" class="small-box-footer">अगाडी बढ्नुहोस <i
                                            class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>

                            <div class="col-lg-3 col-6 mb-4">
                                <!-- small box -->
                                <div class="small-box bg-alt-red">
                                    <a href="<?=  base_url()?>bato-kayam">
                                        <div class="inner text-center ">
                                            <h5>बाटो कायम <br>(<?php echo $bato_kayam?>)</h5>
                                        </div>
                                    </a>
                                    <a href="<?=  base_url()?>bato-kayam" class="small-box-footer">अगाडी बढ्नुहोस <i
                                            class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>

                            <div class="col-lg-3 col-6 mb-4">
                                <!-- small box -->
                                <div class="small-box bg-alt-red">
                                    <a href="<?=  base_url()?>purjama-ghar-kayam">
                                        <div class="inner text-center ">
                                            <h5>जग्गाधनी पुर्जामा घर कायम <br>(<?php echo $purjama_ghar_kayam?>)</h5>
                                        </div>
                                    </a>
                                    <a href="<?=  base_url()?>purjama-ghar-kayam" class="small-box-footer">अगाडी बढ्नुहोस <i
                                            class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>

                            <div class="col-lg-3 col-6 mb-4">
                                <!-- small box -->
                                <div class="small-box bg-alt-red">
                                    <a href="<?=  base_url()?>char-killa">
                                        <div class="inner text-center ">
                                            <h5>चार किल्ला प्रमाणित <br>(<?php echo $char_killa?>)</h5>
                                        </div>
                                    </a>
                                    <a href="<?=  base_url()?>char-killa" class="small-box-footer">अगाडी बढ्नुहोस <i
                                            class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>

                            <div class="col-lg-3 col-6 mb-4">
                                <!-- small box -->
                                <div class="small-box bg-alt-red">
                                    <a href="<?=  base_url()?>mohi-lagat-katta">
                                        <div class="inner text-center ">
                                            <h5>मोही लागत कट्टा <br>(<?php echo $mohi_lagat_katta?>)</h5>
                                        </div>
                                    </a>
                                    <a href="<?=  base_url()?>mohi-lagat-katta" class="small-box-footer">अगाडी बढ्नुहोस <i
                                            class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>

                    </div>
                </div>

            </div>
        </div>
    </div>


    </section>
</div>
