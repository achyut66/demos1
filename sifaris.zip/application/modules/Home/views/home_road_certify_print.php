<?php
    $local_body     = Modules::run("Settings/getLocal",$result->local_body);
    $state          = Modules::run("Settings/getState",$result->state);
    $ward           = Modules::run("Settings/getWard",$result->ward);
    $district       = Modules::run("Settings/getDistrict",$result->district);
    $office         = Modules::run("Settings/getOffice",$result->office);
    if(!empty($result->document))
    {
        $documents      = explode("+",$result->document);

    }
    $path           = base_url()."assets/documents/home/road/";
    $current_session    = Modules::run('Settings/getCurrentSession',$result->session_id);
    $worker_post        = Modules::run('Settings/getPost',$ward_worker->post_id);
    $this_office   = Modules::run('Settings/getOffice', $print_office->id);
?>
<!--<style>-->
<!--    .head {-->
<!--        border:2px solid black;-->
<!--    }-->
<!--    .body {-->
<!--        border:2px solid black;-->
<!--    }-->
<!--    .tr1 {-->
<!--        border:2px solid black;-->
<!--    }-->
<!--</style>-->
<div class="letter_print">
    <hr>
    <div class="row">
        <div class="col-3 letter-head-left">
            <p style="font-size:18px;"><span class="red"> पत्र संख्या: </span> <?= $current_session->name ?><br></p>
            <p style="font-size:18px;"><span class="red"> चलानी नं.:  </span> <?php echo !empty($chalani_no)?$chalani_no:'चलानी गरिएको छैन' ?></p>
        </div>
        <div class="col-3 text-right letter-head-right" style="margin-left: 605px">
            <div class="myclear"> </div>
             <p style="font-size:18px; margin-top: -39px;"><span class="red"> मिति : </span> <?= $chalani_result->nepali_chalani_miti?></p>
        </div>
    </div>
    <div class="col-md-4">
        <?php
            $this_office   = Modules::run('Settings/getOffice', $print_office->id);
        ?>
        <div class='row'>
            <p style="font-size:18px; margin-top: 30px;"><?= !empty($this_office->sambodhan) ? $this_office->sambodhan : ''?></p>
        </div>
        <div class="row">
           <p style="font-size:18px;"> <?= $this_office->name?></p>
        </div>
        <div class="row">
           <p style="font-size:18px;"> <?= !empty($this_office->address) ? $this_office->address : ''?></p>
        </div>
    </div>
   
    <div class="text-center my-4 py-2 mt-5">
       <p style="font-size:26px;"><span class="red">बिषय:<u></span> : घरबाटो प्रमाणित ।</u></p>
    </div>
    <div style="margin-top: -18px;">
        <p class="text-body" style="font-size: 18px; text-align: justify;">
          प्रस्तुत बिषयमा  <b><?= $local_body->name ?></b>
                                   वडा नं <b><?= getonlyNumber($result->ward)?>
                                   </b> मा पर्ने निम्न कित्ता जग्गाको हालको मितिसम्ममा निम्न अनुसारको  घरबाटो रहेकोले सोही व्यहोरा खुलाई सिफारिस पाउँ भनी <b>
                                       <?php echo SITE_DISTRICT?></b> जिल्ला <b><?php echo SITE_OFFICE ?></b> वडा नं. <b><?= getonlyNumber($result->ward)?>
                                       </b> निवासी <?=$result->gender_spec?> <?= $result->applicant_name?></b>ले यस वडा कार्यालयमा दिनुभएको निवेदन अनुसार निम्न कित्ता जग्गाको हालको मितिसम्ममा निम्न अनुसारको घरबाटोको विवरण रहेको व्यहोरा सिफारिसका साथ अनुरोध गरिन्छ ।
                                </p>
    </div>
   
    <div class="text-center my-3 pt-3">
         <p style="font-size: 22px;">तपशिल</p>
    </div>

    <div class="table-responsive text-center" style="font-size: 20px;">
                            <table class="table table-bordered mybordertable table-sm letter-table">
                                <thead>
                                <tr>
                                    <td rowspan="2" style="width: 15%;">साबिक गा बि स / न पा</td>
                                    <td rowspan="2" style="width: 15%;">हाल गा बि स / न पा</td>
                                    <td colspan="3" style="width: 15%;">जग्गाको विवरण</td>
                                    <td rowspan="2">घर</td>
                                    <td rowspan="2" style="width: 15%;"> घरको प्रकार</td>
                                    <td rowspan="2" style="width: 15%;">अनुमानित मुल्य</td>
                                    <td rowspan="2" style="width: 15%;">बाटो</td>
                                    <td rowspan="2">बाटोको प्रकार</td>
                                    <td rowspan="2">कैफियत</td>
                                </tr>
                                <tr>
                                    <td>नक्सा सिट नं</td>
                                    <td>कि.नं</td>
                                    <td>क्षेत्रफल</td>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                    foreach($land_details as $details)
                                    {
                                        $old_new_address    = $this->Mdl_oldnew_address->getById($details->old_new_address);
                                        if($details->home == 1)
                                        {
                                            $home       = "भएको";
                                            $home_type      = $this->Mdl_home_type->getById($details->home_type);
                                        }
                                        else
                                        {
                                            $home       = "नभएको";
                                        }

                                        if($details->road == 1)
                                        {
                                            $road       = "भएको";
                                            $road_type      = $this->Mdl_road_type->getById($details->road_type);
                                        }
                                        else
                                        {
                                            $road       = "नभएको";
                                        }

                                        if(empty($details->description))
                                        {
                                            $description    = "-";
                                        }
                                        else
                                        {
                                            $description    = $details->description;
                                        }
                                ?>
                                    <tr class="tr1">
                                        <td>
                                            <?= $old_new_address->name ?>
                                        </td>
                                        <td>
                                            <?= $old_new_address->new_name?>
                                        </td>
                                        <td>
                                            <?= $details->map_sheet_no ?>
                                        </td>
                                        <td>
                                            <?= $details->kitta_no ?>
                                        </td>
                                        <td>
                                            <?= $details->biggha."-".$details->kattha."-".$details->dhur .'-'. $details->paisa?>
                                        </td>
                                        <td>
                                            <?= $home ?>
                                        </td>
                                        <td>
                                            <?= $details->home == 1 ? $home_type->name : "-" ?>
                                        </td>
                                        <td>
                                            <?= $details->home == 1 ? $details->estimated_cost : "-" ?>
                                        </td>
                                        <td>
                                            <?= $road ?>
                                        </td>
                                        <td>
                                            <?= $details->road == 1 ? $road_type->name : "-"?>
                                        </td>
                                        <td>
                                            <?= $description ?>
                                        </td>
                                    </tr>
                                <?php
                                    }
                                ?>
                                </tbody>
                            </table>
                        </div>
    <div class="space4"></div>
    <div class="row" style="font-size:20px;">
        <div class="col-3 offset-9">
            <div class="signature">
                <?= $ward_worker->name?><br />
                <?php if(!empty($department)) {
                    echo $department->name;
                } else { ?>
                     <?= $worker_post->name?>
                <?php  } ?>
               
            </div>
        </div>
    </div>
</div>